## Scope

Apply ONE consistent premium design language across every existing module — no logic, routing, hooks, API, or feature changes. Only presentation.

Modules touched (UI only):
Dashboard/Home · Sales · POS · Products · Production · Inventory · Finance · Attendance · Payroll · Payroll Settlement · Analytics · Accounts · Settings.

## Approach — centralize, don't rewrite every page

Instead of manually restyling 60+ page files, I'll upgrade the shared surfaces so every page inherits the new look for free, then do targeted polish passes on the highest-traffic pages.

### 1. Design tokens (`src/styles.css`)
- Refine the warm maroon / cream / gold palette: luxury red primary, warm cream bg, pure white cards, soft orange accent, success green, info blue, analytics purple — all as semantic tokens.
- Radius scale anchored on **20px** for cards, 12px for controls.
- Spacing rhythm on **8px** grid, **24px** card padding utility.
- Typography scale: Page 28px · Section 20–22px · KPI numbers 36–42px · Body 15–16px · Description 14px · Label 12px. Applied via base styles + a small set of `.text-page-title`, `.text-section-title`, `.text-kpi` utilities.
- Soft elevation tokens: `--shadow-sm`, `--shadow-card`, `--shadow-elevated`, `--shadow-brand`.
- Motion tokens: 150–200ms ease-out for hover, lift, fade.

### 2. Shared shadcn primitives
Upgrade in place (no API change) so every consumer inherits:
- `Card` — 20px radius, 24px padding, soft border, hover lift.
- `Button` — primary luxury red, secondary white, ghost, danger, icon; consistent height/radius.
- `Input`, `Select`, `Textarea`, `Label` — unified rounded controls, focus ring, validation states.
- `Table` — rounded container, sticky header, soft zebra + row hover, comfortable spacing.
- `Badge`, `Skeleton`, `Separator`, `Tabs`, `Dialog`, `Sheet` — visual polish only.

### 3. Global chrome — `src/components/app/app-shell.tsx` + `app-sidebar.tsx`
- **Sidebar** rebuilt as premium branded rail:
  - Luxury dark maroon gradient
  - Large logo + "Risol Yuk!" wordmark + version chip
  - Rounded nav items with elegant hover; active item = filled red with gold accent bar
  - Collapsible groups
  - Two decorative botanical/risol illustrations (SVG, generated) positioned subtly — never overused
  - Bottom user profile card with avatar, name, role
- **Top header** replaced globally:
  - Left: dynamic greeting `Selamat datang kembali, {firstName} 👋` + contextual subtitle mapped from current pathname (Dashboard/Products/Inventory/... copy per spec)
  - Right: current date · "Outlet Utama" chip · notification bell
  - No breadcrumbs anywhere.
- Page subtitle map lives in a small `src/lib/page-meta.ts` (pure lookup, not a hook, not routing).

### 4. Shared page primitives
Extend the existing `src/features/finance/_shared.tsx` pattern into a project-wide `src/components/app/page-primitives.tsx`:
- `PageHeader`, `SectionTitle`, `KpiCard`, `EmptyState`, `LoadingSkeleton` (table/card/chart variants), `FilterBar`.
- Every module already uses similar local versions — I'll re-export a unified set and swap the finance-local one to re-export from the shared one so styling converges without hunting through every file.

### 5. Targeted page polish
After shared surfaces land, do a focused visual pass on:
- Sales Home (already redesigned — align to new tokens)
- POS
- Dashboard/Finance overview
- Inventory items list
- Products list
- One representative Analytics page
This validates the system end-to-end. Other pages inherit automatically from Card/Table/Button/Input upgrades.

### 6. States
- Skeletons replace spinners in the shared Loading primitive.
- Empty states get illustration + explanation + primary CTA via the shared `EmptyState`.

### 7. Assets
Generate two soft botanical/risol PNGs for the sidebar decoration via imagegen (transparent PNG, low-opacity placement).

## Out of scope
- No new routes, no renamed menus, no changed navigation flow.
- No business logic, service, hook, or API edits.
- No dark-mode overhaul (tokens updated, but not a new theme).
- No per-page redesign beyond the 6 validation pages — the rest inherit.

## Verification
- `tsgo` typecheck after each batch.
- Playwright screenshot of Sales Home, POS, Inventory, Finance dashboard to confirm the new language lands consistently.

## Deliverable order
1. Tokens in `styles.css` + shared primitives upgrade (Card/Button/Input/Table/Badge).
2. New `AppSidebar` + `AppShell` header with greeting + subtitle map + decorative assets.
3. Shared `page-primitives.tsx`; converge finance `_shared.tsx` to re-export.
4. Visual polish pass on the 6 validation pages.
5. Typecheck + screenshot verification.

Shall I proceed?
