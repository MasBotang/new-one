import { useEffect, useMemo, useState } from "react";
import { getRouteApi, useNavigate } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { salesService } from "@/services/sales.service";
import { queueService, QUEUE_STATUS_LABEL, type QueueOrder } from "@/services/queue.service";
import { refundService, REFUND_STATUS_LABEL, type RefundRequest } from "@/services/refund.service";
import { preorderService } from "@/services/preorder.service";
import { whatsappService } from "@/services/whatsapp.service";
import { SOURCE_ORDER_LABEL, SOURCE_ORDER_LIST, type Sale, type SourceOrder } from "@/services/types";
import { useRole } from "@/lib/role-context";
import { formatIDR, formatDateTime } from "@/lib/format";
import { printSaleReceipt } from "@/features/pos/invoice-receipt";
import { CheckCircle2, Clock, ListChecks, MessageCircle, Play, Printer, RotateCcw, XCircle } from "lucide-react";
import { PreorderPanel } from "./preorder-page";

const pesananRouteApi = getRouteApi("/_app/sales/pesanan");

type OuterTab = "pesanan" | "preorder";

type PesananStatus = "baru" | "diproses" | "selesai" | "refund";

interface UnifiedOrder {
  sale: Sale;
  queue?: QueueOrder;
  refund?: RefundRequest;
  status: PesananStatus;
}

const STATUS_LABEL: Record<PesananStatus, string> = {
  baru: "Baru",
  diproses: "Diproses",
  selesai: "Selesai",
  refund: "Refund",
};

const STATUS_PILL: Record<PesananStatus, string> = {
  baru: "bg-sky-50 text-sky-700 border-sky-200",
  diproses: "bg-amber-50 text-amber-800 border-amber-200",
  selesai: "bg-emerald-50 text-emerald-700 border-emerald-200",
  refund: "bg-rose-50 text-rose-700 border-rose-200",
};

const STATUS_ACCENT: Record<PesananStatus, string> = {
  baru: "before:bg-sky-400",
  diproses: "before:bg-amber-400",
  selesai: "before:bg-emerald-400",
  refund: "before:bg-rose-400",
};

const STATUS_DOT: Record<PesananStatus, string> = {
  baru: "bg-sky-500",
  diproses: "bg-amber-500",
  selesai: "bg-emerald-500",
  refund: "bg-rose-500",
};

function deriveStatus(sale: Sale, queue: QueueOrder | undefined, refund: RefundRequest | undefined): PesananStatus {
  if (sale.voided || refund?.status === "approved") return "refund";
  if (!queue) return "selesai"; // sale tanpa queue (misal preorder belum aktif)
  if (queue.status === "waiting") return "baru";
  if (queue.status === "completed") return "selesai";
  return "diproses";
}

function isSameDay(iso: string, day: string): boolean {
  if (!day) return true;
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}` === day;
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function PesananPage() {
  const { role, profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "Operator";
  const canApproveRefund = role === "owner" || role === "admin";
  const canRequestRefund = role === "cashier" || role === "admin" || role === "owner";

  // Outer tab (Pesanan vs Pre Order) disinkronkan dengan search param
  // supaya /sales/pesanan?tab=preorder — dan redirect dari /sales/preorder —
  // langsung membuka tab yang benar dan bookmarkable.
  const search = pesananRouteApi.useSearch();
  const navigate = useNavigate({ from: "/sales/pesanan" });
  const outerTab: OuterTab = search.tab === "preorder" ? "preorder" : "pesanan";
  const setOuterTab = (next: OuterTab) => {
    navigate({
      search: (prev: { tab?: OuterTab }) => ({
        ...prev,
        tab: next === "preorder" ? "preorder" : undefined,
      }),
      replace: true,
    });
  };

  const [rows, setRows] = useState<UnifiedOrder[]>([]);
  const [tab, setTab] = useState<PesananStatus | "all">("all");
  const [dateFilter, setDateFilter] = useState<string>(todayKey());
  const [marketplaceFilter, setMarketplaceFilter] = useState<string>("all");
  const [outletFilter, setOutletFilter] = useState<string>("all");
  const [kasirFilter, setKasirFilter] = useState<string>("all");

  // Badge jumlah Pre Order aktif (scheduled + ready_to_process) — dipindahkan
  // dari sidebar. Refresh saat event preorder berubah.
  const [preorderBadge, setPreorderBadge] = useState(0);
  useEffect(() => {
    const compute = () => {
      try {
        setPreorderBadge(preorderService.countActive());
      } catch {
        setPreorderBadge(0);
      }
    };
    compute();
    const onChanged = () => compute();
    window.addEventListener("desalut:preorders-changed", onChanged);
    const iv = setInterval(compute, 30_000);
    return () => {
      window.removeEventListener("desalut:preorders-changed", onChanged);
      clearInterval(iv);
    };
  }, []);

  const [detail, setDetail] = useState<UnifiedOrder | null>(null);
  const [refundOpen, setRefundOpen] = useState(false);
  const [refundReason, setRefundReason] = useState("");
  const [approveTarget, setApproveTarget] = useState<RefundRequest | null>(null);
  const [approveNote, setApproveNote] = useState("");

  function refresh() {
    const sales = salesService.list();
    const queues = queueService.list();
    const queueBySale = new Map(queues.map((q) => [q.saleId, q]));
    const refunds = refundService.list();
    const refundBySale = new Map<string, RefundRequest>();
    for (const r of refunds) {
      const existing = refundBySale.get(r.saleId);
      if (!existing || new Date(r.requestedAt) > new Date(existing.requestedAt)) {
        refundBySale.set(r.saleId, r);
      }
    }
    const unified: UnifiedOrder[] = sales.map((sale) => {
      const queue = queueBySale.get(sale.id);
      const refund = refundBySale.get(sale.id);
      return { sale, queue, refund, status: deriveStatus(sale, queue, refund) };
    });
    setRows(unified);
  }

  useEffect(() => {
    refresh();
    const iv = setInterval(refresh, 8000);
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(iv);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  const kasirOptions = useMemo(() => {
    const set = new Set<string>();
    for (const r of rows) set.add(r.sale.cashier);
    return Array.from(set);
  }, [rows]);

  const outletOptions = useMemo(() => {
    const set = new Set<string>();
    for (const r of rows) if (r.sale.outletId) set.add(r.sale.outletId);
    return Array.from(set);
  }, [rows]);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (tab !== "all" && r.status !== tab) return false;
      if (!isSameDay(r.sale.createdAt, dateFilter)) return false;
      if (marketplaceFilter !== "all" && (r.sale.sourceOrder ?? "outlet") !== marketplaceFilter) return false;
      if (outletFilter !== "all" && r.sale.outletId !== outletFilter) return false;
      if (kasirFilter !== "all" && r.sale.cashier !== kasirFilter) return false;
      return true;
    });
  }, [rows, tab, dateFilter, marketplaceFilter, outletFilter, kasirFilter]);

  const counts = useMemo(() => {
    const c: Record<PesananStatus | "all", number> = {
      all: 0,
      baru: 0,
      diproses: 0,
      selesai: 0,
      refund: 0,
    };
    for (const r of rows) {
      if (!isSameDay(r.sale.createdAt, dateFilter)) continue;
      if (marketplaceFilter !== "all" && (r.sale.sourceOrder ?? "outlet") !== marketplaceFilter) continue;
      if (outletFilter !== "all" && r.sale.outletId !== outletFilter) continue;
      if (kasirFilter !== "all" && r.sale.cashier !== kasirFilter) continue;
      c.all++;
      c[r.status]++;
    }
    return c;
  }, [rows, dateFilter, marketplaceFilter, outletFilter, kasirFilter]);

  function openRefund(o: UnifiedOrder) {
    setDetail(o);
    setRefundReason("");
    setRefundOpen(true);
  }

  // Sprint 1 (H-3 + BRD Kanban): kasir bisa lanjutkan status antrean.
  function advanceQueue(o: UnifiedOrder) {
    if (!o.queue) {
      toast.error("Antrean produksi tidak ditemukan");
      return;
    }
    const before = o.queue.status;
    const next = queueService.advance(o.queue.id, actor);
    if (!next || next.status === before) {
      toast.info("Status sudah final");
      return;
    }
    toast.success(`Status: ${QUEUE_STATUS_LABEL[before]} → ${QUEUE_STATUS_LABEL[next.status]}`);
    refresh();
    // Otomatis buka WA saat status berpindah ke Ready / Completed.
    const tpl = whatsappService.templateForQueueStatus(next.status);
    if (tpl && o.sale.customerName) {
      const link = whatsappService.buildLink(tpl, {
        phone: (o.sale as { customerPhone?: string }).customerPhone,
        customerName: o.sale.customerName,
        orderNumber: o.sale.orderNumber,
        actor,
        entity: "sale",
        entityId: o.sale.id,
      });
      if ("url" in link) {
        window.open(link.url, "_blank", "noopener");
      }
    }
  }

  // Kirim WA manual (mis. ulang notif setelah status ready, atau void/refund).
  function sendWhatsApp(o: UnifiedOrder) {
    let tpl: ReturnType<typeof whatsappService.templateForQueueStatus> | "void" | "refund" | null =
      o.queue ? whatsappService.templateForQueueStatus(o.queue.status) : null;
    let extra: { total?: number } = {};
    if (!tpl) {
      if (o.refund?.status === "approved") {
        tpl = "refund";
        extra.total = o.sale.total;
      } else if (o.sale.voided) {
        tpl = "void";
      }
    }
    if (!tpl) {
      toast.error("Notifikasi WA baru bisa dikirim saat status Siap/Selesai/Void/Refund");
      return;
    }
    const link = whatsappService.buildLink(tpl, {
      phone: (o.sale as { customerPhone?: string }).customerPhone,
      customerName: o.sale.customerName,
      orderNumber: o.sale.orderNumber,
      actor,
      entity: "sale",
      entityId: o.sale.id,
      ...extra,
    });
    if ("error" in link) {
      toast.error(link.error);
      return;
    }
    window.open(link.url, "_blank", "noopener");
  }


  function submitRefundRequest() {
    if (!detail) return;
    if (!refundReason.trim()) {
      toast.error("Isi alasan refund");
      return;
    }
    refundService.request({
      saleId: detail.sale.id,
      reason: refundReason.trim(),
      actor,
      actorRole: role ?? undefined,
    });
    toast.success("Pengajuan refund dikirim, menunggu approval Owner");
    setRefundOpen(false);
    setDetail(null);
    refresh();
  }

  function approveRefund() {
    if (!approveTarget) return;
    const result = refundService.approve(approveTarget.id, {
      actor,
      actorRole: role ?? undefined,
      note: approveNote.trim() || undefined,
    });
    if (!result.ok) {
      toast.error(result.reason);
      setApproveTarget(null);
      setApproveNote("");
      refresh();
      return;
    }
    toast.success("Refund disetujui — stok, antrean, dan packaging dikembalikan");
    // Auto WA refund notification bila customer punya nomor HP.
    const sale = salesService.list().find((s) => s.id === approveTarget.saleId);
    if (sale && (sale as { customerPhone?: string }).customerPhone) {
      const link = whatsappService.buildLink("refund", {
        phone: (sale as { customerPhone?: string }).customerPhone,
        customerName: sale.customerName,
        orderNumber: sale.orderNumber,
        total: sale.total,
        actor,
        entity: "sale",
        entityId: sale.id,
      });
      if ("url" in link) window.open(link.url, "_blank", "noopener");
    }
    setApproveTarget(null);
    setApproveNote("");
    refresh();
  }


  function rejectRefund() {
    if (!approveTarget) return;
    refundService.reject(approveTarget.id, {
      actor,
      actorRole: role ?? undefined,
      note: approveNote.trim() || undefined,
    });
    toast.success("Pengajuan refund ditolak");
    setApproveTarget(null);
    setApproveNote("");
    refresh();
  }

  function reprint(o: UnifiedOrder) {
    // Reprint memakai renderer invoice canonical yang sama dengan checkout POS
    // sehingga packing detail, extra packaging, customer, notes, dan payment
    // tampil identik.
    if (!printSaleReceipt(o.sale)) {
      toast.error("Popup diblokir browser");
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6 md:p-8">
      {/* Page hero */}
      <header className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-6 items-center gap-1.5 rounded-full border border-primary/20 bg-primary/5 px-2.5 text-[11px] font-medium uppercase tracking-wider text-primary">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              Sales · Pesanan
            </span>
          </div>
          <h1 className="text-[28px] font-semibold leading-tight tracking-tight text-foreground">
            Pusat Pesanan
          </h1>
          <p className="text-sm text-muted-foreground">
            Seluruh aktivitas order hari ini — reguler dan Pre Order — dalam satu ruang kerja.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {(["all", "baru", "diproses", "selesai", "refund"] as const).map((k) => {
            const label = k === "all" ? "Semua" : STATUS_LABEL[k as PesananStatus];
            const count = counts[k];
            return (
              <div
                key={k}
                className="flex items-center gap-2 rounded-full border border-border/60 bg-card px-3 py-1.5 text-xs shadow-sm"
              >
                {k !== "all" && (
                  <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[k as PesananStatus]}`} />
                )}
                <span className="text-muted-foreground">{label}</span>
                <span className="tabular-nums font-semibold text-foreground">{count}</span>
              </div>
            );
          })}
        </div>
      </header>

      {/* Outer tabs — Pesanan vs Pre Order */}
      <Tabs value={outerTab} onValueChange={(v) => setOuterTab(v as OuterTab)}>
        <TabsList className="h-10 rounded-full bg-muted/60 p-1">
          <TabsTrigger value="pesanan" className="rounded-full px-4">Pesanan</TabsTrigger>
          <TabsTrigger value="preorder" className="rounded-full px-4">
            Pre Order
            {preorderBadge > 0 && (
              <Badge className="ml-2 h-5 px-1.5 text-[10px] tabular-nums">
                {preorderBadge}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {outerTab === "preorder" ? (
        <PreorderPanel />
      ) : (
        <>
          {/* Filter Bar */}
          <Card className="overflow-hidden">
            <CardContent className="grid gap-3 p-4 md:grid-cols-5 md:p-5">
              <div className="flex flex-col gap-1">
                <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">Tanggal</Label>
                <Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} className="h-9" />
              </div>
              <div className="flex flex-col gap-1">
                <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">Outlet</Label>
                <Select value={outletFilter} onValueChange={setOutletFilter}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Outlet</SelectItem>
                    {outletOptions.map((o) => (
                      <SelectItem key={o} value={o}>{o}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1">
                <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">Marketplace</Label>
                <Select value={marketplaceFilter} onValueChange={setMarketplaceFilter}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Sumber</SelectItem>
                    {SOURCE_ORDER_LIST.map((s) => (
                      <SelectItem key={s} value={s}>{SOURCE_ORDER_LABEL[s]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1">
                <Label className="text-[11px] uppercase tracking-wider text-muted-foreground">Kasir</Label>
                <Select value={kasirFilter} onValueChange={setKasirFilter}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Kasir</SelectItem>
                    {kasirOptions.map((k) => (
                      <SelectItem key={k} value={k}>{k}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  className="h-9 w-full"
                  onClick={() => {
                    setDateFilter(todayKey());
                    setMarketplaceFilter("all");
                    setOutletFilter("all");
                    setKasirFilter("all");
                  }}
                >
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Status Tabs */}
          <Tabs value={tab} onValueChange={(v) => setTab(v as PesananStatus | "all")}>
            <TabsList className="flex h-11 flex-wrap gap-1 rounded-xl bg-muted/50 p-1">
              <TabsTrigger value="all" className="rounded-lg px-3.5 text-sm">
                Semua <Badge variant="outline" className="ml-2 tabular-nums">{counts.all}</Badge>
              </TabsTrigger>
              <TabsTrigger value="baru" className="rounded-lg px-3.5 text-sm">
                <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-sky-500" />
                Baru <Badge variant="outline" className="ml-2 tabular-nums">{counts.baru}</Badge>
              </TabsTrigger>
              <TabsTrigger value="diproses" className="rounded-lg px-3.5 text-sm">
                <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-amber-500" />
                Diproses <Badge variant="outline" className="ml-2 tabular-nums">{counts.diproses}</Badge>
              </TabsTrigger>
              <TabsTrigger value="selesai" className="rounded-lg px-3.5 text-sm">
                <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-emerald-500" />
                Selesai <Badge variant="outline" className="ml-2 tabular-nums">{counts.selesai}</Badge>
              </TabsTrigger>
              <TabsTrigger value="refund" className="rounded-lg px-3.5 text-sm">
                <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-rose-500" />
                Refund <Badge variant="outline" className="ml-2 tabular-nums">{counts.refund}</Badge>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Order List */}
          <div className="flex flex-col gap-2.5">
            {filtered.length === 0 && (
              <Card className="border-dashed">
                <CardContent className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                    <ListChecks className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="text-base font-semibold">Belum ada pesanan</div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Tidak ada pesanan pada filter ini. Coba ubah tanggal atau reset filter.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
            {filtered.map((o) => (
              <Card
                key={o.sale.id}
                className={`relative overflow-hidden before:absolute before:inset-y-0 before:left-0 before:w-1 ${STATUS_ACCENT[o.status]}`}
              >
                <CardContent className="flex flex-col gap-3 py-4 pl-5 md:flex-row md:items-center md:justify-between">
                  <div className="flex min-w-0 flex-col gap-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-base font-bold tabular-nums text-foreground">
                        {o.sale.orderNumber ?? "—"}
                      </span>
                      <Badge variant="outline" className={`gap-1.5 ${STATUS_PILL[o.status]}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[o.status]}`} />
                        {STATUS_LABEL[o.status]}
                      </Badge>
                      {o.refund?.status === "pending" && (
                        <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-800">
                          Refund Pending
                        </Badge>
                      )}
                      <span className="font-mono text-[11px] text-muted-foreground/80">{o.sale.id}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                      <span>{formatDateTime(o.sale.createdAt)}</span>
                      <span className="text-border">·</span>
                      <span>{o.sale.cashier}</span>
                      <span className="text-border">·</span>
                      <span>{SOURCE_ORDER_LABEL[(o.sale.sourceOrder ?? "outlet") as SourceOrder]}</span>
                    </div>
                    <div className="flex flex-wrap items-baseline gap-x-3 text-sm">
                      <span className="font-medium text-foreground">{o.sale.customerName ?? "Tanpa nama"}</span>
                      <span className="text-muted-foreground">{o.sale.items.length} item</span>
                      <span className="tabular-nums font-semibold text-foreground">{formatIDR(o.sale.total)}</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <Button size="sm" variant="outline" onClick={() => setDetail(o)}>
                      Detail
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => reprint(o)}>
                      <Printer className="mr-1 h-3.5 w-3.5" /> Cetak
                    </Button>
                    {o.queue && o.queue.status !== "completed" && !o.sale.voided && (
                      <Button size="sm" onClick={() => advanceQueue(o)}>
                        <Play className="mr-1 h-3.5 w-3.5" />
                        Lanjut: {QUEUE_STATUS_LABEL[o.queue.status]}
                      </Button>
                    )}
                    {o.queue && (o.queue.status === "ready" || o.queue.status === "completed") && !o.sale.voided && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                        onClick={() => sendWhatsApp(o)}
                      >
                        <MessageCircle className="mr-1 h-3.5 w-3.5" /> WA
                      </Button>
                    )}
                    {(o.sale.voided || o.refund?.status === "approved") && (o.sale as { customerPhone?: string }).customerPhone && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-rose-300 text-rose-700 hover:bg-rose-50"
                        onClick={() => sendWhatsApp(o)}
                      >
                        <MessageCircle className="mr-1 h-3.5 w-3.5" />
                        WA {o.refund?.status === "approved" ? "Refund" : "Void"}
                      </Button>
                    )}
                    {canRequestRefund && !o.sale.voided && !o.refund && (
                      <Button size="sm" variant="outline" onClick={() => openRefund(o)}>
                        <RotateCcw className="mr-1 h-3.5 w-3.5" /> Refund
                      </Button>
                    )}
                    {canApproveRefund && o.refund?.status === "pending" && (
                      <Button size="sm" onClick={() => setApproveTarget(o.refund!)}>
                        Review Refund
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Detail Dialog — invoice layout */}
          <Dialog open={!!detail && !refundOpen} onOpenChange={(v) => !v && setDetail(null)}>
            <DialogContent className="max-w-xl">
              <DialogHeader>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={detail ? STATUS_PILL[detail.status] : ""}>
                    {detail && STATUS_LABEL[detail.status]}
                  </Badge>
                  <span className="font-mono text-xs text-muted-foreground">{detail?.sale.id}</span>
                </div>
                <DialogTitle className="text-xl">
                  {detail?.sale.orderNumber ?? "Detail Pesanan"}
                </DialogTitle>
                <DialogDescription>{detail && formatDateTime(detail.sale.createdAt)}</DialogDescription>
              </DialogHeader>
              {detail && (
                <div className="flex flex-col gap-4 text-sm">
                  <div className="grid grid-cols-2 gap-3 rounded-xl border border-border/60 bg-muted/30 p-4">
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Kasir</div>
                      <div className="font-medium">{detail.sale.cashier}</div>
                    </div>
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Customer</div>
                      <div className="font-medium">{detail.sale.customerName ?? "-"}</div>
                    </div>
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Sumber</div>
                      <div className="font-medium">{SOURCE_ORDER_LABEL[(detail.sale.sourceOrder ?? "outlet") as SourceOrder]}</div>
                    </div>
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Pembayaran</div>
                      <div className="font-medium capitalize">{detail.sale.payment}</div>
                    </div>
                  </div>

                  <div className="rounded-xl border border-border/60">
                    <div className="border-b border-border/60 px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                      Item
                    </div>
                    <ul className="divide-y divide-border/60">
                      {detail.sale.items.map((i, idx) => (
                        <li key={idx} className="flex justify-between px-4 py-2.5">
                          <span>
                            <span className="tabular-nums font-semibold text-primary">{i.qty}×</span>{" "}
                            {i.name}
                          </span>
                          <span className="tabular-nums">{formatIDR(i.price * i.qty)}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="flex justify-between border-t border-border/60 bg-muted/30 px-4 py-3">
                      <span className="font-semibold">Total</span>
                      <span className="tabular-nums text-lg font-bold text-primary">{formatIDR(detail.sale.total)}</span>
                    </div>
                  </div>

                  {detail.queue && (
                    <div className="rounded-xl border border-border/60 p-4">
                      <div className="mb-3 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                        <ListChecks className="h-3.5 w-3.5" /> Timeline Status
                      </div>
                      <ol className="relative space-y-3 border-l border-border/60 pl-4">
                        {detail.queue.timeline.map((t, i) => (
                          <li key={i} className="relative text-xs">
                            <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-background bg-primary" />
                            <div className="font-medium text-foreground">{QUEUE_STATUS_LABEL[t.status]}</div>
                            <div className="text-muted-foreground">
                              {formatDateTime(t.at)} {t.by && `· ${t.by}`}
                            </div>
                          </li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {detail.refund && (
                    <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-4 text-xs">
                      <div className="font-semibold text-amber-900">
                        Refund · {REFUND_STATUS_LABEL[detail.refund.status]}
                      </div>
                      <div className="mt-1 text-amber-900/90">Alasan: {detail.refund.reason}</div>
                      <div className="mt-1 text-amber-800/80">
                        Diajukan {formatDateTime(detail.refund.requestedAt)} oleh {detail.refund.requestedBy}
                      </div>
                      {detail.refund.decidedAt && (
                        <div className="text-amber-800/80">
                          Diputuskan {formatDateTime(detail.refund.decidedAt)} oleh {detail.refund.decidedBy}
                          {detail.refund.decisionNote ? ` · ${detail.refund.decisionNote}` : ""}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setDetail(null)}>Tutup</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Request Refund Dialog */}
          <Dialog open={refundOpen} onOpenChange={setRefundOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Ajukan Refund</DialogTitle>
                <DialogDescription>
                  Pengajuan akan ditinjau dan disetujui oleh Owner sebelum refund efektif.
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-2">
                <Label>Alasan</Label>
                <Textarea
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  placeholder="Contoh: Customer membatalkan pesanan"
                  rows={4}
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setRefundOpen(false)}>Batal</Button>
                <Button onClick={submitRefundRequest}>Kirim Pengajuan</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Approve Refund Dialog */}
          <Dialog open={!!approveTarget} onOpenChange={(v) => !v && setApproveTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Review Pengajuan Refund</DialogTitle>
                <DialogDescription>
                  Sale {approveTarget?.saleId} · Alasan: {approveTarget?.reason}
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-2">
                <Label>Catatan (opsional)</Label>
                <Textarea
                  value={approveNote}
                  onChange={(e) => setApproveNote(e.target.value)}
                  rows={3}
                />
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setApproveTarget(null)}>Tutup</Button>
                <Button variant="destructive" onClick={rejectRefund}>
                  <XCircle className="mr-1 h-4 w-4" /> Tolak
                </Button>
                <Button onClick={approveRefund}>
                  <CheckCircle2 className="mr-1 h-4 w-4" /> Setujui Refund
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      )}
    </div>
  );
}

