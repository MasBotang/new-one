import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Pencil,
  Plus,
  Trash2,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Lock,
} from "lucide-react";
import { shiftService, isShiftLocked } from "@/services/shift.service";
import { marketplaceSettlementService } from "@/services/marketplace-settlement.service";
import { inventoryService } from "@/services/inventory.service";
import { salesSummaryService } from "@/services/sales-summary.service";
import { useRole } from "@/lib/role-context";
import type {
  Shift,
  ShiftMarketplaceReconciliation,
  ShiftOperationalExpense,
  ShiftPaymentReconciliation,
  MarketplaceSource,
  PaymentBucket,
} from "@/services/types";
import { MARKETPLACE_SOURCES, SOURCE_ORDER_LABEL } from "@/services/types";
import { formatIDR, formatDateTime } from "@/lib/format";
import { toast } from "sonner";

function toLocalDatetimeInput(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalDatetimeInput(v: string): string {
  const d = new Date(v);
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}
function formatTime(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const PAYMENT_BUCKET_LABEL: Record<PaymentBucket, string> = {
  cash: "Cash",
  qris: "QRIS",
  transfer: "Transfer",
  marketplace: "Marketplace",
};

type AuditStatusLevel = "ok" | "warn" | "error";
interface AuditStatusItem {
  level: AuditStatusLevel;
  label: string;
}

export function ShiftsPage() {
  const { role, profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "Kasir";
  const canEditExpense = role === "admin" || role === "owner";
  const isReadOnly = role === "owner";
  const isCashier = role === "cashier";

  const [current, setCurrent] = useState<Shift | null>(null);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [opening, setOpening] = useState<number>(0);

  // Cash reconciliation
  const [closing, setClosing] = useState<number>(0);
  const [closingTouched, setClosingTouched] = useState(false);
  const [cashReason, setCashReason] = useState("");

  // Marketplace settlement inputs (per marketplace, in the closing dialog)
  const [settlementInputs, setSettlementInputs] = useState<
    Record<MarketplaceSource, { amount: string; notes: string }>
  >(() =>
    MARKETPLACE_SOURCES.reduce(
      (acc, m) => {
        acc[m] = { amount: "", notes: "" };
        return acc;
      },
      {} as Record<MarketplaceSource, { amount: string; notes: string }>,
    ),
  );

  // Detail & dialogs
  const [detail, setDetail] = useState<Shift | null>(null);
  const [expenseDialog, setExpenseDialog] = useState<
    { mode: "add" } | { mode: "edit"; entry: ShiftOperationalExpense; shiftId: string } | null
  >(null);
  const [confirmDelete, setConfirmDelete] =
    useState<{ shiftId: string; entry: ShiftOperationalExpense } | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);

  const opItems = useMemo(
    () => inventoryService.list().filter((i) => i.active && i.category === "operational"),
    [current?.id],
  );
  const pkgItems = useMemo(
    () => inventoryService.list().filter((i) => i.active && i.category === "packaging"),
    [current?.id],
  );

  function refresh() {
    setCurrent(shiftService.current());
    setShifts(shiftService.list());
  }
  useEffect(refresh, []);

  // SSoT: shift summary dari sales-summary.service
  const summary = useMemo(
    () => (current ? salesSummaryService.forShift(current.id) : null),
    [current?.id, shifts.length],
  );

  const totalOpExpense = current?.totalOperationalExpense ?? 0;
  const totalPackagingQty = current?.totalPackagingQty ?? 0;
  const packagingEverSaved = !!current?.packagingUsageSavedAt;

  const expectedCash = summary && current
    ? current.openingCash + summary.payments.cash - totalOpExpense
    : 0;
  const cashDifference = closing - expectedCash;

  // Rekonsiliasi marketplace berdasar input & totals sistem
  const marketplaceRecons: ShiftMarketplaceReconciliation[] = useMemo(() => {
    if (!summary) return [];
    return summary.marketplaces.map((m) => {
      const raw = settlementInputs[m.marketplace]?.amount ?? "";
      const notes = settlementInputs[m.marketplace]?.notes ?? "";
      const trimmed = raw.trim();
      const amount = trimmed === "" ? null : Number(trimmed.replace(/[^\d-]/g, ""));
      const settlementAmount = amount != null && Number.isFinite(amount) ? amount : null;
      return {
        marketplace: m.marketplace,
        systemTotal: m.total,
        systemOrders: m.orders,
        settlementAmount,
        difference: settlementAmount != null ? settlementAmount - m.total : 0,
        notes: notes.trim() || undefined,
      };
    });
  }, [summary, settlementInputs]);

  // Rekonsiliasi pembayaran (system-only untuk saat ini; kasir bisa cross-check)
  const paymentRecons: ShiftPaymentReconciliation[] = useMemo(() => {
    if (!summary) return [];
    const buckets: PaymentBucket[] = ["cash", "qris", "transfer", "marketplace"];
    return buckets.map((b) => ({
      bucket: b,
      systemTotal: summary.payments[b],
      // Actual cash sudah tercakup di Cash Audit; bucket lainnya read-only.
      actualTotal: b === "cash" ? closing : undefined,
      difference: b === "cash" ? closing - summary.payments.cash : undefined,
    }));
  }, [summary, closing]);

  // Status audit — jawaban ringkas "apakah semuanya sesuai?"
  const auditStatuses: AuditStatusItem[] = useMemo(() => {
    if (!summary) return [];
    const list: AuditStatusItem[] = [];

    // Cash
    if (!closingTouched) {
      list.push({ level: "warn", label: "Actual Cash belum diinput" });
    } else if (cashDifference === 0) {
      list.push({ level: "ok", label: "Cash sesuai" });
    } else if (cashDifference !== 0 && !cashReason.trim()) {
      list.push({
        level: "error",
        label: `Cash selisih ${formatIDR(cashDifference)} — alasan wajib`,
      });
    } else {
      list.push({
        level: "warn",
        label: `Cash selisih ${formatIDR(cashDifference)} (alasan tercatat)`,
      });
    }

    // Marketplace
    for (const r of marketplaceRecons) {
      const label = SOURCE_ORDER_LABEL[r.marketplace];
      if (r.systemTotal === 0 && r.settlementAmount == null) continue; // skip idle
      if (r.settlementAmount == null) {
        list.push({ level: "error", label: `${label} settlement belum diinput` });
      } else if (r.difference === 0) {
        list.push({ level: "ok", label: `${label} sesuai` });
      } else {
        list.push({
          level: "warn",
          label: `${label} selisih ${formatIDR(r.difference)}`,
        });
      }
    }

    // Pengeluaran operasional tanpa keterangan
    const opsMissingNote = (current?.operationalExpenses ?? []).filter(
      (e) => !e.notes || !e.notes.trim(),
    );
    if (opsMissingNote.length > 0) {
      list.push({
        level: "warn",
        label: `${opsMissingNote.length} pengeluaran operasional belum memiliki keterangan`,
      });
    }

    // Packaging
    if (!packagingEverSaved) {
      list.push({ level: "warn", label: "Pemakaian Packaging belum disimpan" });
    }

    return list;
  }, [
    summary,
    closingTouched,
    cashDifference,
    cashReason,
    marketplaceRecons,
    current?.operationalExpenses,
    packagingEverSaved,
  ]);

  const hasBlockingError = auditStatuses.some((s) => s.level === "error");

  function openShift() {
    if (opening < 0) return toast.error("Kas pembuka tidak valid");
    if (isReadOnly) return toast.error("Owner tidak dapat membuka shift");
    shiftService.open(actor, opening, role ?? undefined);
    toast.success("Shift dibuka");
    setOpening(0);
    refresh();
  }

  function doCloseShift() {
    if (!current || !summary) return;
    if (!closingTouched) return toast.error("Masukkan jumlah kas penutup (Actual Cash)");
    if (closing < 0) return toast.error("Kas penutup tidak valid");
    if (cashDifference !== 0 && !cashReason.trim())
      return toast.error("Alasan wajib diisi bila cash difference ≠ 0");

    // Blokir jika ada status error (contoh: marketplace settlement kosong sementara ada transaksi)
    const errorEntries = auditStatuses.filter((s) => s.level === "error");
    if (errorEntries.length > 0) {
      return toast.error(errorEntries[0].label);
    }

    // Sinkronkan input settlement ke marketplaceSettlementService supaya
    // Dashboard admin tetap konsisten (single source of truth di level data).
    const closeDateKey = (() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    })();
    for (const r of marketplaceRecons) {
      if (r.settlementAmount == null) continue;
      marketplaceSettlementService.upsert({
        date: closeDateKey,
        marketplace: r.marketplace,
        orderCount: r.systemOrders,
        grossSales: r.systemTotal,
        marketplaceFee: Math.max(0, r.systemTotal - r.settlementAmount),
        netReceived: r.settlementAmount,
        notes: r.notes,
        createdBy: actor,
      });
    }


    shiftService.close({
      closingCash: closing,
      expectedCash,
      cashDifferenceReason: cashDifference !== 0 ? cashReason.trim() : undefined,
      totalOrders: summary.totalOrders,
      totalRevenue: summary.totalRevenue,
      cashSales: summary.payments.cash,
      qrisSales: summary.payments.qris,
      transferSales: summary.payments.transfer,
      marketplaceSales: summary.payments.marketplace,
      marketplaceReconciliations: marketplaceRecons,
      paymentReconciliations: paymentRecons,
      actor,
      actorRole: role ?? undefined,
    });
    toast.success("Shift ditutup");
    setClosing(0);
    setClosingTouched(false);
    setCashReason("");
    setConfirmClose(false);
    refresh();
  }

  function tryCloseShift() {
    if (!current || !summary) return;
    if (!closingTouched) return toast.error("Masukkan jumlah kas penutup (Actual Cash)");
    if (closing < 0) return toast.error("Kas penutup tidak valid");
    if (cashDifference !== 0 && !cashReason.trim())
      return toast.error("Alasan wajib diisi bila cash difference ≠ 0");
    if (!packagingEverSaved) {
      setConfirmClose(true);
      return;
    }
    doCloseShift();
  }

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 p-6 md:p-8">
      <header className="flex flex-col gap-1.5">
        <span className="inline-flex h-6 w-fit items-center gap-1.5 rounded-full border border-primary/20 bg-primary/5 px-2.5 text-[11px] font-medium uppercase tracking-wider text-primary">
          <span className="h-1.5 w-1.5 rounded-full bg-primary" />
          Sales · Shifts
        </span>
        <h1 className="text-[28px] font-semibold leading-tight tracking-tight">Audit Shift</h1>
        <p className="max-w-3xl text-sm text-muted-foreground">
          Menjawab satu pertanyaan: <em>apakah seluruh transaksi pada shift ini sudah sesuai?</em>{" "}
          Cash, marketplace, pembayaran, dan pengeluaran operasional direkonsiliasi di sini.
        </p>
      </header>

      {!current && !isReadOnly && (
        <Card className="overflow-hidden border-dashed">
          <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="text-sm font-semibold">Belum ada shift terbuka</div>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Buka shift untuk mulai menerima transaksi.
              </p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
              <div className="flex flex-col gap-1">
                <Label htmlFor="opening" className="text-[11px] uppercase tracking-wider text-muted-foreground">
                  Kas pembuka
                </Label>
                <NumberInput
                  id="opening"
                  min={0}
                  value={opening}
                  onChange={setOpening}
                  onKeyDown={(e) => e.key === "Enter" && openShift()}
                  className="w-48"
                />
              </div>
              <Button onClick={openShift}>Buka Shift</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {!current && isReadOnly && (
        <Card>
          <CardContent className="py-6 text-sm text-muted-foreground">
            Tidak ada shift aktif.
          </CardContent>
        </Card>
      )}

      {current && summary && (
        <>
          {/* Hero — Live shift panel */}
          <Card className="relative overflow-hidden border-primary/15">
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-primary/8 via-transparent to-gold/10" />
            <CardContent className="relative p-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                  </span>
                  Live
                </span>
                <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
                  Shift Saat Ini
                </span>
              </div>
              <div className="mt-3 grid gap-4 md:grid-cols-4">
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Kasir</div>
                  <div className="mt-1 truncate text-base font-semibold">{current.cashier}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Dibuka</div>
                  <div className="mt-1 text-base font-semibold">{formatDateTime(current.openedAt)}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Kas Pembuka</div>
                  <div className="mt-1 text-base font-semibold tabular-nums">{formatIDR(current.openingCash)}</div>
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Omzet · Order</div>
                  <div className="mt-1 text-base font-semibold tabular-nums">
                    {formatIDR(summary.totalRevenue)}
                    <span className="ml-2 text-xs font-normal text-muted-foreground">
                      · {summary.totalOrders} order
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>


          {/* Pengeluaran Operasional (LIVE) */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Pengeluaran Operasional</CardTitle>
              {!isReadOnly && (
                <Button size="sm" onClick={() => setExpenseDialog({ mode: "add" })}>
                  <Plus className="h-4 w-4" /> Tambah
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {opItems.length === 0 && (
                <p className="mb-2 rounded-md border border-dashed p-3 text-xs text-muted-foreground">
                  Belum ada item Inventory kategori <strong>Operasional</strong>.
                </p>
              )}
              <OperationalExpenseTable
                entries={current.operationalExpenses ?? []}
                canEdit={canEditExpense && !isReadOnly}
                onEdit={(e) => setExpenseDialog({ mode: "edit", entry: e, shiftId: current.id })}
                onDelete={(e) => setConfirmDelete({ shiftId: current.id, entry: e })}
              />
              <div className="mt-3 flex items-center justify-end gap-2 text-sm">
                <span className="text-muted-foreground">Total (mengurangi Expected Cash)</span>
                <strong className="tabular-nums">{formatIDR(totalOpExpense)}</strong>
              </div>
            </CardContent>
          </Card>

          {/* Pemakaian Packaging */}
          <PackagingUsageCard
            shift={current}
            pkgItems={pkgItems}
            actor={actor}
            role={role}
            readOnly={isReadOnly}
            onSaved={refresh}
          />

          {/* Rekonsiliasi Pembayaran (system view) */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Rekonsiliasi Pembayaran</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                {paymentRecons.map((r) => (
                  <div
                    key={r.bucket}
                    className="flex flex-col gap-0.5 rounded-md border bg-muted/20 px-3 py-2"
                  >
                    <span className="text-xs uppercase text-muted-foreground">
                      {PAYMENT_BUCKET_LABEL[r.bucket]}
                    </span>
                    <span className="text-lg font-semibold tabular-nums">
                      {formatIDR(r.systemTotal)}
                    </span>
                    {r.bucket === "cash" && closingTouched && (
                      <span
                        className={`text-xs tabular-nums ${
                          cashDifference === 0
                            ? "text-muted-foreground"
                            : cashDifference > 0
                              ? "text-emerald-600"
                              : "text-destructive"
                        }`}
                      >
                        Aktual: {formatIDR(closing)} · Δ {cashDifference > 0 ? "+" : ""}
                        {formatIDR(cashDifference)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Closing */}
          {!isReadOnly && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Closing Shift</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-3 sm:grid-cols-2">
                <SummaryRow label="Opening Cash" value={formatIDR(current.openingCash)} />
                <SummaryRow label="Cash Sales (sistem)" value={formatIDR(summary.payments.cash)} />
                <SummaryRow
                  label="Pengeluaran Operasional"
                  value={`− ${formatIDR(totalOpExpense)}`}
                />
                <SummaryRow
                  label="Expected Cash"
                  value={formatIDR(expectedCash)}
                  hint="Opening + Cash Sales − Pengeluaran"
                />
                <div className="flex flex-col gap-1">
                  <Label htmlFor="closing">Actual Cash</Label>
                  <NumberInput
                    id="closing"
                    min={0}
                    value={closing}
                    onChange={(v) => {
                      setClosing(v);
                      setClosingTouched(true);
                    }}
                    className="w-full"
                  />
                </div>
                <SummaryRow
                  label="Difference"
                  value={
                    <span
                      className={
                        cashDifference === 0
                          ? ""
                          : cashDifference > 0
                            ? "text-emerald-600"
                            : "text-destructive"
                      }
                    >
                      {cashDifference > 0 ? "+" : ""}
                      {formatIDR(cashDifference)}
                    </span>
                  }
                />
                {cashDifference !== 0 && (
                  <div className="flex flex-col gap-1 sm:col-span-2">
                    <Label htmlFor="reason">Alasan Selisih (wajib)</Label>
                    <Input
                      id="reason"
                      value={cashReason}
                      onChange={(e) => setCashReason(e.target.value)}
                      placeholder="Contoh: kembalian kurang, uang tips masuk kas, dll"
                    />
                  </div>
                )}

                {/* Marketplace reconciliation — digenerate dari MARKETPLACE_SOURCES */}
                <div className="sm:col-span-2 mt-2 flex flex-col gap-2">
                  <h3 className="text-sm font-semibold">Rekonsiliasi Marketplace</h3>
                  <p className="text-xs text-muted-foreground">
                    Bandingkan total sistem dengan settlement yang diterima. Kosongkan bila
                    marketplace tidak ada transaksi.
                  </p>
                  <div className="grid gap-2">
                    {marketplaceRecons.map((r) => (
                      <div
                        key={r.marketplace}
                        className="grid gap-2 rounded-md border bg-muted/20 p-3 sm:grid-cols-4 sm:items-end"
                      >
                        <div className="flex flex-col gap-0.5">
                          <span className="text-xs uppercase text-muted-foreground">
                            {SOURCE_ORDER_LABEL[r.marketplace]}
                          </span>
                          <span className="text-[10px] text-muted-foreground">
                            {r.systemOrders} order
                          </span>
                        </div>
                        <SummaryRow label="Sistem" value={formatIDR(r.systemTotal)} />
                        <div className="flex flex-col gap-1">
                          <Label
                            htmlFor={`settle-${r.marketplace}`}
                            className="text-xs"
                          >
                            Settlement
                          </Label>
                          <Input
                            id={`settle-${r.marketplace}`}
                            inputMode="numeric"
                            value={settlementInputs[r.marketplace].amount}
                            onChange={(e) =>
                              setSettlementInputs((prev) => ({
                                ...prev,
                                [r.marketplace]: {
                                  ...prev[r.marketplace],
                                  amount: e.target.value,
                                },
                              }))
                            }
                            placeholder={r.systemTotal === 0 ? "—" : "0"}
                          />
                        </div>
                        <SummaryRow
                          label="Selisih"
                          value={
                            r.settlementAmount == null ? (
                              <span className="text-muted-foreground">—</span>
                            ) : (
                              <span
                                className={
                                  r.difference === 0
                                    ? ""
                                    : r.difference > 0
                                      ? "text-emerald-600"
                                      : "text-destructive"
                                }
                              >
                                {r.difference > 0 ? "+" : ""}
                                {formatIDR(r.difference)}
                              </span>
                            )
                          }
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="sm:col-span-2 mt-2 grid gap-3 sm:grid-cols-2">
                  <SummaryRow label="Total Order" value={String(summary.totalOrders)} />
                  <SummaryRow label="Total Omzet" value={formatIDR(summary.totalRevenue)} />
                  <SummaryRow label="QRIS" value={formatIDR(summary.payments.qris)} />
                  <SummaryRow label="Transfer" value={formatIDR(summary.payments.transfer)} />
                  <SummaryRow
                    label="Marketplace (sistem)"
                    value={formatIDR(summary.payments.marketplace)}
                  />
                  <SummaryRow
                    label="Total Pemakaian Packaging"
                    value={`${totalPackagingQty} pcs`}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Status Audit */}
          {auditStatuses.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Status Audit</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="flex flex-col gap-1.5 text-sm">
                  {auditStatuses.map((s, i) => (
                    <AuditStatusRow key={i} item={s} />
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {!isReadOnly && (
            <div className="flex flex-col items-end gap-2">
              {hasBlockingError && (
                <p className="text-xs text-destructive">
                  Ada status merah — perbaiki sebelum menutup shift.
                </p>
              )}
              <Button size="lg" onClick={tryCloseShift} disabled={hasBlockingError}>
                Tutup Shift
              </Button>
            </div>
          )}
        </>
      )}

      {/* Riwayat */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Riwayat Shift
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kasir</TableHead>
                  <TableHead>Dibuka</TableHead>
                  <TableHead>Ditutup</TableHead>
                  <TableHead className="text-right">Kas Pembuka</TableHead>
                  <TableHead className="text-right">Omzet</TableHead>
                  <TableHead className="text-right">Op. Expense</TableHead>
                  <TableHead className="text-right">Selisih</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {shifts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="py-10 text-center text-sm text-muted-foreground">
                      Belum ada shift.
                    </TableCell>
                  </TableRow>
                )}
                {shifts.map((s) => {
                  const variance =
                    s.closingCash != null && s.expectedCash != null
                      ? s.closingCash - s.expectedCash
                      : null;
                  const locked = isShiftLocked(s);
                  return (
                    <TableRow
                      key={s.id}
                      className="cursor-pointer hover:bg-muted/40"
                      onClick={() => setDetail(s)}
                    >
                      <TableCell className="flex items-center gap-1">
                        {locked && <Lock className="h-3 w-3 text-muted-foreground" />}
                        {s.cashier}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatDateTime(s.openedAt)}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {s.closedAt ? formatDateTime(s.closedAt) : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {formatIDR(s.openingCash)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {s.totalRevenue != null ? formatIDR(s.totalRevenue) : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {s.totalOperationalExpense != null
                          ? formatIDR(s.totalOperationalExpense)
                          : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {variance == null ? (
                          "—"
                        ) : (
                          <span
                            className={
                              variance === 0
                                ? ""
                                : variance > 0
                                  ? "text-emerald-600"
                                  : "text-destructive"
                            }
                          >
                            {variance > 0 ? "+" : ""}
                            {formatIDR(variance)}
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <ShiftDetailDialog shift={detail} onClose={() => setDetail(null)} />

      {expenseDialog && (
        <OperationalExpenseDialog
          mode={expenseDialog.mode}
          initial={expenseDialog.mode === "edit" ? expenseDialog.entry : undefined}
          shiftId={
            expenseDialog.mode === "edit"
              ? expenseDialog.shiftId
              : current?.id ?? ""
          }
          opItems={opItems}
          actor={actor}
          role={role}
          onClose={() => setExpenseDialog(null)}
          onSaved={() => {
            setExpenseDialog(null);
            refresh();
          }}
        />
      )}

      {confirmDelete && (
        <AlertDialog open onOpenChange={(o) => !o && setConfirmDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Hapus pengeluaran ini?</AlertDialogTitle>
              <AlertDialogDescription>
                Stok Inventory <strong>{confirmDelete.entry.itemName}</strong> akan
                dikembalikan sebanyak {confirmDelete.entry.qty} {confirmDelete.entry.unit}.
                Aktivitas ini tercatat pada Audit Log.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Batal</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  try {
                    shiftService.deleteOperationalExpense({
                      shiftId: confirmDelete.shiftId,
                      expenseId: confirmDelete.entry.id,
                      actor,
                      actorRole: role ?? undefined,
                    });
                    toast.success("Pengeluaran dihapus");
                    setConfirmDelete(null);
                    refresh();
                  } catch (err) {
                    toast.error((err as Error).message);
                  }
                }}
              >
                Hapus
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {confirmClose && (
        <AlertDialog open onOpenChange={(o) => !o && setConfirmClose(false)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Pemakaian Packaging belum diinput</AlertDialogTitle>
              <AlertDialogDescription>
                Anda belum menyimpan Pemakaian Packaging pada shift ini. Tetap
                tutup Shift?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Kembali</AlertDialogCancel>
              <AlertDialogAction onClick={doCloseShift}>Ya, Tutup</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {isCashier && current && (
        <p className="text-xs text-muted-foreground">
          Kasir hanya dapat menambah Pengeluaran Operasional saat shift aktif. Edit/hapus
          dilakukan oleh Admin. Shift yang sudah ditutup terkunci untuk kasir.
        </p>
      )}
    </div>
  );
}

function AuditStatusRow({ item }: { item: AuditStatusItem }) {
  const icon =
    item.level === "ok" ? (
      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
    ) : item.level === "warn" ? (
      <AlertTriangle className="h-4 w-4 text-amber-500" />
    ) : (
      <XCircle className="h-4 w-4 text-destructive" />
    );
  return (
    <li className="flex items-center gap-2">
      {icon}
      <span
        className={
          item.level === "error"
            ? "text-destructive"
            : item.level === "warn"
              ? "text-amber-700"
              : ""
        }
      >
        {item.label}
      </span>
    </li>
  );
}


function OperationalExpenseTable({
  entries,
  canEdit,
  onEdit,
  onDelete,
}: {
  entries: ShiftOperationalExpense[];
  canEdit: boolean;
  onEdit: (e: ShiftOperationalExpense) => void;
  onDelete: (e: ShiftOperationalExpense) => void;
}) {
  if (entries.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">Belum ada pengeluaran.</p>
    );
  }
  return (
    <div className="overflow-x-auto rounded-lg border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-16">Jam</TableHead>
            <TableHead>Barang</TableHead>
            <TableHead className="w-20 text-right">Qty</TableHead>
            <TableHead className="w-32 text-right">Harga</TableHead>
            <TableHead className="w-32 text-right">Total</TableHead>
            <TableHead>Catatan</TableHead>
            {canEdit && <TableHead className="w-24"></TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {entries.map((e) => (
            <TableRow key={e.id}>
              <TableCell className="text-xs text-muted-foreground">
                {formatTime(e.at)}
              </TableCell>
              <TableCell>
                {e.itemName}{" "}
                <span className="text-xs text-muted-foreground">({e.unit})</span>
              </TableCell>
              <TableCell className="text-right tabular-nums">{e.qty}</TableCell>
              <TableCell className="text-right tabular-nums">
                {formatIDR(e.price)}
              </TableCell>
              <TableCell className="text-right tabular-nums">
                {formatIDR(e.total)}
              </TableCell>
              <TableCell className="text-xs text-muted-foreground">
                {e.notes ?? "—"}
              </TableCell>
              {canEdit && (
                <TableCell className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => onEdit(e)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onDelete(e)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function OperationalExpenseDialog({
  mode,
  initial,
  shiftId,
  opItems,
  actor,
  role,
  onClose,
  onSaved,
}: {
  mode: "add" | "edit";
  initial?: ShiftOperationalExpense;
  shiftId: string;
  opItems: ReturnType<typeof inventoryService.list>;
  actor: string;
  role: string | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [at, setAt] = useState<string>(
    initial ? toLocalDatetimeInput(initial.at) : toLocalDatetimeInput(new Date().toISOString()),
  );
  const [itemId, setItemId] = useState(initial?.itemId ?? "");
  const [qty, setQty] = useState<number>(initial?.qty ?? 1);
  const [price, setPrice] = useState<number>(initial?.price ?? 0);
  const [notes, setNotes] = useState(initial?.notes ?? "");

  const total = Math.max(0, qty) * Math.max(0, price);

  function pickItem(v: string) {
    setItemId(v);
    if (mode === "add" && price === 0) {
      const it = inventoryService.get(v);
      if (it) setPrice(it.purchasePrice);
    }
  }

  function submit() {
    if (!itemId) return toast.error("Pilih barang");
    if (qty <= 0) return toast.error("Qty harus > 0");
    if (price < 0) return toast.error("Harga tidak valid");
    try {
      if (mode === "add") {
        shiftService.addOperationalExpense({
          at: fromLocalDatetimeInput(at),
          itemId,
          qty,
          price,
          notes,
          actor,
          actorRole: role ?? undefined,
        });
        toast.success("Pengeluaran ditambahkan");
      } else if (initial) {
        shiftService.updateOperationalExpense({
          shiftId,
          expenseId: initial.id,
          at: fromLocalDatetimeInput(at),
          itemId,
          qty,
          price,
          notes,
          actor,
          actorRole: role ?? undefined,
        });
        toast.success("Pengeluaran diubah");
      }
      onSaved();
    } catch (err) {
      toast.error((err as Error).message);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {mode === "add" ? "Tambah Pengeluaran Operasional" : "Ubah Pengeluaran"}
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="flex flex-col gap-1">
            <Label htmlFor="at">Jam</Label>
            <Input
              id="at"
              type="datetime-local"
              value={at}
              onChange={(e) => setAt(e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-1">
            <Label>Barang</Label>
            <Select value={itemId} onValueChange={pickItem}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih barang…" />
              </SelectTrigger>
              <SelectContent>
                {opItems.map((it) => (
                  <SelectItem key={it.id} value={it.id}>
                    {it.name} ({it.unit})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="flex flex-col gap-1">
              <Label htmlFor="qty">Qty</Label>
              <NumberInput id="qty" min={0} value={qty} onChange={setQty} />
            </div>
            <div className="flex flex-col gap-1">
              <Label htmlFor="price">Harga</Label>
              <NumberInput id="price" min={0} value={price} onChange={setPrice} />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 text-sm">
            <span className="text-muted-foreground">Total</span>
            <strong className="tabular-nums">{formatIDR(total)}</strong>
          </div>
          <div className="flex flex-col gap-1">
            <Label htmlFor="notes">Catatan</Label>
            <Input
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Opsional"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Batal
          </Button>
          <Button onClick={submit}>Simpan</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PackagingUsageCard({
  shift,
  pkgItems,
  actor,
  role,
  readOnly,
  onSaved,
}: {
  shift: Shift;
  pkgItems: ReturnType<typeof inventoryService.list>;
  actor: string;
  role: string | null;
  readOnly: boolean;
  onSaved: () => void;
}) {
  const savedMap = useMemo(() => {
    const m = new Map<string, number>();
    (shift.packagingUsage ?? []).forEach((p) => m.set(p.itemId, p.qty));
    return m;
  }, [shift.packagingUsage]);

  const [draft, setDraft] = useState<Record<string, number>>({});

  useEffect(() => {
    const next: Record<string, number> = {};
    pkgItems.forEach((it) => {
      next[it.id] = savedMap.get(it.id) ?? 0;
    });
    setDraft(next);
  }, [shift.id, pkgItems.length, savedMap]);

  function save() {
    try {
      shiftService.savePackagingUsage({
        shiftId: shift.id,
        entries: pkgItems.map((it) => ({ itemId: it.id, qty: draft[it.id] ?? 0 })),
        actor,
        actorRole: role ?? undefined,
      });
      toast.success("Pemakaian Packaging disimpan");
      onSaved();
    } catch (err) {
      toast.error((err as Error).message);
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base">Pemakaian Packaging</CardTitle>
        {shift.packagingUsageSavedAt && (
          <span className="text-xs text-muted-foreground">
            Terakhir disimpan {formatDateTime(shift.packagingUsageSavedAt)}
            {shift.packagingUsageSavedBy ? ` · ${shift.packagingUsageSavedBy}` : ""}
          </span>
        )}
      </CardHeader>
      <CardContent>
        {pkgItems.length === 0 ? (
          <p className="rounded-md border border-dashed p-3 text-xs text-muted-foreground">
            Belum ada item Inventory kategori <strong>Packaging</strong>.
          </p>
        ) : (
          <>
            <div className="grid gap-2 sm:grid-cols-2">
              {pkgItems.map((it) => (
                <div
                  key={it.id}
                  className="flex items-center justify-between gap-2 rounded-md border bg-muted/20 px-3 py-2"
                >
                  <div className="flex flex-col">
                    <span className="text-sm">{it.name}</span>
                    <span className="text-[10px] text-muted-foreground">
                      stok {it.stock} {it.unit}
                    </span>
                  </div>
                  <NumberInput
                    min={0}
                    value={draft[it.id] ?? 0}
                    onChange={(v) => setDraft((d) => ({ ...d, [it.id]: v }))}
                    className="w-24"
                    disabled={readOnly}
                  />
                </div>
              ))}
            </div>
            {!readOnly && (
              <div className="mt-3 flex justify-end">
                <Button onClick={save}>Simpan</Button>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function SummaryRow({
  label,
  value,
  hint,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-md border bg-muted/20 px-3 py-2">
      <div className="flex flex-col">
        <span className="text-xs text-muted-foreground">{label}</span>
        {hint && <span className="text-[10px] text-muted-foreground/70">{hint}</span>}
      </div>
      <span className="text-sm font-medium tabular-nums">{value}</span>
    </div>
  );
}

function ShiftDetailDialog({
  shift,
  onClose,
}: {
  shift: Shift | null;
  onClose: () => void;
}) {
  if (!shift) return null;
  const ops = shift.operationalExpenses ?? [];
  const pkg = shift.packagingUsage ?? [];
  const variance =
    shift.closingCash != null && shift.expectedCash != null
      ? shift.closingCash - shift.expectedCash
      : null;
  return (
    <Dialog open={!!shift} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Detail Shift · {shift.cashier}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4 text-sm">
          <div className="grid gap-2 sm:grid-cols-2">
            <SummaryRow label="Dibuka" value={formatDateTime(shift.openedAt)} />
            <SummaryRow
              label="Ditutup"
              value={shift.closedAt ? formatDateTime(shift.closedAt) : "—"}
            />
            <SummaryRow label="Opening Cash" value={formatIDR(shift.openingCash)} />
            <SummaryRow label="Total Order" value={String(shift.totalOrders ?? 0)} />
            <SummaryRow label="Total Omzet" value={formatIDR(shift.totalRevenue ?? 0)} />
            <SummaryRow label="Cash" value={formatIDR(shift.cashSales ?? 0)} />
            <SummaryRow label="QRIS" value={formatIDR(shift.qrisSales ?? 0)} />
            <SummaryRow label="Marketplace" value={formatIDR(shift.marketplaceSales ?? 0)} />
            <SummaryRow
              label="Total Pengeluaran Operasional"
              value={formatIDR(shift.totalOperationalExpense ?? 0)}
            />
            <SummaryRow
              label="Total Pemakaian Packaging"
              value={`${shift.totalPackagingQty ?? 0} pcs`}
            />
            <SummaryRow
              label="Expected Cash"
              value={shift.expectedCash != null ? formatIDR(shift.expectedCash) : "—"}
            />
            <SummaryRow
              label="Actual Cash"
              value={shift.closingCash != null ? formatIDR(shift.closingCash) : "—"}
            />
            <SummaryRow
              label="Cash Difference"
              value={
                variance == null ? (
                  "—"
                ) : (
                  <span
                    className={
                      variance === 0
                        ? ""
                        : variance > 0
                          ? "text-emerald-600"
                          : "text-destructive"
                    }
                  >
                    {variance > 0 ? "+" : ""}
                    {formatIDR(variance)}
                  </span>
                )
              }
            />
            {shift.cashDifferenceReason && (
              <div className="sm:col-span-2">
                <SummaryRow
                  label="Alasan Selisih"
                  value={shift.cashDifferenceReason}
                />
              </div>
            )}
          </div>

          <section className="flex flex-col gap-2">
            <h3 className="text-sm font-semibold">Pengeluaran Operasional</h3>
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Jam</TableHead>
                    <TableHead>Barang</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Harga</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead>Catatan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ops.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="py-4 text-center text-xs text-muted-foreground">
                        Tidak ada pengeluaran.
                      </TableCell>
                    </TableRow>
                  )}
                  {ops.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatTime(e.at)}
                      </TableCell>
                      <TableCell>
                        {e.itemName}
                        <span className="ml-1 text-xs text-muted-foreground">({e.unit})</span>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">{e.qty}</TableCell>
                      <TableCell className="text-right tabular-nums">{formatIDR(e.price)}</TableCell>
                      <TableCell className="text-right tabular-nums">{formatIDR(e.total)}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {e.notes ?? "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </section>

          <section className="flex flex-col gap-2">
            <h3 className="text-sm font-semibold">Pemakaian Packaging</h3>
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nama Packaging</TableHead>
                    <TableHead className="text-right">Qty Dipakai</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pkg.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={2} className="py-4 text-center text-xs text-muted-foreground">
                        Tidak ada pemakaian packaging.
                      </TableCell>
                    </TableRow>
                  )}
                  {pkg.map((p, i) => (
                    <TableRow key={i}>
                      <TableCell>{p.itemName}</TableCell>
                      <TableCell className="text-right tabular-nums">
                        {p.qty} {p.unit}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
