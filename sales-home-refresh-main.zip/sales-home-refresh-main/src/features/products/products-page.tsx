import { useEffect, useMemo, useRef, useState } from "react";
import {
  Plus,
  Trash2,
  Pencil,
  Search,
  ImageIcon,
  Upload,
  RefreshCw,
  AlertTriangle,
  PackageX,
  Package,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { productService } from "@/services/product.service";
import { priceGroupService } from "@/services/price-group.service";
import type { PriceGroup, Product } from "@/services/types";
import { formatIDR } from "@/lib/format";
import { toast } from "sonner";
import { usePermission } from "@/lib/permissions";

const DEFAULT_CATEGORIES = ["Kopi", "Teh", "Pastry", "Makanan", "Minuman", "Lainnya"];
const CUSTOM_CATEGORY = "__custom__";

function emptyProduct(): Product {
  return {
    id: `p_${Date.now()}`,
    name: "",
    category: "Kopi",
    sku: "",
    price: 0,
    cost: 0,
    stock: 0,
    minStock: 5,
    imageUrl: "",
    active: true,
  };
}

function stockStatus(p: Product) {
  const stock = p.stock ?? 0;
  const min = p.minStock ?? 0;
  if (stock <= 0) return { label: "Habis", tone: "destructive" as const };
  if (min > 0 && stock <= min) return { label: "Stok Menipis", tone: "warning" as const };
  return { label: "Tersedia", tone: "ok" as const };
}

export function ProductsPage() {
  const { can } = usePermission();
  const canEdit = can("product.edit");
  const canDelete = can("product.delete");
  const canEditPrice = can("product.editPrice");
  const canCreate = can("product.create");
  const [products, setProducts] = useState<Product[]>([]);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive" | "low" | "out">("all");
  const [editing, setEditing] = useState<Product | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [customCategory, setCustomCategory] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<Product | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [priceGroups, setPriceGroups] = useState<PriceGroup[]>([]);

  function refresh() {
    setProducts(productService.list());
    setPriceGroups(priceGroupService.list());
  }
  useEffect(refresh, []);

  const categories = useMemo(() => {
    const set = new Set<string>([...DEFAULT_CATEGORIES, ...productService.categories()]);
    return Array.from(set);
  }, [products]);

  const filtered = products.filter((p) => {
    const q = query.toLowerCase();
    const matchQ =
      !q ||
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.sku ?? "").toLowerCase().includes(q);
    const matchC = categoryFilter === "all" || p.category === categoryFilter;
    const s = stockStatus(p);
    const matchS =
      statusFilter === "all" ||
      (statusFilter === "active" && p.active) ||
      (statusFilter === "inactive" && !p.active) ||
      (statusFilter === "low" && s.tone === "warning") ||
      (statusFilter === "out" && s.tone === "destructive");
    return matchQ && matchC && matchS;
  });

  const stats = useMemo(() => {
    const total = products.length;
    const active = products.filter((p) => p.active).length;
    const low = products.filter((p) => {
      const s = stockStatus(p);
      return s.tone === "warning";
    }).length;
    const out = products.filter((p) => (p.stock ?? 0) <= 0).length;
    const inventoryValue = products.reduce(
      (acc, p) => acc + (p.cost ?? 0) * (p.stock ?? 0),
      0,
    );
    return { total, active, low, out, inventoryValue };
  }, [products]);

  function openNew() {
    const draft = emptyProduct();
    draft.sku = productService.generateSku(draft.category);
    setEditing(draft);
    setIsNew(true);
    setCustomCategory("");
  }

  function openEdit(p: Product) {
    setEditing({ ...p });
    setIsNew(false);
    setCustomCategory(DEFAULT_CATEGORIES.includes(p.category) ? "" : p.category);
  }

  function onCategoryChange(value: string) {
    if (!editing) return;
    if (value === CUSTOM_CATEGORY) {
      setCustomCategory(editing.category && !DEFAULT_CATEGORIES.includes(editing.category) ? editing.category : "");
      return;
    }
    const next = { ...editing, category: value };
    if (isNew) next.sku = productService.generateSku(value);
    setEditing(next);
    setCustomCategory("");
  }

  function regenerateSku() {
    if (!editing) return;
    setEditing({ ...editing, sku: productService.generateSku(editing.category) });
  }

  function onFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !editing) return;
    if (file.size > 1_500_000) {
      toast.error("Ukuran gambar maks 1.5 MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setEditing((cur) => (cur ? { ...cur, imageUrl: String(reader.result) } : cur));
    };
    reader.readAsDataURL(file);
  }

  function save() {
    if (!editing) return;
    const finalCategory = customCategory.trim() || editing.category;
    if (!editing.name.trim()) {
      toast.error("Nama produk wajib diisi");
      return;
    }
    if (!finalCategory) {
      toast.error("Kategori wajib diisi");
      return;
    }
    if (editing.price < 0 || editing.cost < 0) {
      toast.error("Harga tidak boleh negatif");
      return;
    }
    const toSave: Product = {
      ...editing,
      category: finalCategory,
      sku: editing.sku || productService.generateSku(finalCategory),
      stock: editing.stock ?? 0,
      minStock: editing.minStock ?? 0,
    };
    productService.upsert(toSave);
    refresh();
    setEditing(null);
    toast.success(isNew ? "Produk berhasil ditambahkan" : "Produk berhasil diperbarui");
  }

  function remove() {
    if (!confirmDelete) return;
    productService.remove(confirmDelete.id);
    refresh();
    setConfirmDelete(null);
    toast.success("Produk dihapus");
  }

  const margin = editing
    ? editing.price > 0
      ? Math.round(((editing.price - editing.cost) / editing.price) * 100)
      : 0
    : 0;

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold tracking-tight">Atur Produk</h1>
        <p className="text-sm text-muted-foreground">
          Kelola katalog produk yang dipakai di Kasir, Produksi, dan Inventaris.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard icon={<Package className="h-4 w-4" />} label="Total Produk" value={String(stats.total)} hint={`${stats.active} aktif`} />
        <StatCard icon={<AlertTriangle className="h-4 w-4" />} label="Stok Menipis" value={String(stats.low)} tone="warning" />
        <StatCard icon={<PackageX className="h-4 w-4" />} label="Stok Habis" value={String(stats.out)} tone="destructive" />
      </div>

      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari nama, SKU, atau kategori…"
                className="pl-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Kategori" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Kategori</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="active">Aktif</SelectItem>
                <SelectItem value="inactive">Nonaktif</SelectItem>
                <SelectItem value="low">Stok Menipis</SelectItem>
                <SelectItem value="out">Stok Habis</SelectItem>
              </SelectContent>
            </Select>
            <span className="text-xs text-muted-foreground">{filtered.length} produk</span>
            {canCreate && (
              <Button onClick={openNew} className="ml-auto">
                <Plus className="h-4 w-4" /> Tambah Produk
              </Button>
            )}
          </div>

          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[64px]">Foto</TableHead>
                  <TableHead>Nama Produk</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Kategori</TableHead>
                  <TableHead className="text-right">Harga Jual</TableHead>
                  <TableHead className="text-right">Modal</TableHead>
                  <TableHead className="text-right">Stok</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="py-10 text-center text-sm text-muted-foreground">
                      Belum ada produk yang cocok.
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((p) => {
                  const s = stockStatus(p);
                  return (
                    <TableRow key={p.id} className={!p.active ? "opacity-60" : ""}>
                      <TableCell>
                        <div className="h-10 w-10 overflow-hidden rounded-md border bg-muted">
                          {p.imageUrl ? (
                            <img src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                              <ImageIcon className="h-4 w-4" strokeWidth={1.75} />
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{p.name}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{p.sku ?? "—"}</TableCell>
                      <TableCell className="text-sm">
                        <Badge variant="outline">{p.category}</Badge>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">{formatIDR(p.price)}</TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">{formatIDR(p.cost)}</TableCell>
                      <TableCell className="text-right tabular-nums">
                        {p.stock ?? 0}
                        {p.minStock ? <span className="text-xs text-muted-foreground"> / {p.minStock}</span> : null}
                      </TableCell>
                      <TableCell>
                        {!p.active ? (
                          <Badge variant="secondary">Nonaktif</Badge>
                        ) : s.tone === "destructive" ? (
                          <Badge variant="destructive">{s.label}</Badge>
                        ) : s.tone === "warning" ? (
                          <Badge className="bg-amber-500/15 text-amber-700 hover:bg-amber-500/20 dark:text-amber-400">{s.label}</Badge>
                        ) : (
                          <Badge variant="outline" className="text-emerald-600 dark:text-emerald-400">{s.label}</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {canEdit && (
                          <Button size="sm" variant="ghost" onClick={() => openEdit(p)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                        {canDelete && (
                          <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(p)} aria-label="Hapus">
                            <Trash2 className="h-4 w-4 text-destructive" strokeWidth={1.75} />
                          </Button>
                        )}
                        {!canEdit && !canDelete && (
                          <span className="text-xs text-muted-foreground">Lihat saja</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{isNew ? "Tambah Produk" : "Edit Produk"}</DialogTitle>
            <DialogDescription>
              Lengkapi detail produk. SKU dibuat otomatis berdasarkan kategori.
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <div className="flex flex-col gap-6">
              {/* Image */}
              <section className="flex flex-col gap-3">
                <div className="text-sm font-medium">Foto Produk</div>
                <div className="flex gap-4">
                  <div className="h-28 w-28 shrink-0 overflow-hidden rounded-lg border bg-muted">
                    {editing.imageUrl ? (
                      <img src={editing.imageUrl} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                        <ImageIcon className="h-6 w-6" strokeWidth={1.5} />
                      </div>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col gap-2">
                    <div className="flex gap-2">
                      <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="h-4 w-4" /> Unggah
                      </Button>
                      {editing.imageUrl && (
                        <Button type="button" variant="ghost" size="sm" onClick={() => setEditing({ ...editing, imageUrl: "" })}>
                          Hapus
                        </Button>
                      )}
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={onFilePick}
                    />
                    <Input
                      placeholder="atau tempel URL gambar"
                      value={editing.imageUrl ?? ""}
                      onChange={(e) => setEditing({ ...editing, imageUrl: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">PNG/JPG, maks 1.5 MB.</p>
                  </div>
                </div>
              </section>

              <Separator />

              {/* Basic info */}
              <section className="flex flex-col gap-4">
                <div className="text-sm font-medium">Informasi Dasar</div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Nama Produk</Label>
                    <Input
                      value={editing.name}
                      onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                      placeholder="cth. Es Kopi Susu"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Kategori</Label>
                    <Select
                      value={customCategory ? CUSTOM_CATEGORY : editing.category}
                      onValueChange={onCategoryChange}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {categories.map((c) => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                        <SelectItem value={CUSTOM_CATEGORY}>+ Kategori baru…</SelectItem>
                      </SelectContent>
                    </Select>
                    {customCategory !== "" || editing.category === "" ? (
                      <Input
                        className="mt-1"
                        placeholder="Nama kategori baru"
                        value={customCategory}
                        onChange={(e) => setCustomCategory(e.target.value)}
                      />
                    ) : null}
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label className="flex items-center justify-between">
                      <span>SKU</span>
                      <span className="text-xs text-muted-foreground">otomatis</span>
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        className="font-mono"
                        value={editing.sku ?? ""}
                        onChange={(e) => setEditing({ ...editing, sku: e.target.value.toUpperCase() })}
                      />
                      <Button type="button" variant="outline" size="icon" onClick={regenerateSku} aria-label="Regenerate SKU">
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Status</Label>
                    <div className="flex h-9 items-center justify-between rounded-md border px-3">
                      <span className="text-sm">{editing.active ? "Produk Aktif" : "Nonaktif"}</span>
                      <Switch
                        checked={editing.active}
                        onCheckedChange={(v) => setEditing({ ...editing, active: v })}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">Produk nonaktif tidak muncul di Kasir.</p>
                  </div>
                </div>
              </section>

              <Separator />

              {/* Pricing */}
              <section className="flex flex-col gap-4">
                <div className="text-sm font-medium">Harga</div>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Modal</Label>
                    <NumberInput
                      min={0}
                      value={editing.cost}
                      onChange={(v) => setEditing({ ...editing, cost: v })}
                      disabled={!canEditPrice}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Jual</Label>
                    <NumberInput
                      min={0}
                      value={editing.price}
                      onChange={(v) => setEditing({ ...editing, price: v })}
                      disabled={!canEditPrice}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Margin</Label>
                    <div className="flex h-9 items-center rounded-md border bg-muted/40 px-3 text-sm tabular-nums">
                      {margin}% <span className="ml-2 text-xs text-muted-foreground">({formatIDR(Math.max(0, editing.price - editing.cost))})</span>
                    </div>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Reseller</Label>
                    <NumberInput
                      min={0}
                      value={editing.priceReseller ?? 0}
                      onChange={(v) => setEditing({ ...editing, priceReseller: v })}
                    />
                    <p className="text-xs text-muted-foreground">Dipakai bila kasir memilih tipe Reseller. Kosongkan (0) untuk memakai harga jual.</p>
                  </div>
                </div>
                {priceGroups.length > 0 && (
                  <div className="flex flex-col gap-3">
                    <div className="text-sm font-medium">Harga per Price Group</div>
                    <p className="text-xs text-muted-foreground">
                      Kosongkan (0) untuk memakai harga jual default. Sistem otomatis memakai harga grup ini
                      saat kasir memilih source order terkait.
                    </p>
                    <div className="grid gap-3 md:grid-cols-2">
                      {priceGroups.map((g) => (
                        <div key={g.id} className="flex flex-col gap-1.5">
                          <Label className="text-xs">
                            {g.name}{" "}
                            <span className="text-muted-foreground">
                              ({g.sources.join(", ") || "—"})
                            </span>
                          </Label>
                          <NumberInput
                            min={0}
                            value={editing.prices?.[g.id] ?? 0}
                            onChange={(v) =>
                              setEditing({
                                ...editing,
                                prices: { ...(editing.prices ?? {}), [g.id]: v },
                              })
                            }
                            disabled={!canEditPrice}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </section>

              <Separator />

              {/* Stock */}
              <section className="flex flex-col gap-4">
                <div className="text-sm font-medium">Stok</div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Quantity (Stok Saat Ini)</Label>
                    <NumberInput
                      min={0}
                      value={editing.stock ?? 0}
                      onChange={(v) => setEditing({ ...editing, stock: v })}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Minimum Stok</Label>
                    <NumberInput
                      min={0}
                      value={editing.minStock ?? 0}
                      onChange={(v) => setEditing({ ...editing, minStock: v })}
                    />
                    <p className="text-xs text-muted-foreground">Peringatan muncul saat stok ≤ angka ini.</p>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Sumber Stok</Label>
                    <Select
                      value={editing.stockSource ?? "freezer"}
                      onValueChange={(v) => setEditing({ ...editing, stockSource: v as "freezer" | "showcase" })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="freezer">Freezer (Frozen)</SelectItem>
                        <SelectItem value="showcase">Showcase (Matang)</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Menentukan lokasi stok saat penjualan.</p>
                  </div>
                </div>
              </section>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Batal</Button>
            <Button onClick={save}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus produk?</AlertDialogTitle>
            <AlertDialogDescription>
              "{confirmDelete?.name}" akan dihapus permanen dari katalog.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={remove}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  hint,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint?: string;
  tone?: "warning" | "destructive";
}) {
  const toneClass =
    tone === "destructive"
      ? "text-destructive"
      : tone === "warning"
        ? "text-amber-600 dark:text-amber-400"
        : "text-foreground";
  return (
    <Card>
      <CardContent className="flex flex-col gap-1 pt-5">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className={toneClass}>{icon}</span>
          {label}
        </div>
        <div className={`text-xl font-semibold tabular-nums ${toneClass}`}>{value}</div>
        {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
      </CardContent>
    </Card>
  );
}