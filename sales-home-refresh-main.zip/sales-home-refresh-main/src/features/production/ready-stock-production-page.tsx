import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Package, Factory, RefreshCw, Inbox } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { productionPlanningService } from "@/services/production-planning.service";
import { stockMovementService } from "@/services/stock-movement.service";
import type { StockMovement } from "@/services/types";
import { formatDateTime, formatNumber } from "@/lib/format";

interface Summary {
  semiFinished: { itemId: string; name: string; unit: string; stock: number }[];
  waitingFinished: { productId: string; name: string; qty: number }[];
  totalWaitingFinished: number;
  totalSemiCount: number;
}

export function ReadyStockProductionPage() {
  const [summary, setSummary] = useState<Summary>({
    semiFinished: [],
    waitingFinished: [],
    totalWaitingFinished: 0,
    totalSemiCount: 0,
  });
  const [recentMoves, setRecentMoves] = useState<StockMovement[]>([]);

  function refresh() {
    setSummary(productionPlanningService.readyStockProductionSummary());
    const semiIds = new Set(
      productionPlanningService.readyStockProductionSummary().semiFinished.map((s) => s.itemId),
    );
    setRecentMoves(
      stockMovementService
        .list()
        .filter((m) => semiIds.has(m.itemId))
        .slice(0, 20),
    );
  }

  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Ready Stock Production</h1>
          <p className="text-sm text-muted-foreground">
            Stok semi-finished (adonan, ayam suwir, dll.) dan produk jadi yang belum di-release ke
            Sales.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={refresh}>
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/production/produksi">
              <Factory className="h-4 w-4" /> Waiting Release
            </Link>
          </Button>
        </div>
      </header>

      <div className="grid gap-3 sm:grid-cols-3">
        <MiniStat
          label="Jenis Semi-Finished"
          value={summary.totalSemiCount}
        />
        <MiniStat
          label="Waiting Release (pcs)"
          value={summary.totalWaitingFinished}
        />
        <MiniStat
          label="Total Item Aktif"
          value={summary.semiFinished.length + summary.waitingFinished.length}
        />
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Package className="h-4 w-4" /> Semi Finished Product
          </CardTitle>
        </CardHeader>
        <CardContent className="px-0">
          {summary.semiFinished.length === 0 ? (
            <EmptyState
              title="Belum ada stok semi-finished"
              description="Buat lewat pencatatan produksi adonan."
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nama</TableHead>
                  <TableHead className="text-right">Stok</TableHead>
                  <TableHead>Satuan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {summary.semiFinished.map((s) => (
                  <TableRow key={s.itemId} className="hover:bg-muted/40">
                    <TableCell className="font-medium">{s.name}</TableCell>
                    <TableCell className="text-right tabular-nums font-semibold">
                      {formatNumber(s.stock)}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{s.unit}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Factory className="h-4 w-4" /> Produk Jadi — Waiting Release
          </CardTitle>
        </CardHeader>
        <CardContent className="px-0">
          {summary.waitingFinished.length === 0 ? (
            <EmptyState
              title="Tidak ada produk menunggu release"
              description="Semua produk jadi sudah dilepas ke Ready Stock Sales."
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produk</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {summary.waitingFinished.map((w) => (
                  <TableRow key={w.productId} className="hover:bg-muted/40">
                    <TableCell className="font-medium">{w.name}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      <Badge variant="secondary">{formatNumber(w.qty)}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Riwayat Pergerakan Semi-Finished</CardTitle>
        </CardHeader>
        <CardContent className="px-0">
          {recentMoves.length === 0 ? (
            <EmptyState
              title="Belum ada pergerakan"
              description="Aktivitas produksi semi-finished akan tampil di sini."
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Waktu</TableHead>
                  <TableHead>Item</TableHead>
                  <TableHead className="text-right">Delta</TableHead>
                  <TableHead className="text-right">Saldo</TableHead>
                  <TableHead>Alasan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentMoves.map((m) => (
                  <TableRow key={m.id} className="hover:bg-muted/40">
                    <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                      {formatDateTime(m.createdAt)}
                    </TableCell>
                    <TableCell className="text-sm">{m.itemName}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      <span
                        className={
                          m.delta >= 0
                            ? "text-emerald-600 dark:text-emerald-400"
                            : "text-destructive"
                        }
                      >
                        {m.delta >= 0 ? "+" : ""}
                        {formatNumber(m.delta)}
                      </span>{" "}
                      <span className="text-xs text-muted-foreground">{m.unit}</span>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(m.balanceAfter)}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {m.reason ?? "-"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: number }) {
  return (
    <Card className="h-full transition-colors hover:border-primary/40">
      <CardContent className="pt-4">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="mt-1 text-2xl font-semibold tabular-nums">{formatNumber(value)}</p>
      </CardContent>
    </Card>
  );
}

function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="flex flex-col items-center gap-2 px-6 py-10 text-center">
      <div className="grid h-10 w-10 place-items-center rounded-full bg-muted text-muted-foreground">
        <Inbox className="h-5 w-5" strokeWidth={1.75} />
      </div>
      <p className="text-sm font-medium text-foreground">{title}</p>
      <p className="max-w-sm text-xs text-muted-foreground">{description}</p>
    </div>
  );
}
