import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Factory,
  ChefHat,
  Play,
  History,
  Sparkles,
  Hand,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { NumberInput } from "@/components/ui/number-input";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { recipeService } from "@/services/recipe.service";
import { productionService } from "@/services/production.service";
import { useRole } from "@/lib/role-context";
import { RECIPE_TYPE_LABEL, type Recipe } from "@/services/types";
import { formatNumber } from "@/lib/format";
import { toast } from "sonner";

const FOLDER_PRESETS = ["Pelipat A", "Pelipat B", "Pelipat C"];

export function DailyProductionPage() {
  const { profile, user } = useRole();
  const operator = profile?.full_name || user?.email || "Operator";

  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [tick, setTick] = useState(0);

  function refresh() {
    setRecipes(recipeService.active());
    setTick((t) => t + 1);
  }
  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  const adonanRecipes = useMemo(() => recipes.filter((r) => r.type === "semi_finished"), [recipes]);
  const risolRecipes = useMemo(() => recipes.filter((r) => r.type === "finished"), [recipes]);

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Pencatatan Produksi</h1>
          <p className="text-sm text-muted-foreground">
            Catat hasil kerja harian: buat adonan, lipat risol per pelipat, lalu input total panir.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline" size="sm">
            <Link to="/production/history">
              <History className="h-4 w-4" /> Riwayat
            </Link>
          </Button>
        </div>
      </header>

      <Tabs defaultValue="adonan" className="flex flex-col gap-4">
        <TabsList className="grid h-auto w-full grid-cols-3 gap-1 bg-muted p-1">
          <TabsTrigger value="adonan" className="flex flex-col gap-0.5 py-2.5">
            <span className="text-sm font-semibold">1 · Buat Adonan</span>
            <span className="text-[10px] opacity-70">Tim Kulit</span>
          </TabsTrigger>
          <TabsTrigger value="lipat" className="flex flex-col gap-0.5 py-2.5">
            <span className="text-sm font-semibold">2 · Lipat Risol</span>
            <span className="text-[10px] opacity-70">Per pelipat</span>
          </TabsTrigger>
          <TabsTrigger value="panir" className="flex flex-col gap-0.5 py-2.5">
            <span className="text-sm font-semibold">3 · Panir</span>
            <span className="text-[10px] opacity-70">Input total hasil panir</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="adonan" className="mt-0">
          <RecipeGrid
            recipes={adonanRecipes}
            mode="adonan"
            operator={operator}
            onRan={refresh}
            tick={tick}
            emptyHint="Belum ada resep Adonan aktif. Minta admin menambahkan resep tipe Adonan."
          />
        </TabsContent>

        <TabsContent value="lipat" className="mt-0">
          <RecipeGrid
            recipes={risolRecipes}
            mode="lipat"
            operator={operator}
            onRan={refresh}
            tick={tick}
            emptyHint="Belum ada resep Varian Risol aktif. Minta admin menambahkan resep tipe Barang Jadi."
          />
        </TabsContent>

        <TabsContent value="panir" className="mt-0">
          <PanirPanel operator={operator} onSubmitted={refresh} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function RecipeGrid({
  recipes,
  mode,
  operator,
  onRan,
  tick,
  emptyHint,
}: {
  recipes: Recipe[];
  mode: "adonan" | "lipat";
  operator: string;
  onRan: () => void;
  tick: number;
  emptyHint: string;
}) {
  if (recipes.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-full bg-muted text-muted-foreground">
            <ChefHat className="h-6 w-6" strokeWidth={1.5} />
          </div>
          <p className="max-w-md text-sm text-muted-foreground">{emptyHint}</p>
        </CardContent>
      </Card>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
      {recipes.map((r) => (
        <RecipeCard
          key={`${r.id}-${tick}`}
          recipe={r}
          mode={mode}
          operator={operator}
          onRan={onRan}
        />
      ))}
    </div>
  );
}

function RecipeCard({
  recipe,
  mode,
  operator,
  onRan,
}: {
  recipe: Recipe;
  mode: "adonan" | "lipat";
  operator: string;
  onRan: () => void;
}) {
  const [qty, setQty] = useState<number>(0);
  const [notes, setNotes] = useState("");
  const [folderLabel, setFolderLabel] = useState<string>(
    mode === "lipat" ? FOLDER_PRESETS[0] : "",
  );
  const [folderCustom, setFolderCustom] = useState("");
  const [busy, setBusy] = useState(false);
  // Adonan: berat aktual (dalam satuan yang dipilih)
  const [actualWeight, setActualWeight] = useState<number>(0);
  const [weightUnit, setWeightUnit] = useState<"g" | "kg">(
    recipe.estimatedNetWeightUnit ?? "g",
  );
  // Pelipat: produk rusak (waste)
  const [waste, setWaste] = useState<number>(0);

  const outputName = productionService.outputName(recipe);

  // Konversi berat aktual → gram baseline, lalu → batch aktual
  const estWeightG =
    (recipe.estimatedNetWeight ?? 0) *
    (recipe.estimatedNetWeightUnit === "kg" ? 1000 : 1);
  const actualWeightG = actualWeight * (weightUnit === "kg" ? 1000 : 1);
  const actualBatches =
    mode === "adonan" && estWeightG > 0 && actualWeightG > 0
      ? Math.round((actualWeightG / estWeightG) * 10000) / 10000
      : 0;

  async function run() {
    if (mode === "adonan") {
      if (estWeightG <= 0) {
        toast.error(
          "Resep belum memiliki Estimasi Berat Bersih. Atur dulu di halaman Resep.",
        );
        return;
      }
      if (!(actualWeight > 0)) {
        toast.error("Masukkan berat aktual terlebih dahulu");
        return;
      }
    } else if (!(qty > 0)) {
      toast.error("Masukkan jumlah terlebih dahulu");
      return;
    }
    setBusy(true);
    try {
      const folder =
        mode === "lipat"
          ? folderLabel === "__custom__"
            ? folderCustom.trim()
            : folderLabel
          : undefined;
      if (mode === "lipat" && !folder) {
        throw new Error("Isi nama pelipat terlebih dahulu");
      }
      if (mode === "adonan") {
        // Bahan dikonsumsi × batch aktual (proporsional terhadap berat aktual).
        productionService.executeRun({
          recipeId: recipe.id,
          activity: "create_adonan",
          batches: actualBatches,
          operator,
          notes,
          producedQuantityOverride: actualWeight,
          actualWeight,
          actualWeightUnit: weightUnit,
        });
        toast.success(
          `Adonan tercatat: ${formatNumber(actualWeight)} ${weightUnit} · ${formatNumber(
            actualBatches,
          )} batch`,
        );
      } else {
        // Lipat: qty adalah jumlah pcs risol. Batches = qty / hasil per resep,
        // supaya konsumsi bahan proporsional (mis. 50 pcs × 55g/pcs = 2750g).
        const perRecipe = recipe.outputQuantity > 0 ? recipe.outputQuantity : 1;
        const batches = qty / perRecipe;
        productionService.executeRun({
          recipeId: recipe.id,
          activity: "produce_finished",
          batches,
          operator,
          notes,
          folderLabel: folder,
          producedQuantityOverride: qty,
          wasteQuantity: waste > 0 ? waste : undefined,
        });
        toast.success(
          `${folder}: +${formatNumber(qty)} ${recipe.outputUnit} ${outputName}` +
            (waste > 0 ? ` (waste ${formatNumber(waste)})` : ""),
        );
      }
      setNotes("");
      setQty(0);
      setActualWeight(0);
      setWaste(0);
      onRan();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="flex flex-col">
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0">
        <div className="flex min-w-0 flex-col gap-1">
          <CardTitle className="truncate text-base">{recipe.name}</CardTitle>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant="outline">{RECIPE_TYPE_LABEL[recipe.type]}</Badge>
            <span className="text-xs text-muted-foreground">→ {outputName}</span>
          </div>
        </div>
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border bg-muted/40 text-muted-foreground">
          {mode === "lipat" ? (
            <Hand className="h-4 w-4" strokeWidth={1.75} />
          ) : (
            <Sparkles className="h-4 w-4" strokeWidth={1.75} />
          )}
        </div>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-4">
        {mode === "lipat" && (
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Pelipat</Label>
            <Select value={folderLabel} onValueChange={setFolderLabel}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FOLDER_PRESETS.map((f) => (
                  <SelectItem key={f} value={f}>
                    {f}
                  </SelectItem>
                ))}
                <SelectItem value="__custom__">Lainnya…</SelectItem>
              </SelectContent>
            </Select>
            {folderLabel === "__custom__" && (
              <Input
                value={folderCustom}
                onChange={(e) => setFolderCustom(e.target.value)}
                placeholder="Nama pelipat"
                className="mt-1"
              />
            )}
          </div>
        )}

        {mode === "adonan" ? (
          <>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">Berat Aktual Hasil Timbangan</Label>
              <div className="flex gap-2">
                <NumberInput
                  value={actualWeight}
                  onChange={(v) => setActualWeight(Math.max(0, v))}
                  min={0}
                  allowDecimal
                />
                <Select value={weightUnit} onValueChange={(v) => setWeightUnit(v as "g" | "kg")}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="g">gram</SelectItem>
                    <SelectItem value="kg">kg</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {estWeightG > 0 ? (
                <p className="text-[11px] text-muted-foreground">
                  Estimasi berat bersih/resep:{" "}
                  <span className="font-medium">
                    {formatNumber(recipe.estimatedNetWeight ?? 0)}{" "}
                    {recipe.estimatedNetWeightUnit ?? "g"}
                  </span>
                </p>
              ) : (
                <p className="text-[11px] text-destructive">
                  Resep belum memiliki Estimasi Berat Bersih — atur di halaman Resep.
                </p>
              )}
            </div>
            <div className="rounded-md border bg-muted/20 p-3 text-xs">
              <div className="flex items-baseline justify-between">
                <span className="text-muted-foreground">Batch Aktual</span>
                <span className="text-base font-semibold tabular-nums">
                  {actualBatches > 0 ? formatNumber(actualBatches) : "—"}
                </span>
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">
                Bahan akan dikonsumsi sebanyak {actualBatches > 0 ? formatNumber(actualBatches) : "—"}× dari komposisi resep.
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">Jumlah dilipat ({recipe.outputUnit})</Label>
              <NumberInput
                value={qty}
                onChange={(v) => setQty(Math.max(0, v))}
                min={0}
                allowDecimal
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs">Produk Rusak / Waste ({recipe.outputUnit})</Label>
              <NumberInput
                value={waste}
                onChange={(v) => setWaste(Math.max(0, v))}
                min={0}
                allowDecimal
              />
              <p className="text-[11px] text-muted-foreground">
                Catat produk gagal/robek untuk analisa waste harian.
              </p>
            </div>
          </>
        )}

        <div className="flex flex-col gap-1.5">
          <Label className="text-xs">Catatan (opsional)</Label>
          <Textarea
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="cth. batch pagi"
          />
        </div>

        {recipe.notes && (
          <>
            <Separator />
            <div className="text-xs text-muted-foreground">
              <span className="font-medium text-foreground">SOP: </span>
              {recipe.notes}
            </div>
          </>
        )}

        <div className="mt-auto pt-2">
          <Button
            onClick={run}
            disabled={
              busy ||
              (mode === "adonan" ? actualWeight <= 0 || estWeightG <= 0 : qty <= 0)
            }
            className="w-full"
          >
            <Play className="h-4 w-4" />
            {busy ? "Memproses…" : mode === "lipat" ? "Catat Lipat" : "Catat Adonan"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function PanirPanel({
  operator,
  onSubmitted,
}: {
  operator: string;
  onSubmitted: () => void;
}) {
  const [qty, setQty] = useState<number>(0);
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [summaryTick, setSummaryTick] = useState(0);

  const summary = useMemo(
    () => productionService.todayPanirSummary(),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [summaryTick],
  );

  const preview = useMemo(
    () => (qty > 0 ? summary.requirementsFor(qty) : []),
    [qty, summary],
  );
  const hasShortage = preview.some((p) => !p.sufficient);

  async function submit() {
    setBusy(true);
    try {
      productionService.recordPanir({ panirQty: qty, operator, notes });
      toast.success(`Panir tercatat: ${formatNumber(qty)} pcs`);
      setNotes("");
      setQty(0);
      setSummaryTick((t) => t + 1);
      onSubmitted();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const noRecipe = !summary.activePanirRecipe;

  return (
    <div className="mx-auto grid max-w-2xl grid-cols-1 gap-4">
      {/* Kartu utama: input panir */}
      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0">
          <div className="flex min-w-0 flex-col gap-1">
            <CardTitle className="text-base">Total Hasil Panir Hari Ini</CardTitle>
            <span className="text-xs text-muted-foreground">
              Cukup input satu angka: total pcs yang berhasil dipanir hari ini (gabungan semua
              varian). Bahan panir otomatis dikurangi dari inventaris.
            </span>
          </div>
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border bg-muted/40 text-muted-foreground">
            <Factory className="h-4 w-4" strokeWidth={1.75} />
          </div>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          {noRecipe && (
            <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-xs text-destructive">
              Resep panir belum diatur. Minta admin membuat resep panir aktif di halaman{" "}
              <span className="font-medium">Resep Produksi</span> sebelum mencatat panir.
            </div>
          )}

          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-md border bg-muted/20 p-3">
              <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Total Lipat
              </div>
              <div className="text-lg font-semibold tabular-nums">
                {formatNumber(summary.totalLipat)}
              </div>
            </div>
            <div className="rounded-md border bg-muted/20 p-3">
              <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Sudah Dipanir
              </div>
              <div className="text-lg font-semibold tabular-nums">
                {formatNumber(summary.totalPanir)}
              </div>
            </div>
            <div className="rounded-md border bg-muted/20 p-3">
              <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Selisih
              </div>
              <div
                className={`text-lg font-semibold tabular-nums ${
                  summary.selisih === 0
                    ? "text-emerald-600"
                    : summary.selisih > 0
                      ? "text-amber-600"
                      : "text-destructive"
                }`}
              >
                {formatNumber(summary.selisih)}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Jumlah dipanir sekarang (pcs)</Label>
            <NumberInput value={qty} onChange={(v) => setQty(Math.max(0, v))} min={0} allowDecimal />
          </div>

          {qty > 0 && preview.length > 0 && (
            <div className="rounded-md border bg-muted/10 p-3 text-xs">
              <div className="mb-1.5 font-medium">Bahan yang akan dikurangi:</div>
              <ul className="space-y-1">
                {preview.map((p) => (
                  <li key={p.itemId} className="flex justify-between gap-2">
                    <span className={p.sufficient ? "" : "text-destructive"}>{p.name}</span>
                    <span className="tabular-nums">
                      {formatNumber(p.required)} {p.unit}
                      {!p.sufficient && (
                        <span className="ml-1 text-destructive">
                          (stok {formatNumber(p.available)})
                        </span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <Label className="text-xs">Catatan (opsional)</Label>
            <Textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="cth. sebagian gosong, sisa 3 pcs"
            />
          </div>

          <Button
            onClick={submit}
            disabled={busy || qty <= 0 || noRecipe || hasShortage}
            className="w-full"
          >
            <Play className="h-4 w-4" /> {busy ? "Memproses…" : "Catat Panir"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
