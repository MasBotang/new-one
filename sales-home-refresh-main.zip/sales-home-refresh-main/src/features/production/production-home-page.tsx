import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Factory,
  Package,
  AlertTriangle,
  ClipboardList,
  ChefHat,
  History as HistoryIcon,
  Sparkles,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  productionRecommendationService,
  type ProductionRecommendation,
} from "@/services/production-recommendation.service";
import { formatNumber } from "@/lib/format";
import { useRole } from "@/lib/role-context";

/**
 * Home Produksi — pusat monitoring operasional.
 *
 * Bukan dashboard analitik: tidak ada chart, tidak ada KPI berlebihan.
 * Fokus utama:
 *   1. Rekomendasi produksi hari ini (per varian)
 *   2. Ready stock saat ini
 *   3. Minimum stock alert
 *   4. Pre-Order yang belum tertutup ready stock
 */
export function ProductionHomePage() {
  const { profile, user } = useRole();
  const operator = profile?.full_name || user?.email || "";
  const [rows, setRows] = useState<ProductionRecommendation[]>([]);

  function refresh() {
    setRows(productionRecommendationService.build());
  }

  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  const totalRecommended = useMemo(() => rows.reduce((s, r) => s + r.recommended, 0), [rows]);
  const alerts = useMemo(() => rows.filter((r) => r.belowMinStock), [rows]);
  const preorderGaps = useMemo(() => rows.filter((r) => r.preorderShortfall > 0), [rows]);

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Home Produksi</h1>
          <p className="text-sm text-muted-foreground">
            Rekomendasi & monitoring produksi hari ini. Sistem memberi rekomendasi — keputusan akhir
            tetap di Tim Produksi.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild size="sm">
            <Link to="/production/produksi">
              <Factory className="h-4 w-4" /> Mulai Produksi
            </Link>
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/production/ready-stock">
              <Package className="h-4 w-4" /> Ready Stock
            </Link>
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/production/recipes">
              <ChefHat className="h-4 w-4" /> Resep
            </Link>
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/production/history">
              <HistoryIcon className="h-4 w-4" /> Riwayat
            </Link>
          </Button>
        </div>
      </header>

      {alerts.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Ready Stock di bawah batas minimum</AlertTitle>
          <AlertDescription>
            {alerts.map((a) => a.name).join(", ")} — pertimbangkan produksi tambahan.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-3 sm:grid-cols-3">
        <MiniStat label="Varian Aktif" value={rows.length} />
        <MiniStat label="Total Rekomendasi" value={totalRecommended} />
        <MiniStat label="Operator" value={0} textValue={operator || "-"} />
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="h-4 w-4" /> Rekomendasi Produksi Hari Ini
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Rekomendasi = Forecast + Pre-Order − Ready Stock. Hanya panduan.
          </p>
        </CardHeader>
        <CardContent className="px-0">
          {rows.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              Belum ada produk aktif untuk direkomendasikan.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produk</TableHead>
                  <TableHead className="text-right">Forecast</TableHead>
                  <TableHead className="text-right">Pre-Order</TableHead>
                  <TableHead className="text-right">Ready Stock</TableHead>
                  <TableHead className="text-right">Min. Stock</TableHead>
                  <TableHead className="text-right">Rekomendasi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.productId} className="hover:bg-muted/40">
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {r.name}
                        {r.belowMinStock && (
                          <Badge variant="destructive" className="text-[10px]">
                            di bawah min
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {formatNumber(Math.round(r.forecast))}
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {formatNumber(r.preorder)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(r.readyStock)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {formatNumber(r.minStock)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      <Badge variant={r.recommended > 0 ? "default" : "secondary"}>
                        {formatNumber(r.recommended)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {preorderGaps.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <ClipboardList className="h-4 w-4" /> Pre-Order Belum Tertutup Ready Stock
            </CardTitle>
          </CardHeader>
          <CardContent className="px-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produk</TableHead>
                  <TableHead className="text-right">Pre-Order</TableHead>
                  <TableHead className="text-right">Ready Stock</TableHead>
                  <TableHead className="text-right">Kekurangan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {preorderGaps.map((r) => (
                  <TableRow key={r.productId} className="hover:bg-muted/40">
                    <TableCell className="font-medium">{r.name}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(r.preorder)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(r.readyStock)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      <Badge>{formatNumber(r.preorderShortfall)}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function MiniStat({
  label,
  value,
  textValue,
}: {
  label: string;
  value: number;
  textValue?: string;
}) {
  return (
    <Card className="h-full">
      <CardContent className="pt-4">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="mt-1 truncate text-lg font-semibold tabular-nums">
          {textValue ?? formatNumber(value)}
        </p>
      </CardContent>
    </Card>
  );
}
