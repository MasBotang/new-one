import { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Pencil,
  Trash2,
  Power,
  Search,
  ChefHat,
  Sparkles,
  Layers,
  Wheat,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { recipeService, type NewRecipe } from "@/services/recipe.service";
import { inventoryService } from "@/services/inventory.service";
import {
  RECIPE_TYPE_LABEL,
  type InventoryItem,
  type Recipe,
  type RecipeIngredient,
  type RecipeType,
} from "@/services/types";
import { formatNumber, parseFraction, roundTo } from "@/lib/format";
import { useRole } from "@/lib/role-context";
import { toast } from "sonner";

function FractionInput({
  value,
  onChange,
  placeholder,
}: {
  value: number;
  onChange: (n: number) => void;
  placeholder?: string;
}) {
  const [text, setText] = useState<string>(value ? String(value) : "");
  // Sync external value updates when not focused (e.g. switching ingredient).
  useEffect(() => {
    setText(value ? String(value) : "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  const parsed = parseFraction(text);
  const invalid = text.trim() !== "" && (!isFinite(parsed) || parsed <= 0);
  return (
    <div className="flex flex-col gap-0.5">
      <Input
        value={text}
        onChange={(e) => {
          const t = e.target.value;
          setText(t);
          const n = parseFraction(t);
          if (isFinite(n) && n >= 0) onChange(roundTo(n, 6));
        }}
        placeholder={placeholder ?? "cth. 1/8, 1 1/2, 0.125"}
        className={invalid ? "border-destructive" : undefined}
        inputMode="decimal"
      />
      {text.includes("/") && isFinite(parsed) && parsed > 0 && (
        <span className="px-1 text-[10px] text-muted-foreground">
          ≈ {roundTo(parsed, 4)}
        </span>
      )}
    </div>
  );
}

function emptyDraft(type: RecipeType = "semi_finished"): NewRecipe {
  const isPanir = type === "panir";
  return {
    name: "",
    type,
    outputTargetType: "inventory",
    outputRefId: "",
    outputName: isPanir ? "Panir" : "",
    outputQuantity: 1,
    outputUnit: isPanir ? "pcs" : "",
    estimatedYieldPct: 100,
    estimatedNetWeight: 0,
    estimatedNetWeightUnit: "g",
    notes: "",
    ingredients: [],
    active: true,
  };
}

export function RecipesPage() {
  const { role } = useRole();
  const isAdmin = role === "admin" || role === "owner";
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<RecipeType>("semi_finished");
  const [draft, setDraft] = useState<NewRecipe | null>(null);
  const [editing, setEditing] = useState<Recipe | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Recipe | null>(null);

  // Non-admin tidak boleh membuka tab Panir.
  useEffect(() => {
    if (!isAdmin && tab === "panir") setTab("semi_finished");
  }, [isAdmin, tab]);

  function refresh() {
    setRecipes(recipeService.list());
    setItems(inventoryService.list());
  }
  useEffect(refresh, []);

  const activeItems = useMemo(() => items.filter((i) => i.active), [items]);
  // Resep adonan aktif → bisa dipakai sebagai bahan untuk resep Varian Risol.
  const adonanRecipes = useMemo(
    () => recipes.filter((r) => r.type === "semi_finished" && r.active),
    [recipes],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return recipes.filter((r) => {
      if (r.type !== tab) return false;
      if (q && !r.name.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [recipes, query, tab]);

  function openNew() {
    setDraft(emptyDraft(tab));
    setEditing(null);
    setIsNew(true);
  }
  function openEdit(r: Recipe) {
    setDraft({
      name: r.name,
      type: r.type,
      outputTargetType: r.outputTargetType,
      outputRefId: r.outputRefId,
      outputName: r.outputName ?? "",
      outputQuantity: r.outputQuantity,
      outputUnit: r.outputUnit,
      estimatedYieldPct: r.estimatedYieldPct,
      estimatedNetWeight: r.estimatedNetWeight ?? 0,
      estimatedNetWeightUnit: r.estimatedNetWeightUnit ?? "g",
      notes: r.notes ?? "",
      ingredients: r.ingredients.map((i) => ({
        ...i,
        source: i.source ?? "inventory",
      })),
      active: r.active,
    });
    setEditing(r);
    setIsNew(false);
  }
  function close() {
    setDraft(null);
    setEditing(null);
    setIsNew(false);
  }

  function addIngredient() {
    if (!draft) return;
    setDraft({
      ...draft,
      ingredients: [...draft.ingredients, recipeService.emptyIngredient()],
    });
  }
  function updateIngredient(idx: number, patch: Partial<RecipeIngredient>) {
    if (!draft) return;
    const next = draft.ingredients.map((i, k) => (k === idx ? { ...i, ...patch } : i));
    setDraft({ ...draft, ingredients: next });
  }
  function removeIngredient(idx: number) {
    if (!draft) return;
    setDraft({ ...draft, ingredients: draft.ingredients.filter((_, k) => k !== idx) });
  }

  const errors = useMemo(
    () => (draft ? recipeService.validate(draft, editing?.id) : []),
    [draft, editing],
  );
  const canSave = !!draft && errors.length === 0;

  function save() {
    if (!draft) return;
    try {
      if (isNew) {
        recipeService.create(draft);
        toast.success("Resep ditambahkan");
      } else if (editing) {
        recipeService.update(editing.id, draft);
        toast.success("Resep diperbarui");
      }
      refresh();
      close();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  function toggleActive(r: Recipe) {
    recipeService.setActive(r.id, !r.active);
    refresh();
    toast.success(r.active ? "Resep dinonaktifkan" : "Resep diaktifkan");
  }
  function remove() {
    if (!confirmDelete) return;
    recipeService.remove(confirmDelete.id);
    setConfirmDelete(null);
    refresh();
    toast.success("Resep dihapus");
  }

  function outputLabel(r: Recipe): string {
    return (
      r.outputName ||
      items.find((i) => i.id === r.outputRefId)?.name ||
      "(belum ditentukan)"
    );
  }

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Resep Produksi</h1>
          <p className="text-sm text-muted-foreground">
            Kelola dua bagian resep: <span className="font-medium">Adonan</span> (isian / kulit /
            base) dan <span className="font-medium">Varian Risol</span> (barang jadi). Resep di
            sini menjadi acuan input staf produksi.
          </p>
        </div>
        <Button onClick={openNew} disabled={activeItems.length === 0}>
          <Plus className="h-4 w-4" />
          {tab === "semi_finished"
            ? "Tambah Resep Adonan"
            : tab === "finished"
              ? "Tambah Resep Varian"
              : "Tambah Resep Panir"}
        </Button>
      </header>

      {activeItems.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 py-10 text-center">
            <ChefHat className="h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
            <div className="text-sm font-medium">Belum ada item inventaris aktif</div>
            <p className="max-w-md text-xs text-muted-foreground">
              Tambahkan minimal satu item di Inventaris terlebih dahulu — resep harus mereferensikan
              bahan dari inventaris, bukan teks bebas.
            </p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <Tabs value={tab} onValueChange={(v) => setTab(v as RecipeType)}>
            <TabsList className={`grid w-full ${isAdmin ? "grid-cols-3" : "grid-cols-2"} sm:w-auto`}>
              <TabsTrigger value="semi_finished" className="gap-2">
                <Layers className="h-4 w-4" strokeWidth={1.75} />
                Adonan
              </TabsTrigger>
              <TabsTrigger value="finished" className="gap-2">
                <ChefHat className="h-4 w-4" strokeWidth={1.75} />
                Varian Risol
              </TabsTrigger>
              {isAdmin && (
                <TabsTrigger value="panir" className="gap-2">
                  <Wheat className="h-4 w-4" strokeWidth={1.75} />
                  Panir
                </TabsTrigger>
              )}
            </TabsList>
          </Tabs>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[220px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari nama resep…"
                className="pl-9"
              />
            </div>
            <span className="text-xs text-muted-foreground">{filtered.length} resep</span>
          </div>

          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader className="bg-muted/40">
                <TableRow className="hover:bg-transparent">
                  <TableHead>Nama Resep</TableHead>
                  <TableHead className="w-[140px]">Tipe</TableHead>
                  <TableHead>Output</TableHead>
                  <TableHead className="w-[100px] text-right">Bahan</TableHead>
                  <TableHead className="w-[100px] text-right">Yield</TableHead>
                  <TableHead className="w-[110px]">Status</TableHead>
                  <TableHead className="w-[140px] text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow className="hover:bg-transparent">
                    <TableCell colSpan={7} className="py-16">
                      <div className="flex flex-col items-center gap-2 text-center">
                        <div className="grid h-10 w-10 place-items-center rounded-full bg-muted text-muted-foreground">
                          <ChefHat className="h-5 w-5" strokeWidth={1.5} />
                        </div>
                        <div className="text-sm font-medium">Belum ada resep</div>
                        <div className="max-w-sm text-xs text-muted-foreground">
                          Setiap resep yang Anda buat akan otomatis tampil di Produksi Harian.
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((r) => (
                  <TableRow key={r.id} className={!r.active ? "opacity-60" : ""}>
                    <TableCell className="font-medium">{r.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{RECIPE_TYPE_LABEL[r.type]}</Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      <span className="font-medium">{outputLabel(r)}</span>
                      <span className="ml-1 text-muted-foreground">
                        · {formatNumber(r.outputQuantity)} {r.outputUnit}
                      </span>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{r.ingredients.length}</TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {r.estimatedYieldPct}%
                    </TableCell>
                    <TableCell>
                      {r.active ? (
                        <Badge variant="outline" className="text-emerald-600 dark:text-emerald-400">
                          Aktif
                        </Badge>
                      ) : (
                        <Badge variant="secondary">Nonaktif</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button size="sm" variant="ghost" onClick={() => toggleActive(r)} title={r.active ? "Nonaktifkan" : "Aktifkan"}>
                        <Power className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => openEdit(r)} aria-label="Edit">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(r)} aria-label="Hapus">
                        <Trash2 className="h-4 w-4 text-destructive" strokeWidth={1.75} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!draft} onOpenChange={(o) => !o && close()}>
        <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {isNew ? "Tambah Resep" : "Edit Resep"} —{" "}
              {draft?.type === "semi_finished"
                ? "Adonan"
                : draft?.type === "finished"
                  ? "Varian Risol"
                  : "Panir"}
            </DialogTitle>
            <DialogDescription>
              {draft?.type === "semi_finished"
                ? "Resep Adonan menghasilkan isian / kulit / base yang nantinya dipakai oleh resep Varian Risol."
                : draft?.type === "finished"
                  ? "Resep Varian Risol bisa memakai bahan langsung dari inventaris ataupun adonan yang sudah dibuat (mis. 1/8 telur, 1/3 smoked beef)."
                  : "Resep Panir adalah komposisi bahan panir per 1 pcs risol (mis. tepung panir, telur). Bahan otomatis dikurangi dari inventaris saat pencatatan panir, sebanyak qty panir × komposisi."}
            </DialogDescription>
          </DialogHeader>
          {draft && (
            <div className="flex flex-col gap-6">
              <section className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <Label>Nama Resep</Label>
                  <Input
                    value={draft.name}
                    onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                    placeholder={
                      draft.type === "semi_finished"
                        ? "cth. Adonan Mayo Original"
                        : "cth. Risol Mayo Smoked Beef"
                    }
                    autoFocus
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Tipe Resep</Label>
                  <Select
                    value={draft.type}
                    onValueChange={(v) => setDraft({ ...draft, type: v as RecipeType })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="semi_finished">{RECIPE_TYPE_LABEL.semi_finished}</SelectItem>
                      <SelectItem value="finished">{RECIPE_TYPE_LABEL.finished}</SelectItem>
                      {isAdmin && (
                        <SelectItem value="panir">{RECIPE_TYPE_LABEL.panir}</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                {draft.type !== "panir" && (
                  <>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <Label>
                    Nama Hasil Produksi{" "}
                    <span className="text-xs font-normal text-muted-foreground">
                      (akan tampil di inventaris)
                    </span>
                  </Label>
                  <Input
                    value={draft.outputName}
                    onChange={(e) => setDraft({ ...draft, outputName: e.target.value })}
                    placeholder={
                      draft.type === "semi_finished"
                        ? "cth. Adonan Mayo Original"
                        : "cth. Risol Mayo Smoked Beef"
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    Item inventaris dengan nama ini akan otomatis dibuat atau ditautkan saat resep
                    disimpan — tidak perlu menyiapkan stok hasil produksi secara manual.
                  </p>
                </div>

                <div className="flex flex-col gap-1.5">
                  <Label>Hasil per Batch</Label>
                  <NumberInput
                    value={draft.outputQuantity}
                    onChange={(v) => setDraft({ ...draft, outputQuantity: v })}
                    allowDecimal
                    min={0}
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Jumlah hasil dari 1× resep dijalankan.
                  </p>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Satuan Hasil</Label>
                  <Input
                    value={draft.outputUnit}
                    onChange={(e) => setDraft({ ...draft, outputUnit: e.target.value })}
                    placeholder={
                      draft.type === "semi_finished" ? "cth. gram, ml, kg" : "cth. pcs"
                    }
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <Label>Estimasi Hasil Akhir (%)</Label>
                  <NumberInput
                    value={draft.estimatedYieldPct}
                    onChange={(v) => setDraft({ ...draft, estimatedYieldPct: v })}
                    min={0}
                    max={100}
                  />
                  <p className="text-xs text-muted-foreground">
                    Persentase hasil akhir setelah memperhitungkan susut produksi (0–100%). Isi
                    100% jika tidak ada susut.
                  </p>
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <Label>
                    Estimasi Berat Bersih per 1 Resep{" "}
                    <span className="text-xs font-normal text-muted-foreground">(opsional)</span>
                  </Label>
                  <div className="flex gap-2">
                    <NumberInput
                      value={draft.estimatedNetWeight ?? 0}
                      onChange={(v) => setDraft({ ...draft, estimatedNetWeight: v })}
                      min={0}
                      allowDecimal
                    />
                    <Select
                      value={draft.estimatedNetWeightUnit ?? "g"}
                      onValueChange={(v) =>
                        setDraft({ ...draft, estimatedNetWeightUnit: v as "g" | "kg" })
                      }
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="g">gram</SelectItem>
                        <SelectItem value="kg">kg</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Dipakai oleh <span className="font-medium">Buat Adonan</span> untuk menghitung
                    batch aktual dari berat hasil timbangan: Batch Aktual = Berat Aktual ÷
                    Estimasi Berat Bersih.
                  </p>
                </div>
                  </>
                )}
                {draft.type === "panir" && (
                  <div className="md:col-span-2 rounded-md border border-dashed bg-muted/30 p-3 text-xs text-muted-foreground">
                    Resep Panir hanya berupa <span className="font-medium">komposisi bahan per 1 pcs</span>.
                    Saat pencatatan Panir, bahan di bawah akan otomatis dikurangi dari inventaris
                    sebanyak <span className="font-medium">qty panir × komposisi</span>. Tidak ada
                    item hasil produksi baru.
                  </div>
                )}
              </section>

              <Separator />

              <section className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold">
                    {draft.type === "semi_finished"
                      ? "Bahan Baku"
                      : draft.type === "panir"
                        ? "Komposisi Panir per 1 pcs"
                        : "Komposisi 1 Resep"}
                  </Label>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={addIngredient}
                    disabled={activeItems.length === 0}
                  >
                    <Plus className="h-4 w-4" /> Tambah Bahan
                  </Button>
                </div>
                {draft.ingredients.length === 0 && (
                  <p className="rounded-md border border-dashed py-6 text-center text-xs text-muted-foreground">
                    Belum ada bahan. Tambahkan minimal satu bahan
                    {draft.type === "finished" ? " (dari inventaris atau adonan)" : " dari inventaris"}.
                  </p>
                )}
                {draft.ingredients.map((ing, idx) => {
                  const it = items.find((i) => i.id === ing.inventoryItemId);
                  const source: "inventory" | "recipe" = ing.source ?? "inventory";
                  const showSourceToggle = draft.type === "finished";
                  return (
                    <div key={idx} className="grid grid-cols-12 gap-2 rounded-md border p-3">
                      {showSourceToggle && (
                        <div className="col-span-12 flex items-center gap-2">
                          <Label className="text-xs text-muted-foreground">Sumber:</Label>
                          <div className="inline-flex rounded-md border p-0.5 text-xs">
                            <button
                              type="button"
                              onClick={() =>
                                updateIngredient(idx, {
                                  source: "inventory",
                                  inventoryItemId: "",
                                  recipeId: undefined,
                                })
                              }
                              className={`flex items-center gap-1 rounded px-2 py-1 ${
                                source === "inventory"
                                  ? "bg-foreground text-background"
                                  : "text-muted-foreground"
                              }`}
                            >
                              <Wheat className="h-3 w-3" /> Bahan Baku
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                updateIngredient(idx, {
                                  source: "recipe",
                                  inventoryItemId: "",
                                  recipeId: undefined,
                                })
                              }
                              className={`flex items-center gap-1 rounded px-2 py-1 ${
                                source === "recipe"
                                  ? "bg-foreground text-background"
                                  : "text-muted-foreground"
                              }`}
                            >
                              <Layers className="h-3 w-3" /> Adonan
                            </button>
                          </div>
                        </div>
                      )}
                      <div className="col-span-12 md:col-span-7">
                        <Label className="text-xs text-muted-foreground">
                          {source === "recipe" ? "Pilih Adonan" : "Pilih Bahan Baku"}
                        </Label>
                        {source === "recipe" ? (
                          <Select
                            value={ing.recipeId ?? ""}
                            onValueChange={(v) => {
                              const adonan = adonanRecipes.find((r) => r.id === v);
                              updateIngredient(idx, {
                                recipeId: v,
                                // Inventory item id adonan = outputRefId resep adonan
                                inventoryItemId: adonan?.outputRefId ?? "",
                              });
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih adonan…" />
                            </SelectTrigger>
                            <SelectContent className="max-h-72">
                              {adonanRecipes.length === 0 && (
                                <div className="px-3 py-2 text-xs text-muted-foreground">
                                  Belum ada resep Adonan aktif.
                                </div>
                              )}
                              {adonanRecipes.map((r) => (
                                <SelectItem key={r.id} value={r.id}>
                                  {r.outputName || r.name} · {r.outputUnit}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <Select
                            value={ing.inventoryItemId}
                            onValueChange={(v) => updateIngredient(idx, { inventoryItemId: v })}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih bahan…" />
                            </SelectTrigger>
                            <SelectContent className="max-h-72">
                              {activeItems.map((i) => (
                                <SelectItem key={i.id} value={i.id}>
                                  {i.name} · stok {formatNumber(i.stock)} {i.unit}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </div>
                      <div className="col-span-9 md:col-span-4">
                        <Label className="text-xs text-muted-foreground">
                          Jumlah per 1 resep {it ? `(${it.unit})` : ""}
                        </Label>
                        <FractionInput
                          value={ing.quantity}
                          onChange={(v) => updateIngredient(idx, { quantity: v })}
                          placeholder="cth. 1/8 atau 0.125"
                        />
                      </div>
                      <div className="col-span-3 md:col-span-1 flex items-end justify-end">
                        <Button size="icon" variant="ghost" onClick={() => removeIngredient(idx)} aria-label="Hapus bahan">
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </section>

              <Separator />

              <section className="flex flex-col gap-3">
                <div className="flex flex-col gap-1.5">
                  <Label>Catatan Produksi / SOP</Label>
                  <Textarea
                    rows={3}
                    value={draft.notes ?? ""}
                    onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
                    placeholder="Tulis langkah-langkah, suhu, durasi, atau catatan kualitas."
                  />
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Sparkles className="h-3 w-3" />
                  <span>
                    Begitu disimpan, resep aktif otomatis muncul di Produksi Harian — tanpa
                    perubahan kode.
                  </span>
                </div>
              </section>

              {errors.length > 0 && (
                <p className="text-xs text-destructive">{errors[0].message}</p>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={close}>
              Batal
            </Button>
            <Button onClick={save} disabled={!canSave}>
              {isNew ? "Simpan Resep" : "Simpan Perubahan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus resep ini?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan. Riwayat produksi yang sudah tercatat tetap
              tersimpan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={remove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}