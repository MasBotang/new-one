import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Factory, Send, RefreshCw, History } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NumberInput } from "@/components/ui/number-input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { productionService } from "@/services/production.service";
import { useRole } from "@/lib/role-context";
import { formatDateTime, formatNumber } from "@/lib/format";
import { toast } from "sonner";

interface Waiting {
  productId: string;
  name: string;
  wipStock: number;
  readyStock: number;
}

export function WaitingReleasePage() {
  const { role, profile, user } = useRole();
  const operator = profile?.full_name || user?.email || "Operator";

  const [rows, setRows] = useState<Waiting[]>([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Waiting | null>(null);
  const [qty, setQty] = useState<number>(0);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  function refresh() {
    setRows(productionService.pendingFinishing());
  }

  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? rows.filter((r) => r.name.toLowerCase().includes(q)) : rows;
  }, [rows, search]);

  const totalWaiting = useMemo(() => rows.reduce((s, r) => s + r.wipStock, 0), [rows]);

  function openReleaseDialog(r: Waiting) {
    setSelected(r);
    setQty(r.wipStock);
    setNotes("");
  }

  function handleRelease() {
    if (!selected) return;
    if (qty <= 0 || qty > selected.wipStock) {
      toast.error(`Qty release harus antara 1 dan ${selected.wipStock}`);
      return;
    }
    setSaving(true);
    try {
      productionService.release({
        productId: selected.productId,
        quantity: qty,
        operator,
        notes: notes.trim() || undefined,
        role: role ?? undefined,
      });
      toast.success(
        `Release ${formatNumber(qty)} × ${selected.name} — pindah ke Ready Stock Sales.`,
      );
      setSelected(null);
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Gagal release");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Waiting Release</h1>
          <p className="text-sm text-muted-foreground">
            Produk hasil produksi belum bisa dijual. Tekan Release untuk memindahkan ke Ready Stock
            Sales.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={refresh}>
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link to="/production/history">
              <History className="h-4 w-4" /> Riwayat
            </Link>
          </Button>
        </div>
      </header>

      <div className="grid gap-3 sm:grid-cols-3">
        <MiniStat label="Produk Menunggu" value={rows.length} />
        <MiniStat label="Total Qty Menunggu" value={totalWaiting} />
        <MiniStat label="Operator" value={0} textValue={operator} />
      </div>

      <Card>
        <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Factory className="h-4 w-4" /> Antrian Release
          </CardTitle>
          <Input
            placeholder="Cari produk…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 w-52"
          />
        </CardHeader>
        <CardContent className="px-0">
          {filtered.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              Tidak ada produk menunggu release.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produk</TableHead>
                  <TableHead className="text-right">Ready Produksi</TableHead>
                  <TableHead className="text-right">Ready Sales</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((r) => (
                  <TableRow key={r.productId} className="hover:bg-muted/40">
                    <TableCell className="font-medium">{r.name}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      <Badge variant="secondary">{formatNumber(r.wipStock)}</Badge>
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {formatNumber(r.readyStock)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button size="sm" onClick={() => openReleaseDialog(r)}>
                        <Send className="h-3.5 w-3.5" /> Release
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Release ke Ready Stock Sales</DialogTitle>
            <p className="text-sm text-muted-foreground">
              Konfirmasi jumlah produk yang akan dipindahkan dari Ready Produksi ke Ready Sales.
            </p>
          </DialogHeader>
          {selected && (
            <div className="flex flex-col gap-3">
              <div className="rounded-md border bg-muted/40 p-3 text-sm">
                <p className="font-medium">{selected.name}</p>
                <p className="text-xs text-muted-foreground">
                  Ready Produksi: {formatNumber(selected.wipStock)} · Ready Sales:{" "}
                  {formatNumber(selected.readyStock)}
                </p>
              </div>
              <div className="flex flex-col gap-1">
                <Label className="text-xs">Qty di-release</Label>
                <NumberInput
                  value={qty}
                  onChange={(v) => setQty(Number(v) || 0)}
                  min={1}
                  max={selected.wipStock}
                />
              </div>
              <div className="flex flex-col gap-1">
                <Label className="text-xs">Catatan (opsional)</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelected(null)} disabled={saving}>
              Batal
            </Button>
            <Button onClick={handleRelease} disabled={saving || qty <= 0}>
              <Send className="h-3.5 w-3.5" /> Konfirmasi Release
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MiniStat({
  label,
  value,
  textValue,
}: {
  label: string;
  value: number;
  textValue?: string;
}) {
  return (
    <Card className="h-full transition-colors hover:border-primary/40">
      <CardContent className="pt-4">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="mt-1 truncate text-lg font-semibold tabular-nums">
          {textValue ?? formatNumber(value)}
        </p>
      </CardContent>
    </Card>
  );
}
