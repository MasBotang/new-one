import { Outlet, useRouter, useRouterState } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Bell, Store } from "lucide-react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AppSidebar } from "./app-sidebar";
import { useRole } from "@/lib/role-context";
import { canAccess, ROLE_LANDING } from "@/lib/navigation";
import { preorderService } from "@/services/preorder.service";
import { getPageMeta } from "@/lib/page-meta";

const DATE_FMT = new Intl.DateTimeFormat("id-ID", {
  weekday: "long",
  day: "numeric",
  month: "long",
});

function firstName(full?: string | null, email?: string | null): string {
  const raw = (full || email || "").trim();
  if (!raw) return "Tim";
  const base = raw.includes("@") ? raw.split("@")[0] : raw;
  return base.split(/[\s._-]+/)[0].replace(/^./, (c) => c.toUpperCase());
}

export function AppShell({ children }: { children?: ReactNode }) {
  const { role, hydrated, user, profile } = useRole();
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (!hydrated) return;
    if (!user) {
      router.navigate({ to: "/auth", search: { redirect: pathname }, replace: true });
      return;
    }
    if (!role) return;
    if (!canAccess(role, pathname)) {
      router.navigate({ to: ROLE_LANDING[role], replace: true });
    }
  }, [hydrated, user, role, pathname, router]);

  useEffect(() => {
    if (!user) return;
    const tick = () => {
      try {
        preorderService.promoteDue(new Date());
      } catch (err) {
        console.error("[preorder] promoteDue failed", err);
      }
    };
    tick();
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, [user]);

  const [today, setToday] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setToday(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  const meta = useMemo(() => getPageMeta(pathname), [pathname]);
  const name = firstName(profile?.full_name, user?.email);

  if (!hydrated || !user || !role) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
        Memuat workspace…
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-10 flex shrink-0 items-center gap-3 border-b border-border/60 bg-background/80 px-4 py-3 backdrop-blur md:px-8">
            <SidebarTrigger className="-ml-1 shrink-0 md:hidden" />
            <div className="flex min-w-0 flex-1 items-center justify-between gap-4">
              <div className="min-w-0">
                <h1 className="font-display truncate text-[17px] font-semibold leading-tight text-foreground sm:text-[19px]">
                  Selamat datang kembali, {name} <span aria-hidden>👋</span>
                </h1>
                <p className="mt-0.5 truncate text-[12.5px] text-muted-foreground">
                  {meta.subtitle}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="hidden text-[12px] font-medium tabular-nums text-muted-foreground md:inline">
                  {DATE_FMT.format(today)}
                </span>
                <Badge
                  variant="outline"
                  className="hidden h-7 gap-1.5 rounded-full border-border/70 bg-background pl-2 pr-3 text-[11px] font-medium text-foreground sm:inline-flex"
                >
                  <Store className="h-3.5 w-3.5 text-primary" strokeWidth={1.9} />
                  Outlet Utama
                </Badge>
                <Button
                  size="icon"
                  variant="ghost"
                  className="relative h-9 w-9 rounded-full"
                  aria-label="Notifikasi"
                >
                  <Bell className="h-4 w-4" strokeWidth={1.9} />
                  <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-primary" />
                </Button>
              </div>
            </div>
          </header>

          <main className="flex-1 px-4 py-6 md:px-8 md:py-8">
            <div className="page-enter mx-auto w-full max-w-[1440px]">
              {children ?? <Outlet />}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
