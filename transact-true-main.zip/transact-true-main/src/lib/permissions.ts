import { useRole } from "@/lib/role-context";
import type { Role } from "@/services/types";

/**
 * Central permission matrix.
 *
 * Every capability has an EXPLICIT entry for all four roles (admin, owner,
 * cashier, production) — no implicit `false`. UI components and route guards
 * read the same matrix via `usePermission()` / `roleCan()` so there is a single
 * source of truth for access decisions. Service-layer (audit-worthy) guards may
 * still check `role` explicitly where an extra defense-in-depth layer is needed.
 *
 * Naming convention:
 *   page.*   → access to a page/route
 *   action.* → a specific write/operation
 *   <domain>.<verb> → domain-scoped capability (existing baseline)
 */
export type Capability =
  // --- Existing baseline capabilities (admin-only actions) ---
  | "product.edit"
  | "product.delete"
  | "product.editPrice"
  | "product.create"
  | "sale.void"
  | "stock.adjust"
  | "packaging.manage"
  | "settings.manage"
  // --- Page access capabilities ---
  | "page.pos"
  | "page.shifts"
  | "page.pesanan"
  // --- Shift operation capabilities ---
  | "action.openShift"
  | "action.closeShift"
  | "shift.operate"
  | "shift.editExpense"
  | "shift.cashierNote"
  // --- Domain action capabilities (Sales) ---
  | "action.approveRefund"
  | "action.requestRefund"
  | "action.manageTarget";

const ROLES: Role[] = ["admin", "owner", "cashier", "production"];

/**
 * Full matrix — one explicit boolean per role for every capability.
 *
 * Business rules encoded here:
 *   admin      → full access (baseline preserved).
 *   owner      → Home/Dashboard only; no Sales operational pages or actions
 *                (no POS/Shift/Pesanan access).
 *   cashier    → daily operations (POS, Shift, Pesanan).
 *   production → scoped to Production & Inventory only; no Sales/POS/Shift/
 *                Pesanan/finance capability here.
 */
const MATRIX: Record<Capability, Record<Role, boolean>> = {
  // Existing baseline — admin-only actions.
  "product.edit": { admin: true, owner: false, cashier: false, production: false },
  "product.delete": { admin: true, owner: false, cashier: false, production: false },
  "product.editPrice": { admin: true, owner: false, cashier: false, production: false },
  "product.create": { admin: true, owner: false, cashier: false, production: false },
  "sale.void": { admin: true, owner: false, cashier: false, production: false },
  "stock.adjust": { admin: true, owner: false, cashier: false, production: false },
  "packaging.manage": { admin: true, owner: false, cashier: false, production: false },
  "settings.manage": { admin: true, owner: false, cashier: false, production: false },

  // Page access.
  // Owner is restricted to Home/Dashboard only — no Sales operational pages.
  "page.pos": { admin: true, owner: false, cashier: true, production: false },
  "page.shifts": { admin: true, owner: false, cashier: true, production: false },
  "page.pesanan": { admin: true, owner: false, cashier: true, production: false },

  // Shift operations (owner is read-only, production has no shift scope).
  "action.openShift": { admin: true, owner: false, cashier: true, production: false },
  "action.closeShift": { admin: true, owner: false, cashier: true, production: false },
  "shift.operate": { admin: true, owner: false, cashier: true, production: false },
  "shift.editExpense": { admin: true, owner: false, cashier: false, production: false },
  "shift.cashierNote": { admin: false, owner: false, cashier: true, production: false },

  // Sales domain actions.
  // Owner is intentionally excluded from POS/Shift/Pesanan pages (see page.*),
  // so refund approval is granted to admin only; if owner gains read-only access
  // to /sales/pesanan in the future, flip owner → true here.
  "action.approveRefund": { admin: true, owner: false, cashier: false, production: false },
  "action.requestRefund": { admin: true, owner: false, cashier: true, production: false },
  "action.manageTarget": { admin: true, owner: false, cashier: false, production: false },
};

export function roleCan(role: Role | null, cap: Capability): boolean {
  if (!role) return false;
  return MATRIX[cap]?.[role] ?? false;
}

export function usePermission() {
  const { role } = useRole();
  return {
    role,
    can: (cap: Capability) => roleCan(role, cap),
  };
}

/**
 * Route → required capability map for the generic root route guard.
 * A path matches when it equals the key or is nested beneath it. Routes not
 * listed here fall back to the navigation-based visibility check.
 */
const ROUTE_CAPABILITIES: { prefix: string; cap: Capability }[] = [
  { prefix: "/sales/pos", cap: "page.pos" },
  { prefix: "/sales/shifts", cap: "page.shifts" },
  { prefix: "/sales/pesanan", cap: "page.pesanan" },
];

/** The capability required to access a given path, if any. */
export function capabilityForPath(path: string): Capability | null {
  const match = ROUTE_CAPABILITIES.find(
    (r) => path === r.prefix || path.startsWith(r.prefix + "/"),
  );
  return match?.cap ?? null;
}

/** True when the role is allowed to access the path per the matrix. */
export function canAccessPath(role: Role | null, path: string): boolean {
  const cap = capabilityForPath(path);
  if (!cap) return true; // not a capability-guarded route
  return roleCan(role, cap);
}

export { ROLES };
