import { useEffect, useMemo, useState } from "react";
import { getRouteApi, useNavigate } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageShell, PageHeader } from "@/components/app/page-shell";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { salesService } from "@/services/sales.service";
import { queueService, QUEUE_STATUS_LABEL, type QueueOrder } from "@/services/queue.service";
import { refundService, REFUND_STATUS_LABEL, type RefundRequest } from "@/services/refund.service";
import { preorderService } from "@/services/preorder.service";
import { whatsappService } from "@/services/whatsapp.service";
import { SOURCE_ORDER_LABEL, SOURCE_ORDER_LIST, type Sale, type SourceOrder } from "@/services/types";
import { useRole } from "@/lib/role-context";
import { usePermission } from "@/lib/permissions";
import { formatIDR, formatDateTime } from "@/lib/format";
import { formatPaymentSummary } from "@/lib/payment";
import { printSaleReceipt } from "@/features/pos/invoice-receipt";
import {
  CheckCircle2,
  ListChecks,
  MessageCircle,
  MoreHorizontal,
  Play,
  Printer,
  RotateCcw,
  Search,
  ShoppingBag,
  Sparkles,
  User,
  XCircle,
} from "lucide-react";
import { PreorderPanel } from "./preorder-page";

const pesananRouteApi = getRouteApi("/_app/sales/pesanan");

type OuterTab = "pesanan" | "preorder";

type PesananStatus = "baru" | "diproses" | "selesai" | "refund";

interface UnifiedOrder {
  sale: Sale;
  queue?: QueueOrder;
  refund?: RefundRequest;
  status: PesananStatus;
}

const STATUS_LABEL: Record<PesananStatus, string> = {
  baru: "Baru",
  diproses: "Diproses",
  selesai: "Selesai",
  refund: "Refund",
};

// Soft, premium status tokens — light tint + subtle border.
const STATUS_PILL: Record<PesananStatus, string> = {
  baru: "bg-sky-50 text-sky-700 border-sky-200",
  diproses: "bg-amber-50 text-amber-800 border-amber-200",
  selesai: "bg-emerald-50 text-emerald-700 border-emerald-200",
  refund: "bg-rose-50 text-rose-700 border-rose-200",
};

const STATUS_DOT: Record<PesananStatus, string> = {
  baru: "bg-sky-500",
  diproses: "bg-amber-500",
  selesai: "bg-emerald-500",
  refund: "bg-rose-500",
};

const STATUS_TINT: Record<PesananStatus, string> = {
  baru: "bg-sky-50 text-sky-600 ring-sky-100",
  diproses: "bg-amber-50 text-amber-600 ring-amber-100",
  selesai: "bg-emerald-50 text-emerald-600 ring-emerald-100",
  refund: "bg-rose-50 text-rose-600 ring-rose-100",
};

// The four queue milestones we render in the vertical timeline.
const TIMELINE_STEPS: { key: "baru" | "diproses" | "siap" | "selesai"; label: string; sub: string }[] = [
  { key: "baru", label: "Baru", sub: "Pesanan dibuat" },
  { key: "diproses", label: "Diproses", sub: "Menunggu diproses" },
  { key: "siap", label: "Siap", sub: "Menunggu siap diambil" },
  { key: "selesai", label: "Selesai", sub: "Selesai diambil pelanggan" },
];

function deriveStatus(sale: Sale, queue: QueueOrder | undefined, refund: RefundRequest | undefined): PesananStatus {
  if (sale.voided || refund?.status === "approved") return "refund";
  if (!queue) return "selesai";
  if (queue.status === "waiting") return "baru";
  if (queue.status === "completed") return "selesai";
  return "diproses";
}

function isSameDay(iso: string, day: string): boolean {
  if (!day) return true;
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}` === day;
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function timeOnly(iso: string) {
  return new Date(iso).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

// Map an order's derived status + queue.status onto our fixed timeline steps
// so we can render "done / current / pending" dots.
function stepStateFor(o: UnifiedOrder, key: "baru" | "diproses" | "siap" | "selesai"): "done" | "current" | "pending" {
  if (o.sale.voided || o.refund?.status === "approved") {
    // Refund path: show whatever milestones did happen as done, rest pending.
    if (key === "baru") return "done";
    return "pending";
  }
  const qStatus = o.queue?.status;
  const order: Record<string, number> = {
    waiting: 0,
    cooking: 1,
    packing: 1,
    ready: 2,
    completed: 3,
  };
  const idx: Record<string, number> = { baru: 0, diproses: 1, siap: 2, selesai: 3 };
  const current = qStatus ? order[qStatus] : 3;
  const stepIdx = idx[key];
  if (stepIdx < current) return "done";
  if (stepIdx === current) return "current";
  return "pending";
}

export function PesananPage() {
  const { role, profile, user } = useRole();
  const { can } = usePermission();
  const actor = profile?.full_name ?? user?.email ?? "Operator";
  // Sourced from central MATRIX (Finding B): no manual role === "..." checks.
  const canApproveRefund = can("action.approveRefund");
  const canRequestRefund = can("action.requestRefund");

  const search = pesananRouteApi.useSearch();
  const navigate = useNavigate({ from: "/sales/pesanan" });
  const outerTab: OuterTab = search.tab === "preorder" ? "preorder" : "pesanan";
  const setOuterTab = (next: OuterTab) => {
    navigate({
      search: (prev: { tab?: OuterTab }) => ({
        ...prev,
        tab: next === "preorder" ? "preorder" : undefined,
      }),
      replace: true,
    });
  };

  const [rows, setRows] = useState<UnifiedOrder[]>([]);
  const [tab, setTab] = useState<PesananStatus | "all">("all");
  const [dateFilter, setDateFilter] = useState<string>(todayKey());
  const [marketplaceFilter, setMarketplaceFilter] = useState<string>("all");
  const [outletFilter, setOutletFilter] = useState<string>("all");
  const [kasirFilter, setKasirFilter] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [preorderBadge, setPreorderBadge] = useState(0);
  useEffect(() => {
    const compute = () => {
      try {
        setPreorderBadge(preorderService.countActive());
      } catch {
        setPreorderBadge(0);
      }
    };
    compute();
    const onChanged = () => compute();
    window.addEventListener("desalut:preorders-changed", onChanged);
    const iv = setInterval(compute, 30_000);
    return () => {
      window.removeEventListener("desalut:preorders-changed", onChanged);
      clearInterval(iv);
    };
  }, []);

  const [refundOpen, setRefundOpen] = useState(false);
  const [refundReason, setRefundReason] = useState("");
  const [approveTarget, setApproveTarget] = useState<RefundRequest | null>(null);
  const [approveNote, setApproveNote] = useState("");

  function refresh() {
    const sales = salesService.list();
    const queues = queueService.list();
    const queueBySale = new Map(queues.map((q) => [q.saleId, q]));
    const refunds = refundService.list();
    const refundBySale = new Map<string, RefundRequest>();
    for (const r of refunds) {
      const existing = refundBySale.get(r.saleId);
      if (!existing || new Date(r.requestedAt) > new Date(existing.requestedAt)) {
        refundBySale.set(r.saleId, r);
      }
    }
    const unified: UnifiedOrder[] = sales.map((sale) => {
      const queue = queueBySale.get(sale.id);
      const refund = refundBySale.get(sale.id);
      return { sale, queue, refund, status: deriveStatus(sale, queue, refund) };
    });
    setRows(unified);
  }

  useEffect(() => {
    refresh();
    const iv = setInterval(refresh, 8000);
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(iv);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  const kasirOptions = useMemo(() => {
    const set = new Set<string>();
    for (const r of rows) set.add(r.sale.cashier);
    return Array.from(set);
  }, [rows]);

  const outletOptions = useMemo(() => {
    const set = new Set<string>();
    for (const r of rows) if (r.sale.outletId) set.add(r.sale.outletId);
    return Array.from(set);
  }, [rows]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows
      .filter((r) => {
        if (tab !== "all" && r.status !== tab) return false;
        if (!isSameDay(r.sale.createdAt, dateFilter)) return false;
        if (marketplaceFilter !== "all" && (r.sale.sourceOrder ?? "outlet") !== marketplaceFilter) return false;
        if (outletFilter !== "all" && r.sale.outletId !== outletFilter) return false;
        if (kasirFilter !== "all" && r.sale.cashier !== kasirFilter) return false;
        if (!q) return true;
        const s = r.sale;
        const hay = [
          s.orderNumber,
          s.id,
          s.customerName,
          s.customerPhone,
          ...s.items.map((i) => i.name),
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        return hay.includes(q);
      })
      .sort((a, b) => new Date(b.sale.createdAt).getTime() - new Date(a.sale.createdAt).getTime());
  }, [rows, tab, dateFilter, marketplaceFilter, outletFilter, kasirFilter, query]);

  const counts = useMemo(() => {
    const c: Record<PesananStatus | "all", number> = {
      all: 0,
      baru: 0,
      diproses: 0,
      selesai: 0,
      refund: 0,
    };
    for (const r of rows) {
      if (!isSameDay(r.sale.createdAt, dateFilter)) continue;
      if (marketplaceFilter !== "all" && (r.sale.sourceOrder ?? "outlet") !== marketplaceFilter) continue;
      if (outletFilter !== "all" && r.sale.outletId !== outletFilter) continue;
      if (kasirFilter !== "all" && r.sale.cashier !== kasirFilter) continue;
      c.all++;
      c[r.status]++;
    }
    return c;
  }, [rows, dateFilter, marketplaceFilter, outletFilter, kasirFilter]);

  // Auto-select first order in current filter view.
  useEffect(() => {
    if (filtered.length === 0) {
      setSelectedId(null);
      return;
    }
    if (!selectedId || !filtered.find((o) => o.sale.id === selectedId)) {
      setSelectedId(filtered[0].sale.id);
    }
  }, [filtered, selectedId]);

  const detail = useMemo(
    () => rows.find((r) => r.sale.id === selectedId) ?? null,
    [rows, selectedId],
  );

  function openRefund(o: UnifiedOrder) {
    setSelectedId(o.sale.id);
    setRefundReason("");
    setRefundOpen(true);
  }

  function advanceQueue(o: UnifiedOrder) {
    if (!o.queue) {
      toast.error("Antrean produksi tidak ditemukan");
      return;
    }
    const before = o.queue.status;
    const next = queueService.advance(o.queue.id, actor);
    if (!next || next.status === before) {
      toast.info("Status sudah final");
      return;
    }
    toast.success(`Status: ${QUEUE_STATUS_LABEL[before]} → ${QUEUE_STATUS_LABEL[next.status]}`);
    refresh();
    const tpl = whatsappService.templateForQueueStatus(next.status);
    if (tpl && o.sale.customerName) {
      const link = whatsappService.buildLink(tpl, {
        phone: (o.sale as { customerPhone?: string }).customerPhone,
        customerName: o.sale.customerName,
        orderNumber: o.sale.orderNumber,
        actor,
        entity: "sale",
        entityId: o.sale.id,
      });
      if ("url" in link) {
        window.open(link.url, "_blank", "noopener");
      }
    }
  }

  function sendWhatsApp(o: UnifiedOrder) {
    let tpl: ReturnType<typeof whatsappService.templateForQueueStatus> | "void" | "refund" | null =
      o.queue ? whatsappService.templateForQueueStatus(o.queue.status) : null;
    let extra: { total?: number } = {};
    if (!tpl) {
      if (o.refund?.status === "approved") {
        tpl = "refund";
        extra.total = o.sale.total;
      } else if (o.sale.voided) {
        tpl = "void";
      }
    }
    if (!tpl) {
      toast.error("Notifikasi WA baru bisa dikirim saat status Siap/Selesai/Void/Refund");
      return;
    }
    const link = whatsappService.buildLink(tpl, {
      phone: (o.sale as { customerPhone?: string }).customerPhone,
      customerName: o.sale.customerName,
      orderNumber: o.sale.orderNumber,
      actor,
      entity: "sale",
      entityId: o.sale.id,
      ...extra,
    });
    if ("error" in link) {
      toast.error(link.error);
      return;
    }
    window.open(link.url, "_blank", "noopener");
  }

  function submitRefundRequest() {
    if (!detail) return;
    if (!refundReason.trim()) {
      toast.error("Isi alasan refund");
      return;
    }
    refundService.request({
      saleId: detail.sale.id,
      reason: refundReason.trim(),
      actor,
      actorRole: role ?? undefined,
    });
    toast.success("Pengajuan refund dikirim, menunggu approval Owner");
    setRefundOpen(false);
    refresh();
  }

  function approveRefund() {
    if (!approveTarget) return;
    const result = refundService.approve(approveTarget.id, {
      actor,
      actorRole: role ?? undefined,
      note: approveNote.trim() || undefined,
    });
    if (!result.ok) {
      toast.error(result.reason);
      setApproveTarget(null);
      setApproveNote("");
      refresh();
      return;
    }
    toast.success("Refund disetujui — stok, antrean, dan packaging dikembalikan");
    const sale = salesService.list().find((s) => s.id === approveTarget.saleId);
    if (sale && (sale as { customerPhone?: string }).customerPhone) {
      const link = whatsappService.buildLink("refund", {
        phone: (sale as { customerPhone?: string }).customerPhone,
        customerName: sale.customerName,
        orderNumber: sale.orderNumber,
        total: sale.total,
        actor,
        entity: "sale",
        entityId: sale.id,
      });
      if ("url" in link) window.open(link.url, "_blank", "noopener");
    }
    setApproveTarget(null);
    setApproveNote("");
    refresh();
  }

  function rejectRefund() {
    if (!approveTarget) return;
    refundService.reject(approveTarget.id, {
      actor,
      actorRole: role ?? undefined,
      note: approveNote.trim() || undefined,
    });
    toast.success("Pengajuan refund ditolak");
    setApproveTarget(null);
    setApproveNote("");
    refresh();
  }

  function reprint(o: UnifiedOrder) {
    if (!printSaleReceipt(o.sale, true)) {
      toast.error("Popup diblokir browser");
    }
  }

  function resetFilters() {
    setDateFilter(todayKey());
    setMarketplaceFilter("all");
    setOutletFilter("all");
    setKasirFilter("all");
    setQuery("");
    setTab("all");
  }

  // ============= KPI cards =============
  const kpiCards: { key: PesananStatus | "all"; label: string; sub: string; icon: React.ReactNode; tint: string }[] = [
    {
      key: "all",
      label: "Semua Pesanan",
      sub: "Total hari ini",
      icon: <ShoppingBag className="h-5 w-5" />,
      tint: "bg-primary/8 text-primary ring-primary/15",
    },
    {
      key: "baru",
      label: "Baru",
      sub: "Menunggu diproses",
      icon: <Sparkles className="h-5 w-5" />,
      tint: STATUS_TINT.baru,
    },
    {
      key: "diproses",
      label: "Diproses",
      sub: "Sedang dikerjakan",
      icon: <Play className="h-5 w-5" />,
      tint: STATUS_TINT.diproses,
    },
    {
      key: "selesai",
      label: "Selesai",
      sub: "Selesai diambil",
      icon: <CheckCircle2 className="h-5 w-5" />,
      tint: STATUS_TINT.selesai,
    },
    {
      key: "refund",
      label: "Refund",
      sub: "Dibatalkan / refund",
      icon: <RotateCcw className="h-5 w-5" />,
      tint: STATUS_TINT.refund,
    },
  ];

  return (
    <PageShell maxWidth="screen-2xl">
      <PageHeader
        breadcrumb={["Sales", "Pesanan"]}
        title="Pusat Pesanan"
        description="Kelola semua aktivitas order reguler dan pre-order dalam satu ruang kerja."
        actions={
          <Tabs value={outerTab} onValueChange={(v) => setOuterTab(v as OuterTab)}>
            <TabsList className="h-10 rounded-full bg-muted/70 p-1">
              <TabsTrigger value="pesanan" className="rounded-full px-4 text-sm">
                Pesanan
              </TabsTrigger>
              <TabsTrigger value="preorder" className="rounded-full px-4 text-sm">
                Pre Order
                {preorderBadge > 0 && (
                  <Badge className="ml-2 h-5 px-1.5 text-[10px] tabular-nums">{preorderBadge}</Badge>
                )}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        }
      />

      {outerTab === "preorder" ? (
        <PreorderPanel />
      ) : (
        <>
          {/* ============= KPI CARDS ============= */}
          <section className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
            {kpiCards.map((k) => {
              const active = tab === k.key;
              const count = counts[k.key];
              return (
                <button
                  key={k.key}
                  type="button"
                  onClick={() => setTab(k.key)}
                  className={`group relative flex flex-col items-start gap-3 rounded-2xl border bg-card p-5 text-left shadow-[0_1px_2px_rgba(24,20,16,0.04)] transition-all duration-150 hover:-translate-y-0.5 hover:shadow-[0_10px_30px_-12px_rgba(107,24,24,0.18)] ${
                    active
                      ? "border-primary/40 ring-2 ring-primary/15"
                      : "border-border/60 hover:border-border"
                  }`}
                >
                  <div className="flex w-full items-start justify-between">
                    <span
                      className={`inline-flex h-10 w-10 items-center justify-center rounded-xl ring-1 ${k.tint}`}
                    >
                      {k.icon}
                    </span>
                    {active && (
                      <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-primary">
                        Aktif
                      </span>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-muted-foreground">{k.label}</div>
                    <div className="mt-1 font-display text-3xl font-semibold tabular-nums leading-none text-foreground">
                      {count}
                    </div>
                    <div className="mt-1.5 text-[11px] text-muted-foreground/80">{k.sub}</div>
                  </div>
                </button>
              );
            })}
          </section>

          {/* ============= FILTER BAR ============= */}
          <section className="rounded-2xl border border-border/60 bg-card p-4 shadow-[0_1px_2px_rgba(24,20,16,0.04)] md:p-5">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-12 md:items-end">
              <div className="md:col-span-4">
                <Label className="mb-1.5 block text-[11px] uppercase tracking-wider text-muted-foreground">
                  Cari
                </Label>
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Cari pelanggan, no. invoice, produk…"
                    className="h-10 rounded-xl border-border/60 bg-background pl-9"
                  />
                </div>
              </div>
              <div className="md:col-span-2">
                <Label className="mb-1.5 block text-[11px] uppercase tracking-wider text-muted-foreground">
                  Tanggal
                </Label>
                <Input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="h-10 rounded-xl"
                />
              </div>
              <div className="md:col-span-2">
                <Label className="mb-1.5 block text-[11px] uppercase tracking-wider text-muted-foreground">
                  Outlet
                </Label>
                <Select value={outletFilter} onValueChange={setOutletFilter}>
                  <SelectTrigger className="h-10 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Outlet</SelectItem>
                    {outletOptions.map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2">
                <Label className="mb-1.5 block text-[11px] uppercase tracking-wider text-muted-foreground">
                  Marketplace
                </Label>
                <Select value={marketplaceFilter} onValueChange={setMarketplaceFilter}>
                  <SelectTrigger className="h-10 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Sumber</SelectItem>
                    {SOURCE_ORDER_LIST.map((s) => (
                      <SelectItem key={s} value={s}>
                        {SOURCE_ORDER_LABEL[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2 md:flex md:items-end md:gap-2">
                <div className="min-w-0 flex-1">
                  <Label className="mb-1.5 block text-[11px] uppercase tracking-wider text-muted-foreground">
                    Kasir
                  </Label>
                  <Select value={kasirFilter} onValueChange={setKasirFilter}>
                    <SelectTrigger className="h-10 rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Kasir</SelectItem>
                      {kasirOptions.map((k) => (
                        <SelectItem key={k} value={k}>
                          {k}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  variant="ghost"
                  className="h-10 shrink-0 rounded-xl px-3 text-muted-foreground hover:text-foreground"
                  onClick={resetFilters}
                >
                  <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
                  Reset
                </Button>
              </div>
            </div>
          </section>

          {/* ============= WORKSPACE: LIST + DETAIL ============= */}
          <section className="grid grid-cols-1 gap-6 xl:grid-cols-12 xl:items-start">
            {/* ---- Order List ---- */}
            <div className="xl:col-span-7">
              <div className="flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card shadow-[0_1px_2px_rgba(24,20,16,0.04)]">
                {/* List header with segmented filter */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 px-5 py-4">
                  <Tabs value={tab} onValueChange={(v) => setTab(v as PesananStatus | "all")}>
                    <TabsList className="h-9 rounded-full bg-muted/70 p-1">
                      <TabsTrigger value="all" className="rounded-full px-3 text-xs">
                        Semua <span className="ml-1.5 tabular-nums text-muted-foreground">{counts.all}</span>
                      </TabsTrigger>
                      <TabsTrigger value="baru" className="rounded-full px-3 text-xs">
                        Baru <span className="ml-1.5 tabular-nums text-muted-foreground">{counts.baru}</span>
                      </TabsTrigger>
                      <TabsTrigger value="diproses" className="rounded-full px-3 text-xs">
                        Diproses <span className="ml-1.5 tabular-nums text-muted-foreground">{counts.diproses}</span>
                      </TabsTrigger>
                    </TabsList>
                  </Tabs>
                  <div className="text-xs text-muted-foreground">
                    Menampilkan{" "}
                    <span className="font-semibold text-foreground tabular-nums">{filtered.length}</span> pesanan
                  </div>
                </div>

                {/* Table header (desktop) */}
                <div className="hidden grid-cols-[minmax(0,1.6fr)_minmax(0,1.4fr)_minmax(0,1fr)_auto] gap-4 border-b border-border/60 bg-muted/30 px-5 py-2.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground md:grid">
                  <span>Order</span>
                  <span>Pelanggan · Outlet</span>
                  <span className="text-right">Total</span>
                  <span className="w-24 text-right">Waktu</span>
                </div>

                {/* List body */}
                <div className="flex max-h-[720px] flex-col divide-y divide-border/50 overflow-y-auto">
                  {filtered.length === 0 && (
                    <div className="flex flex-col items-center justify-center gap-3 px-6 py-20 text-center">
                      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                        <ListChecks className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div>
                        <div className="text-base font-semibold">Belum ada pesanan</div>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Tidak ada pesanan pada filter ini. Coba ubah tanggal atau reset filter.
                        </p>
                      </div>
                    </div>
                  )}
                  {filtered.map((o) => {
                    const isActive = selectedId === o.sale.id;
                    return (
                      <button
                        key={o.sale.id}
                        type="button"
                        onClick={() => setSelectedId(o.sale.id)}
                        className={`group relative grid grid-cols-1 gap-1 px-5 py-4 text-left transition-colors duration-150 hover:bg-accent/40 md:grid-cols-[minmax(0,1.6fr)_minmax(0,1.4fr)_minmax(0,1fr)_auto] md:items-center md:gap-4 ${
                          isActive ? "bg-primary/5" : ""
                        }`}
                      >
                        {isActive && (
                          <span className="absolute inset-y-2 left-0 w-1 rounded-r-full bg-primary" />
                        )}
                        {/* Col 1: Order id + status */}
                        <div className="flex min-w-0 flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-bold tabular-nums text-foreground">
                              {o.sale.orderNumber ?? "—"}
                            </span>
                            <Badge
                              variant="outline"
                              className={`gap-1 px-1.5 py-0 text-[10px] font-medium ${STATUS_PILL[o.status]}`}
                            >
                              <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[o.status]}`} />
                              {STATUS_LABEL[o.status]}
                            </Badge>
                          </div>
                          <span className="truncate font-mono text-[10px] text-muted-foreground/80">
                            {o.sale.id}
                          </span>
                        </div>
                        {/* Col 2: Customer + outlet */}
                        <div className="flex min-w-0 flex-col gap-0.5">
                          <span className="truncate text-sm font-medium text-foreground">
                            {o.sale.customerName ?? "Pelanggan Umum"}
                          </span>
                          <span className="truncate text-xs text-muted-foreground">
                            {SOURCE_ORDER_LABEL[(o.sale.sourceOrder ?? "outlet") as SourceOrder]}
                            {o.sale.outletId ? ` · ${o.sale.outletId}` : ""}
                          </span>
                        </div>
                        {/* Col 3: Total */}
                        <div className="flex min-w-0 flex-col text-left md:text-right">
                          <span className="font-semibold tabular-nums text-foreground">
                            {formatIDR(o.sale.total)}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {o.sale.items.length} item
                          </span>
                        </div>
                        {/* Col 4: Time */}
                        <div className="flex w-24 min-w-0 flex-col text-left md:text-right">
                          <span className="text-xs font-medium text-foreground">
                            {timeOnly(o.sale.createdAt)}
                          </span>
                          <span className="text-[10px] text-muted-foreground">Hari ini</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* ---- Order Detail ---- */}
            <div className="xl:col-span-5">
              <OrderDetailPanel
                detail={detail}
                canApproveRefund={canApproveRefund}
                canRequestRefund={canRequestRefund}
                onAdvance={advanceQueue}
                onReprint={reprint}
                onSendWhatsApp={sendWhatsApp}
                onRequestRefund={openRefund}
                onReviewRefund={(r) => setApproveTarget(r)}
              />
            </div>
          </section>

          {/* ============= DIALOGS ============= */}
          <Dialog open={refundOpen} onOpenChange={setRefundOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Ajukan Refund</DialogTitle>
                <DialogDescription>
                  Pengajuan akan ditinjau dan disetujui oleh Owner sebelum refund efektif.
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-2">
                <Label>Alasan</Label>
                <Textarea
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  placeholder="Contoh: Customer membatalkan pesanan"
                  rows={4}
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setRefundOpen(false)}>
                  Batal
                </Button>
                <Button onClick={submitRefundRequest}>Kirim Pengajuan</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={!!approveTarget} onOpenChange={(v) => !v && setApproveTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Review Pengajuan Refund</DialogTitle>
                <DialogDescription>
                  Sale {approveTarget?.saleId} · Alasan: {approveTarget?.reason}
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-2">
                <Label>Catatan (opsional)</Label>
                <Textarea
                  value={approveNote}
                  onChange={(e) => setApproveNote(e.target.value)}
                  rows={3}
                />
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setApproveTarget(null)}>
                  Tutup
                </Button>
                <Button variant="destructive" onClick={rejectRefund}>
                  <XCircle className="mr-1 h-4 w-4" /> Tolak
                </Button>
                <Button onClick={approveRefund}>
                  <CheckCircle2 className="mr-1 h-4 w-4" /> Setujui Refund
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      )}
    </PageShell>
  );
}

// ================================================================
// Order Detail Panel — sticky right column, aligned with list top.
// ================================================================
function OrderDetailPanel({
  detail,
  canRequestRefund,
  canApproveRefund,
  onAdvance,
  onReprint,
  onSendWhatsApp,
  onRequestRefund,
  onReviewRefund,
}: {
  detail: UnifiedOrder | null;
  canRequestRefund: boolean;
  canApproveRefund: boolean;
  onAdvance: (o: UnifiedOrder) => void;
  onReprint: (o: UnifiedOrder) => void;
  onSendWhatsApp: (o: UnifiedOrder) => void;
  onRequestRefund: (o: UnifiedOrder) => void;
  onReviewRefund: (r: RefundRequest) => void;
}) {
  if (!detail) {
    return (
      <div className="flex h-full min-h-[520px] flex-col items-center justify-center rounded-2xl border border-dashed border-border/60 bg-card/50 p-10 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
          <ShoppingBag className="h-6 w-6 text-muted-foreground" />
        </div>
        <div className="mt-4 text-base font-semibold text-foreground">Pilih pesanan</div>
        <p className="mt-1 max-w-xs text-sm text-muted-foreground">
          Pilih salah satu pesanan di kiri untuk melihat detail, timeline, dan aksi cepat.
        </p>
      </div>
    );
  }

  const s = detail.sale;
  const canAdvance = !!detail.queue && detail.queue.status !== "completed" && !s.voided;
  const primaryLabel = detail.queue
    ? detail.queue.status === "waiting"
      ? "Proses Pesanan"
      : detail.queue.status === "cooking"
        ? "Lanjut ke Packing"
        : detail.queue.status === "packing"
          ? "Tandai Siap"
          : detail.queue.status === "ready"
            ? "Selesaikan"
            : "Selesai"
    : "Selesai";

  return (
    <aside className="sticky top-6 flex flex-col overflow-hidden rounded-2xl border border-border/60 bg-card shadow-[0_1px_2px_rgba(24,20,16,0.04)]">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 border-b border-border/60 px-5 py-4">
        <div className="min-w-0">
          <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Detail Pesanan
          </div>
          <div className="mt-1 flex items-center gap-2">
            <h2 className="font-display text-xl font-semibold tabular-nums text-foreground">
              {s.orderNumber ?? "—"}
            </h2>
            <Badge variant="outline" className={`gap-1 ${STATUS_PILL[detail.status]}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[detail.status]}`} />
              {STATUS_LABEL[detail.status]}
            </Badge>
          </div>
          <div className="mt-1 font-mono text-[11px] text-muted-foreground/80">{s.id}</div>
        </div>
        <div className="text-right text-xs text-muted-foreground">
          <div>{formatDateTime(s.createdAt)}</div>
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex max-h-[640px] flex-col gap-5 overflow-y-auto p-5">
        {/* Customer info */}
        <section>
          <SectionTitle icon={<User className="h-3.5 w-3.5" />}>Informasi Pelanggan</SectionTitle>
          <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-3 rounded-xl border border-border/50 bg-muted/30 p-4 text-sm">
            <Field label="Nama">{s.customerName ?? "Pelanggan Umum"}</Field>
            <Field label="No. HP">{s.customerPhone ?? "—"}</Field>
            <Field label="Sumber">
              {SOURCE_ORDER_LABEL[(s.sourceOrder ?? "outlet") as SourceOrder]}
            </Field>
            <Field label="Outlet">{s.outletId ?? "—"}</Field>
            <Field label="Kasir">{s.cashier}</Field>
            <Field label="Tipe">
              <span className="capitalize">{s.customerType ?? "end user"}</span>
            </Field>
          </div>
        </section>

        {/* Items */}
        <section>
          <SectionTitle icon={<ShoppingBag className="h-3.5 w-3.5" />}>
            Item Pesanan ({s.items.length})
          </SectionTitle>
          <ul className="mt-2 divide-y divide-border/50 rounded-xl border border-border/50">
            {s.items.map((i, idx) => (
              <li key={idx} className="flex items-center justify-between gap-3 px-4 py-2.5 text-sm">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/8 text-xs font-semibold tabular-nums text-primary">
                    {i.qty}×
                  </span>
                  <div className="min-w-0">
                    <div className="truncate font-medium text-foreground">{i.name}</div>
                    <div className="text-xs text-muted-foreground tabular-nums">
                      {formatIDR(i.price)}
                    </div>
                  </div>
                </div>
                <span className="shrink-0 text-sm font-medium tabular-nums text-foreground">
                  {formatIDR(i.price * i.qty)}
                </span>
              </li>
            ))}
          </ul>
        </section>

        {/* Payment */}
        <section>
          <SectionTitle>Ringkasan Pembayaran</SectionTitle>
          <dl className="mt-2 space-y-2 rounded-xl border border-border/50 bg-muted/30 p-4 text-sm">
            <div className="flex justify-between text-muted-foreground">
              <dt>Subtotal</dt>
              <dd className="tabular-nums text-foreground">{formatIDR(s.subtotal)}</dd>
            </div>
            {s.discount > 0 && (
              <div className="flex justify-between text-muted-foreground">
                <dt>Diskon</dt>
                <dd className="tabular-nums text-destructive">- {formatIDR(s.discount)}</dd>
              </div>
            )}
            <div className="border-t border-border/50 pt-2" />
            <div className="flex items-center justify-between">
              <dt className="text-sm font-semibold text-foreground">Total</dt>
              <dd className="font-display text-lg font-bold tabular-nums text-primary">
                {formatIDR(s.total)}
              </dd>
            </div>
            <div className="flex justify-between pt-1 text-xs text-muted-foreground">
              <dt>Metode Pembayaran</dt>
              <dd className="font-medium text-foreground">{formatPaymentSummary(s)}</dd>
            </div>
          </dl>
        </section>

        {/* Timeline */}
        <section>
          <SectionTitle icon={<ListChecks className="h-3.5 w-3.5" />}>Timeline Status</SectionTitle>
          <ol className="mt-3 space-y-1">
            {TIMELINE_STEPS.map((step, idx) => {
              const state = stepStateFor(detail, step.key);
              const isLast = idx === TIMELINE_STEPS.length - 1;
              return (
                <li key={step.key} className="relative flex gap-3 pb-3">
                  {!isLast && (
                    <span
                      aria-hidden
                      className={`absolute left-[7px] top-4 h-full w-px ${
                        state === "done" ? "bg-primary/50" : "bg-border"
                      }`}
                    />
                  )}
                  <span
                    className={`relative mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-full ring-4 ring-card ${
                      state === "done"
                        ? "bg-primary"
                        : state === "current"
                          ? "bg-primary/25 outline outline-2 outline-primary"
                          : "bg-border"
                    }`}
                  >
                    {state === "done" && (
                      <CheckCircle2 className="h-2.5 w-2.5 text-primary-foreground" />
                    )}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div
                      className={`text-sm font-medium ${
                        state === "pending" ? "text-muted-foreground" : "text-foreground"
                      }`}
                    >
                      {step.label}
                    </div>
                    <div className="text-xs text-muted-foreground">{step.sub}</div>
                  </div>
                </li>
              );
            })}
          </ol>
        </section>

        {/* Notes / Refund info */}
        {detail.refund && (
          <section>
            <SectionTitle>Catatan Refund</SectionTitle>
            <div className="mt-2 rounded-xl border border-amber-200 bg-amber-50/70 p-4 text-xs text-amber-900">
              <div className="font-semibold">
                Status: {REFUND_STATUS_LABEL[detail.refund.status]}
              </div>
              <div className="mt-1">Alasan: {detail.refund.reason}</div>
              <div className="mt-1 text-amber-800/80">
                Diajukan {formatDateTime(detail.refund.requestedAt)} oleh {detail.refund.requestedBy}
              </div>
              {detail.refund.decidedAt && (
                <div className="text-amber-800/80">
                  Diputuskan {formatDateTime(detail.refund.decidedAt)} oleh {detail.refund.decidedBy}
                  {detail.refund.decisionNote ? ` · ${detail.refund.decisionNote}` : ""}
                </div>
              )}
            </div>
          </section>
        )}
      </div>

      {/* Actions footer */}
      <div className="flex flex-wrap items-center gap-2 border-t border-border/60 bg-muted/20 px-5 py-4">
        <Button
          variant="ghost"
          size="sm"
          className="h-9 rounded-lg text-muted-foreground hover:text-foreground"
          onClick={() => onReprint(detail)}
        >
          <Printer className="mr-1.5 h-3.5 w-3.5" /> Cetak
        </Button>
        {canRequestRefund && !s.voided && !detail.refund && (
          <Button
            variant="ghost"
            size="sm"
            className="h-9 rounded-lg text-muted-foreground hover:text-foreground"
            onClick={() => onRequestRefund(detail)}
          >
            <RotateCcw className="mr-1.5 h-3.5 w-3.5" /> Refund
          </Button>
        )}
        {detail.queue && (detail.queue.status === "ready" || detail.queue.status === "completed") && !s.voided && (
          <Button
            variant="ghost"
            size="sm"
            className="h-9 rounded-lg text-emerald-700 hover:bg-emerald-50 hover:text-emerald-800"
            onClick={() => onSendWhatsApp(detail)}
          >
            <MessageCircle className="mr-1.5 h-3.5 w-3.5" /> WA
          </Button>
        )}
        {(s.voided || detail.refund?.status === "approved") && s.customerPhone && (
          <Button
            variant="ghost"
            size="sm"
            className="h-9 rounded-lg text-rose-700 hover:bg-rose-50 hover:text-rose-800"
            onClick={() => onSendWhatsApp(detail)}
          >
            <MessageCircle className="mr-1.5 h-3.5 w-3.5" /> WA {detail.refund?.status === "approved" ? "Refund" : "Void"}
          </Button>
        )}
        <div className="ml-auto flex items-center gap-2">
          {canApproveRefund && detail.refund?.status === "pending" ? (
            <Button
              size="sm"
              className="h-10 rounded-xl bg-gradient-to-r from-primary to-primary-deep px-5 text-primary-foreground shadow-[0_6px_18px_-6px_rgba(107,24,24,0.55)] transition-transform hover:shadow-[0_10px_22px_-6px_rgba(107,24,24,0.55)] active:scale-[0.98]"
              onClick={() => onReviewRefund(detail.refund!)}
            >
              Review Refund
            </Button>
          ) : canAdvance ? (
            <Button
              size="sm"
              className="h-10 rounded-xl bg-gradient-to-r from-primary to-primary-deep px-5 text-primary-foreground shadow-[0_6px_18px_-6px_rgba(107,24,24,0.55)] transition-transform hover:shadow-[0_10px_22px_-6px_rgba(107,24,24,0.55)] active:scale-[0.98]"
              onClick={() => onAdvance(detail)}
            >
              <Play className="mr-1.5 h-3.5 w-3.5" /> {primaryLabel}
            </Button>
          ) : (
            <Button
              size="sm"
              variant="outline"
              className="h-10 rounded-xl px-5"
              disabled
            >
              <MoreHorizontal className="mr-1.5 h-3.5 w-3.5" /> Selesai
            </Button>
          )}
        </div>
      </div>
    </aside>
  );
}

function SectionTitle({
  children,
  icon,
}: {
  children: React.ReactNode;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
      {icon}
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className="mt-0.5 truncate text-sm font-medium text-foreground">{children}</div>
    </div>
  );
}
