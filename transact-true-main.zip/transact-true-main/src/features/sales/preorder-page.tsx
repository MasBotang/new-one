import { useEffect, useMemo, useState } from "react";
import { addMonths, format, isSameDay, isSameMonth, startOfMonth, startOfWeek, endOfMonth, endOfWeek, addDays } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { NumberInput } from "@/components/ui/number-input";
import { ChevronLeft, ChevronRight, Trash2, CheckCircle2, PlayCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { preorderService } from "@/services/preorder.service";
import { salesService } from "@/services/sales.service";
import { shiftService } from "@/services/shift.service";
import { queueService } from "@/services/queue.service";
import {
  PREORDER_STATUS_LABEL,
  SOURCE_ORDER_LABEL,
  type PreOrder,
  type PreOrderStatus,
  type PaymentMethod,
  type PaymentEntry,
} from "@/services/types";
import { formatIDR } from "@/lib/format";
import { useRole } from "@/lib/role-context";

function toKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const STATUS_TONE: Record<PreOrderStatus, string> = {
  scheduled: "bg-slate-500/10 text-slate-700 border-slate-500/20",
  ready_to_process: "bg-blue-500/10 text-blue-700 border-blue-500/20",
  completed: "bg-emerald-500/10 text-emerald-700 border-emerald-500/20",
  cancelled: "bg-muted text-muted-foreground border-transparent",
};

/**
 * Panel Pre Order — dirender sebagai tab di dalam halaman Pesanan.
 * Tetap menggunakan preorderService dan lifecycle yang sudah ada; tidak
 * ada perubahan business logic. Untuk kompatibilitas import lama, alias
 * `PreorderPage` diekspor sebagai komponen yang sama.
 */
export function PreorderPanel() {
  const { profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "User";
  const [cursor, setCursor] = useState<Date>(startOfMonth(new Date()));
  const [rows, setRows] = useState<PreOrder[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  function refresh() {
    setRows(preorderService.list());
  }
  useEffect(refresh, []);
  useEffect(() => {
    const onChanged = () => refresh();
    window.addEventListener("desalut:preorders-changed", onChanged);
    return () => window.removeEventListener("desalut:preorders-changed", onChanged);
  }, []);

  const monthStart = startOfMonth(cursor);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const gridEnd = endOfWeek(endOfMonth(monthStart), { weekStartsOn: 1 });
  const days: Date[] = [];
  for (let d = gridStart; d <= gridEnd; d = addDays(d, 1)) days.push(d);

  const byDate = useMemo(() => {
    const m = new Map<string, PreOrder[]>();
    for (const p of rows) {
      const arr = m.get(p.date) ?? [];
      arr.push(p);
      m.set(p.date, arr);
    }
    return m;
  }, [rows]);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Monitoring pesanan mendatang. Pembuatan Pre Order baru dilakukan melalui POS (Kasir).
        </p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setCursor(addMonths(cursor, -1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="min-w-[140px] text-center text-sm font-semibold">
            {format(cursor, "MMMM yyyy")}
          </div>
          <Button variant="outline" size="sm" onClick={() => setCursor(addMonths(cursor, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>


      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-7 gap-1 text-xs">
            {["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map((d) => (
              <div key={d} className="py-2 text-center font-medium text-muted-foreground">
                {d}
              </div>
            ))}
            {days.map((d) => {
              const key = toKey(d);
              const list = byDate.get(key) ?? [];
              const inMonth = isSameMonth(d, monthStart);
              const isToday = isSameDay(d, new Date());
              const active = list.filter((p) => p.status !== "cancelled" && p.status !== "completed").length;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSelectedDate(d)}
                  className={`flex min-h-[80px] flex-col items-start gap-1 rounded-md border p-2 text-left transition hover:border-primary/40 ${
                    inMonth ? "bg-card" : "bg-muted/30 text-muted-foreground"
                  } ${isToday ? "border-primary" : ""}`}
                >
                  <span className="text-xs font-semibold">{d.getDate()}</span>
                  {active > 0 && (
                    <Badge variant="secondary" className="text-[10px]">
                      {active} PO
                    </Badge>
                  )}
                  {list.slice(0, 2).map((p) => (
                    <span key={p.id} className="line-clamp-1 w-full text-[10px] text-muted-foreground">
                      {p.time} · {p.customerName}
                    </span>
                  ))}
                  {list.length > 2 && (
                    <span className="text-[10px] text-muted-foreground">
                      +{list.length - 2} lagi
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Sheet open={!!selectedDate} onOpenChange={(o) => !o && setSelectedDate(null)}>
        <SheetContent className="flex flex-col gap-4 sm:max-w-lg">
          <SheetHeader>
            <SheetTitle>
              Pre Order · {selectedDate ? format(selectedDate, "d MMMM yyyy") : ""}
            </SheetTitle>
          </SheetHeader>
          {selectedDate && (
            <DayList
              date={selectedDate}
              items={byDate.get(toKey(selectedDate)) ?? []}
              actor={actor}
              onChanged={refresh}
            />
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

/** @deprecated Route lama; halaman ini kini dilebur ke tab di /sales/pesanan. */
export const PreorderPage = PreorderPanel;

function DayList({
  date,
  items,
  actor,
  onChanged,
}: {
  date: Date;
  items: PreOrder[];
  actor: string;
  onChanged: () => void;
}) {
  const ordered = [...items].sort((a, b) => a.time.localeCompare(b.time));
  const numberOf = new Map<string, number>();
  ordered.forEach((p, i) => numberOf.set(p.id, i + 1));
  // Sprint 5: dialog pelunasan.
  const [settlePo, setSettlePo] = useState<PreOrder | null>(null);
  const [settleMethod, setSettleMethod] = useState<PaymentMethod>("cash");
  const [settleTendered, setSettleTendered] = useState<number>(0);
  const [settleBusy, setSettleBusy] = useState(false);
  function markReady(id: string) {
    preorderService.setStatus(id, "ready_to_process");
    toast.success("Ditandai siap diproses");
    onChanged();
  }
  function cancel(id: string) {
    preorderService.setStatus(id, "cancelled");
    toast.success("Pre Order dibatalkan");
    onChanged();
  }
  function remove(id: string) {
    preorderService.remove(id);
    toast.success("Pre Order dihapus");
    onChanged();
  }
  function requestComplete(po: PreOrder) {
    const subtotal = po.items.reduce((a, i) => a + i.price * i.qty, 0);
    const remaining = po.remainingBalance ?? subtotal;
    if (remaining > 0) {
      setSettleMethod(po.dpMethod ?? "cash");
      setSettleTendered(remaining);
      setSettlePo(po);
      return;
    }
    // Sudah lunas via DP → lanjut Complete tanpa dialog. Seluruh subtotal
    // sudah tercakup di DP; kirim satu entry DP dengan amount = subtotal.
    const dpMethod = po.dpMethod ?? "cash";
    finalizeComplete(po, [{ method: dpMethod, amount: subtotal }]);
  }
  function finalizeComplete(po: PreOrder, payment: PaymentEntry[]) {
    const shift = shiftService.current();
    if (!shift) {
      toast.error("Buka shift dulu untuk menyelesaikan Pre Order");
      return;
    }
    const subtotal = po.items.reduce((a, i) => a + i.price * i.qty, 0);
    // Sprint 8: Sale.total SELALU = subtotal penuh order (bukan
    // remainingBalance, yang sudah 0 setelah payDp()). Payment breakdown
    // dipasok eksplisit oleh caller (requestComplete / confirmSettle) supaya
    // mencerminkan kapan/bagaimana uang benar-benar diterima.
    const paidSum = payment.reduce((a, e) => a + (e.amount || 0), 0);
    if (paidSum !== subtotal) {
      console.error("[preorder] finalizeComplete: payment sum mismatch", {
        preorderId: po.id,
        subtotal,
        paidSum,
        payment,
      });
      toast.error("Data pembayaran tidak konsisten — batal menyimpan");
      return;
    }
    const sale = salesService.create({
      cashier: actor,
      customerName: po.customerName,
      shiftId: shift.id,
      items: po.items,
      subtotal,
      discount: 0,
      total: subtotal,
      payment,
      saleType: po.saleType ?? "frozen",
      customerType: po.sourceOrder === "reseller" ? "reseller" : "end_user",
      isPreorder: true,
      customerPhone: po.customerPhone,
      pickupAt: new Date(`${po.date}T${po.time}:00`).toISOString(),
      sourceOrder: po.sourceOrder,
      priceGroupId: po.priceGroupId,
      preorderId: po.id,
    });
    // Sprint 3 (Finding #3B): relink Queue yang dibuat di promoteDue() dari
    // placeholder saleId=po.id ke sale.id yang baru. Wajib dilakukan SEBELUM
    // proses Complete dianggap selesai supaya deriveStatus() & canRefund()
    // menemukan Queue yang benar. Queue tidak dibuat ulang — hanya di-update.
    if (po.queueId) {
      try {
        const relinked = queueService.relinkSale(po.queueId, sale.id);
        if (!relinked) {
          console.warn("[preorder] complete → queue not found for relink", {
            preorderId: po.id,
            queueId: po.queueId,
            saleId: sale.id,
          });
        }
      } catch (err) {
        console.error("[preorder] complete → queue relink failed", err);
      }
    }
    preorderService.update(po.id, { status: "completed", saleId: sale.id });
    toast.success("Pre Order selesai & tercatat sebagai Sale");
    onChanged();
  }
  function confirmSettle() {
    if (!settlePo) return;
    const subtotal = settlePo.items.reduce((a, i) => a + i.price * i.qty, 0);
    // Tangkap sisa pelunasan SEBELUM payDp() memutasinya jadi 0.
    const remaining = settlePo.remainingBalance ?? subtotal;
    if (settleMethod === "cash" && (settleTendered || 0) < remaining) {
      toast.error("Uang tunai kurang dari sisa pelunasan");
      return;
    }
    setSettleBusy(true);
    try {
      const dpAmount = settlePo.downPayment ?? 0;
      const dpMethod = settlePo.dpMethod ?? "cash";
      // Catat pelunasan DP di service (audit + update dpPaidAt).
      preorderService.payDp(settlePo.id, remaining, {
        actor,
        method: settleMethod,
      });
      const fresh = preorderService.byId(settlePo.id) ?? settlePo;
      // Bangun payment breakdown dari nilai yang ditangkap SEBELUM payDp():
      // entry DP (kalau ada) + entry pelunasan saat ini. Jumlahnya harus
      // pas dengan subtotal (divalidasi di finalizeComplete).
      const payment: PaymentEntry[] =
        dpAmount > 0
          ? [
              { method: dpMethod, amount: dpAmount },
              { method: settleMethod, amount: remaining },
            ]
          : [{ method: settleMethod, amount: subtotal }];
      finalizeComplete(fresh, payment);
      setSettlePo(null);
    } finally {
      setSettleBusy(false);
    }
  }

  void date;
  const settleRemaining = settlePo ? settlePo.remainingBalance ?? settlePo.total : 0;
  const settleDp = settlePo?.downPayment ?? 0;
  return (
    <div className="flex flex-col gap-3 px-4">
      {items.length === 0 && (
        <p className="py-10 text-center text-sm text-muted-foreground">
          Belum ada Pre Order. Buat melalui POS (Kasir).
        </p>
      )}
      {ordered.map((p) => (
        <div key={p.id} className="flex flex-col gap-2 rounded-lg border p-3 text-sm">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex h-6 min-w-[2rem] items-center justify-center rounded-md bg-primary/10 px-1.5 font-mono text-xs font-bold text-primary">
                  #{String(numberOf.get(p.id) ?? 0).padStart(3, "0")}
                </span>
                <span className="font-medium">{p.time} · {p.customerName}</span>
                {(p.downPayment ?? 0) > 0 && (
                  <Badge
                    variant="outline"
                    className="border-amber-500/30 bg-amber-500/10 text-[10px] font-semibold text-amber-700"
                  >
                    DP {formatIDR(p.downPayment ?? 0)}
                  </Badge>
                )}
              </div>
              {p.customerPhone && (
                <div className="text-xs text-muted-foreground">{p.customerPhone}</div>
              )}
            </div>
            <Badge variant="outline" className={STATUS_TONE[p.status]}>
              {PREORDER_STATUS_LABEL[p.status]}
            </Badge>
          </div>
          <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
            {p.items.map((i) => (
              <div key={i.productId} className="flex justify-between">
                <span>{i.qty}× {i.name}</span>
                <span className="tabular-nums">{formatIDR(i.price * i.qty)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">{SOURCE_ORDER_LABEL[p.sourceOrder]}</span>
            <span className="font-semibold tabular-nums">{formatIDR(p.total)}</span>
          </div>
          {(p.downPayment ?? 0) > 0 && (
            <div className="flex justify-between text-[11px]">
              <span className="text-muted-foreground">Sisa Pelunasan</span>
              <span className="font-semibold tabular-nums text-amber-700">
                {formatIDR(p.remainingBalance ?? p.total)}
              </span>
            </div>
          )}
          {p.notes && <div className="text-xs italic text-muted-foreground">"{p.notes}"</div>}
          {p.status !== "completed" && p.status !== "cancelled" && (
            <div className="flex flex-wrap gap-1.5">
              {p.status === "scheduled" && (
                <Button size="sm" variant="outline" onClick={() => markReady(p.id)}>
                  <PlayCircle className="h-3.5 w-3.5" /> Siap Diproses
                </Button>
              )}
              <Button size="sm" onClick={() => requestComplete(p)}>
                <CheckCircle2 className="h-3.5 w-3.5" /> Selesaikan
              </Button>
              <Button size="sm" variant="ghost" onClick={() => cancel(p.id)}>
                <XCircle className="h-3.5 w-3.5" /> Batal
              </Button>
            </div>
          )}
          {(p.status === "cancelled" || p.status === "completed") && (
            <Button size="sm" variant="ghost" onClick={() => remove(p.id)} className="w-fit">
              <Trash2 className="h-3.5 w-3.5 text-destructive" /> Hapus
            </Button>
          )}
        </div>
      ))}

      <Dialog open={!!settlePo} onOpenChange={(o) => !o && !settleBusy && setSettlePo(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Pelunasan Pre Order</DialogTitle>
          </DialogHeader>
          {settlePo && (
            <div className="flex flex-col gap-4">
              <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-center">
                <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Sisa Pelunasan
                </div>
                <div className="mt-0.5 text-3xl font-bold tabular-nums text-primary">
                  {formatIDR(settleRemaining)}
                </div>
              </div>
              <dl className="grid grid-cols-2 gap-y-1 text-sm">
                <dt className="text-muted-foreground">Total Order</dt>
                <dd className="text-right tabular-nums">{formatIDR(settlePo.total)}</dd>
                <dt className="text-muted-foreground">DP Terbayar</dt>
                <dd className="text-right tabular-nums text-emerald-600">
                  {formatIDR(settleDp)}
                </dd>
                <dt className="font-medium">Harus Dibayar</dt>
                <dd className="text-right font-semibold tabular-nums">
                  {formatIDR(settleRemaining)}
                </dd>
              </dl>
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Metode Pelunasan
                </Label>
                <div className="grid grid-cols-4 gap-2">
                  {(["cash", "qris", "card", "transfer"] as PaymentMethod[]).map((m) => {
                    const active = settleMethod === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setSettleMethod(m)}
                        className={`rounded-lg border px-2 py-2 text-xs font-semibold uppercase transition ${
                          active
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border/70 bg-card text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {m}
                      </button>
                    );
                  })}
                </div>
              </div>
              {settleMethod === "cash" && (
                <div className="flex flex-col gap-2">
                  <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                    Uang Diterima
                  </Label>
                  <NumberInput
                    min={0}
                    value={settleTendered}
                    onChange={setSettleTendered}
                    className="h-11 text-lg font-bold tabular-nums"
                  />
                  <div className="flex justify-between rounded-md border px-3 py-2 text-sm">
                    <span className="text-muted-foreground">
                      {(settleTendered || 0) < settleRemaining ? "Kekurangan" : "Kembalian"}
                    </span>
                    <span className="font-semibold tabular-nums">
                      {formatIDR(Math.abs((settleTendered || 0) - settleRemaining))}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter className="gap-2 sm:justify-between">
            <Button
              variant="outline"
              onClick={() => setSettlePo(null)}
              disabled={settleBusy}
            >
              Batal
            </Button>
            <Button
              onClick={confirmSettle}
              disabled={
                settleBusy ||
                (settleMethod === "cash" && (settleTendered || 0) < settleRemaining)
              }
              className="min-w-[10rem]"
            >
              {settleBusy ? "Memproses…" : `Bayar · ${formatIDR(settleRemaining)}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
