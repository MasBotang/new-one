import { useEffect, useMemo, useRef, useState } from "react";
import {
  Plus,
  Trash2,
  Pencil,
  Search,
  ImageIcon,
  Upload,
  RefreshCw,
  AlertTriangle,
  PackageX,
  Package,
  CheckCircle2,
  PackageOpen,
  SlidersHorizontal,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { PageShell, PageHeader, StatCard } from "@/components/app/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { productService } from "@/services/product.service";
import { priceGroupService } from "@/services/price-group.service";
import type { PriceGroup, Product } from "@/services/types";
import { formatIDR } from "@/lib/format";
import { toast } from "sonner";
import { usePermission } from "@/lib/permissions";

const DEFAULT_CATEGORIES = ["Kopi", "Teh", "Pastry", "Makanan", "Minuman", "Lainnya"];
const CUSTOM_CATEGORY = "__custom__";

function emptyProduct(): Product {
  return {
    id: `p_${Date.now()}`,
    name: "",
    category: "Kopi",
    sku: "",
    price: 0,
    cost: 0,
    stock: 0,
    minStock: 5,
    imageUrl: "",
    active: true,
  };
}

function stockStatus(p: Product) {
  const stock = p.stock ?? 0;
  const min = p.minStock ?? 0;
  if (stock <= 0) return { label: "Habis", tone: "destructive" as const };
  if (min > 0 && stock <= min) return { label: "Stok Menipis", tone: "warning" as const };
  return { label: "Tersedia", tone: "ok" as const };
}

export function ProductsPage() {
  const { can } = usePermission();
  const canEdit = can("product.edit");
  const canDelete = can("product.delete");
  const canEditPrice = can("product.editPrice");
  const canCreate = can("product.create");
  const [products, setProducts] = useState<Product[]>([]);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive" | "low" | "out">("all");
  const [editing, setEditing] = useState<Product | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [customCategory, setCustomCategory] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<Product | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [priceGroups, setPriceGroups] = useState<PriceGroup[]>([]);

  function refresh() {
    setProducts(productService.list());
    setPriceGroups(priceGroupService.list());
  }
  useEffect(refresh, []);

  const categories = useMemo(() => {
    const set = new Set<string>([...DEFAULT_CATEGORIES, ...productService.categories()]);
    return Array.from(set);
  }, [products]);

  const filtered = products.filter((p) => {
    const q = query.toLowerCase();
    const matchQ =
      !q ||
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.sku ?? "").toLowerCase().includes(q);
    const matchC = categoryFilter === "all" || p.category === categoryFilter;
    const s = stockStatus(p);
    const matchS =
      statusFilter === "all" ||
      (statusFilter === "active" && p.active) ||
      (statusFilter === "inactive" && !p.active) ||
      (statusFilter === "low" && s.tone === "warning") ||
      (statusFilter === "out" && s.tone === "destructive");
    return matchQ && matchC && matchS;
  });

  const stats = useMemo(() => {
    const total = products.length;
    const active = products.filter((p) => p.active).length;
    const low = products.filter((p) => {
      const s = stockStatus(p);
      return s.tone === "warning";
    }).length;
    const out = products.filter((p) => (p.stock ?? 0) <= 0).length;
    const inventoryValue = products.reduce(
      (acc, p) => acc + (p.cost ?? 0) * (p.stock ?? 0),
      0,
    );
    return { total, active, low, out, inventoryValue };
  }, [products]);

  function openNew() {
    const draft = emptyProduct();
    draft.sku = productService.generateSku(draft.category);
    setEditing(draft);
    setIsNew(true);
    setCustomCategory("");
  }

  function openEdit(p: Product) {
    setEditing({ ...p });
    setIsNew(false);
    setCustomCategory(DEFAULT_CATEGORIES.includes(p.category) ? "" : p.category);
  }

  function onCategoryChange(value: string) {
    if (!editing) return;
    if (value === CUSTOM_CATEGORY) {
      setCustomCategory(editing.category && !DEFAULT_CATEGORIES.includes(editing.category) ? editing.category : "");
      return;
    }
    const next = { ...editing, category: value };
    if (isNew) next.sku = productService.generateSku(value);
    setEditing(next);
    setCustomCategory("");
  }

  function regenerateSku() {
    if (!editing) return;
    setEditing({ ...editing, sku: productService.generateSku(editing.category) });
  }

  function onFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !editing) return;
    if (file.size > 1_500_000) {
      toast.error("Ukuran gambar maks 1.5 MB");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setEditing((cur) => (cur ? { ...cur, imageUrl: String(reader.result) } : cur));
    };
    reader.readAsDataURL(file);
  }

  function save() {
    if (!editing) return;
    const finalCategory = customCategory.trim() || editing.category;
    if (!editing.name.trim()) {
      toast.error("Nama produk wajib diisi");
      return;
    }
    if (!finalCategory) {
      toast.error("Kategori wajib diisi");
      return;
    }
    if (editing.price < 0 || editing.cost < 0) {
      toast.error("Harga tidak boleh negatif");
      return;
    }
    const toSave: Product = {
      ...editing,
      category: finalCategory,
      sku: editing.sku || productService.generateSku(finalCategory),
      stock: editing.stock ?? 0,
      minStock: editing.minStock ?? 0,
    };
    productService.upsert(toSave);
    refresh();
    setEditing(null);
    toast.success(isNew ? "Produk berhasil ditambahkan" : "Produk berhasil diperbarui");
  }

  function remove() {
    if (!confirmDelete) return;
    productService.remove(confirmDelete.id);
    refresh();
    setConfirmDelete(null);
    toast.success("Produk dihapus");
  }

  const margin = editing
    ? editing.price > 0
      ? Math.round(((editing.price - editing.cost) / editing.price) * 100)
      : 0
    : 0;

  const hasNoProducts = products.length === 0;

  return (
    <PageShell>
        <PageHeader
          breadcrumb={["Sales", "Produk"]}
          title="Katalog Produk"
          description="Kelola produk yang digunakan oleh Kasir, Produksi, Inventaris, dan Laporan dalam satu workspace."
        />

        {/* Business Summary */}
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard icon={<Package className="h-3.5 w-3.5" />} label="Total Produk" value={stats.total} hint="Semua produk di katalog" />
          <StatCard icon={<CheckCircle2 className="h-3.5 w-3.5" />} label="Produk Aktif" value={stats.active} hint={`${stats.total - stats.active} nonaktif`} tone="ok" />
          <StatCard icon={<AlertTriangle className="h-3.5 w-3.5" />} label="Stok Menipis" value={stats.low} hint="Perlu restock segera" tone="warn" />
          <StatCard icon={<PackageX className="h-3.5 w-3.5" />} label="Stok Habis" value={stats.out} hint="Tidak dapat dijual" tone="danger" />
        </section>

        {/* Action Toolbar */}
        <div className="rounded-[20px] border border-black/[0.04] bg-card p-3 shadow-[0_1px_2px_rgba(20,10,0,0.04),0_12px_32px_-16px_rgba(20,10,0,0.08)]">
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative min-w-[240px] flex-1">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari produk, SKU, barcode…"
                className="h-11 rounded-full border-transparent bg-[oklch(0.97_0.01_75)] pl-11 pr-4 text-sm shadow-none transition-colors focus-visible:border-transparent focus-visible:bg-background focus-visible:ring-2 focus-visible:ring-primary/20"
              />
            </div>
            <div className="hidden h-6 w-px bg-border/60 sm:block" />
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="h-11 w-[170px] rounded-full border-border/70 bg-background text-sm">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="h-3.5 w-3.5 text-muted-foreground" />
                  <SelectValue placeholder="Kategori" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Kategori</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
              <SelectTrigger className="h-11 w-[160px] rounded-full border-border/70 bg-background text-sm">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="active">Aktif</SelectItem>
                <SelectItem value="inactive">Nonaktif</SelectItem>
                <SelectItem value="low">Stok Menipis</SelectItem>
                <SelectItem value="out">Stok Habis</SelectItem>
              </SelectContent>
            </Select>
            <div className="ml-auto flex items-center gap-3">
              <span className="hidden text-xs font-medium text-muted-foreground sm:inline">
                {filtered.length} dari {stats.total} produk
              </span>
              {canCreate && (
                <Button
                  onClick={openNew}
                  className="h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-[0_6px_16px_-4px_oklch(0.42_0.12_25/0.35)] transition-all hover:bg-primary/95 hover:shadow-[0_8px_22px_-4px_oklch(0.42_0.12_25/0.45)] active:scale-[0.98]"
                >
                  <Plus className="h-4 w-4" /> Tambah Produk
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Product Table */}
        <div className="overflow-hidden rounded-[20px] border border-black/[0.04] bg-card shadow-[0_1px_2px_rgba(20,10,0,0.04),0_12px_32px_-16px_rgba(20,10,0,0.08)]">
          {hasNoProducts ? (
            <EmptyState onCreate={canCreate ? openNew : undefined} />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-border/40 hover:bg-transparent">
                    <TableHead className="h-12 px-6 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">Produk</TableHead>
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">Kategori</TableHead>
                    <TableHead className="text-right text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">Harga</TableHead>
                    <TableHead className="text-right text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">Stok</TableHead>
                    <TableHead className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">Status</TableHead>
                    <TableHead className="w-[100px] pr-6 text-right text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.length === 0 && (
                    <TableRow className="hover:bg-transparent">
                      <TableCell colSpan={6} className="py-16 text-center">
                        <div className="mx-auto flex max-w-sm flex-col items-center gap-2">
                          <div className="grid h-12 w-12 place-items-center rounded-full bg-muted text-muted-foreground">
                            <Search className="h-5 w-5" />
                          </div>
                          <div className="text-sm font-medium text-foreground">Tidak ada hasil</div>
                          <p className="text-xs text-muted-foreground">
                            Coba ubah kata kunci atau reset filter di atas.
                          </p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                  {filtered.map((p) => {
                    const s = stockStatus(p);
                    return (
                      <TableRow
                        key={p.id}
                        className={cn(
                          "group border-b border-border/30 transition-colors duration-150 last:border-0 hover:bg-[oklch(0.985_0.008_75)]",
                          !p.active && "opacity-60",
                        )}
                      >
                        <TableCell className="py-4 pl-6">
                          <div className="flex items-center gap-3.5">
                            <div className="h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-black/[0.04] bg-[oklch(0.96_0.012_75)] shadow-sm">
                              {p.imageUrl ? (
                                <img src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" />
                              ) : (
                                <div className="flex h-full w-full items-center justify-center text-muted-foreground/60">
                                  <ImageIcon className="h-4 w-4" strokeWidth={1.5} />
                                </div>
                              )}
                            </div>
                            <div className="min-w-0 flex-col">
                              <div className="truncate text-sm font-semibold text-foreground">{p.name || "Tanpa Nama"}</div>
                              <div className="mt-0.5 font-mono text-[11px] text-muted-foreground">
                                {p.sku ?? "—"}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center rounded-full bg-[oklch(0.96_0.012_75)] px-2.5 py-1 text-xs font-medium text-foreground/70">
                            {p.category}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex flex-col items-end leading-tight">
                            <span className="text-sm font-semibold tabular-nums text-foreground">{formatIDR(p.price)}</span>
                            <span className="text-[11px] tabular-nums text-muted-foreground">Modal {formatIDR(p.cost)}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <StockBadge stock={p.stock ?? 0} minStock={p.minStock ?? 0} tone={s.tone} />
                        </TableCell>
                        <TableCell>
                          <StatusChip active={p.active} stockTone={s.tone} stockLabel={s.label} />
                        </TableCell>
                        <TableCell className="pr-6 text-right">
                          <div className="flex items-center justify-end gap-1 opacity-70 transition-opacity group-hover:opacity-100">
                            {canEdit && (
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => openEdit(p)}
                                className="h-8 w-8 rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
                                aria-label="Edit"
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                            )}
                            {canDelete && (
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => setConfirmDelete(p)}
                                className="h-8 w-8 rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                                aria-label="Hapus"
                              >
                                <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
                              </Button>
                            )}
                            {!canEdit && !canDelete && (
                              <span className="text-xs text-muted-foreground">Lihat</span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{isNew ? "Tambah Produk" : "Edit Produk"}</DialogTitle>
            <DialogDescription>
              Lengkapi detail produk. SKU dibuat otomatis berdasarkan kategori.
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <div className="flex flex-col gap-6">
              {/* Image */}
              <section className="flex flex-col gap-3">
                <div className="text-sm font-medium">Foto Produk</div>
                <div className="flex gap-4">
                  <div className="h-28 w-28 shrink-0 overflow-hidden rounded-lg border bg-muted">
                    {editing.imageUrl ? (
                      <img src={editing.imageUrl} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                        <ImageIcon className="h-6 w-6" strokeWidth={1.5} />
                      </div>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col gap-2">
                    <div className="flex gap-2">
                      <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="h-4 w-4" /> Unggah
                      </Button>
                      {editing.imageUrl && (
                        <Button type="button" variant="ghost" size="sm" onClick={() => setEditing({ ...editing, imageUrl: "" })}>
                          Hapus
                        </Button>
                      )}
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={onFilePick}
                    />
                    <Input
                      placeholder="atau tempel URL gambar"
                      value={editing.imageUrl ?? ""}
                      onChange={(e) => setEditing({ ...editing, imageUrl: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">PNG/JPG, maks 1.5 MB.</p>
                  </div>
                </div>
              </section>

              <Separator />

              {/* Basic info */}
              <section className="flex flex-col gap-4">
                <div className="text-sm font-medium">Informasi Dasar</div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Nama Produk</Label>
                    <Input
                      value={editing.name}
                      onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                      placeholder="cth. Es Kopi Susu"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Kategori</Label>
                    <Select
                      value={customCategory ? CUSTOM_CATEGORY : editing.category}
                      onValueChange={onCategoryChange}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {categories.map((c) => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                        <SelectItem value={CUSTOM_CATEGORY}>+ Kategori baru…</SelectItem>
                      </SelectContent>
                    </Select>
                    {customCategory !== "" || editing.category === "" ? (
                      <Input
                        className="mt-1"
                        placeholder="Nama kategori baru"
                        value={customCategory}
                        onChange={(e) => setCustomCategory(e.target.value)}
                      />
                    ) : null}
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label className="flex items-center justify-between">
                      <span>SKU</span>
                      <span className="text-xs text-muted-foreground">otomatis</span>
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        className="font-mono"
                        value={editing.sku ?? ""}
                        onChange={(e) => setEditing({ ...editing, sku: e.target.value.toUpperCase() })}
                      />
                      <Button type="button" variant="outline" size="icon" onClick={regenerateSku} aria-label="Regenerate SKU">
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Status</Label>
                    <div className="flex h-9 items-center justify-between rounded-md border px-3">
                      <span className="text-sm">{editing.active ? "Produk Aktif" : "Nonaktif"}</span>
                      <Switch
                        checked={editing.active}
                        onCheckedChange={(v) => setEditing({ ...editing, active: v })}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">Produk nonaktif tidak muncul di Kasir.</p>
                  </div>
                </div>
              </section>

              <Separator />

              {/* Pricing */}
              <section className="flex flex-col gap-4">
                <div className="text-sm font-medium">Harga</div>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Modal</Label>
                    <NumberInput
                      min={0}
                      value={editing.cost}
                      onChange={(v) => setEditing({ ...editing, cost: v })}
                      disabled={!canEditPrice}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Jual</Label>
                    <NumberInput
                      min={0}
                      value={editing.price}
                      onChange={(v) => setEditing({ ...editing, price: v })}
                      disabled={!canEditPrice}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Margin</Label>
                    <div className="flex h-9 items-center rounded-md border bg-muted/40 px-3 text-sm tabular-nums">
                      {margin}% <span className="ml-2 text-xs text-muted-foreground">({formatIDR(Math.max(0, editing.price - editing.cost))})</span>
                    </div>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Reseller</Label>
                    <NumberInput
                      min={0}
                      value={editing.priceReseller ?? 0}
                      onChange={(v) => setEditing({ ...editing, priceReseller: v })}
                    />
                    <p className="text-xs text-muted-foreground">Dipakai bila kasir memilih tipe Reseller. Kosongkan (0) untuk memakai harga jual.</p>
                  </div>
                </div>
                {priceGroups.length > 0 && (
                  <div className="flex flex-col gap-3">
                    <div className="text-sm font-medium">Harga per Price Group</div>
                    <p className="text-xs text-muted-foreground">
                      Kosongkan (0) untuk memakai harga jual default. Sistem otomatis memakai harga grup ini
                      saat kasir memilih source order terkait.
                    </p>
                    <div className="grid gap-3 md:grid-cols-2">
                      {priceGroups.map((g) => (
                        <div key={g.id} className="flex flex-col gap-1.5">
                          <Label className="text-xs">
                            {g.name}{" "}
                            <span className="text-muted-foreground">
                              ({g.sources.join(", ") || "—"})
                            </span>
                          </Label>
                          <NumberInput
                            min={0}
                            value={editing.prices?.[g.id] ?? 0}
                            onChange={(v) =>
                              setEditing({
                                ...editing,
                                prices: { ...(editing.prices ?? {}), [g.id]: v },
                              })
                            }
                            disabled={!canEditPrice}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </section>

              <Separator />

              {/* Stock */}
              <section className="flex flex-col gap-4">
                <div className="text-sm font-medium">Stok</div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Quantity (Stok Saat Ini)</Label>
                    <NumberInput
                      min={0}
                      value={editing.stock ?? 0}
                      onChange={(v) => setEditing({ ...editing, stock: v })}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Minimum Stok</Label>
                    <NumberInput
                      min={0}
                      value={editing.minStock ?? 0}
                      onChange={(v) => setEditing({ ...editing, minStock: v })}
                    />
                    <p className="text-xs text-muted-foreground">Peringatan muncul saat stok ≤ angka ini.</p>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Sumber Stok</Label>
                    <Select
                      value={editing.stockSource ?? "freezer"}
                      onValueChange={(v) => setEditing({ ...editing, stockSource: v as "freezer" | "showcase" })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="freezer">Freezer (Frozen)</SelectItem>
                        <SelectItem value="showcase">Showcase (Matang)</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Menentukan lokasi stok saat penjualan.</p>
                  </div>
                </div>
              </section>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Batal</Button>
            <Button onClick={save}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus produk?</AlertDialogTitle>
            <AlertDialogDescription>
              "{confirmDelete?.name}" akan dihapus permanen dari katalog.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={remove}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PageShell>
  );
}

function StockBadge({
  stock,
  minStock,
  tone,
}: {
  stock: number;
  minStock: number;
  tone: "ok" | "warning" | "destructive";
}) {
  const styles =
    tone === "destructive"
      ? "bg-red-500/10 text-red-700 dark:text-red-400"
      : tone === "warning"
        ? "bg-amber-500/12 text-amber-700 dark:text-amber-400"
        : "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400";
  const dot =
    tone === "destructive" ? "bg-red-500" : tone === "warning" ? "bg-amber-500" : "bg-emerald-500";
  return (
    <div className="inline-flex flex-col items-end gap-0.5">
      <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums", styles)}>
        <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />
        {stock}
      </span>
      {minStock > 0 && (
        <span className="text-[10px] text-muted-foreground">min {minStock}</span>
      )}
    </div>
  );
}

function StatusChip({
  active,
  stockTone,
  stockLabel,
}: {
  active: boolean;
  stockTone: "ok" | "warning" | "destructive";
  stockLabel: string;
}) {
  if (!active) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
        <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/60" />
        Nonaktif
      </span>
    );
  }
  if (stockTone === "destructive") {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-red-500/10 px-2.5 py-1 text-xs font-medium text-red-700 dark:text-red-400">
        <span className="h-1.5 w-1.5 rounded-full bg-red-500" />
        {stockLabel}
      </span>
    );
  }
  if (stockTone === "warning") {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/12 px-2.5 py-1 text-xs font-medium text-amber-700 dark:text-amber-400">
        <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
        {stockLabel}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
      Aktif
    </span>
  );
}

function EmptyState({ onCreate }: { onCreate?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-5 px-6 py-20 text-center">
      <div className="relative">
        <div className="absolute inset-0 -z-10 rounded-full bg-primary/5 blur-2xl" />
        <div className="grid h-20 w-20 place-items-center rounded-3xl border border-black/[0.04] bg-gradient-to-br from-[oklch(0.97_0.015_75)] to-[oklch(0.94_0.02_70)] shadow-[0_1px_2px_rgba(20,10,0,0.04),0_20px_40px_-20px_rgba(20,10,0,0.2)]">
          <PackageOpen className="h-8 w-8 text-primary/70" strokeWidth={1.5} />
        </div>
      </div>
      <div className="flex max-w-sm flex-col gap-1.5">
        <div className="text-lg font-semibold text-foreground">Belum ada produk</div>
        <p className="text-sm text-muted-foreground">
          Tambahkan produk pertama untuk mulai berjualan di Kasir, Produksi, dan Inventaris.
        </p>
      </div>
      {onCreate && (
        <Button
          onClick={onCreate}
          className="h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-[0_6px_16px_-4px_oklch(0.42_0.12_25/0.35)] transition-all hover:bg-primary/95 active:scale-[0.98]"
        >
          <Plus className="h-4 w-4" /> Tambah Produk Pertama
        </Button>
      )}
    </div>
  );
}