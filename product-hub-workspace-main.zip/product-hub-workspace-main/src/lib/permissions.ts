import { useRole } from "@/lib/role-context";
import type { Role } from "@/services/types";

/**
 * Central permission matrix. Keep it small and readable — one rule per
 * capability. UI components read via `usePermission()`; service-layer
 * (audit-worthy) guards should still check `role` explicitly.
 */
export type Capability =
  | "product.edit"
  | "product.delete"
  | "product.editPrice"
  | "product.create"
  | "sale.void"
  | "stock.adjust"
  | "packaging.manage"
  | "settings.manage";

const MATRIX: Record<Capability, Role[]> = {
  "product.edit": ["admin"],
  "product.delete": ["admin"],
  "product.editPrice": ["admin"],
  "product.create": ["admin"],
  "sale.void": ["admin"],
  "stock.adjust": ["admin"],
  "packaging.manage": ["admin"],
  "settings.manage": ["admin"],
};

export function roleCan(role: Role | null, cap: Capability): boolean {
  if (!role) return false;
  return MATRIX[cap]?.includes(role) ?? false;
}

export function usePermission() {
  const { role } = useRole();
  return {
    role,
    can: (cap: Capability) => roleCan(role, cap),
  };
}