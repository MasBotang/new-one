import { useEffect, useMemo, useState } from "react";
import { addMonths, format, isSameDay, isSameMonth, startOfMonth, startOfWeek, endOfMonth, endOfWeek, addDays } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { ChevronLeft, ChevronRight, Trash2, CheckCircle2, PlayCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { preorderService } from "@/services/preorder.service";
import { salesService } from "@/services/sales.service";
import { shiftService } from "@/services/shift.service";
import {
  PREORDER_STATUS_LABEL,
  SOURCE_ORDER_LABEL,
  type PreOrder,
  type PreOrderStatus,
} from "@/services/types";
import { formatIDR } from "@/lib/format";
import { useRole } from "@/lib/role-context";

function toKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const STATUS_TONE: Record<PreOrderStatus, string> = {
  scheduled: "bg-slate-500/10 text-slate-700 border-slate-500/20",
  ready_to_process: "bg-blue-500/10 text-blue-700 border-blue-500/20",
  completed: "bg-emerald-500/10 text-emerald-700 border-emerald-500/20",
  cancelled: "bg-muted text-muted-foreground border-transparent",
};

/**
 * Panel Pre Order — dirender sebagai tab di dalam halaman Pesanan.
 * Tetap menggunakan preorderService dan lifecycle yang sudah ada; tidak
 * ada perubahan business logic. Untuk kompatibilitas import lama, alias
 * `PreorderPage` diekspor sebagai komponen yang sama.
 */
export function PreorderPanel() {
  const { profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "User";
  const [cursor, setCursor] = useState<Date>(startOfMonth(new Date()));
  const [rows, setRows] = useState<PreOrder[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  function refresh() {
    setRows(preorderService.list());
  }
  useEffect(refresh, []);
  useEffect(() => {
    const onChanged = () => refresh();
    window.addEventListener("desalut:preorders-changed", onChanged);
    return () => window.removeEventListener("desalut:preorders-changed", onChanged);
  }, []);

  const monthStart = startOfMonth(cursor);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const gridEnd = endOfWeek(endOfMonth(monthStart), { weekStartsOn: 1 });
  const days: Date[] = [];
  for (let d = gridStart; d <= gridEnd; d = addDays(d, 1)) days.push(d);

  const byDate = useMemo(() => {
    const m = new Map<string, PreOrder[]>();
    for (const p of rows) {
      const arr = m.get(p.date) ?? [];
      arr.push(p);
      m.set(p.date, arr);
    }
    return m;
  }, [rows]);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Monitoring pesanan mendatang. Pembuatan Pre Order baru dilakukan melalui POS (Kasir).
        </p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setCursor(addMonths(cursor, -1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="min-w-[140px] text-center text-sm font-semibold">
            {format(cursor, "MMMM yyyy")}
          </div>
          <Button variant="outline" size="sm" onClick={() => setCursor(addMonths(cursor, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>


      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-7 gap-1 text-xs">
            {["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map((d) => (
              <div key={d} className="py-2 text-center font-medium text-muted-foreground">
                {d}
              </div>
            ))}
            {days.map((d) => {
              const key = toKey(d);
              const list = byDate.get(key) ?? [];
              const inMonth = isSameMonth(d, monthStart);
              const isToday = isSameDay(d, new Date());
              const active = list.filter((p) => p.status !== "cancelled" && p.status !== "completed").length;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSelectedDate(d)}
                  className={`flex min-h-[80px] flex-col items-start gap-1 rounded-md border p-2 text-left transition hover:border-primary/40 ${
                    inMonth ? "bg-card" : "bg-muted/30 text-muted-foreground"
                  } ${isToday ? "border-primary" : ""}`}
                >
                  <span className="text-xs font-semibold">{d.getDate()}</span>
                  {active > 0 && (
                    <Badge variant="secondary" className="text-[10px]">
                      {active} PO
                    </Badge>
                  )}
                  {list.slice(0, 2).map((p) => (
                    <span key={p.id} className="line-clamp-1 w-full text-[10px] text-muted-foreground">
                      {p.time} · {p.customerName}
                    </span>
                  ))}
                  {list.length > 2 && (
                    <span className="text-[10px] text-muted-foreground">
                      +{list.length - 2} lagi
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Sheet open={!!selectedDate} onOpenChange={(o) => !o && setSelectedDate(null)}>
        <SheetContent className="flex flex-col gap-4 sm:max-w-lg">
          <SheetHeader>
            <SheetTitle>
              Pre Order · {selectedDate ? format(selectedDate, "d MMMM yyyy") : ""}
            </SheetTitle>
          </SheetHeader>
          {selectedDate && (
            <DayList
              date={selectedDate}
              items={byDate.get(toKey(selectedDate)) ?? []}
              actor={actor}
              onChanged={refresh}
            />
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

/** @deprecated Route lama; halaman ini kini dilebur ke tab di /sales/pesanan. */
export const PreorderPage = PreorderPanel;

function DayList({
  date,
  items,
  actor,
  onChanged,
}: {
  date: Date;
  items: PreOrder[];
  actor: string;
  onChanged: () => void;
}) {
  const ordered = [...items].sort((a, b) => a.time.localeCompare(b.time));
  const numberOf = new Map<string, number>();
  ordered.forEach((p, i) => numberOf.set(p.id, i + 1));
  function markReady(id: string) {
    preorderService.setStatus(id, "ready_to_process");
    toast.success("Ditandai siap diproses");
    onChanged();
  }
  function cancel(id: string) {
    preorderService.setStatus(id, "cancelled");
    toast.success("Pre Order dibatalkan");
    onChanged();
  }
  function remove(id: string) {
    preorderService.remove(id);
    toast.success("Pre Order dihapus");
    onChanged();
  }
  function complete(po: PreOrder) {
    const shift = shiftService.current();
    if (!shift) {
      toast.error("Buka shift dulu untuk menyelesaikan Pre Order");
      return;
    }
    const subtotal = po.items.reduce((a, i) => a + i.price * i.qty, 0);
    const sale = salesService.create({
      cashier: actor,
      customerName: po.customerName,
      shiftId: shift.id,
      items: po.items,
      subtotal,
      discount: 0,
      total: subtotal,
      payment: "cash",
      saleType: po.saleType ?? "frozen",
      customerType: po.sourceOrder === "reseller" ? "reseller" : "end_user",
      isPreorder: true,
      customerPhone: po.customerPhone,
      pickupAt: new Date(`${po.date}T${po.time}:00`).toISOString(),
      sourceOrder: po.sourceOrder,
      priceGroupId: po.priceGroupId,
      preorderId: po.id,
    });
    preorderService.update(po.id, { status: "completed", saleId: sale.id });
    toast.success("Pre Order selesai & tercatat sebagai Sale");
    onChanged();
  }
  void date;
  return (
    <div className="flex flex-col gap-3 px-4">
      {items.length === 0 && (
        <p className="py-10 text-center text-sm text-muted-foreground">
          Belum ada Pre Order. Buat melalui POS (Kasir).
        </p>
      )}
      {ordered.map((p) => (
        <div key={p.id} className="flex flex-col gap-2 rounded-lg border p-3 text-sm">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex h-6 min-w-[2rem] items-center justify-center rounded-md bg-primary/10 px-1.5 font-mono text-xs font-bold text-primary">
                  #{String(numberOf.get(p.id) ?? 0).padStart(3, "0")}
                </span>
                <span className="font-medium">{p.time} · {p.customerName}</span>
              </div>
              {p.customerPhone && (
                <div className="text-xs text-muted-foreground">{p.customerPhone}</div>
              )}
            </div>
            <Badge variant="outline" className={STATUS_TONE[p.status]}>
              {PREORDER_STATUS_LABEL[p.status]}
            </Badge>
          </div>
          <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
            {p.items.map((i) => (
              <div key={i.productId} className="flex justify-between">
                <span>{i.qty}× {i.name}</span>
                <span className="tabular-nums">{formatIDR(i.price * i.qty)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">{SOURCE_ORDER_LABEL[p.sourceOrder]}</span>
            <span className="font-semibold tabular-nums">{formatIDR(p.total)}</span>
          </div>
          {p.notes && <div className="text-xs italic text-muted-foreground">"{p.notes}"</div>}
          {p.status !== "completed" && p.status !== "cancelled" && (
            <div className="flex flex-wrap gap-1.5">
              {p.status === "scheduled" && (
                <Button size="sm" variant="outline" onClick={() => markReady(p.id)}>
                  <PlayCircle className="h-3.5 w-3.5" /> Siap Diproses
                </Button>
              )}
              <Button size="sm" onClick={() => complete(p)}>
                <CheckCircle2 className="h-3.5 w-3.5" /> Selesaikan
              </Button>
              <Button size="sm" variant="ghost" onClick={() => cancel(p.id)}>
                <XCircle className="h-3.5 w-3.5" /> Batal
              </Button>
            </div>
          )}
          {(p.status === "cancelled" || p.status === "completed") && (
            <Button size="sm" variant="ghost" onClick={() => remove(p.id)} className="w-fit">
              <Trash2 className="h-3.5 w-3.5 text-destructive" /> Hapus
            </Button>
          )}
        </div>
      ))}
    </div>
  );
}
