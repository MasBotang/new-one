import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Minus,
  Plus,
  Search,
  Trash2,
  AlertTriangle,
  ImageIcon,
  CheckCircle2,
  Printer,
  PauseCircle,
  X,
  Snowflake,
  Flame,
  CalendarClock,
  Package,
  ArrowRight,
  LayoutGrid,
  Beef,
  Fish,
  Utensils,
  Salad,
  Cake,
  IceCream2,
  Coffee,
  Wine,
  ShoppingBag,
  Soup,
  Cookie,
  Sandwich,
  Pizza,
  User,
  Phone,
  StickyNote,
  Store,
  Receipt,
  Banknote,
  CreditCard,
  QrCode,
  Wallet,
  Keyboard,
  Bell,
  Sparkles,
  ShoppingBasket,
  ShoppingCart,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { productService } from "@/services/product.service";
import { salesService } from "@/services/sales.service";
import { shiftService } from "@/services/shift.service";
import { settingsService } from "@/services/settings.service";
import { holdService } from "@/services/hold.service";
import { priceGroupService } from "@/services/price-group.service";
import { preorderService, validatePickup, minPickupTimeFor, todayYmd } from "@/services/preorder.service";
import type {
  CustomerType,
  HoldOrder,
  PaymentMethod,
  Product,
  Sale,
  SaleItem,
  SaleType,
  SourceOrder,
  PriceGroup,
  SalePacking,
  SalePlastic,
  SaleExtraPackaging,
  InventoryItem,
} from "@/services/types";
import { SOURCE_ORDER_LABEL, SOURCE_ORDER_LIST } from "@/services/types";
import { useRole } from "@/lib/role-context";
import { formatIDR, formatDateTime, formatSalesId } from "@/lib/format";
import { printSaleReceipt } from "./invoice-receipt";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { inventoryService } from "@/services/inventory.service";
import {
  PLASTIC_OPTIONS,
  autoBoxName,
  autoBoxQty,
  buildAutoPacking,
  newPackingId,
  recomputePacking,
  resolvePackagingItem,
} from "@/services/packing";

interface CartLine extends SaleItem {}

function priceFor(p: Product, priceGroupId: string | undefined, customerType: CustomerType): number {
  const grouped = priceGroupService.priceFor(p, priceGroupId);
  if (grouped !== p.price) return grouped;
  // Fallback tambahan untuk back-compat reseller.
  if (customerType === "reseller" && p.priceReseller && p.priceReseller > 0) {
    return p.priceReseller;
  }
  return grouped;
}

/** Practical Indonesian cash denominations, ordered low → high. */
const QUICK_CASH = [500, 1000, 5000, 10000, 50000];

const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  cash: "Tunai",
  qris: "QRIS",
  card: "Kartu",
  transfer: "Transfer",
};

const PAYMENT_ICONS: Record<PaymentMethod, LucideIcon> = {
  cash: Banknote,
  qris: QrCode,
  card: CreditCard,
  transfer: Wallet,
};

/** Map category names to a matching Lucide icon. Falls back to LayoutGrid. */
function iconForCategory(name: string): LucideIcon {
  const n = name.toLowerCase();
  if (n === "semua" || n === "all") return LayoutGrid;
  if (/(daging|beef|sapi|ayam|chicken|meat)/.test(n)) return Beef;
  if (/(ikan|fish|seafood|udang|cumi)/.test(n)) return Fish;
  if (/(sayur|salad|veg|greens)/.test(n)) return Salad;
  if (/(sup|soup|kuah)/.test(n)) return Soup;
  if (/(nasi|rice|main|utama|paket)/.test(n)) return Utensils;
  if (/(kue|cake|dessert|manis|pastry)/.test(n)) return Cake;
  if (/(cookie|biskuit|snack|cemilan)/.test(n)) return Cookie;
  if (/(es|ice|dingin|frozen)/.test(n)) return IceCream2;
  if (/(kopi|coffee|teh|tea|drink|minum|jus|juice)/.test(n)) return Coffee;
  if (/(wine|bir|beer|alkohol)/.test(n)) return Wine;
  if (/(burger|sandwich|roti|bread)/.test(n)) return Sandwich;
  if (/(pizza)/.test(n)) return Pizza;
  if (/(paket|bundle|hampers)/.test(n)) return ShoppingBag;
  return LayoutGrid;
}

function firstNameOf(full?: string | null): string {
  const src = (full || "").toString();
  const stripped = src.includes("@") ? src.split("@")[0] : src;
  const clean = stripped.replace(/[._-]+/g, " ").trim();
  if (!clean) return "kembali";
  const w = clean.split(/\s+/)[0];
  return w.charAt(0).toUpperCase() + w.slice(1);
}

function formatTodayLong(): string {
  return new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}




export function POSPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [category, setCategory] = useState<string>("Semua");
  const [query, setQuery] = useState("");
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [payment, setPayment] = useState<PaymentMethod>("cash");
  const [tendered, setTendered] = useState<number>(0);
  const [customerName, setCustomerName] = useState("");
  const [customerNotes, setCustomerNotes] = useState("");
  const [hasShift, setHasShift] = useState(false);
  const [lastSale, setLastSale] = useState<Sale | null>(null);
  const [holds, setHolds] = useState<HoldOrder[]>([]);
  const [activeHoldId, setActiveHoldId] = useState<string | null>(null);
  const [saleType, setSaleType] = useState<SaleType>("frozen");
  const [customerType, setCustomerType] = useState<CustomerType>("end_user");
  const [isPreorder, setIsPreorder] = useState(false);
  const [customerPhone, setCustomerPhone] = useState("");
  const [pickupDate, setPickupDate] = useState("");
  const [pickupTime, setPickupTime] = useState("");
  const [sourceOrder, setSourceOrder] = useState<SourceOrder>("outlet");
  const [priceGroups, setPriceGroups] = useState<PriceGroup[]>([]);
  // Packing / Packaging state
  const [packingOpen, setPackingOpen] = useState(false);
  const [packings, setPackings] = useState<SalePacking[]>([]);
  const [packingCustom, setPackingCustom] = useState(false);
  const [plasticName, setPlasticName] = useState<string>("none");
  const [plasticQty, setPlasticQty] = useState<number>(1);
  const [extras, setExtras] = useState<SaleExtraPackaging[]>([]);
  const [packagingItems, setPackagingItems] = useState<InventoryItem[]>([]);
  const { role, profile, user } = useRole();
  const cashierName = profile?.full_name ?? user?.email ?? "Kasir";
  void role;
  const defaultCustomerName = useMemo(
    () => settingsService.get().defaultCustomerName || "Pelanggan Umum",
    [],
  );
  const searchRef = useRef<HTMLInputElement | null>(null);
  // Guard terhadap double-submit (double click / double Enter) saat checkout.
  const isCompletingRef = useRef(false);
  const [isCompleting, setIsCompleting] = useState(false);

  useEffect(() => {
    setProducts(productService.list().filter((p) => p.active));
    setHolds(holdService.list());
    setPriceGroups(priceGroupService.list());
    setPackagingItems(inventoryService.byCategory("packaging"));
    const sync = () => setHasShift(!!shiftService.current());
    sync();
    window.addEventListener("focus", sync);
    document.addEventListener("visibilitychange", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("focus", sync);
      document.removeEventListener("visibilitychange", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  // Resolve price group aktif dari source order + auto-sync harga cart & customer type.
  const activePriceGroup = useMemo(
    () => (priceGroups.length ? priceGroupService.forSource(sourceOrder) : undefined),
    [priceGroups, sourceOrder],
  );
  const activePriceGroupId = activePriceGroup?.id;

  // Sinkronkan customerType berdasarkan sumber (reseller → reseller, lainnya → end_user).
  useEffect(() => {
    setCustomerType(sourceOrder === "reseller" ? "reseller" : "end_user");
  }, [sourceOrder]);

  // Saat price group / customer type berubah, sinkronkan harga item yang sudah masuk cart.
  useEffect(() => {
    setCart((prev) =>
      prev.map((line) => {
        const p = products.find((x) => x.id === line.productId);
        if (!p) return line;
        return { ...line, price: priceFor(p, activePriceGroupId, customerType) };
      }),
    );
  }, [activePriceGroupId, customerType, products]);

  // Auto-manage packings. Bila belum di-custom oleh kasir, seluruh cart masuk ke Packing 1.
  // Custom mode: JANGAN auto-tambah alokasi. Hanya cap ke bawah bila cart qty berkurang
  // dan hapus item yang sudah tidak ada di cart. Kasir bertanggung jawab mengalokasikan sisa.
  useEffect(() => {
    if (cart.length === 0) {
      setPackings([]);
      setPackingCustom(false);
      return;
    }
    if (!packingCustom) {
      setPackings([
        buildAutoPacking(cart.map((c) => ({ productId: c.productId, name: c.name, qty: c.qty }))),
      ]);
      return;
    }
    setPackings((prev) => {
      const cartMap = new Map(cart.map((c) => [c.productId, c] as const));
      let next = prev.map((p) => ({
        ...p,
        items: p.items
          .filter((it) => cartMap.has(it.productId))
          .map((it) => ({ ...it, name: cartMap.get(it.productId)!.name })),
      }));
      // Cap tiap produk ke cart qty; kurangi dari packing terakhir dulu.
      for (const c of cart) {
        let allocated = next.reduce(
          (a, p) => a + (p.items.find((it) => it.productId === c.productId)?.qty ?? 0),
          0,
        );
        let overshoot = allocated - c.qty;
        for (let i = next.length - 1; i >= 0 && overshoot > 0; i--) {
          const idx = next[i].items.findIndex((it) => it.productId === c.productId);
          if (idx < 0) continue;
          const take = Math.min(overshoot, next[i].items[idx].qty);
          overshoot -= take;
          const newQty = next[i].items[idx].qty - take;
          const items =
            newQty === 0
              ? next[i].items.filter((_, j) => j !== idx)
              : next[i].items.map((it, j) => (j === idx ? { ...it, qty: newQty } : it));
          next[i] = { ...next[i], items };
        }
      }
      return next.map((p) => recomputePacking(p));
    });
  }, [cart, packingCustom]);

  const cartTotalQty = cart.reduce((a, c) => a + c.qty, 0);
  const packingsTotalQty = packings.reduce((a, p) => a + p.totalQty, 0);
  const allocationSummary = cart.map((c) => {
    const allocated = packings.reduce(
      (a, p) => a + (p.items.find((it) => it.productId === c.productId)?.qty ?? 0),
      0,
    );
    return {
      productId: c.productId,
      name: c.name,
      cart: c.qty,
      allocated,
      remaining: c.qty - allocated,
    };
  });
  const anyRemaining = allocationSummary.some((s) => s.remaining !== 0);
  const hasEmptyPacking = packings.length > 0 && packings.some((p) => p.totalQty === 0);
  const packingConsistent = !anyRemaining && !hasEmptyPacking;




  const categories = useMemo(
    () => ["Semua", ...Array.from(new Set(products.map((p) => p.category)))],
    [products],
  );

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (category !== "Semua" && p.category !== category) return false;
      if (!q) return true;
      const extra = p as unknown as { barcode?: string; code?: string };
      const haystack = [p.name, p.sku, extra.barcode, extra.code]
        .filter(Boolean)
        .map((v) => String(v).toLowerCase());
      return haystack.some((h) => h.includes(q));
    });
  }, [products, category, query]);

  const subtotal = cart.reduce((a, c) => a + c.price * c.qty, 0);
  const total = subtotal;
  const productImageMap = useMemo(
    () => new Map(products.map((p) => [p.id, p.imageUrl] as const)),
    [products],
  );

  function stockOf(productId: string): number | undefined {
    return products.find((p) => p.id === productId)?.stock;
  }

  function addToCart(p: Product) {
    const stock = p.stock;
    const inCart = cart.find((c) => c.productId === p.id)?.qty ?? 0;
    if (typeof stock === "number" && inCart + 1 > stock) {
      toast.error(`Stok ${p.name} tidak mencukupi (tersedia ${stock})`);
      return;
    }
    setCart((prev) => {
      const i = prev.findIndex((c) => c.productId === p.id);
      if (i >= 0) {
        const next = [...prev];
        next[i] = { ...next[i], qty: next[i].qty + 1 };
        return next;
      }
      return [
        ...prev,
        {
          productId: p.id,
          name: p.name,
          price: priceFor(p, activePriceGroupId, customerType),
          cost: p.cost,
          qty: 1,
        },
      ];
    });
  }

  function adjust(productId: string, delta: number) {
    if (delta > 0) {
      const stock = stockOf(productId);
      const inCart = cart.find((c) => c.productId === productId)?.qty ?? 0;
      if (typeof stock === "number" && inCart + delta > stock) {
        toast.error(`Stok tidak mencukupi (tersedia ${stock})`);
        return;
      }
    }
    setCart((prev) =>
      prev
        .map((c) => (c.productId === productId ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0),
    );
  }

  function remove(productId: string) {
    setCart((prev) => prev.filter((c) => c.productId !== productId));
  }

  function openPayment() {
    if (!cart.length) return;
    if (!shiftService.current()) {
      setHasShift(false);
      toast.error("Buka shift terlebih dahulu sebelum transaksi");
      return;
    }
    if (!packingConsistent) {
      toast.error(
        anyRemaining
          ? "Alokasikan seluruh qty ke Packing sebelum bayar"
          : "Packing tidak boleh kosong",
      );
      setPackingOpen(true);
      return;
    }
    setTendered(total);
    setPayment("cash");
    setPaymentOpen(true);
  }

  // Keyboard shortcuts POS (tidak bentrok dengan shortcut browser):
  //  Enter = Checkout · Esc = tutup dialog · F2 = fokus search
  //  F4 = Payment · Ctrl+P = Print Invoice
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      const typing =
        !!target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if (e.key === "F2") {
        e.preventDefault();
        searchRef.current?.focus();
      } else if (e.key === "F4") {
        e.preventDefault();
        if (!paymentOpen) openPayment();
      } else if (e.key === "Escape") {
        if (paymentOpen) setPaymentOpen(false);
        if (packingOpen) setPackingOpen(false);
      } else if ((e.ctrlKey || e.metaKey) && (e.key === "p" || e.key === "P")) {
        e.preventDefault();
        printReceipt();
      } else if (e.key === "Enter" && !typing) {
        e.preventDefault();
        if (paymentOpen) completeSale();
        else openPayment();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentOpen, packingOpen, cart, total, lastSale]);




  function completeSale() {
    // Idempoten terhadap double-click / double-Enter: bila sedang memproses,
    // panggilan berikutnya diabaikan sampai proses selesai (finally).
    if (isCompletingRef.current) return;
    isCompletingRef.current = true;
    setIsCompleting(true);
    try {
    const cashier = cashierName;
    const shift = shiftService.current();
    if (!shift) {
      setHasShift(false);
      setPaymentOpen(false);
      toast.error("Shift tidak aktif. Transaksi dibatalkan.");
      return;
    }
    // Validasi Pre Order
    if (isPreorder) {
      if (!customerName.trim()) {
        toast.error("Nama customer wajib untuk Pre Order");
        return;
      }
      const pickupErr = validatePickup(pickupDate, pickupTime);
      if (pickupErr) {
        toast.error(pickupErr);
        return;
      }
    }
    // Validasi stok final (jaga-jaga bila stok berubah dari tab lain).
    const fresh = productService.list();
    for (const line of cart) {
      const p = fresh.find((x) => x.id === line.productId);
      if (p && typeof p.stock === "number" && line.qty > p.stock) {
        toast.error(`Stok ${p.name} tidak mencukupi (tersedia ${p.stock})`);
        return;
      }
    }
    const tenderedNum = tendered || 0;
    if (payment === "cash" && tenderedNum < total) {
      toast.error("Uang tunai kurang dari total");
      return;
    }
    // Customer is mandatory — fall back to the configured default name
    // so the receipt and history always have a value.
    const finalCustomer = customerName.trim() || defaultCustomerName;
    const pickupAt =
      isPreorder && pickupDate && pickupTime
        ? new Date(`${pickupDate}T${pickupTime}`).toISOString()
        : undefined;
    // Pre Order dari kasir: catat sebagai PreOrder record.
    // Sale tetap dibuat (untuk struk & pembayaran DP/lunas), tapi TIDAK
    // masuk Queue — muncul di halaman Pre Order sampai jam pickup tiba.
    let preorderId: string | undefined;
    if (isPreorder && pickupDate && pickupTime) {
      try {
        const po = preorderService.create({
          customerName: finalCustomer,
          customerPhone: customerPhone.trim() || undefined,
          date: pickupDate,
          time: pickupTime,
          items: cart,
          sourceOrder,
          priceGroupId: activePriceGroupId,
          saleType,
          createdBy: cashier,
        });
        preorderId = po.id;
      } catch (err) {
        console.error("[pos] create PreOrder failed", err);
      }
    }
    // Bangun plastic + extras payload.
     const plasticPayload: SalePlastic | undefined =
       plasticName !== "none" && plasticQty > 0
         ? {
             ...resolvePackagingItem(plasticName),
             qty: plasticQty,
           }
         : undefined;
     const extrasPayload: SaleExtraPackaging[] | undefined =
       extras.length > 0
         ? extras.filter((e) => e.qty > 0 && e.itemName.trim().length > 0)
         : undefined;
     if (!packingConsistent) {
       toast.error("Jumlah item di Packing belum sama dengan Cart");
       return;
     }
     const sale = salesService.create({
      cashier,
      customerName: finalCustomer,
      shiftId: shift.id,
      items: cart,
      subtotal,
      discount: 0,
      total,
      payment,
      tendered: payment === "cash" ? tenderedNum : undefined,
      change: payment === "cash" ? Math.max(0, tenderedNum - total) : undefined,
      saleType,
      customerType,
      isPreorder,
      customerPhone: customerPhone.trim() || undefined,
      pickupAt,
      sourceOrder,
      priceGroupId: activePriceGroupId,
      preorderId,
      packings,
      plastic: plasticPayload,
      extraPackaging: extrasPayload,
      customerNotes: customerNotes.trim() || undefined,
    });
    // Kaitkan Sale ke PreOrder yang barusan dibuat.
    if (preorderId) {
      try {
        preorderService.update(preorderId, { saleId: sale.id });
      } catch (err) {
        console.error("[pos] link PreOrder ↔ Sale failed", err);
      }
    }
    if (activeHoldId) {
      holdService.remove(activeHoldId);
      setHolds(holdService.list());
      setActiveHoldId(null);
    }
    setCart([]);
    setCustomerName("");
    setCustomerNotes("");
    setCustomerPhone("");
    setPickupDate("");
    setPickupTime("");
    setIsPreorder(false);
    setPaymentOpen(false);
    setLastSale(sale);
    setPackings([]);
    setPackingCustom(false);
    setPlasticName("none");
    setPlasticQty(1);
    setExtras([]);
    // Refresh daftar produk & inventory packaging supaya stok terlihat berkurang.
    setProducts(productService.list().filter((p) => p.active));
    setPackagingItems(inventoryService.byCategory("packaging"));
    // Fokus balik ke pencarian untuk transaksi berikutnya.
    setTimeout(() => searchRef.current?.focus(), 50);
    } finally {
      isCompletingRef.current = false;
      setIsCompleting(false);
    }
  }

  function quickCash(amount: number) {
    setTendered((prev) => (prev || 0) + amount);
  }

  function holdCurrent() {
    if (!cart.length) {
      toast.error("Keranjang masih kosong");
      return;
    }
    const name = customerName.trim() || defaultCustomerName;
    holdService.save(cart, name);
    setHolds(holdService.list());
    setCart([]);
    setCustomerName("");
    setActiveHoldId(null);
    toast.success("Pesanan ditahan");
  }

  function restoreHold(order: HoldOrder) {
    setCart(order.items);
    setCustomerName(
      order.customerName && order.customerName !== defaultCustomerName ? order.customerName : "",
    );
    setActiveHoldId(order.id);
    toast.success(`Pesanan ${order.customerName} dimuat`);
  }

  function dropHold(id: string) {
    holdService.remove(id);
    setHolds(holdService.list());
    if (activeHoldId === id) setActiveHoldId(null);
  }

  function printReceipt() {
    if (!lastSale) return;
    if (!printSaleReceipt(lastSale)) {
      toast.error("Popup diblokir browser");
    }
  }


  // ---- Packing manipulation ----
  function enableCustomPacking() {
    setPackingCustom(true);
    if (packings.length === 0 && cart.length > 0) {
      setPackings([
        buildAutoPacking(cart.map((c) => ({ productId: c.productId, name: c.name, qty: c.qty }))),
      ]);
    }
  }
  function addPacking() {
    setPackingCustom(true);
    setPackings((prev) => [
      ...prev,
      { id: newPackingId(), items: [], totalQty: 0, boxItemName: autoBoxName(0), boxQty: 0 },
    ]);
  }
  function removePacking(pid: string) {
    setPackings((prev) => {
      if (prev.length <= 1) return prev;
      const removed = prev.find((p) => p.id === pid);
      const rest = prev.filter((p) => p.id !== pid);
      if (!removed) return rest;
      // Pindahkan item removed ke packing pertama agar alokasi tetap konsisten.
      const p0 = rest[0];
      const merged = [...p0.items];
      for (const it of removed.items) {
        const idx = merged.findIndex((x) => x.productId === it.productId);
        if (idx >= 0) merged[idx] = { ...merged[idx], qty: merged[idx].qty + it.qty };
        else merged.push(it);
      }
      rest[0] = recomputePacking({ ...p0, items: merged });
      return rest;
    });
  }
  function setItemQty(pid: string, productId: string, rawQty: number) {
    setPackingCustom(true);
    const cartLine = cart.find((c) => c.productId === productId);
    if (!cartLine) return;
    setPackings((prev) => {
      const otherAlloc = prev.reduce(
        (a, p) =>
          a +
          (p.id === pid ? 0 : p.items.find((it) => it.productId === productId)?.qty ?? 0),
        0,
      );
      const maxAllowed = Math.max(0, cartLine.qty - otherAlloc);
      const qty = Math.max(0, Math.min(Math.floor(rawQty || 0), maxAllowed));
      return prev.map((p) => {
        if (p.id !== pid) return p;
        const idx = p.items.findIndex((it) => it.productId === productId);
        let items = p.items;
        if (qty === 0) {
          if (idx >= 0) items = items.filter((_, j) => j !== idx);
        } else if (idx >= 0) {
          items = items.map((it, j) => (j === idx ? { ...it, qty } : it));
        } else {
          items = [...items, { productId, name: cartLine.name, qty }];
        }
        return recomputePacking({ ...p, items });
      });
    });
  }
  function setPackingLabel(pid: string, label: string) {
    setPackings((prev) => prev.map((p) => (p.id === pid ? { ...p, label } : p)));
  }

  function addExtra() {
    setExtras((prev) => [...prev, { itemName: "", qty: 1 }]);
  }
  function updateExtra(idx: number, patch: Partial<SaleExtraPackaging>) {
    setExtras((prev) =>
      prev.map((e, i) => {
        if (i !== idx) return e;
        const merged = { ...e, ...patch };
        if (patch.itemName !== undefined) {
          const resolved = resolvePackagingItem(patch.itemName);
          merged.itemId = resolved.itemId;
          merged.itemName = resolved.itemName;
        }
        return merged;
      }),
    );
  }
  function removeExtra(idx: number) {
    setExtras((prev) => prev.filter((_, i) => i !== idx));
  }


  return (
    <div
      className="flex h-[calc(100vh-3.5rem)] flex-col page-enter"
      style={{ backgroundColor: "var(--pos-page)" }}
    >



      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[minmax(0,1fr)_420px]">
      <div className="flex min-h-0 min-w-0 flex-col gap-4 p-6 lg:pr-4">


        {!hasShift && (
          <Card className="border-amber-500/30 bg-amber-500/5">
            <CardContent className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
              <div className="flex min-w-0 items-center gap-3">
                <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600" strokeWidth={1.75} />
                <span className="text-foreground">
                  Tidak ada shift aktif. Buka shift sebelum melakukan transaksi.
                </span>
              </div>
              <Button asChild size="sm" variant="outline">
                <Link to="/sales/shifts">Buka shift</Link>
              </Button>
            </CardContent>
          </Card>
        )}
        {holds.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="shrink-0 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Hold
            </span>
            <div className="-mx-1 flex flex-1 gap-2 overflow-x-auto px-1 pb-1">
              {holds.map((h) => {
                const isActive = h.id === activeHoldId;
                return (
                  <div
                    key={h.id}
                    className={`group inline-flex shrink-0 items-center gap-2 rounded-full border pl-3 pr-1 py-1 text-xs transition ${
                      isActive
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border bg-card hover:border-primary/40"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => restoreHold(h)}
                      className="flex items-center gap-2"
                    >
                      <PauseCircle className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.75} />
                      <span className="max-w-[140px] truncate font-medium">{h.customerName}</span>
                      <span className="tabular-nums text-muted-foreground">
                        {formatIDR(h.total)}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => dropHold(h.id)}
                      aria-label={`Hapus hold ${h.customerName}`}
                      className="grid h-5 w-5 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-destructive"
                    >
                      <X className="h-3 w-3" strokeWidth={2} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
        {/* Premium search — tall, elegant, keyboard-first. */}
        <div className="group relative">
          <Search
            className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground transition group-focus-within:text-primary"
            strokeWidth={1.75}
          />
          <Input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari nama produk, SKU, barcode..."
            aria-label="Cari produk"
            className="h-[54px] rounded-[18px] border-border/50 bg-card pl-14 pr-24 text-[15px] font-medium shadow-[0_1px_0_oklch(1_0_0_/_0.9)_inset,0_8px_24px_-16px_oklch(0.22_0.025_40_/_0.15)] transition placeholder:font-normal placeholder:text-muted-foreground/70 focus-visible:border-primary/40 focus-visible:ring-2 focus-visible:ring-primary/15"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-16 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground"
            >
              <X className="h-4 w-4" strokeWidth={1.75} />
            </button>
          ) : null}
          <kbd
            title="Tekan F2 untuk fokus pencarian"
            className="pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 items-center gap-1 rounded-lg border border-border/60 bg-muted/60 px-2 py-1 text-[11px] font-semibold tracking-wide text-muted-foreground sm:inline-flex"
          >
            F2
          </kbd>
        </div>

        {/* Premium category pills — rounded, gradient-active, elegant. */}
        <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
          {categories.map((c) => {
            const Icon = iconForCategory(c);
            const isActive = category === c;
            return (
              <button
                key={c}
                type="button"
                onClick={() => setCategory(c)}
                aria-pressed={isActive}
                className={`group inline-flex shrink-0 items-center gap-2 rounded-full px-5 py-2.5 text-[13px] font-semibold transition active:scale-[0.98] ${
                  isActive
                    ? "brand-gradient text-primary-foreground shadow-brand"
                    : "border border-border/50 bg-card text-foreground/80 shadow-[0_1px_2px_oklch(0.22_0.025_40_/_0.04)] hover:-translate-y-0.5 hover:border-primary/30 hover:text-foreground"
                }`}
              >
                <Icon
                  className={`h-4 w-4 ${isActive ? "text-primary-foreground" : "text-primary/70 group-hover:text-primary"}`}
                  strokeWidth={1.75}
                />
                <span className="whitespace-nowrap">{c}</span>
              </button>
            );
          })}
        </div>

        <div className="grid min-h-0 flex-1 grid-cols-2 gap-4 overflow-y-auto pb-6 pt-2 pr-1 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
          {visible.map((p) => {
            const stock = p.stock;
            const outOfStock = typeof stock === "number" && stock <= 0;
            const lowStock =
              typeof stock === "number" && stock > 0 && (p.minStock ?? 0) > 0 && stock <= (p.minStock ?? 0);
            const price = priceFor(p, activePriceGroupId, customerType);
            const inCartQty = cart.find((x) => x.productId === p.id)?.qty ?? 0;
            return (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                disabled={outOfStock}
                aria-label={`${p.name}${outOfStock ? " · stok habis" : ""}`}
                className={`group relative flex flex-col overflow-visible rounded-[18px] pos-card text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 ${
                  outOfStock
                    ? "cursor-not-allowed opacity-60"
                    : "pos-card-hover active:translate-y-0 active:scale-[0.98]"
                }`}
              >
                {/* Image hero — ~68% of card, PNG-friendly, generous breathing room. */}
                <div
                  className="relative flex h-[158px] w-full items-center justify-center overflow-hidden rounded-t-[17px] px-5 pt-6 pb-3"
                  style={{
                    background:
                      "radial-gradient(85% 95% at 50% 30%, #FFFFFF 0%, #FBF7F1 100%)",
                  }}
                >
                  {/* Subtle botanical wash */}
                  <svg
                    aria-hidden
                    viewBox="0 0 100 100"
                    className="pointer-events-none absolute -bottom-3 -right-3 h-20 w-20 opacity-[0.10] text-primary"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="0.8"
                  >
                    <path d="M50 10 C 48 40 48 70 50 95" />
                    <path d="M50 30 C 38 34 30 44 28 56" />
                    <path d="M50 30 C 62 34 70 44 72 56" />
                    <path d="M50 55 C 40 58 32 68 30 78" />
                    <path d="M50 55 C 60 58 68 68 70 78" />
                  </svg>
                  {p.imageUrl ? (
                    <img
                      src={p.imageUrl}
                      alt={p.name}
                      loading="lazy"
                      className={`relative h-full w-full object-contain drop-shadow-[0_10px_18px_oklch(0.22_0.025_40_/_0.18)] transition duration-300 ${
                        outOfStock ? "grayscale" : "group-hover:-translate-y-1 group-hover:scale-[1.04]"
                      }`}
                    />
                  ) : (
                    <ShoppingBasket
                      className="h-12 w-12 text-primary/30"
                      strokeWidth={1.25}
                    />
                  )}

                  {/* Selected quantity badge — subtle, replaces heavy border. */}
                  {inCartQty > 0 && !outOfStock && (
                    <span className="absolute right-2.5 top-2.5 inline-flex h-6 min-w-6 items-center justify-center rounded-full brand-gradient px-1.5 text-[11px] font-bold tabular-nums text-primary-foreground shadow-brand">
                      {inCartQty}
                    </span>
                  )}

                  {/* Stock badges — muted, only when meaningful. */}
                  {outOfStock ? (
                    <span className="absolute left-2.5 top-2.5 rounded-full bg-destructive/95 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-destructive-foreground shadow-sm">
                      Habis
                    </span>
                  ) : lowStock ? (
                    <span className="absolute left-2.5 top-2.5 rounded-full bg-gold px-2 py-0.5 text-[10px] font-semibold tracking-wider text-foreground/80 shadow-sm">
                      Sisa {stock}
                    </span>
                  ) : null}
                </div>
                {/* Info — minimal: name + price only. */}
                <div className="flex flex-1 flex-col gap-1.5 px-4 py-3.5">
                  <span className="line-clamp-2 min-h-[2.5rem] text-[13.5px] font-semibold leading-snug text-foreground">
                    {p.name}
                  </span>
                  <span className="mt-auto text-[16px] font-bold tabular-nums text-primary">
                    {formatIDR(price)}
                  </span>
                </div>
              </button>
            );
          })}

          {visible.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center gap-3 py-16 text-center">
              <div className="grid h-14 w-14 place-items-center rounded-full bg-muted text-muted-foreground">
                <Search className="h-6 w-6" strokeWidth={1.5} />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Produk tidak ditemukan</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {query ? `Tidak ada hasil untuk "${query}".` : "Coba pilih kategori lain."}
                </p>
              </div>
              {query && (
                <Button size="sm" variant="outline" onClick={() => setQuery("")}>
                  Bersihkan pencarian
                </Button>
              )}
            </div>
          )}
        </div>
      </div>


      <aside className="m-4 ml-2 mt-4 flex min-h-0 flex-col overflow-hidden rounded-[22px] pos-panel lg:sticky lg:top-4 lg:h-[calc(100vh-3.5rem-2rem)]">
        <div className="flex items-center justify-between gap-2 border-b px-4 py-2">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
              <Receipt className="h-4 w-4" strokeWidth={1.75} />
            </span>
            <div className="flex min-w-0 flex-col leading-tight">
              <span className="text-sm font-semibold">Pesanan Saat Ini</span>
              <span className="text-[11px] text-muted-foreground">
                {cart.length} item · {cartTotalQty} qty
                {activeHoldId ? " · dari Hold" : ""}
              </span>
            </div>
          </div>
          {cart.length > 0 && (
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" onClick={holdCurrent} disabled={!hasShift} title="Tahan pesanan">
                <PauseCircle className="h-4 w-4" /> Tahan
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setCart([]);
                  setActiveHoldId(null);
                }}
                title="Kosongkan keranjang"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        {/* Customer + order settings — hierarki: Nama → Telepon → Catatan → Source → PO. */}
        <div className="space-y-1.5 px-4 py-2" style={{ backgroundColor: "var(--pos-surface-2)", borderBottom: "1px solid var(--pos-border-soft)" }}>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="customer" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Customer
              </Label>
              <div className="relative mt-0.5">
                <User className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="customer"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder={defaultCustomerName}
                  className="h-8 pl-8 text-sm"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="customer-phone" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                No. Telepon
              </Label>
              <div className="relative mt-0.5">
                <Phone className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="customer-phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="0812xxxxxxxx"
                  className="h-8 pl-8 text-sm"
                  inputMode="tel"
                />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-[1fr_auto] items-end gap-2">
            <div>
              <Label htmlFor="customer-notes" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Catatan <span className="normal-case text-muted-foreground/70">(opsional)</span>
              </Label>
              <div className="relative mt-0.5">
                <StickyNote className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="customer-notes"
                  value={customerNotes}
                  onChange={(e) => setCustomerNotes(e.target.value)}
                  placeholder="Contoh: tidak pedas, dipisah…"
                  className="h-8 pl-8 text-sm"
                />
              </div>
            </div>
            <div className="flex h-8 shrink-0 overflow-hidden rounded-md border text-[11px]">
              <button
                type="button"
                onClick={() => setCustomerType("end_user")}
                aria-pressed={customerType === "end_user"}
                className={`px-2.5 font-medium transition ${customerType === "end_user" ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-muted"}`}
              >
                End User
              </button>
              <button
                type="button"
                onClick={() => setCustomerType("reseller")}
                aria-pressed={customerType === "reseller"}
                className={`px-2.5 font-medium transition ${customerType === "reseller" ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:bg-muted"}`}
              >
                Reseller
              </button>
            </div>
          </div>


          <div className="rounded-lg border border-border/70 bg-muted/30 p-2">
            <div className="mb-1 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              <Store className="h-3.5 w-3.5" strokeWidth={1.75} />
              Source Order
            </div>
            <div className="flex items-center gap-1.5">
              <Select value={sourceOrder} onValueChange={(v) => setSourceOrder(v as SourceOrder)}>
                <SelectTrigger className="h-8 flex-1 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SOURCE_ORDER_LIST.map((s) => (
                    <SelectItem key={s} value={s}>
                      {SOURCE_ORDER_LABEL[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex overflow-hidden rounded-md border">
                <button
                  type="button"
                  onClick={() => setSaleType("frozen")}
                  title="Frozen"
                  aria-pressed={saleType === "frozen"}
                  className={`grid h-8 w-8 place-items-center transition ${
                    saleType === "frozen" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  <Snowflake className="h-3.5 w-3.5" strokeWidth={1.75} />
                </button>
                <button
                  type="button"
                  onClick={() => setSaleType("matang")}
                  title="Matang"
                  aria-pressed={saleType === "matang"}
                  className={`grid h-8 w-8 place-items-center transition ${
                    saleType === "matang" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  <Flame className="h-3.5 w-3.5" strokeWidth={1.75} />
                </button>
              </div>
              <button
                type="button"
                onClick={() => setIsPreorder((v) => !v)}
                title="Pre Order"
                aria-pressed={isPreorder}
                className={`grid h-8 w-8 place-items-center rounded-md border transition ${
                  isPreorder ? "border-primary bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
                }`}
              >
                <CalendarClock className="h-3.5 w-3.5" strokeWidth={1.75} />
              </button>
            </div>
            {activePriceGroup && (
              <p className="mt-2 text-[10px] text-muted-foreground">
                Harga aktif: <span className="font-semibold text-foreground">{activePriceGroup.name}</span>
              </p>
            )}
          </div>

          <div
            className={`grid transition-all duration-200 ease-out ${
              isPreorder ? "mt-1 grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
            }`}
            aria-hidden={!isPreorder}
          >
            <div className="overflow-hidden">
              <div
                className="grid gap-1.5 rounded-[14px] border p-2.5"
                style={{
                  backgroundColor: "#FAFAF8",
                  borderColor: "#ECE7E2",
                  boxShadow: "0 4px 12px rgba(70, 45, 25, 0.04)",
                }}
              >
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label
                      htmlFor="pickup-date"
                      className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground"
                    >
                      Tanggal Pengambilan
                    </Label>
                    <Input
                      id="pickup-date"
                      type="date"
                      value={pickupDate}
                      min={todayYmd()}
                      onChange={(e) => {
                        const v = e.target.value;
                        setPickupDate(v);
                        if (pickupTime && validatePickup(v, pickupTime)) {
                          setPickupTime("");
                        }
                      }}
                      disabled={!isPreorder}
                      tabIndex={isPreorder ? undefined : -1}
                      className="mt-0.5 h-8 text-sm"
                    />
                  </div>
                  <div>
                    <Label
                      htmlFor="pickup-time"
                      className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground"
                    >
                      Jam Pengambilan
                    </Label>
                    <Input
                      id="pickup-time"
                      type="time"
                      value={pickupTime}
                      min={pickupDate ? minPickupTimeFor(pickupDate) : undefined}
                      step={300}
                      onChange={(e) => setPickupTime(e.target.value)}
                      disabled={!isPreorder}
                      tabIndex={isPreorder ? undefined : -1}
                      className="mt-0.5 h-8 text-sm"
                    />
                  </div>
                </div>
                {isPreorder && pickupDate && pickupTime && validatePickup(pickupDate, pickupTime) && (
                  <p className="text-[11px] text-destructive">
                    {validatePickup(pickupDate, pickupTime)}
                  </p>
                )}
                {isPreorder && pickupDate === todayYmd() && (
                  <p className="text-[10px] text-muted-foreground">
                    Slot paling awal hari ini: {minPickupTimeFor(pickupDate)}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Group 2 · Order Items — Daftar Pesanan (premium section, own scroll) */}
        <div className="flex min-h-0 flex-1 flex-col px-3 py-1.5">
          <section
            className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border bg-white"
            style={{
              borderColor: "#ECE7E2",
              boxShadow: "0 8px 24px rgba(70, 45, 25, 0.05)",
            }}
          >
            <header
              className="flex shrink-0 items-center gap-1.5 border-b px-3 py-1.5"
              style={{ borderColor: "#ECE7E2" }}
            >
              <ShoppingCart className="h-3 w-3 text-primary" strokeWidth={1.75} />
              <h3 className="text-[11px] font-semibold uppercase tracking-wider text-primary">Daftar Pesanan</h3>
              <span className="ml-auto text-[10px] tabular-nums text-muted-foreground">
                {cart.length} item
              </span>
            </header>


            <div className="min-h-0 flex-1 overflow-y-auto p-3">
              {cart.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center gap-3 py-10 text-center">
                  <div
                    className="grid h-16 w-16 place-items-center rounded-2xl text-primary"
                    style={{ backgroundColor: "#F6EFE9", border: "1px solid #ECE7E2" }}
                  >
                    <ShoppingBasket className="h-7 w-7" strokeWidth={1.5} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Belum ada pesanan</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Tambahkan produk untuk mulai transaksi.
                    </p>
                  </div>
                </div>
              ) : (
                <ul className="flex flex-col gap-2">
                  {cart.map((c) => {
                    const image = productImageMap.get(c.productId);
                    return (
                      <li
                        key={c.productId}
                        className="group flex items-center gap-2.5 rounded-[14px] border bg-white p-2.5 transition hover:-translate-y-0.5"
                        style={{
                          borderColor: "#ECE7E2",
                          boxShadow: "0 2px 8px rgba(70, 45, 25, 0.04)",
                        }}
                      >
                        {/* Product image */}
                        <div
                          className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-[10px]"
                          style={{
                            background:
                              "radial-gradient(85% 95% at 50% 30%, #FFFFFF 0%, #FBF7F1 100%)",
                            border: "1px solid #ECE7E2",
                          }}
                        >
                          {image ? (
                            <img
                              src={image}
                              alt={c.name}
                              loading="lazy"
                              className="h-full w-full object-contain"
                            />
                          ) : (
                            <ShoppingBasket
                              className="h-5 w-5 text-primary/40"
                              strokeWidth={1.5}
                            />
                          )}
                        </div>

                        {/* Name + unit price */}
                        <div className="min-w-0 flex-1">
                          <p className="line-clamp-2 text-[13px] font-semibold leading-snug text-foreground">
                            {c.name}
                          </p>
                          <p className="mt-0.5 text-[11px] tabular-nums text-muted-foreground">
                            {formatIDR(c.price)}
                          </p>
                        </div>

                        {/* Quantity stepper — circular, maroon hover */}
                        <div className="flex shrink-0 items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => adjust(c.productId, -1)}
                            className="grid h-8 w-8 place-items-center rounded-full border text-muted-foreground transition hover:border-primary hover:bg-primary/5 hover:text-primary active:scale-95"
                            style={{ borderColor: "#ECE7E2" }}
                            aria-label="Kurangi"
                          >
                            <Minus className="h-3.5 w-3.5" strokeWidth={2} />
                          </button>
                          <span className="min-w-[24px] text-center text-sm font-semibold tabular-nums text-foreground">
                            {c.qty}
                          </span>
                          <button
                            type="button"
                            onClick={() => adjust(c.productId, 1)}
                            className="grid h-8 w-8 place-items-center rounded-full border text-muted-foreground transition hover:border-primary hover:bg-primary/5 hover:text-primary active:scale-95"
                            style={{ borderColor: "#ECE7E2" }}
                            aria-label="Tambah"
                          >
                            <Plus className="h-3.5 w-3.5" strokeWidth={2} />
                          </button>
                        </div>

                        {/* Subtotal */}
                        <div className="w-[76px] shrink-0 text-right">
                          <p className="text-[13px] font-semibold tabular-nums text-foreground">
                            {formatIDR(c.price * c.qty)}
                          </p>
                        </div>

                        {/* Delete — circular ghost, red hover */}
                        <button
                          type="button"
                          onClick={() => remove(c.productId)}
                          className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive active:scale-95"
                          aria-label="Hapus"
                        >
                          <Trash2 className="h-3.5 w-3.5" strokeWidth={1.75} />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </section>
        </div>



        {/* Summary + checkout — premium sticky footer, cream, spacious. */}
        <div
          className="flex flex-col gap-2 px-4 py-2.5"
          style={{ backgroundColor: "var(--pos-page)", borderTop: "1px solid var(--pos-border-soft)" }}
        >
          {cart.length > 0 && (
            <button
              type="button"
              onClick={() => setPackingOpen(true)}
              className="flex items-center justify-between rounded-xl pos-item px-3.5 py-2 text-left text-[12px] hover:-translate-y-0.5"
            >
              <span className="flex items-center gap-2">
                <Package className="h-4 w-4 text-primary" strokeWidth={1.75} />
                <span className="font-semibold text-foreground">Packing</span>
                <span className="text-muted-foreground">
                  {packings.length} · {packingsTotalQty} pcs
                  {plasticName !== "none" ? ` · ${plasticName}` : ""}
                  {extras.length > 0 ? ` · +${extras.length}` : ""}
                </span>
              </span>
              <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          )}
          <div className="pos-section px-4 py-2.5">
            <div className="flex items-end justify-between gap-2">
              <div className="flex flex-col leading-tight">
                <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  Grand Total
                </span>
                <span className="font-display text-[26px] font-bold leading-none tabular-nums text-primary mt-1">
                  {formatIDR(total)}
                </span>
              </div>
              <span className="pb-1 text-[11px] tabular-nums text-muted-foreground">
                {cartTotalQty} qty
              </span>
            </div>
          </div>
          <Button
            className="brand-gradient shadow-brand h-11 rounded-xl border-0 text-[13px] font-semibold tracking-wide text-primary-foreground transition hover:-translate-y-0.5 hover:shadow-[0_18px_40px_-18px_oklch(0.38_0.14_26_/_0.55)] active:scale-[0.99] disabled:cursor-not-allowed disabled:bg-none disabled:bg-muted disabled:text-muted-foreground disabled:shadow-none disabled:hover:translate-y-0"
            disabled={!cart.length || !hasShift || !packingConsistent || isCompleting}
            onClick={openPayment}
          >
            <CreditCard className="mr-2 h-4 w-4" strokeWidth={1.75} />
            {!hasShift
              ? "Buka shift untuk bertransaksi"
              : !packingConsistent
                ? anyRemaining
                  ? `Alokasi Packing kurang ${cartTotalQty - packingsTotalQty}`
                  : "Packing kosong — perbaiki"
                : "Bayar"}
          </Button>

        </div>

      </aside>
      </div>



      {/* Atur Packing drawer */}
      <Sheet open={packingOpen} onOpenChange={setPackingOpen}>
        <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-lg">
          <SheetHeader className="border-b px-4 py-3">
            <SheetTitle className="flex items-center gap-2">
              <Package className="h-4 w-4" strokeWidth={1.75} />
              Atur Packing
            </SheetTitle>
            <p className="text-xs text-muted-foreground">
              Default seluruh produk = 1 Packing. Buat beberapa Packing bila customer minta dipisah.
              Box otomatis dihitung dari isi tiap Packing.
            </p>
          </SheetHeader>
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
            {/* Alokasi per produk */}
            {packingCustom && allocationSummary.length > 0 && (
              <div className="rounded-md border bg-muted/20 p-3 text-xs space-y-1.5">
                <div className="font-semibold uppercase tracking-wider text-muted-foreground">
                  Alokasi per Produk
                </div>
                {allocationSummary.map((s) => (
                  <div key={s.productId} className="flex items-center justify-between gap-2">
                    <span className="truncate">{s.name}</span>
                    <span className="tabular-nums text-muted-foreground">
                      Cart {s.cart} · Alokasi {s.allocated} ·{" "}
                      <span
                        className={
                          s.remaining === 0
                            ? "font-semibold text-emerald-600"
                            : "font-semibold text-amber-600"
                        }
                      >
                        Sisa {s.remaining}
                      </span>
                    </span>
                  </div>
                ))}
              </div>
            )}
            {/* Consistency banner */}
            {!packingConsistent && (
              <div className="rounded-md border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-xs text-amber-700">
                {anyRemaining
                  ? `Alokasi belum sesuai Cart (${packingsTotalQty}/${cartTotalQty}).`
                  : "Ada Packing kosong. Hapus atau isi terlebih dahulu."}
              </div>
            )}
            {/* Packings */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Packing ({packings.length})
                </span>
                <div className="flex gap-1">
                  {packingCustom && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setPackingCustom(false);
                      }}
                    >
                      Reset ke 1 Packing
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={packingCustom ? addPacking : enableCustomPacking}
                  >
                    <Plus className="h-3.5 w-3.5" />
                    {packingCustom ? "Tambah Packing" : "Pisah Packing"}
                  </Button>
                </div>
              </div>
              {packings.map((p, idx) => (
                <div key={p.id} className="rounded-lg border bg-card p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold">Packing {idx + 1}</span>
                    {packings.length > 1 && (
                      <button
                        onClick={() => removePacking(p.id)}
                        className="text-xs text-muted-foreground hover:text-destructive"
                      >
                        Hapus
                      </button>
                    )}
                  </div>
                  {packingCustom && (
                    <Input
                      value={p.label ?? ""}
                      onChange={(e) => setPackingLabel(p.id, e.target.value)}
                      placeholder="Label (opsional) — mis. Rumah / Kantor"
                      className="h-8 text-xs"
                      maxLength={40}
                    />
                  )}
                  {packingCustom ? (
                    <ul className="flex flex-col divide-y">
                      {cart.map((c) => {
                        const line = p.items.find((it) => it.productId === c.productId);
                        const qty = line?.qty ?? 0;
                        const otherAlloc = packings.reduce(
                          (a, pp) =>
                            a +
                            (pp.id === p.id
                              ? 0
                              : pp.items.find((it) => it.productId === c.productId)?.qty ?? 0),
                          0,
                        );
                        const maxAllowed = Math.max(0, c.qty - otherAlloc);
                        return (
                          <li
                            key={c.productId}
                            className="flex items-center justify-between gap-2 py-2 text-sm"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="truncate">{c.name}</div>
                              <div className="text-[10px] text-muted-foreground tabular-nums">
                                Maks {maxAllowed} / Cart {c.qty}
                              </div>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button
                                type="button"
                                size="icon"
                                variant="outline"
                                className="h-7 w-7"
                                onClick={() => setItemQty(p.id, c.productId, qty - 1)}
                                disabled={qty <= 0}
                                aria-label="Kurangi"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                              <NumberInput
                                value={qty}
                                onChange={(v) => setItemQty(p.id, c.productId, v)}
                                min={0}
                                max={qty + maxAllowed}
                                className="h-7 w-14 text-center text-xs"
                              />
                              <Button
                                type="button"
                                size="icon"
                                variant="outline"
                                className="h-7 w-7"
                                onClick={() => setItemQty(p.id, c.productId, qty + 1)}
                                disabled={maxAllowed <= 0}
                                aria-label="Tambah"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  ) : (
                    <ul className="flex flex-col divide-y">
                      {p.items.length === 0 && (
                        <li className="py-2 text-xs italic text-muted-foreground">Belum ada item</li>
                      )}
                      {p.items.map((it) => (
                        <li key={it.productId} className="py-1.5 text-sm">
                          {it.qty}× {it.name}
                        </li>
                      ))}
                    </ul>
                  )}
                  <div className="flex items-center justify-between rounded-md bg-muted/40 px-2 py-1.5 text-xs">
                    <span className="text-muted-foreground">
                      Total {p.totalQty} pcs →{" "}
                      <span className="font-medium text-foreground">{p.boxItemName}</span>
                      {p.boxQty > 1 ? ` × ${p.boxQty}` : ""}
                    </span>
                    {!p.boxItemId && p.totalQty > 0 && (
                      <Badge variant="outline" className="text-[10px]">
                        Tidak di Inventory
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>


            {/* Plastic */}
            <div className="space-y-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Plastik
              </span>
              <div className="grid grid-cols-2 gap-2">
                <Select value={plasticName} onValueChange={setPlasticName}>
                  <SelectTrigger className="h-9 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Tidak pakai plastik</SelectItem>
                    {PLASTIC_OPTIONS.map((n) => (
                      <SelectItem key={n} value={n}>
                        {n}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <NumberInput
                  min={1}
                  value={plasticQty}
                  onChange={(v) => setPlasticQty(Math.max(1, v))}
                  disabled={plasticName === "none"}
                  className="h-9"
                />
              </div>
              <p className="text-[10px] text-muted-foreground">
                Harga Rp 0. Stok Inventory tetap dikurangi bila item cocok.
              </p>
            </div>

            {/* Extra packaging */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Packaging Tambahan
                </span>
                <Button size="sm" variant="outline" onClick={addExtra}>
                  <Plus className="h-3.5 w-3.5" /> Tambah
                </Button>
              </div>
              {extras.length === 0 && (
                <p className="text-[10px] italic text-muted-foreground">
                  Kosong. Tambah bila customer minta packaging ekstra.
                </p>
              )}
              {extras.map((ex, idx) => (
                <div key={idx} className="grid grid-cols-[1fr_80px_auto] items-center gap-2">
                  <Select
                    value={ex.itemId ?? ex.itemName ?? ""}
                    onValueChange={(val) => {
                      const item = packagingItems.find((p) => p.id === val);
                      updateExtra(idx, {
                        itemId: item?.id,
                        itemName: item?.name ?? val,
                      });
                    }}
                  >
                    <SelectTrigger className="h-9 text-xs">
                      <SelectValue placeholder="Pilih item packaging" />
                    </SelectTrigger>
                    <SelectContent>
                      {packagingItems.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <NumberInput
                    min={1}
                    value={ex.qty}
                    onChange={(v) => updateExtra(idx, { qty: Math.max(1, v) })}
                    className="h-9"
                  />
                  <Button size="icon" variant="ghost" onClick={() => removeExtra(idx)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <p className="text-[10px] text-muted-foreground">
                Harga Rp 0. Tetap mengurangi stok Inventory. Tercatat di Audit Log.
              </p>
            </div>
          </div>
          <SheetFooter className="border-t px-4 py-3">
            <Button
              className="w-full"
              disabled={!packingConsistent}
              onClick={() => setPackingOpen(false)}
            >
              {packingConsistent
                ? "Simpan Packing"
                : anyRemaining
                  ? "Alokasi belum penuh"
                  : "Ada Packing kosong"}
            </Button>
          </SheetFooter>

        </SheetContent>
      </Sheet>


      <Dialog open={paymentOpen} onOpenChange={setPaymentOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary">
                <Wallet className="h-4 w-4" strokeWidth={2} />
              </span>
              Pembayaran
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            {/* Amount hero */}
            <div className="rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-center">
              <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Total Tagihan
              </div>
              <div className="mt-0.5 text-3xl font-bold tabular-nums text-primary">
                {formatIDR(total)}
              </div>
              <div className="mt-0.5 text-[11px] text-muted-foreground">
                {cart.length} produk · {cartTotalQty} qty
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Label className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Metode Bayar
              </Label>
              <div className="grid grid-cols-4 gap-2">
                {(["cash", "qris", "card", "transfer"] as PaymentMethod[]).map((m) => {
                  const Icon = PAYMENT_ICONS[m];
                  const active = payment === m;
                  return (
                    <button
                      key={m}
                      type="button"
                      aria-pressed={active}
                      onClick={() => setPayment(m)}
                      className={`flex flex-col items-center justify-center gap-1 rounded-xl border px-2 py-3 text-xs font-semibold transition ${
                        active
                          ? "border-primary bg-primary/10 text-primary shadow-sm"
                          : "border-border/70 bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                      }`}
                    >
                      <Icon className="h-5 w-5" strokeWidth={1.75} />
                      {PAYMENT_LABELS[m]}
                    </button>
                  );
                })}
              </div>
            </div>

            {payment === "cash" && (
              <div className="flex flex-col gap-2">
                <Label htmlFor="tendered" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Uang Tunai Diterima
                </Label>
                <NumberInput
                  id="tendered"
                  min={0}
                  autoFocus
                  value={tendered}
                  onChange={setTendered}
                  className="h-12 text-xl font-bold tabular-nums"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      if (isCompletingRef.current) return;
                      completeSale();
                    }
                  }}
                />
                <div className="flex flex-wrap gap-1.5">
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    onClick={() => setTendered(total)}
                  >
                    Uang Pas
                  </Button>
                  {QUICK_CASH.map((amt) => (
                    <Button
                      key={amt}
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => quickCash(amt)}
                      className="tabular-nums"
                    >
                      +{formatIDR(amt)}
                    </Button>
                  ))}
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => setTendered(0)}
                  >
                    Reset
                  </Button>
                </div>
                <div
                  className={`flex items-center justify-between rounded-lg border px-3 py-2.5 text-sm transition ${
                    (tendered || 0) < total
                      ? "border-destructive/40 bg-destructive/5"
                      : "border-emerald-500/30 bg-emerald-500/5"
                  }`}
                >
                  <span className="text-muted-foreground">
                    {(tendered || 0) < total ? "Kekurangan" : "Kembalian"}
                  </span>
                  <span
                    className={`text-lg font-bold tabular-nums ${
                      (tendered || 0) < total ? "text-destructive" : "text-emerald-600"
                    }`}
                  >
                    {formatIDR(Math.abs((tendered || 0) - total))}
                  </span>
                </div>
              </div>
            )}
          </div>
          <DialogFooter className="gap-2 sm:justify-between">
            <Button variant="outline" onClick={() => setPaymentOpen(false)} disabled={isCompleting}>
              Batal
            </Button>
            <Button
              onClick={completeSale}
              disabled={isCompleting || (payment === "cash" && (tendered || 0) < total)}
              className="min-w-[10rem] font-semibold"
            >
              {isCompleting ? "Memproses…" : `Selesaikan · ${formatIDR(total)}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      <Dialog open={!!lastSale} onOpenChange={(o) => !o && setLastSale(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="sr-only">
            <DialogTitle>Transaksi Berhasil</DialogTitle>
          </DialogHeader>
          {lastSale && (
            <div className="flex flex-col">
              {/* Hero status */}
              <div className="flex flex-col items-center gap-2 pb-4 pt-2 text-center">
                <div className="grid h-12 w-12 place-items-center rounded-full bg-emerald-500/10 text-emerald-600">
                  <CheckCircle2 className="h-7 w-7" strokeWidth={2} />
                </div>
                <div className="text-base font-semibold">Transaksi Berhasil</div>
                <div className="text-xs text-muted-foreground">
                  {formatDateTime(lastSale.createdAt)}
                </div>
              </div>

              {/* Headline amount */}
              <div className="rounded-xl border bg-muted/40 p-4 text-center">
                <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  Total Pembayaran
                </div>
                <div className="mt-1 text-3xl font-bold tabular-nums">
                  {formatIDR(lastSale.total)}
                </div>
                <div className="mt-1 font-mono text-xs text-muted-foreground">
                  {lastSale.orderNumber ? `${lastSale.orderNumber} · ` : ""}
                  {formatSalesId(lastSale.id)}
                </div>

              </div>

              {/* Payment summary */}
              <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                <dt className="text-muted-foreground">Customer</dt>
                <dd className="text-right font-medium">{lastSale.customerName ?? "—"}</dd>
                <dt className="text-muted-foreground">Metode</dt>
                <dd className="text-right font-medium">{PAYMENT_LABELS[lastSale.payment]}</dd>
                {lastSale.tendered != null && (
                  <>
                    <dt className="text-muted-foreground">Tunai Diterima</dt>
                    <dd className="text-right tabular-nums">{formatIDR(lastSale.tendered)}</dd>
                  </>
                )}
                {lastSale.change != null && (
                  <>
                    <dt className="text-muted-foreground">Kembalian</dt>
                    <dd className="text-right font-semibold tabular-nums text-emerald-600">
                      {formatIDR(lastSale.change)}
                    </dd>
                  </>
                )}
              </dl>

              {/* Items */}
              <div className="mt-4 flex items-center justify-between border-b pb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                <span>Item Dibeli</span>
                <span>
                  {lastSale.items.reduce((a, i) => a + i.qty, 0)} qty ·{" "}
                  {lastSale.items.length} produk
                </span>
              </div>
              <ul className="max-h-44 divide-y overflow-y-auto">
                {lastSale.items.map((i) => (
                  <li
                    key={i.productId}
                    className="flex items-start justify-between gap-2 py-2 text-sm"
                  >
                    <div className="min-w-0">
                      <div className="truncate font-medium">{i.name}</div>
                      <div className="text-xs text-muted-foreground tabular-nums">
                        {i.qty} × {formatIDR(i.price)}
                      </div>
                    </div>
                    <div className="shrink-0 text-sm font-semibold tabular-nums">
                      {formatIDR(i.price * i.qty)}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => setLastSale(null)}>
              Transaksi Baru
            </Button>
            <Button onClick={printReceipt}>
              <Printer className="h-4 w-4" /> Cetak Struk
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}