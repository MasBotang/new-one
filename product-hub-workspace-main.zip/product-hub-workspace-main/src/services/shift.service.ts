import { storage, StorageKeys } from "./storage";
import { stockMovementService } from "./stock-movement.service";
import { inventoryService } from "./inventory.service";
import { auditService } from "./audit.service";
import type {
  Shift,
  ShiftMarketplaceReconciliation,
  ShiftOperationalExpense,
  ShiftPackagingUsage,
  ShiftPaymentReconciliation,
} from "./types";

function uid(prefix = "shift") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

/**
 * Setelah shift ditutup, seluruh data dianggap final. Hanya admin/owner
 * yang boleh mengubah — kasir dikunci di UI dan di service layer.
 */
export function isShiftLocked(shift: Shift | null | undefined): boolean {
  return !!shift?.closedAt;
}
export function canMutateShift(shift: Shift, role?: string | null): boolean {
  if (!shift.closedAt) return true;
  return role === "admin" || role === "owner";
}

/**
 * Service-layer guard. Setiap fungsi mutasi Shift WAJIB memanggil ini
 * sebelum melakukan perubahan agar kasir tidak dapat mengubah shift
 * yang sudah ditutup meskipun service dipanggil secara langsung (mis.
 * dari console, tooling, atau bypass UI).
 */
export function assertCanMutateShift(shift: Shift, role?: string | null): void {
  if (!canMutateShift(shift, role)) {
    throw new Error(
      "Shift sudah ditutup — hanya Admin/Owner yang dapat mengubah data shift ini.",
    );
  }
}

export interface CloseShiftInput {
  closingCash: number;
  expectedCash: number;
  cashDifferenceReason?: string;
  totalOrders: number;
  totalRevenue: number;
  cashSales: number;
  qrisSales: number;
  transferSales: number;
  marketplaceSales: number;
  marketplaceReconciliations: ShiftMarketplaceReconciliation[];
  paymentReconciliations: ShiftPaymentReconciliation[];
  actor: string;
  actorRole?: string;
}


export interface AddOperationalExpenseInput {
  at?: string;
  itemId: string;
  qty: number;
  price: number;
  notes?: string;
  actor: string;
  actorRole?: string;
}

export interface UpdateOperationalExpenseInput {
  shiftId: string;
  expenseId: string;
  at?: string;
  itemId: string;
  qty: number;
  price: number;
  notes?: string;
  actor: string;
  actorRole?: string;
}

export interface SavePackagingUsageInput {
  entries: { itemId: string; qty: number }[];
  actor: string;
  actorRole?: string;
}

function saveShift(next: Shift) {
  const list = shiftService.list();
  const idx = list.findIndex((s) => s.id === next.id);
  if (idx >= 0) list[idx] = next;
  else list.unshift(next);
  storage.set(StorageKeys.shifts, list);
  const cur = shiftService.current();
  if (cur && cur.id === next.id) storage.set(StorageKeys.currentShift, next);
}

function recalcOperationalTotal(shift: Shift): Shift {
  const list = shift.operationalExpenses ?? [];
  return {
    ...shift,
    operationalExpenses: list,
    totalOperationalExpense: list.reduce((a, e) => a + e.total, 0),
  };
}

function recalcPackagingTotal(shift: Shift): Shift {
  const list = shift.packagingUsage ?? [];
  return {
    ...shift,
    packagingUsage: list,
    totalPackagingQty: list.reduce((a, p) => a + p.qty, 0),
  };
}

/** Apply a signed delta to inventory + record movement. Positive = add stock back, negative = deduct. */
function moveStock(
  itemId: string,
  signedDelta: number,
  reason: string,
  notes?: string,
  packaging = false,
) {
  if (signedDelta === 0) return;
  if (signedDelta < 0) {
    stockMovementService.record({
      itemId,
      type: packaging ? "sales_packaging_usage" : "operational_usage",
      quantity: Math.abs(signedDelta),
      reason,
      notes,
    });
  } else {
    stockMovementService.record({
      itemId,
      type: "adjustment",
      adjustmentAbsolute: true,
      quantity: (inventoryService.get(itemId)?.stock ?? 0) + signedDelta,
      reason,
      notes: notes ? `${notes} (koreksi +${signedDelta})` : `Koreksi +${signedDelta}`,
    });
  }
}

export const shiftService = {
  list(): Shift[] {
    return storage.get<Shift[]>(StorageKeys.shifts) ?? [];
  },
  current(): Shift | null {
    return storage.get<Shift>(StorageKeys.currentShift);
  },
  get(id: string): Shift | undefined {
    return shiftService.list().find((s) => s.id === id);
  },
  open(cashier: string, openingCash: number, actorRole?: string): Shift {
    const shift: Shift = {
      id: uid(),
      cashier,
      openedAt: new Date().toISOString(),
      openingCash,
      operationalExpenses: [],
      totalOperationalExpense: 0,
    };
    storage.set(StorageKeys.currentShift, shift);
    const list = shiftService.list();
    list.unshift(shift);
    storage.set(StorageKeys.shifts, list);
    auditService.log({
      actor: cashier,
      actorRole,
      action: "shift_open",
      entity: "shift",
      entityId: shift.id,
      metadata: { openingCash },
    });
    return shift;
  },

  // -------------------- Operational Expense --------------------
  addOperationalExpense(input: AddOperationalExpenseInput): ShiftOperationalExpense | null {
    const cur = shiftService.current();
    if (!cur) throw new Error("Tidak ada shift aktif");
    assertCanMutateShift(cur, input.actorRole);
    const item = inventoryService.get(input.itemId);
    if (!item) throw new Error("Barang tidak ditemukan");
    if (item.category !== "operational")
      throw new Error("Barang harus kategori Operasional");
    if (input.qty <= 0) throw new Error("Qty harus > 0");
    if (input.price < 0) throw new Error("Harga tidak valid");

    const entry: ShiftOperationalExpense = {
      id: uid("opex"),
      at: input.at ?? new Date().toISOString(),
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      qty: input.qty,
      price: input.price,
      total: input.qty * input.price,
      notes: input.notes?.trim() || undefined,
      createdBy: input.actor,
    };

    // Deduct inventory immediately.
    try {
      moveStock(
        item.id,
        -input.qty,
        `Shift ${cur.id} · Pengeluaran Operasional`,
        entry.notes,
      );
    } catch (err) {
      console.error("[shift] operational deduction failed", err);
      throw err;
    }

    const next = recalcOperationalTotal({
      ...cur,
      operationalExpenses: [...(cur.operationalExpenses ?? []), entry],
    });
    saveShift(next);

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "operational_expense_added",
      entity: "shift_operational_expense",
      entityId: entry.id,
      metadata: {
        shiftId: cur.id,
        itemId: entry.itemId,
        itemName: entry.itemName,
        qty: entry.qty,
        price: entry.price,
        total: entry.total,
        notes: entry.notes,
      },
    });
    return entry;
  },

  updateOperationalExpense(input: UpdateOperationalExpenseInput) {
    const shift = shiftService.get(input.shiftId);
    if (!shift) throw new Error("Shift tidak ditemukan");
    assertCanMutateShift(shift, input.actorRole);
    const list = shift.operationalExpenses ?? [];
    const idx = list.findIndex((e) => e.id === input.expenseId);
    if (idx < 0) throw new Error("Data pengeluaran tidak ditemukan");
    const prev = list[idx];
    const item = inventoryService.get(input.itemId);
    if (!item) throw new Error("Barang tidak ditemukan");
    if (item.category !== "operational")
      throw new Error("Barang harus kategori Operasional");
    if (input.qty <= 0) throw new Error("Qty harus > 0");

    // FIX (Sprint 1.5): pra-validasi shortage sebelum melakukan reverse +
    // deduct berurutan. Sebelumnya bila deduct gagal, reverse sudah kadung
    // dieksekusi → stok over-restored dan expense tidak ter-update →
    // Inventory ↔ Ringkasan Pengeluaran tidak sinkron.
    {
      const targetStock = inventoryService.get(item.id)?.stock ?? 0;
      const effectiveAvailable =
        targetStock + (prev.itemId === item.id ? prev.qty : 0);
      if (effectiveAvailable < input.qty) {
        throw new Error(
          `Stok ${item.name} tidak mencukupi (tersedia ${effectiveAvailable}, butuh ${input.qty})`,
        );
      }
    }
    // Reverse previous stock deduction (only if same item OR if item changed we
    // add back the old item and deduct the new one).
    moveStock(
      prev.itemId,
      +prev.qty,
      `Shift ${shift.id} · Koreksi Pengeluaran Operasional (reverse)`,
      `Edit oleh ${input.actor}`,
    );
    moveStock(
      item.id,
      -input.qty,
      `Shift ${shift.id} · Koreksi Pengeluaran Operasional`,
      input.notes?.trim() || undefined,
    );


    const updated: ShiftOperationalExpense = {
      ...prev,
      at: input.at ?? prev.at,
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      qty: input.qty,
      price: input.price,
      total: input.qty * input.price,
      notes: input.notes?.trim() || undefined,
      updatedAt: new Date().toISOString(),
      updatedBy: input.actor,
    };
    const nextList = [...list];
    nextList[idx] = updated;
    const next = recalcOperationalTotal({ ...shift, operationalExpenses: nextList });
    saveShift(next);

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "operational_expense_updated",
      entity: "shift_operational_expense",
      entityId: updated.id,
      metadata: {
        shiftId: shift.id,
        before: prev,
        after: updated,
      },
    });
    return updated;
  },

  deleteOperationalExpense(params: {
    shiftId: string;
    expenseId: string;
    actor: string;
    actorRole?: string;
  }) {
    const shift = shiftService.get(params.shiftId);
    if (!shift) throw new Error("Shift tidak ditemukan");
    assertCanMutateShift(shift, params.actorRole);
    const list = shift.operationalExpenses ?? [];
    const idx = list.findIndex((e) => e.id === params.expenseId);
    if (idx < 0) throw new Error("Data pengeluaran tidak ditemukan");
    const prev = list[idx];

    // Reverse stock deduction.
    moveStock(
      prev.itemId,
      +prev.qty,
      `Shift ${shift.id} · Hapus Pengeluaran Operasional`,
      `Hapus oleh ${params.actor}`,
    );

    const nextList = list.filter((e) => e.id !== params.expenseId);
    const next = recalcOperationalTotal({ ...shift, operationalExpenses: nextList });
    saveShift(next);

    auditService.log({
      actor: params.actor,
      actorRole: params.actorRole,
      action: "operational_expense_deleted",
      entity: "shift_operational_expense",
      entityId: prev.id,
      metadata: { shiftId: shift.id, entry: prev },
    });
  },

  // -------------------- Packaging Usage --------------------
  /**
   * Simpan (atau ubah) Pemakaian Packaging pada shift target. Selisih dengan
   * data sebelumnya diaplikasikan ke stok Inventory.
   */
  savePackagingUsage(
    input: SavePackagingUsageInput & { shiftId?: string },
  ): Shift {
    const shift = input.shiftId
      ? shiftService.get(input.shiftId)
      : shiftService.current();
    if (!shift) throw new Error("Shift tidak ditemukan");
    assertCanMutateShift(shift, input.actorRole);

    const prev = shift.packagingUsage ?? [];
    const prevMap = new Map(prev.map((p) => [p.itemId, p.qty]));
    const isUpdate = prev.length > 0 || !!shift.packagingUsageSavedAt;

    const nextEntries: ShiftPackagingUsage[] = [];
    for (const e of input.entries) {
      if (e.qty < 0) throw new Error("Qty packaging tidak boleh negatif");
      const item = inventoryService.get(e.itemId);
      if (!item) continue;
      if (item.category !== "packaging") continue;
      if (e.qty > 0) {
        nextEntries.push({
          itemId: item.id,
          itemName: item.name,
          unit: item.unit,
          qty: e.qty,
        });
      }
    }

    // FIX (Sprint 1.5): pra-validasi shortage sebelum mengubah stok apa pun.
    // Sebelumnya moveStock dieksekusi item-per-item; bila item ke-N kurang,
    // item 1..N-1 sudah kadung ter-deduct → shift.packagingUsage TIDAK
    // tersimpan (throw sebelum saveShift) tetapi Inventory sudah berubah
    // separuh. Sekarang: cek semua delta dulu, baru terapkan.
    const seen = new Set<string>();
    const deltaPlan: { itemId: string; signed: number; itemName: string; available: number }[] = [];
    for (const n of nextEntries) {
      seen.add(n.itemId);
      const oldQty = prevMap.get(n.itemId) ?? 0;
      const delta = n.qty - oldQty;
      if (delta !== 0) {
        const inv = inventoryService.get(n.itemId);
        deltaPlan.push({
          itemId: n.itemId,
          signed: -delta,
          itemName: inv?.name ?? n.itemName,
          available: inv?.stock ?? 0,
        });
      }
    }
    for (const [itemId, oldQty] of prevMap) {
      if (seen.has(itemId)) continue;
      if (oldQty > 0) {
        const inv = inventoryService.get(itemId);
        deltaPlan.push({
          itemId,
          signed: +oldQty,
          itemName: inv?.name ?? itemId,
          available: inv?.stock ?? 0,
        });
      }
    }
    // Simulasikan dampak semua delta secara berurutan; deteksi shortage.
    const simStock = new Map<string, number>();
    const shortages: string[] = [];
    for (const step of deltaPlan) {
      const cur = simStock.get(step.itemId) ?? step.available;
      const after = cur + step.signed;
      if (after < 0) {
        shortages.push(
          `${step.itemName} (tersedia ${cur}, butuh ${Math.abs(step.signed)})`,
        );
      }
      simStock.set(step.itemId, after);
    }
    if (shortages.length) {
      throw new Error(
        `Stok packaging tidak mencukupi: ${shortages.join("; ")}`,
      );
    }
    // Aman: eksekusi.
    for (const step of deltaPlan) {
      moveStock(
        step.itemId,
        step.signed,
        step.signed > 0
          ? `Shift ${shift.id} · Koreksi Pemakaian Packaging`
          : `Shift ${shift.id} · Pemakaian Packaging`,
        step.signed > 0
          ? "Item dihapus/dikurangi dari pemakaian"
          : isUpdate
            ? "Update pemakaian"
            : undefined,
        true,
      );
    }


    const nowIso = new Date().toISOString();
    const next = recalcPackagingTotal({
      ...shift,
      packagingUsage: nextEntries,
      packagingUsageSavedAt: nowIso,
      packagingUsageSavedBy: input.actor,
    });
    saveShift(next);

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: isUpdate ? "packaging_usage_updated" : "packaging_usage_saved",
      entity: "shift_packaging_usage",
      entityId: shift.id,
      metadata: {
        shiftId: shift.id,
        before: prev,
        after: nextEntries,
      },
    });
    return next;
  },

  // -------------------- Close Shift --------------------
  close(input: CloseShiftInput): Shift | null {
    const cur = shiftService.current();
    if (!cur) return null;

    const closed: Shift = {
      ...cur,
      closedAt: new Date().toISOString(),
      closingCash: input.closingCash,
      expectedCash: input.expectedCash,
      cashDifferenceReason: input.cashDifferenceReason,
      totalOrders: input.totalOrders,
      totalRevenue: input.totalRevenue,
      cashSales: input.cashSales,
      qrisSales: input.qrisSales,
      transferSales: input.transferSales,
      marketplaceSales: input.marketplaceSales,
      marketplaceReconciliations: input.marketplaceReconciliations,
      paymentReconciliations: input.paymentReconciliations,
    };
    storage.remove(StorageKeys.currentShift);
    const list = shiftService
      .list()
      .map((s) => (s.id === closed.id ? closed : s));
    storage.set(StorageKeys.shifts, list);

    auditService.log({
      actor: input.actor,
      actorRole: input.actorRole,
      action: "shift_close",
      entity: "shift",
      entityId: closed.id,
      metadata: {
        totalOrders: closed.totalOrders,
        totalRevenue: closed.totalRevenue,
        cashSales: closed.cashSales,
        qrisSales: closed.qrisSales,
        transferSales: closed.transferSales,
        marketplaceSales: closed.marketplaceSales,
        totalOperationalExpense: closed.totalOperationalExpense ?? 0,
        totalPackagingQty: closed.totalPackagingQty ?? 0,
        expectedCash: closed.expectedCash,
        closingCash: closed.closingCash,
        cashDifference:
          (closed.closingCash ?? 0) - (closed.expectedCash ?? 0),
        cashDifferenceReason: closed.cashDifferenceReason,
        marketplaceReconciliations: closed.marketplaceReconciliations,
        paymentReconciliations: closed.paymentReconciliations,
      },
    });
    return closed;
  },
};
