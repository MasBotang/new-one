/**
 * Finance Analytics Service — read-only derived analytics.
 *
 * Extracted from `finance.service.ts` as part of Phase 1 refactor
 * (Single Source of Truth). Reuses canonical aggregation helpers from
 * `finance-aggregation.ts` — must not re-implement sales/expense loops.
 *
 * Business rule: monthly / daily NET PROFIT is split into 4 pots via the
 * configurable allocation (default 30/20/40/10). Pot balance =
 * (allocation% × cumulative net profit) − withdrawals from that pot.
 */

import { salesService } from "./sales.service";
import {
  financeExpenses,
  financeDebts,
  financeFundWithdraws,
  financeSettings,
} from "./finance.service";
import {
  aggregateSalesList,
  aggregateSalesRange,
  sumExpensesRange,
  sumWithdrawRange,
  sumDebtPaymentsRange,
  dayRange,
  monthRange,
  type SalesAggregate,
  type DateRange,
} from "./finance-aggregation";
import {
  HEALTH_MARGIN_TARGET,
  HEALTH_WASTE_MAX,
  HEALTH_EXPENSE_RATIO_MAX,
  HEALTH_DEBT_PROGRESS_TARGET,
  HEALTH_WEIGHTS,
  HEALTH_STAR_THRESHOLDS,
  HEALTH_COVERAGE_TOTAL,
  DEFAULT_TREND_DAYS,
  DEFAULT_CASHFLOW_DAYS,
} from "./finance.constants";
import type { Sale, FinancePayment, FundPot } from "./types";

// ---------- Period summaries ----------

export interface PeriodSummary extends SalesAggregate {
  expenses: number;
  netProfit: number;
  waste: number;
}

/**
 * TODO(finance/waste): waste is not yet a first-class recorded field. Until
 * production/shift packaging tracks it, this helper reports 0 and callers
 * treat missing data as "not covered" in the health score. Do not surface
 * the 0 as a real KPI value.
 */
function wasteFor(sales: Sale[]): number {
  void sales;
  return 0;
}

function summarize(range: DateRange, sales?: Sale[]): PeriodSummary {
  const agg = sales ? aggregateSalesList(sales) : aggregateSalesRange(range);
  const expenses = sumExpensesRange(range);
  const scopedSales =
    sales ??
    salesService
      .list()
      .filter((s) => {
        const d = new Date(s.createdAt);
        return d >= range.from && d < range.to;
      });
  return {
    ...agg,
    expenses,
    netProfit: agg.grossProfit - expenses,
    waste: wasteFor(scopedSales),
  };
}

// ---------- Ledger ----------

export interface LedgerEntry {
  id: string;
  at: string;
  direction: "in" | "out";
  amount: number;
  category: string;
  pot: FundPot | null;
  payment: FinancePayment;
  description: string;
  refId: string;
}

function mapPaymentChannel(p: string): FinancePayment {
  if (p === "qris") return "qris";
  if (p === "transfer" || p === "card") return "bank";
  return "cash";
}

// ---------- Public analytics API ----------

export const financeAnalytics = {
  today(): PeriodSummary {
    return summarize(dayRange());
  },
  month(): PeriodSummary {
    return summarize(monthRange());
  },
  allTimeNetProfit(): number {
    const agg = aggregateSalesRange();
    const expenses = financeExpenses.list().reduce((a, e) => a + e.amount, 0);
    return agg.grossProfit - expenses;
  },
  /** Profit per hari, N terakhir. */
  profitTrend(days: number): { date: string; revenue: number; profit: number }[] {
    const now = new Date();
    const all = salesService.list();
    const expenses = financeExpenses.list();
    const buckets: { date: string; revenue: number; profit: number }[] = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      const daySales = all.filter((s) => s.createdAt.slice(0, 10) === key);
      const agg = aggregateSalesList(daySales);
      const exp = expenses
        .filter((e) => e.at.slice(0, 10) === key)
        .reduce((a, e) => a + e.amount, 0);
      buckets.push({
        date: key,
        revenue: agg.revenue,
        profit: agg.grossProfit - exp,
      });
    }
    return buckets;
  },
  cashflow(days = DEFAULT_CASHFLOW_DAYS) {
    // Preserve original semantics: `from` is exact-time (days-1) ago, no
    // upper bound. Build a range covering [from, +∞) for the canonical
    // helpers.
    const now = new Date();
    const from = new Date(now);
    from.setDate(from.getDate() - days + 1);
    const to = new Date(8640000000000000); // max Date value
    const range: DateRange = { from, to };
    const inflow = aggregateSalesRange(range).revenue;
    const outflow =
      sumExpensesRange(range) + sumWithdrawRange(range) + sumDebtPaymentsRange(range);
    return { inflow, outflow, net: inflow - outflow };
  },
  cashPosition(): { channel: FinancePayment; balance: number }[] {
    const settings = financeSettings.get();
    const opening = settings.openingBalance;
    const sales = salesService.list().filter((s) => !s.voided);
    const expenses = financeExpenses.list();
    const withdraws = financeFundWithdraws.list();
    const debtPays = financeDebts.payments();
    const totals: Record<FinancePayment, number> = {
      cash: opening.cash,
      qris: opening.qris,
      bank: opening.bank,
      dompet: opening.dompet,
    };
    for (const s of sales) {
      const ch = mapPaymentChannel(s.payment);
      totals[ch] += s.total;
    }
    for (const e of expenses) totals[e.payment] -= e.amount;
    for (const w of withdraws) totals[w.payment] -= w.amount;
    for (const p of debtPays) totals[p.payment] -= p.amount;
    return (Object.keys(totals) as FinancePayment[]).map((c) => ({
      channel: c,
      balance: totals[c],
    }));
  },
  expenseDistributionByPot(days = DEFAULT_CASHFLOW_DAYS) {
    const now = new Date();
    const from = new Date(now);
    from.setDate(from.getDate() - days + 1);
    const to = new Date(8640000000000000);
    const range: DateRange = { from, to };
    const pots: FundPot[] = ["owner", "development", "operational", "debt"];
    const buckets: Record<FundPot, number> = {
      owner: 0,
      development: 0,
      operational: 0,
      debt: 0,
    };
    for (const pot of pots) {
      buckets[pot] += sumExpensesRange(range, { pot });
      buckets[pot] += sumWithdrawRange(range, { pot });
    }
    buckets.debt += sumDebtPaymentsRange(range);
    return pots.map((pot) => ({ pot, amount: buckets[pot] }));
  },
  potBalance(pot: FundPot): { balance: number; today: number; month: number } {
    const settings = financeSettings.get();
    const alloc = settings.allocation[pot] / 100;
    const cumProfit = financeAnalytics.allTimeNetProfit();
    const allocated = Math.max(0, cumProfit) * alloc;
    // NOTE: FinanceExpense sudah dipotong dari `allTimeNetProfit` (via
    // `aggregateSales - expenses`) sebelum dibagi ke pot. Menambahkan expense
    // per-pot ke `spent` di sini akan double-counting saldo pot. Yang benar-
    // benar mengurangi saldo pot adalah withdraw dari pot tsb + (khusus pot
    // "debt") pembayaran hutang.
    const withdrawsAll = financeFundWithdraws.list().filter((w) => w.pot === pot);
    const debtPaymentsAll = pot === "debt" ? financeDebts.payments() : [];
    const spent =
      withdrawsAll.reduce((a, w) => a + w.amount, 0) +
      debtPaymentsAll.reduce((a, p) => a + p.amount, 0);
    const balance = allocated - spent;
    const today = dayRange();
    const month = monthRange();
    const withinRange = (iso: string, r: DateRange) => {
      const d = new Date(iso);
      return d >= r.from && d < r.to;
    };
    const spentIn = (r: DateRange) =>
      withdrawsAll.filter((w) => withinRange(w.at, r)).reduce((a, w) => a + w.amount, 0) +
      debtPaymentsAll.filter((p) => withinRange(p.at, r)).reduce((a, p) => a + p.amount, 0);
    return { balance, today: spentIn(today), month: spentIn(month) };
  },
  healthScore(): {
    status: "waiting-data" | "ready";
    score: number | null;
    stars: number;
    reasons: { label: string; tone: "positive" | "neutral" | "negative" }[];
    coverage: { covered: number; total: number; percent: number };
    dataQuality: {
      level: "none" | "very-low" | "early" | "almost" | "complete";
      label: string;
      tone: "gray" | "red" | "orange" | "yellow" | "green";
    };
    insight: string;
  } {
    const m = financeAnalytics.month();
    const cf = financeAnalytics.cashflow(DEFAULT_CASHFLOW_DAYS);
    const debtTotals = financeDebts.totals();
    const dev = financeAnalytics.potBalance("development");
    const expensesAll = financeExpenses.list();
    const withdrawsAll = financeFundWithdraws.list();
    const debtPaymentsAll = financeDebts.payments();
    const withdrawTotal = withdrawsAll.reduce((a, w) => a + w.amount, 0);

    const hasAnyExpense = expensesAll.length > 0;
    const hasAnyWithdraw = withdrawsAll.length > 0;
    const hasAnyDebtPayment = debtPaymentsAll.length > 0;
    const hasOperationalExpense = expensesAll.some((e) => e.pot === "operational");
    const hasWasteData = m.waste > 0;
    const hasDevActivity =
      dev.balance > 0 || withdrawsAll.some((w) => w.pot === "development");
    const hasAnyDebt = financeDebts.list().length > 0 || debtTotals.principal > 0;

    if (
      m.revenue === 0 &&
      m.expenses === 0 &&
      debtTotals.principal === 0 &&
      withdrawTotal === 0
    ) {
      return {
        status: "waiting-data",
        score: null,
        stars: 0,
        reasons: [],
        coverage: { covered: 0, total: HEALTH_COVERAGE_TOTAL, percent: 0 },
        dataQuality: { level: "none", label: "Belum Ada Data", tone: "gray" },
        insight:
          "Belum ada transaksi yang tercatat. Mulai catat penjualan, pengeluaran, atau pencairan dana agar Financial Health dapat dievaluasi.",
      };
    }

    const margin: number | null = m.revenue > 0 ? m.grossProfit / m.revenue : null;
    const wasteRatio: number | null =
      m.revenue > 0 && hasWasteData ? m.waste / m.revenue : null;
    const opRatio: number | null =
      m.revenue > 0 && hasOperationalExpense ? m.expenses / m.revenue : null;

    type Tone = "positive" | "neutral" | "negative";
    type Check = { label: string; tone: Tone; weight: number; earned: number; covered: boolean };
    const checks: Check[] = [];

    // 1. Margin
    if (margin === null) {
      checks.push({
        label: "Margin belum bisa dihitung",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.margin,
        earned: 0,
        covered: false,
      });
    } else {
      const ok = margin >= HEALTH_MARGIN_TARGET;
      checks.push({
        label: ok
          ? `Margin sehat (${(margin * 100).toFixed(0)}%)`
          : `Margin tipis (${(margin * 100).toFixed(0)}%)`,
        tone: ok ? "positive" : "negative",
        weight: HEALTH_WEIGHTS.margin,
        earned: ok ? HEALTH_WEIGHTS.margin : 0,
        covered: true,
      });
    }

    // 2. Cashflow
    const cashflowCovered =
      m.revenue > 0 && (hasAnyExpense || hasAnyWithdraw || hasAnyDebtPayment);
    if (!cashflowCovered) {
      checks.push({
        label: "Belum cukup data cashflow",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.cashflow,
        earned: 0,
        covered: false,
      });
    } else if (cf.net > 0) {
      checks.push({
        label: "Cashflow positif",
        tone: "positive",
        weight: HEALTH_WEIGHTS.cashflow,
        earned: HEALTH_WEIGHTS.cashflow,
        covered: true,
      });
    } else if (cf.net === 0) {
      checks.push({
        label: "Cashflow seimbang",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.cashflow,
        earned: 0,
        covered: true,
      });
    } else {
      checks.push({
        label: "Cashflow negatif",
        tone: "negative",
        weight: HEALTH_WEIGHTS.cashflow,
        earned: 0,
        covered: true,
      });
    }

    // 3. Waste
    if (wasteRatio === null) {
      checks.push({
        label: "Belum ada data waste produksi",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.waste,
        earned: 0,
        covered: false,
      });
    } else {
      const ok = wasteRatio <= HEALTH_WASTE_MAX;
      checks.push({
        label: `Waste ${(wasteRatio * 100).toFixed(1)}%`,
        tone: ok ? "positive" : "negative",
        weight: HEALTH_WEIGHTS.waste,
        earned: ok ? HEALTH_WEIGHTS.waste : 0,
        covered: true,
      });
    }

    // 4. Operational
    if (opRatio === null) {
      checks.push({
        label: "Belum ada biaya operasional",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.operational,
        earned: 0,
        covered: false,
      });
    } else {
      const ok = opRatio <= HEALTH_EXPENSE_RATIO_MAX;
      checks.push({
        label: ok
          ? `Operasional terjaga (${(opRatio * 100).toFixed(0)}% dari omset)`
          : `Operasional masih tinggi (${(opRatio * 100).toFixed(0)}% dari omset)`,
        tone: ok ? "positive" : "negative",
        weight: HEALTH_WEIGHTS.operational,
        earned: ok ? HEALTH_WEIGHTS.operational : 0,
        covered: true,
      });
    }

    // 5. Debt
    if (!hasAnyDebt) {
      checks.push({
        label: "Tidak memiliki hutang",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.debt,
        earned: 0,
        covered: false,
      });
    } else {
      const ok = debtTotals.progress >= HEALTH_DEBT_PROGRESS_TARGET;
      checks.push({
        label: `Progress hutang ${(debtTotals.progress * 100).toFixed(0)}%`,
        tone: ok ? "positive" : "negative",
        weight: HEALTH_WEIGHTS.debt,
        earned: ok ? HEALTH_WEIGHTS.debt : 0,
        covered: true,
      });
    }

    // 6. Development
    if (!hasDevActivity) {
      checks.push({
        label: "Belum ada aktivitas Development Fund",
        tone: "neutral",
        weight: HEALTH_WEIGHTS.development,
        earned: 0,
        covered: false,
      });
    } else {
      const ok = dev.balance > 0;
      checks.push({
        label: ok ? `Development Fund aktif` : "Development Fund pernah dicairkan",
        tone: ok ? "positive" : "neutral",
        weight: HEALTH_WEIGHTS.development,
        earned: ok ? HEALTH_WEIGHTS.development : 0,
        covered: true,
      });
    }

    const earned = checks.reduce((a, c) => a + c.earned, 0);
    const score = Math.min(100, Math.max(0, Math.round(earned)));

    // Star mapping (see HEALTH_STAR_THRESHOLDS — gap at 3 is intentional).
    let stars = 0;
    for (const t of HEALTH_STAR_THRESHOLDS) {
      if (score > t.score) {
        stars = t.stars;
        break;
      }
    }

    const covered = checks.filter((c) => c.covered).length;
    const total = checks.length;
    const percent = Math.round((covered / total) * 100);

    let dataQuality: {
      level: "none" | "very-low" | "early" | "almost" | "complete";
      label: string;
      tone: "gray" | "red" | "orange" | "yellow" | "green";
    };
    if (covered === 0) dataQuality = { level: "none", label: "Belum Ada Data", tone: "gray" };
    else if (covered <= 2)
      dataQuality = { level: "very-low", label: "Data Sangat Minim", tone: "red" };
    else if (covered <= 4)
      dataQuality = { level: "early", label: "Data Awal", tone: "orange" };
    else if (covered === 5)
      dataQuality = { level: "almost", label: "Data Hampir Lengkap", tone: "yellow" };
    else dataQuality = { level: "complete", label: "Data Lengkap", tone: "green" };

    let insight: string;
    if (covered <= 2) {
      insight =
        "Analisis masih menggunakan sebagian kecil data bisnis. Lanjutkan pencatatan Expense, Produksi, serta pencairan dana agar evaluasi semakin akurat.";
    } else if (covered <= 4) {
      insight =
        "Sebagian besar indikator sudah tersedia. Masih diperlukan data operasional untuk menghasilkan evaluasi yang lebih lengkap.";
    } else if (covered === 5) {
      insight =
        "Hampir seluruh indikator tersedia. Lengkapi indikator terakhir untuk evaluasi menyeluruh.";
    } else {
      insight =
        "Seluruh indikator bisnis telah tersedia. Financial Health sekarang mencerminkan kondisi usaha secara menyeluruh.";
    }

    return {
      status: "ready",
      score,
      stars,
      reasons: checks.map((c) => ({ label: c.label, tone: c.tone })),
      coverage: { covered, total, percent },
      dataQuality,
      insight,
    };
  },
  topInsights(): { text: string; tone: "positive" | "warning" | "info" }[] {
    const out: { text: string; tone: "positive" | "warning" | "info" }[] = [];
    const trend = financeAnalytics.profitTrend(DEFAULT_TREND_DAYS);
    const half = Math.floor(DEFAULT_TREND_DAYS / 2);
    if (trend.length >= DEFAULT_TREND_DAYS) {
      const prev = trend.slice(0, half).reduce((a, d) => a + d.profit, 0);
      const curr = trend.slice(half).reduce((a, d) => a + d.profit, 0);
      if (prev > 0) {
        const delta = (curr - prev) / prev;
        out.push({
          text: `Profit 7 hari terakhir ${delta >= 0 ? "naik" : "turun"} ${Math.abs(delta * 100).toFixed(0)}% vs minggu sebelumnya`,
          tone: delta >= 0 ? "positive" : "warning",
        });
      }
    }
    const debtTotals = financeDebts.totals();
    if (debtTotals.principal > 0) {
      out.push({
        text: `Hutang tersisa ${((1 - debtTotals.progress) * 100).toFixed(0)}%`,
        tone: debtTotals.progress >= HEALTH_DEBT_PROGRESS_TARGET ? "positive" : "info",
      });
    }
    const dev = financeAnalytics.potBalance("development");
    const settings = financeSettings.get();
    if (settings.developmentTarget > 0) {
      const pct = Math.max(0, dev.balance) / settings.developmentTarget;
      out.push({
        text: `Dana Pengembangan sudah ${(Math.min(1, pct) * 100).toFixed(0)}% dari target`,
        tone: pct >= HEALTH_DEBT_PROGRESS_TARGET ? "positive" : "info",
      });
    }
    // Top product by profit contribution
    const productProfit: Record<string, { name: string; profit: number }> = {};
    for (const s of salesService.list()) {
      if (s.voided) continue;
      for (const it of s.items) {
        const p = productProfit[it.productId] ?? { name: it.name, profit: 0 };
        p.profit += (it.price - (it.cost ?? 0)) * it.qty;
        productProfit[it.productId] = p;
      }
    }
    const top = Object.values(productProfit).sort((a, b) => b.profit - a.profit)[0];
    if (top && top.profit > 0) {
      out.push({ text: `${top.name} memberi profit tertinggi bulan ini`, tone: "positive" });
    }
    const monthExp = financeAnalytics.month().expenses;
    if (monthExp === 0) {
      out.push({ text: "Belum ada pengeluaran tercatat bulan ini", tone: "info" });
    }
    return out.slice(0, 6);
  },
  /** Ledger unifikasi seluruh arus uang. */
  ledger(): LedgerEntry[] {
    const rows: LedgerEntry[] = [];
    for (const s of salesService.list()) {
      if (s.voided) continue;
      rows.push({
        id: `sale:${s.id}`,
        at: s.createdAt,
        direction: "in",
        amount: s.total,
        category: "Penjualan",
        pot: null,
        payment: mapPaymentChannel(s.payment),
        description: `Sales ${s.id}`,
        refId: s.id,
      });
    }
    for (const e of financeExpenses.list()) {
      rows.push({
        id: `exp:${e.id}`,
        at: e.at,
        direction: "out",
        amount: e.amount,
        category: "Expense",
        pot: e.pot,
        payment: e.payment,
        description: e.description,
        refId: e.id,
      });
    }
    for (const w of financeFundWithdraws.list()) {
      rows.push({
        id: `fw:${w.id}`,
        at: w.at,
        direction: "out",
        amount: w.amount,
        category: "Fund Withdraw",
        pot: w.pot,
        payment: w.payment,
        description: w.description,
        refId: w.id,
      });
    }
    for (const p of financeDebts.payments()) {
      rows.push({
        id: `dp:${p.id}`,
        at: p.at,
        direction: "out",
        amount: p.amount,
        category: "Debt Payment",
        pot: "debt",
        payment: p.payment,
        description: p.notes ?? "Pembayaran hutang",
        refId: p.debtId,
      });
    }
    return rows.sort((a, b) => (a.at < b.at ? 1 : -1));
  },
};
