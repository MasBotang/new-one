import { createFileRoute } from "@tanstack/react-router";
import { StockMovementPage } from "@/features/inventory/stock-movement-page";
export const Route = createFileRoute("/_app/inventory/stock-movement")({
  head: () => ({ meta: [{ title: "Pergerakan Stok · DeSalut" }] }),
  component: StockMovementPage,
});