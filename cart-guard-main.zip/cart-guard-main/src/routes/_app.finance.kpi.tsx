import { createFileRoute } from "@tanstack/react-router";
import { FinanceKpiPage } from "@/features/finance/finance-kpi-page";

export const Route = createFileRoute("/_app/finance/kpi")({
  component: FinanceKpiPage,
});
