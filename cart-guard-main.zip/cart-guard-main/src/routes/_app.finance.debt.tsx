import { createFileRoute } from "@tanstack/react-router";
import { FinanceDebtPage } from "@/features/finance/finance-debt-page";

export const Route = createFileRoute("/_app/finance/debt")({
  component: FinanceDebtPage,
});
