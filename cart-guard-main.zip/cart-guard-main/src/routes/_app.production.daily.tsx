import { createFileRoute, Navigate } from "@tanstack/react-router";
// Halaman "Pencatatan Produksi" digabung ke halaman Produksi tunggal.
export const Route = createFileRoute("/_app/production/daily")({
  component: () => <Navigate to="/production/produksi" replace />,
});
