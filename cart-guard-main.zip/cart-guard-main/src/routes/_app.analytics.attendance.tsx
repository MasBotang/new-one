import { createFileRoute } from "@tanstack/react-router";
import { AttendanceAnalyticsPage } from "@/features/analytics/attendance/attendance-analytics-page";

export const Route = createFileRoute("/_app/analytics/attendance")({
  head: () => ({
    meta: [
      { title: "Attendance Analytics · DeSalut" },
      {
        name: "description",
        content:
          "Attendance Analytics — KPI kehadiran, trend, tabel operator, insight, dan export. Read-only.",
      },
    ],
  }),
  component: AttendanceAnalyticsPage,
});
