import { createFileRoute } from "@tanstack/react-router";
import { ProduksiPage } from "@/features/production/produksi-page";

export const Route = createFileRoute("/_app/production/produksi")({
  head: () => ({ meta: [{ title: "Produksi · DeSalut" }] }),
  component: ProduksiPage,
});
