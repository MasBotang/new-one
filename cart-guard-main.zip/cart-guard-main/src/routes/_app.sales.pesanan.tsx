import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { PesananPage } from "@/features/sales/pesanan-page";

const searchSchema = z.object({
  tab: z.enum(["pesanan", "preorder"]).optional(),
});

export const Route = createFileRoute("/_app/sales/pesanan")({
  validateSearch: searchSchema,
  head: () => ({ meta: [{ title: "Pesanan · DeSalut" }] }),
  component: PesananPage,
});
