import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect } from "react";
import { useRole } from "@/lib/role-context";
import { ROLE_LANDING } from "@/lib/navigation";

export const Route = createFileRoute("/")({
  component: IndexRedirect,
});

function IndexRedirect() {
  const router = useRouter();
  const { role, user, hydrated } = useRole();
  useEffect(() => {
    if (!hydrated) return;
    if (role) {
      router.navigate({ to: ROLE_LANDING[role], replace: true });
    } else {
      // Hydrated but no role (signed out, or signed in without a role) —
      // send to auth instead of hanging on the loading screen.
      router.navigate({ to: "/auth", replace: true });
    }
  }, [hydrated, role, user, router]);
  return (
    <div className="flex min-h-[60vh] items-center justify-center text-sm text-muted-foreground">
      Loading workspace…
    </div>
  );
}