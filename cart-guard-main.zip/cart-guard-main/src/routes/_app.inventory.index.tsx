import { createFileRoute } from "@tanstack/react-router";
import { InventoryOverviewPage } from "@/features/inventory/inventory-overview-page";
export const Route = createFileRoute("/_app/inventory/")({
  head: () => ({ meta: [{ title: "Inventaris · DeSalut" }] }),
  component: InventoryOverviewPage,
});