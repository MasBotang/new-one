import { createFileRoute } from "@tanstack/react-router";
import { PayrollAnalyticsPage } from "@/features/analytics/payroll/payroll-analytics-page";

export const Route = createFileRoute("/_app/analytics/payroll")({
  head: () => ({
    meta: [
      { title: "Payroll Analytics · DeSalut" },
      {
        name: "description",
        content:
          "Payroll Analytics — Gross/Net, Bonus, Deduction, Outstanding, Settlement progress, trend, tabel operator, insight, dan export. Read-only.",
      },
    ],
  }),
  component: PayrollAnalyticsPage,
});
