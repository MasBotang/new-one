import { createFileRoute } from "@tanstack/react-router";
import { ProductionHomePage } from "@/features/production/production-home-page";

export const Route = createFileRoute("/_app/production/")({
  head: () => ({ meta: [{ title: "Home Produksi · DeSalut" }] }),
  component: ProductionHomePage,
});
