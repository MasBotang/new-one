import { createFileRoute, Navigate } from "@tanstack/react-router";
import { RecipesPage } from "@/features/production/recipes-page";
import { useRole } from "@/lib/role-context";

function Gate() {
  const { role, hydrated } = useRole();
  if (!hydrated) return null;
  if (role !== "admin") {
    return <Navigate to="/production/produksi" replace />;
  }
  return <RecipesPage />;
}

export const Route = createFileRoute("/_app/production/recipes")({
  head: () => ({ meta: [{ title: "Resep · DeSalut" }] }),
  component: Gate,
});
