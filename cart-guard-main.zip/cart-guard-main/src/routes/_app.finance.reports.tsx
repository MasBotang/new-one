import { createFileRoute } from "@tanstack/react-router";
import { FinanceReportsPage } from "@/features/finance/finance-reports-page";

export const Route = createFileRoute("/_app/finance/reports")({
  component: FinanceReportsPage,
});
