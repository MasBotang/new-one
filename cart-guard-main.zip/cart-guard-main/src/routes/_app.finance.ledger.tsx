import { createFileRoute } from "@tanstack/react-router";
import { FinanceLedgerPage } from "@/features/finance/finance-ledger-page";

export const Route = createFileRoute("/_app/finance/ledger")({
  component: FinanceLedgerPage,
});
