import { createFileRoute } from "@tanstack/react-router";
import { FinanceBudgetPage } from "@/features/finance/finance-budget-page";

export const Route = createFileRoute("/_app/finance/budget")({
  component: FinanceBudgetPage,
});
