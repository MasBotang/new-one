import { createFileRoute } from "@tanstack/react-router";
import { InventoryItemsPage } from "@/features/inventory/inventory-items-page";

export const Route = createFileRoute("/_app/inventory/items")({
  head: () => ({ meta: [{ title: "Items Inventaris · DeSalut" }] }),
  component: InventoryItemsPage,
});