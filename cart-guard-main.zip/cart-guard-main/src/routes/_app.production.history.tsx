import { createFileRoute } from "@tanstack/react-router";
import { ProductionHistoryPage } from "@/features/production/production-history-page";
export const Route = createFileRoute("/_app/production/history")({
  head: () => ({ meta: [{ title: "Riwayat Produksi · DeSalut" }] }),
  component: ProductionHistoryPage,
});
