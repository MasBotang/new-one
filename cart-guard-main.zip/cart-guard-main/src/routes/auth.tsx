import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { useRole } from "@/lib/role-context";
import { ROLE_LANDING } from "@/lib/navigation";
import { toast } from "sonner";
import { adminExists, bootstrapAdmin } from "@/lib/accounts.functions";

export const Route = createFileRoute("/auth")({
  validateSearch: (s) =>
    z.object({ redirect: z.string().optional() }).parse(s),
  head: () => ({
    meta: [
      { title: "Masuk — DeSalut Business OS" },
      { name: "description", content: "Masuk ke workspace DeSalut Business OS." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { user, role, hydrated, signIn } = useRole();
  const navigate = useNavigate();
  const search = Route.useSearch();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (hydrated && user && role) {
      const target = search.redirect || ROLE_LANDING[role];
      navigate({ to: target, replace: true });
    }
  }, [hydrated, user, role, search.redirect, navigate]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    try {
      await signIn(email.trim(), password);
      toast.success("Berhasil masuk");
    } catch (error) {
      const msg = (error as Error).message;
      setErr(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-6 py-10">
      {/* warm decorative blobs */}
      <div
        className="pointer-events-none absolute -top-56 -right-56 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, oklch(0.85 0.12 80 / 0.22), transparent 70%)" }}
      />
      <div
        className="pointer-events-none absolute -bottom-56 -left-56 h-[560px] w-[560px] rounded-full"
        style={{ background: "radial-gradient(circle, oklch(0.45 0.16 26 / 0.10), transparent 70%)" }}
      />

      <div className="relative z-10 grid w-full max-w-[960px] grid-cols-1 overflow-hidden rounded-[28px] border border-white/60 bg-surface shadow-elevated md:grid-cols-[44%_56%]">
        {/* Brand panel */}
        <div
          className="relative overflow-hidden p-10 text-primary-foreground"
          style={{ background: "var(--primary-deep)" }}
        >
          <div
            className="pointer-events-none absolute -top-24 -left-24 h-64 w-64 rounded-full"
            style={{ background: "oklch(0.85 0.14 85 / 0.22)", filter: "blur(80px)" }}
          />
          <div
            className="pointer-events-none absolute bottom-8 right-8 h-48 w-48 rounded-full"
            style={{ background: "var(--primary)", filter: "blur(60px)" }}
          />

          <div className="relative z-10 flex h-full min-h-[420px] flex-col justify-between gap-10">
            <div>
              <div
                className="mb-6 flex items-center justify-center rounded-2xl bg-background shadow-elevated"
                style={{ width: 52, height: 52 }}
              >
                <span
                  className="font-display text-2xl font-bold"
                  style={{ color: "var(--primary-deep)" }}
                >
                  D
                </span>
              </div>
              <h1 className="font-display text-[38px] font-bold leading-[1.05] tracking-tight">
                DeSalut
              </h1>
              <p className="mt-3 max-w-[260px] text-[15px] leading-relaxed text-white/80">
                Business Operating System untuk Risol Mayo Premium —
                penjualan, produksi, inventaris, dan tim dalam satu tempat.
              </p>
            </div>
            <div>
              <div className="mb-3 h-[3px] w-11 rounded-full gold-gradient" />
              <p className="max-w-[260px] text-[12.5px] italic leading-relaxed text-white/60">
                "Artisan Risol Mayo · Premium Business Experience"
              </p>
            </div>
          </div>
        </div>

        {/* Form panel */}
        <div className="p-10 md:p-12" style={{ background: "oklch(0.98 0.012 85)" }}>
          <h2 className="font-display text-[26px] font-bold tracking-tight text-foreground">
            Selamat datang kembali
          </h2>
          <p className="mt-1 text-[13.5px] text-muted-foreground">
            Masuk untuk melanjutkan ke workspace kamu.
          </p>

          {err && (
            <div className="mt-5 rounded-xl bg-destructive-soft px-3 py-2.5 text-[12.5px] font-medium text-destructive">
              {err}
            </div>
          )}

          <form className="mt-6 space-y-4" onSubmit={handleLogin}>
            <div>
              <label
                className="mb-2 block text-[10.5px] font-bold uppercase tracking-[0.09em]"
                style={{ color: "var(--primary-deep)" }}
              >
                Email
              </label>
              <input
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="anda@desalut.id"
                className="w-full rounded-2xl border border-border bg-surface px-4 py-3.5 text-sm text-foreground outline-none transition focus:border-primary focus:shadow-[0_0_0_4px_oklch(0.48_0.16_26_/_0.10)]"
              />
            </div>
            <div>
              <label
                className="mb-2 block text-[10.5px] font-bold uppercase tracking-[0.09em]"
                style={{ color: "var(--primary-deep)" }}
              >
                Kata Sandi
              </label>
              <input
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-2xl border border-border bg-surface px-4 py-3.5 text-sm text-foreground outline-none transition focus:border-primary focus:shadow-[0_0_0_4px_oklch(0.48_0.16_26_/_0.10)]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="mt-2 w-full rounded-2xl py-3.5 text-sm font-bold text-primary-foreground transition hover:-translate-y-0.5 active:translate-y-0 shadow-brand disabled:opacity-60 disabled:hover:translate-y-0"
              style={{ background: "var(--primary-deep)" }}
            >
              {loading ? "Memproses…" : "Masuk ke Workspace"}
            </button>
          </form>

          <BootstrapAdminPanel />
        </div>
      </div>
    </div>
  );
}

function BootstrapAdminPanel() {
  const [open, setOpen] = useState(false);
  const [checking, setChecking] = useState(true);
  const [hasAdmin, setHasAdmin] = useState(true);
  const [full_name, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    adminExists()
      .then((r) => setHasAdmin(r.exists))
      .finally(() => setChecking(false));
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await bootstrapAdmin({ data: { email: email.trim(), password, full_name } });
      toast.success("Admin dibuat. Silakan masuk.");
      setOpen(false);
      setHasAdmin(true);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (checking) return null;
  if (hasAdmin) {
    return (
      <div
        className="mt-7 rounded-2xl border p-4"
        style={{ background: "var(--gold-soft)", borderColor: "oklch(0.88 0.10 88)" }}
      >
        <div
          className="mb-1 text-[10px] font-bold uppercase tracking-[0.14em]"
          style={{ color: "oklch(0.45 0.10 70)" }}
        >
          Akun
        </div>
        <p className="text-[12px] leading-relaxed" style={{ color: "oklch(0.40 0.08 60)" }}>
          Akun baru dibuat oleh Admin melalui menu{" "}
          <span className="font-semibold">Pengaturan → Manajemen Akun</span>. Hubungi admin kamu
          jika butuh akses.
        </p>
      </div>
    );
  }

  return (
    <div
      className="mt-7 rounded-2xl border p-4"
      style={{ background: "var(--gold-soft)", borderColor: "oklch(0.88 0.10 88)" }}
    >
      <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.14em]" style={{ color: "oklch(0.45 0.10 70)" }}>
        Setup Pertama
      </div>
      <p className="text-[12px] leading-relaxed" style={{ color: "oklch(0.40 0.08 60)" }}>
        Belum ada admin di sistem. Buat akun admin pertama untuk mulai.
      </p>
      {!open ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="mt-2 rounded-lg px-3 py-1.5 text-[12px] font-semibold text-primary-foreground"
          style={{ background: "var(--primary-deep)" }}
        >
          Buat Admin Pertama
        </button>
      ) : (
        <form onSubmit={submit} className="mt-3 space-y-2">
          <input required placeholder="Nama lengkap" value={full_name} onChange={(e) => setFullName(e.target.value)}
            className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-[13px]" />
          <input required type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-[13px]" />
          <input required type="password" minLength={6} placeholder="Password (min 6)" value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-[13px]" />
          <button disabled={busy} type="submit"
            className="w-full rounded-lg py-2 text-[13px] font-semibold text-primary-foreground disabled:opacity-60"
            style={{ background: "var(--primary-deep)" }}>
            {busy ? "Membuat…" : "Buat Admin"}
          </button>
        </form>
      )}
    </div>
  );
}
