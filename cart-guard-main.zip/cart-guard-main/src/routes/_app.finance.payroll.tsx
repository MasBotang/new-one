import { createFileRoute } from "@tanstack/react-router";
import { PayrollPage } from "@/features/payroll/payroll-page";

export const Route = createFileRoute("/_app/finance/payroll")({
  component: PayrollPage,
});