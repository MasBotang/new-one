import { createFileRoute } from "@tanstack/react-router";
import { PurchaseInPage } from "@/features/inventory/purchase-in-page";

export const Route = createFileRoute("/_app/inventory/purchase-in")({
  head: () => ({ meta: [{ title: "Barang Masuk · DeSalut" }] }),
  component: PurchaseInPage,
});