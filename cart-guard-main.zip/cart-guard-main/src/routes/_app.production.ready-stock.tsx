import { createFileRoute } from "@tanstack/react-router";
import { ReadyStockProductionPage } from "@/features/production/ready-stock-production-page";
export const Route = createFileRoute("/_app/production/ready-stock")({
  head: () => ({ meta: [{ title: "Ready Stock Production · DeSalut" }] }),
  component: ReadyStockProductionPage,
});
