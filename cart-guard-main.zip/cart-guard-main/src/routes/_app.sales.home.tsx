import { createFileRoute } from "@tanstack/react-router";
import { SalesHomePage } from "@/features/sales/home-page";

export const Route = createFileRoute("/_app/sales/home")({
  component: SalesHomePage,
});