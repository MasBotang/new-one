import { createFileRoute } from "@tanstack/react-router";
import { StockOpnamePage } from "@/features/inventory/stock-opname-page";

export const Route = createFileRoute("/_app/inventory/stock-opname")({
  head: () => ({ meta: [{ title: "Stock Opname · DeSalut" }] }),
  component: StockOpnamePage,
});