import { createFileRoute } from "@tanstack/react-router";
import { FinanceFundPage } from "@/features/finance/finance-fund-page";

export const Route = createFileRoute("/_app/finance/owner-fund")({
  component: () => <FinanceFundPage pot="owner" />,
});
