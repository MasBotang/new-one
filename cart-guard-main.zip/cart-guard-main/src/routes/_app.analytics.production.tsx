import { createFileRoute } from "@tanstack/react-router";
import { ProductionAnalyticsPage } from "@/features/analytics/production/production-analytics-page";

export const Route = createFileRoute("/_app/analytics/production")({
  head: () => ({ meta: [{ title: "Production Analytics · DeSalut" }] }),
  component: ProductionAnalyticsPage,
});
