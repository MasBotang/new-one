import { createFileRoute, Navigate } from "@tanstack/react-router";
// Halaman Planning dihapus. Rekomendasi produksi kini ada di Home Produksi.
export const Route = createFileRoute("/_app/production/planning")({
  component: () => <Navigate to="/production" replace />,
});
