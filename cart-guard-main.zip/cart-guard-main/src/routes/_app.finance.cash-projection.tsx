import { createFileRoute } from "@tanstack/react-router";
import { FinanceCashProjectionPage } from "@/features/finance/finance-cash-projection-page";

export const Route = createFileRoute("/_app/finance/cash-projection")({
  component: FinanceCashProjectionPage,
});
