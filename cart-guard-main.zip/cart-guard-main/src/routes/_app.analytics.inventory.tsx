import { createFileRoute } from "@tanstack/react-router";
import { InventoryAnalyticsPage } from "@/features/analytics/inventory/inventory-analytics-page";

export const Route = createFileRoute("/_app/analytics/inventory")({
  head: () => ({ meta: [{ title: "Inventory Analytics · DeSalut" }] }),
  component: InventoryAnalyticsPage,
});
