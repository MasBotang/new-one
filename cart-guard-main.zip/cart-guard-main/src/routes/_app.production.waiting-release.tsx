import { createFileRoute, Navigate } from "@tanstack/react-router";
// Waiting Release digabung sebagai section terakhir di halaman Produksi.
export const Route = createFileRoute("/_app/production/waiting-release")({
  component: () => <Navigate to="/production/produksi" replace />,
});
