import { createFileRoute } from "@tanstack/react-router";
import { PayrollSettlementPage } from "@/features/payroll-settlement/payroll-settlement-page";

export const Route = createFileRoute("/_app/finance/payroll-settlement")({
  component: PayrollSettlementPage,
});