import {
  ShoppingCart,
  Boxes,
  Factory,
  WalletCards,
  BarChart3,
  UsersRound,
  Settings,
  ListChecks,
  Package,
  Home,
  Clock,
  type LucideIcon,

} from "lucide-react";
import type { Role } from "@/services/types";

export interface NavChild {
  title: string;
  to: string;
  comingVersion?: number;
}

export interface NavItem {
  id: string;
  title: string;
  icon: LucideIcon;
  to?: string;
  children?: NavChild[];
  comingVersion?: number;
}

// ---------- Per-role navigation ----------
// ERP v1.0 — 7 core modules only:
// Analytics, Sales, Production, Inventory, Finance, Accounts, Settings.
const adminNav: NavItem[] = [
  {
    id: "analytics",
    title: "Analytics",
    icon: BarChart3,
    children: [
      { title: "Sales", to: "/analytics/sales" },
      { title: "Inventory", to: "/analytics/inventory" },
      { title: "Production", to: "/analytics/production" },
      { title: "Finance", to: "/analytics/finance" },
      { title: "Attendance", to: "/analytics/attendance" },
      { title: "Payroll", to: "/analytics/payroll" },
    ],
  },

  {
    id: "sales",
    title: "Penjualan",
    icon: ShoppingCart,
    children: [
      { title: "Home", to: "/sales/home" },
      { title: "POS", to: "/sales/pos" },
      { title: "Pesanan", to: "/sales/pesanan" },
      { title: "Produk", to: "/sales/products" },
      { title: "Shift", to: "/sales/shifts" },
    ],
  },
  {
    id: "production",
    title: "Produksi",
    icon: Factory,
    children: [
      { title: "Home", to: "/production" },
      { title: "Produksi", to: "/production/produksi" },
      { title: "Ready Stock", to: "/production/ready-stock" },
      { title: "Resep", to: "/production/recipes" },
      { title: "Riwayat", to: "/production/history" },
    ],
  },
  {
    id: "inventory",
    title: "Inventaris",
    icon: Boxes,
    children: [
      { title: "Dashboard", to: "/inventory" },
      { title: "Daftar Barang", to: "/inventory/items" },
      { title: "Barang Masuk", to: "/inventory/purchase-in" },
      { title: "Stock Opname", to: "/inventory/stock-opname" },
      { title: "Riwayat Stok", to: "/inventory/stock-movement" },
    ],
  },
  {
    id: "finance",
    title: "Keuangan",
    icon: WalletCards,
    children: [
      { title: "Overview", to: "/finance" },
      { title: "Ledger", to: "/finance/ledger" },
      { title: "Pengeluaran", to: "/finance/expenses" },
      { title: "Hutang", to: "/finance/debt" },
      { title: "Owner Fund", to: "/finance/owner-fund" },
      { title: "Development Fund", to: "/finance/development-fund" },
      { title: "Operational Fund", to: "/finance/operational-fund" },
      { title: "Budget", to: "/finance/budget" },
      { title: "Payroll", to: "/finance/payroll" },
      { title: "Payroll Settlement", to: "/finance/payroll-settlement" },
    ],
  },
  {
    id: "accounts",
    title: "Akun",
    icon: UsersRound,
    children: [
      { title: "Daftar Akun", to: "/accounts" },
      { title: "Attendance", to: "/accounts/attendance" },
    ],
  },
  { id: "settings", title: "Pengaturan", icon: Settings, to: "/settings" },
];


// Owner shares the same 7-module sidebar as admin in ERP v1.0.
const ownerNav: NavItem[] = adminNav;

const cashierNav: NavItem[] = [
  { id: "sales-home", title: "Home", icon: Home, to: "/sales/home" },
  { id: "pos", title: "POS", icon: ShoppingCart, to: "/sales/pos" },
  { id: "pesanan", title: "Pesanan", icon: ListChecks, to: "/sales/pesanan" },
  { id: "products", title: "Produk", icon: Package, to: "/sales/products" },
  { id: "shifts", title: "Shift", icon: Clock, to: "/sales/shifts" },
];

const productionNav: NavItem[] = [
  // Sprint 4 (Finding #3): item "Pesanan" dihapus dari nav Production —
  // role Production hanya boleh mengakses modul Production & Inventory.
  {

    id: "inventory",
    title: "Inventaris",
    icon: Boxes,
    children: [
      { title: "Dashboard", to: "/inventory" },
      { title: "Daftar Barang", to: "/inventory/items" },
      { title: "Barang Masuk", to: "/inventory/purchase-in" },
      { title: "Stock Opname", to: "/inventory/stock-opname" },
      { title: "Riwayat Stok", to: "/inventory/stock-movement" },
    ],
  },
  {
    id: "production",
    title: "Produksi",
    icon: Factory,
    children: [
      { title: "Home", to: "/production" },
      { title: "Produksi", to: "/production/produksi" },
      { title: "Ready Stock", to: "/production/ready-stock" },
      { title: "Resep", to: "/production/recipes" },
      { title: "Riwayat", to: "/production/history" },
    ],
  },
];

const NAV_BY_ROLE: Record<Role, NavItem[]> = {
  admin: adminNav,
  owner: ownerNav,
  cashier: cashierNav,
  production: productionNav,
};

// Kept for compatibility with anything still importing NAV_TREE
export const NAV_TREE: NavItem[] = adminNav;

export function navForRole(role: Role): NavItem[] {
  return NAV_BY_ROLE[role] ?? [];
}

export const ROLE_LANDING: Record<Role, string> = {
  admin: "/analytics/sales",
  owner: "/analytics/sales",
  cashier: "/sales/home",
  production: "/production",
};

/** Collect all path prefixes a role may visit. */
function allowedPaths(role: Role): string[] {
  const paths: string[] = [];
  for (const item of navForRole(role)) {
    if (item.to) paths.push(item.to);
    if (item.children) for (const c of item.children) paths.push(c.to);
  }
  return paths;
}

/** True if the path is reachable for this role. */
export function canAccess(role: Role, path: string): boolean {
  const paths = allowedPaths(role);
  return paths.some((p) => path === p || path.startsWith(p + "/"));
}
