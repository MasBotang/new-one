import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Role } from "@/services/types";
import { ensureDefaultAdmin, findByEmail, signInWithPassword, type Account } from "@/lib/accounts.functions";
import { seedIfEmpty, seedInventoryIfEmpty, seedRecipesIfEmpty } from "@/services/seed";

interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
}

interface LocalUser {
  id: string;
  email: string;
}

interface AuthContextValue {
  role: Role | null;
  user: LocalUser | null;
  session: { userId: string } | null;
  profile: Profile | null;
  hydrated: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const SESSION_KEY = "desalut_session";
function accountToState(acc: Account) {
  return {
    user: { id: acc.id, email: acc.email } as LocalUser,
    session: { userId: acc.id },
    profile: { id: acc.id, full_name: acc.fullName, email: acc.email } as Profile,
    role: acc.role,
  };
}

export function RoleProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [session, setSession] = useState<{ userId: string } | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    // Seed default data & default admin (idempotent).
    ensureDefaultAdmin();
    Promise.resolve().then(() => seedIfEmpty()).catch((err) => console.error("[seed]", err));
    Promise.resolve()
      .then(() => seedInventoryIfEmpty())
      .then(() => seedRecipesIfEmpty())
      .catch((err) => console.error("[seed-inv]", err));

    (async () => {
      try {
        if (typeof window === "undefined") return;
        const raw = window.localStorage.getItem(SESSION_KEY);
        if (!raw) return;
        const parsed = JSON.parse(raw) as { email?: string };
        if (!parsed.email) return;
        const acc = await findByEmail(parsed.email);
        if (!acc) {
          window.localStorage.removeItem(SESSION_KEY);
          return;
        }
        const s = accountToState(acc);
        setUser(s.user);
        setSession(s.session);
        setProfile(s.profile);
        setRole(s.role);
      } catch (err) {
        console.error("[auth] restore session failed", err);
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const acc = await signInWithPassword(email, password);
    const s = accountToState(acc);
    setUser(s.user);
    setSession(s.session);
    setProfile(s.profile);
    setRole(s.role);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(SESSION_KEY, JSON.stringify({ email: acc.email }));
    }
  }, []);

  const signOut = useCallback(async () => {
    setUser(null);
    setSession(null);
    setProfile(null);
    setRole(null);
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(SESSION_KEY);
    }
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ role, user, session, profile, hydrated, signIn, signOut }),
    [role, user, session, profile, hydrated, signIn, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useRole() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useRole must be used inside RoleProvider");
  return ctx;
}

export const useAuth = useRole;

export const ROLE_LABELS: Record<Role, string> = {
  admin: "Admin",
  owner: "Owner",
  cashier: "Kasir",
  production: "Tim Produksi",
};

export const ROLE_DESCRIPTIONS: Record<Role, string> = {
  admin: "Akses penuh untuk mengoperasikan dan mengonfigurasi seluruh sistem.",
  owner: "Akses read-only untuk memantau performa bisnis.",
  cashier: "Workspace fokus untuk transaksi kasir.",
  production: "Operasional inventaris, produksi, dan tim.",
};
