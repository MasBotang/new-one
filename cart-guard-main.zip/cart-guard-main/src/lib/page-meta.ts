// Static lookup — no routing, no side effects.
// Maps a pathname to the contextual header subtitle shown in the AppShell.
export function getPageMeta(pathname: string): { title: string; subtitle: string } {
  const p = pathname.replace(/\/+$/, "") || "/";

  // Longest prefix first
  const entries: Array<[string, string, string]> = [
    ["/sales/pos", "POS", "Mulai transaksi dengan cepat."],
    ["/sales/pesanan", "Pesanan", "Pantau seluruh transaksi."],
    ["/sales/preorder", "Pre Order", "Kelola pesanan terjadwal."],
    ["/sales/shifts", "Shift Kasir", "Pantau shift kasir hari ini."],
    ["/sales/products", "Produk", "Kelola seluruh produk yang dijual."],
    ["/sales/home", "Home", "Berikut ringkasan performa penjualan hari ini."],
    ["/sales", "Sales", "Pantau seluruh transaksi."],

    ["/production/recipes", "Resep", "Kelola resep produksi."],
    ["/production/history", "Riwayat Produksi", "Pantau riwayat produksi."],
    ["/production/daily", "Produksi Harian", "Kelola proses produksi harian."],
    ["/production/ready-stock", "Ready Stock", "Kelola stok siap jual."],
    ["/production/waiting-release", "Menunggu Rilis", "Antrian produksi menunggu rilis."],
    ["/production/planning", "Perencanaan", "Rencanakan produksi mendatang."],
    ["/production/produksi", "Produksi", "Kelola proses produksi harian."],
    ["/production", "Production", "Kelola proses produksi harian."],

    ["/inventory/items", "Item", "Kelola daftar item persediaan."],
    ["/inventory/purchase-in", "Pembelian Masuk", "Catat penerimaan barang."],
    ["/inventory/stock-movement", "Mutasi Stok", "Pantau pergerakan stok."],
    ["/inventory/stock-opname", "Stock Opname", "Rekonsiliasi fisik dengan sistem."],
    ["/inventory", "Inventory", "Pantau stok dan mutasi barang."],

    ["/finance/expenses", "Pengeluaran", "Catat & pantau pengeluaran."],
    ["/finance/debt", "Piutang & Utang", "Kelola piutang dan utang."],
    ["/finance/budget", "Anggaran", "Rencanakan anggaran operasional."],
    ["/finance/cash-projection", "Proyeksi Kas", "Proyeksikan arus kas ke depan."],
    ["/finance/kpi", "KPI Keuangan", "Pantau indikator keuangan."],
    ["/finance/ledger", "Buku Besar", "Semua transaksi keuangan."],
    ["/finance/reports", "Laporan Keuangan", "Ringkasan laporan keuangan."],
    ["/finance/development-fund", "Dana Pengembangan", "Kelola dana pengembangan."],
    ["/finance/operational-fund", "Dana Operasional", "Kelola dana operasional."],
    ["/finance/owner-fund", "Dana Owner", "Kelola dana owner."],
    ["/finance/payroll-settlement", "Pelunasan Gaji", "Penyelesaian pembayaran gaji."],
    ["/finance/payroll", "Payroll", "Kelola penggajian."],
    ["/finance", "Finance", "Ringkasan kondisi keuangan."],

    ["/analytics/sales", "Analitik Penjualan", "Lihat performa penjualan."],
    ["/analytics/finance", "Analitik Keuangan", "Lihat performa keuangan."],
    ["/analytics/inventory", "Analitik Inventory", "Lihat performa inventori."],
    ["/analytics/production", "Analitik Produksi", "Lihat performa produksi."],
    ["/analytics/attendance", "Analitik Absensi", "Lihat performa absensi."],
    ["/analytics/payroll", "Analitik Payroll", "Lihat performa payroll."],
    ["/analytics", "Analytics", "Lihat performa bisnis."],

    ["/accounts/attendance", "Absensi", "Pantau absensi karyawan."],
    ["/accounts", "Accounts", "Kelola pengguna dan hak akses."],

    ["/settings", "Settings", "Konfigurasi sistem."],
    ["/", "Dashboard", "Berikut ringkasan performa penjualan hari ini."],
  ];

  for (const [prefix, title, subtitle] of entries) {
    if (p === prefix || p.startsWith(prefix + "/")) return { title, subtitle };
  }
  return { title: "Dashboard", subtitle: "Berikut ringkasan performa penjualan hari ini." };
}
