export function formatIDR(n: number): string {
  if (!Number.isFinite(n)) return "Rp 0";
  return "Rp " + new Intl.NumberFormat("id-ID", { maximumFractionDigits: 0 }).format(n);
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("id-ID").format(n);
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Short, human-friendly transaction reference.
 * - New IDs (INV-YYYYMMDD-NNNN) are returned as-is.
 * - Legacy IDs (sale_…) collapse to a short `#xxxxxx` suffix for backwards compat.
 */
export function formatSalesId(id: string): string {
  if (id.startsWith("INV-")) return id;
  return `#${id.slice(-6).toUpperCase()}`;
}

/**
 * Parse fractional or decimal input: "1/8", "0.125", "1 1/2", "3/4", "2".
 * Returns NaN if invalid.
 */
export function parseFraction(input: string | number): number {
  if (typeof input === "number") return input;
  const s = String(input).trim().replace(",", ".");
  if (!s) return NaN;
  // mixed: "1 1/2"
  const mixed = s.match(/^(-?\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/);
  if (mixed) {
    const whole = parseFloat(mixed[1]);
    const num = parseFloat(mixed[2]);
    const den = parseFloat(mixed[3]);
    if (!den) return NaN;
    return whole + (whole < 0 ? -1 : 1) * (num / den);
  }
  // simple fraction: "1/8"
  const frac = s.match(/^(-?\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/);
  if (frac) {
    const den = parseFloat(frac[2]);
    if (!den) return NaN;
    return parseFloat(frac[1]) / den;
  }
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : NaN;
}

/** Round to N decimals for display. */
export function roundTo(n: number, decimals = 4): number {
  if (!Number.isFinite(n)) return 0;
  const f = Math.pow(10, decimals);
  return Math.round(n * f) / f;
}