import { useRouter } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRole } from "@/lib/role-context";
import { ROLE_LANDING } from "@/lib/navigation";

/**
 * Generic "Akses Ditolak" screen shown by the root route guard when the
 * current role lacks the capability required for a page. Keeps the DeSalut
 * visual language (soft neutral surface, rounded cards, muted typography) and
 * never leaks internal capability names.
 */
export function AccessDenied() {
  const router = useRouter();
  const { role } = useRole();
  const landing = role ? ROLE_LANDING[role] : "/";

  return (
    <div className="flex min-h-[70vh] items-center justify-center px-4">
      <div className="w-full max-w-md rounded-[22px] border border-border/60 bg-card p-8 text-center shadow-[0_20px_60px_-32px_rgba(15,23,42,0.35)]">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
          <ShieldAlert className="h-7 w-7" />
        </div>
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Akses Ditolak
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Maaf, akun Anda tidak memiliki izin untuk membuka halaman ini. Silakan
          kembali ke halaman yang tersedia untuk peran Anda.
        </p>
        <div className="mt-6">
          <Button
            onClick={() => router.navigate({ to: landing, replace: true })}
            className="rounded-xl px-5"
          >
            Kembali ke Beranda
          </Button>
        </div>
      </div>
    </div>
  );
}
