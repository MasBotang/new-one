import * as React from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export interface NumberInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  allowDecimal?: boolean;
}

/**
 * Numeric input that never traps users behind a leading zero.
 * - Stores a string locally so typing feels natural.
 * - Strips leading zeros as soon as the user starts typing.
 * - Only emits the parsed number upward.
 * - Selects all on focus so cashiers can overwrite the default quickly.
 */
export const NumberInput = React.forwardRef<HTMLInputElement, NumberInputProps>(
  function NumberInput(
    { value, onChange, min, max, allowDecimal = false, className, onFocus, onBlur, ...rest },
    ref,
  ) {
    const [text, setText] = React.useState<string>(() => (value ? String(value) : ""));
    const focused = React.useRef(false);

    // Keep local string in sync when parent value changes externally
    // and the input is NOT being actively typed in.
    React.useEffect(() => {
      if (focused.current) return;
      setText(value ? String(value) : "");
    }, [value]);

    function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
      const raw = e.target.value;
      const cleaned = allowDecimal
        ? raw.replace(/[^0-9.]/g, "").replace(/(\..*)\./g, "$1")
        : raw.replace(/[^0-9]/g, "");
      // Strip leading zeros ("0123" -> "123"); keep "0" alone and "0.x"
      let normalized = cleaned;
      if (!allowDecimal) {
        normalized = cleaned.replace(/^0+(?=\d)/, "");
      } else if (/^0\d/.test(cleaned)) {
        normalized = cleaned.replace(/^0+(?=\d)/, "");
      }
      setText(normalized);
      const num = normalized === "" ? 0 : Number(normalized);
      if (Number.isFinite(num)) {
        const clamped =
          min != null && num < min ? min : max != null && num > max ? max : num;
        onChange(clamped);
      }
    }

    return (
      <Input
        ref={ref}
        type="text"
        inputMode={allowDecimal ? "decimal" : "numeric"}
        autoComplete="off"
        value={text}
        onChange={handleChange}
        onFocus={(e) => {
          focused.current = true;
          e.currentTarget.select();
          onFocus?.(e);
        }}
        onBlur={(e) => {
          focused.current = false;
          // Re-sync display from canonical numeric value
          setText(value ? String(value) : "");
          onBlur?.(e);
        }}
        className={cn("tabular-nums", className)}
        {...rest}
      />
    );
  },
);