/**
 * Shared Analytics UI primitives — read-only.
 *
 * Digunakan oleh semua halaman Analytics Module. TIDAK ada state mutasi,
 * TIDAK ada dialog CRUD, TIDAK menyentuh storage. Komponen bebas efek samping.
 */
import type { ComponentType, ReactNode } from "react";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/* ---------------- Layout ---------------- */

export function AnalyticsLayout({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-4 md:p-6">
      {children}
    </div>
  );
}

export function AnalyticsHeader({
  eyebrow,
  title,
  description,
  actions,
  filters,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
  filters?: ReactNode;
}) {
  return (
    <header className="flex flex-col gap-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          {eyebrow ? (
            <div className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">
              {eyebrow}
            </div>
          ) : null}
          <h1 className="mt-0.5 font-display text-2xl font-semibold tracking-tight md:text-3xl">
            {title}
          </h1>
          {description ? (
            <p className="mt-1 text-sm text-muted-foreground">{description}</p>
          ) : null}
        </div>
        {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
      </div>
      {filters ? <div className="flex flex-wrap items-center gap-2">{filters}</div> : null}
    </header>
  );
}

export function AnalyticsSection({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="flex flex-col gap-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="font-display text-base font-semibold tracking-tight">{title}</h2>
          {description ? (
            <p className="text-xs text-muted-foreground">{description}</p>
          ) : null}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

/* ---------------- KPI Card ---------------- */

export interface KPICardProps {
  label: string;
  value: string;
  hint?: string;
  /** persentase perubahan vs periode sebelumnya (0.12 = +12%). */
  deltaPct?: number | null;
  /** Nilai raw untuk mini trend (opsional). */
  trend?: number[];
  tone?: "default" | "positive" | "warning" | "destructive" | "muted";
  icon?: ComponentType<{ className?: string }>;
}

function DeltaBadge({ pct }: { pct: number }) {
  if (!Number.isFinite(pct)) {
    return (
      <Badge variant="secondary" className="gap-1 text-[10px]">
        <Minus className="h-3 w-3" /> —
      </Badge>
    );
  }
  const up = pct > 0;
  const flat = pct === 0;
  const Icon = flat ? Minus : up ? ArrowUpRight : ArrowDownRight;
  const cls = flat
    ? "bg-muted text-muted-foreground"
    : up
      ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400"
      : "bg-red-500/15 text-red-600 dark:text-red-400";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold tabular-nums",
        cls,
      )}
    >
      <Icon className="h-3 w-3" />
      {Math.abs(pct * 100).toFixed(1)}%
    </span>
  );
}

function MiniTrend({ values }: { values: number[] }) {
  if (!values.length) return null;
  const max = Math.max(1, ...values.map((v) => Math.abs(v)));
  return (
    <div className="flex h-8 items-end gap-[2px]">
      {values.map((v, i) => (
        <div
          key={i}
          className="flex-1 rounded-sm bg-primary/60"
          style={{ height: `${Math.max(4, (Math.abs(v) / max) * 100)}%` }}
        />
      ))}
    </div>
  );
}

export function KPICard({
  label,
  value,
  hint,
  deltaPct,
  trend,
  tone = "default",
  icon: Icon,
}: KPICardProps) {
  const toneCls =
    tone === "positive"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "warning"
        ? "text-amber-600 dark:text-amber-400"
        : tone === "destructive"
          ? "text-destructive"
          : tone === "muted"
            ? "text-muted-foreground"
            : "text-foreground";

  return (
    <Card className="rounded-xl">
      <CardContent className="flex flex-col gap-3 p-4 md:p-5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            {Icon ? <Icon className="h-3.5 w-3.5" /> : null}
            <span className="truncate">{label}</span>
          </div>
          {typeof deltaPct === "number" ? <DeltaBadge pct={deltaPct} /> : null}
        </div>
        <div className={cn("font-display text-2xl font-semibold tabular-nums", toneCls)}>
          {value}
        </div>
        {hint ? <div className="text-xs text-muted-foreground">{hint}</div> : null}
        {trend && trend.length > 1 ? <MiniTrend values={trend} /> : null}
      </CardContent>
    </Card>
  );
}

/* ---------------- Chart Card ---------------- */

export function ChartCard({
  title,
  subtitle,
  action,
  children,
  className,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Card className={cn("rounded-xl", className)}>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-2">
        <div className="min-w-0">
          <CardTitle className="text-sm font-semibold tracking-tight">{title}</CardTitle>
          {subtitle ? (
            <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>
          ) : null}
        </div>
        {action}
      </CardHeader>
      <CardContent className="pt-2">{children}</CardContent>
    </Card>
  );
}

/* ---------------- Table Card ---------------- */

export interface TableColumn<Row> {
  key: string;
  header: string;
  align?: "left" | "right" | "center";
  render: (row: Row, index: number) => ReactNode;
  className?: string;
}

export function TableCard<Row>({
  title,
  subtitle,
  action,
  columns,
  rows,
  emptyMessage = "Belum ada data pada periode ini.",
  className,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  columns: TableColumn<Row>[];
  rows: Row[];
  emptyMessage?: string;
  className?: string;
}) {
  return (
    <ChartCard title={title} subtitle={subtitle} action={action} className={className}>
      {rows.length === 0 ? (
        <div className="rounded-md border border-dashed py-8 text-center text-sm text-muted-foreground">
          {emptyMessage}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                {columns.map((c) => (
                  <th
                    key={c.key}
                    className={cn(
                      "px-2 py-2",
                      c.align === "right" && "text-right",
                      c.align === "center" && "text-center",
                      c.align !== "right" && c.align !== "center" && "text-left",
                    )}
                  >
                    {c.header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-b last:border-b-0 hover:bg-muted/40">
                  {columns.map((c) => (
                    <td
                      key={c.key}
                      className={cn(
                        "px-2 py-2 tabular-nums",
                        c.align === "right" && "text-right",
                        c.align === "center" && "text-center",
                        c.className,
                      )}
                    >
                      {c.render(r, i)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </ChartCard>
  );
}

/* ---------------- Insight Card ---------------- */

export interface InsightItem {
  level: "positive" | "warning" | "negative" | "info";
  title: string;
  detail?: string;
}

export function InsightCard({
  title = "Insight",
  items,
  emptyMessage = "Belum ada insight untuk periode ini.",
}: {
  title?: string;
  items: InsightItem[];
  emptyMessage?: string;
}) {
  const dot: Record<InsightItem["level"], string> = {
    positive: "bg-emerald-500",
    warning: "bg-amber-500",
    negative: "bg-red-500",
    info: "bg-muted-foreground/60",
  };
  return (
    <Card className="rounded-xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold tracking-tight">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground">{emptyMessage}</p>
        ) : (
          <ul className="space-y-2.5">
            {items.map((it, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm">
                <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", dot[it.level])} />
                <div className="min-w-0">
                  <div className="font-medium text-foreground">{it.title}</div>
                  {it.detail ? (
                    <div className="text-xs text-muted-foreground">{it.detail}</div>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
