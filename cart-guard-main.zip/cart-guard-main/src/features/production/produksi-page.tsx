import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Send } from "lucide-react";
import { DailyProductionPage } from "./daily-production-page";
import { WaitingReleasePage } from "./waiting-release-page";

/**
 * Halaman Produksi (single page).
 *
 * Menggabungkan seluruh workflow produksi dalam satu halaman:
 *   Pengadon → Pelipat → Pemanir → Release → Ready Stock
 *
 * Tab "Adonan / Lipat / Panir" berasal dari DailyProductionPage.
 * Section "Release" berasal dari WaitingReleasePage (validasi akhir).
 *
 * Release BUKAN proses produksi — Release adalah validasi akhir yang
 * memindahkan hasil produksi ke Ready Stock Sales. Business logic tidak
 * berubah: masih memakai `productionService.release()`.
 */
export function ProduksiPage() {
  return (
    <div className="flex flex-col gap-2">
      <DailyProductionPage />

      <div className="mx-auto w-full max-w-7xl px-6">
        <Card className="border-dashed">
          <CardHeader className="pb-1">
            <CardTitle className="text-base flex items-center gap-2">
              <Send className="h-4 w-4" /> Release (validasi akhir)
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              Petugas Release menghitung ulang hasil produksi, memastikan jumlah fisik sesuai, lalu
              memindahkan ke Ready Stock Sales.
            </p>
          </CardHeader>
          <CardContent className="p-0">
            <WaitingReleasePage />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
