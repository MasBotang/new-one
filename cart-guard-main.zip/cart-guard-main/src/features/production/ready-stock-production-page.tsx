import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Package, Factory, RefreshCw, Boxes, Layers, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { productionPlanningService } from "@/services/production-planning.service";
import { stockMovementService } from "@/services/stock-movement.service";
import type { StockMovement } from "@/services/types";
import { formatDateTime, formatNumber } from "@/lib/format";
import {
  ProductionShell,
  ProductionHeader,
  MetricGrid,
  MetricCard,
  SectionCard,
  EmptyState,
} from "./_components/production-shell";

interface Summary {
  semiFinished: { itemId: string; name: string; unit: string; stock: number }[];
  waitingFinished: { productId: string; name: string; qty: number }[];
  totalWaitingFinished: number;
  totalSemiCount: number;
}

export function ReadyStockProductionPage() {
  const [summary, setSummary] = useState<Summary>({
    semiFinished: [],
    waitingFinished: [],
    totalWaitingFinished: 0,
    totalSemiCount: 0,
  });
  const [recentMoves, setRecentMoves] = useState<StockMovement[]>([]);

  function refresh() {
    setSummary(productionPlanningService.readyStockProductionSummary());
    const semiIds = new Set(
      productionPlanningService.readyStockProductionSummary().semiFinished.map((s) => s.itemId),
    );
    setRecentMoves(
      stockMovementService
        .list()
        .filter((m) => semiIds.has(m.itemId))
        .slice(0, 20),
    );
  }

  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  return (
    <ProductionShell>
      <ProductionHeader
        eyebrow={
          <>
            <Boxes className="h-3.5 w-3.5" /> Production · Ready Stock
          </>
        }
        title="Ready Stock Production"
        description="Stok semi-finished (adonan, ayam suwir, dll.) dan produk jadi yang belum di-release ke Sales."
        actions={
          <>
            <Button
              variant="ghost"
              size="sm"
              onClick={refresh}
              className="rounded-full"
            >
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button asChild size="sm" variant="outline" className="rounded-full">
              <Link to="/production/produksi">
                <Factory className="h-4 w-4" /> Waiting Release
              </Link>
            </Button>
          </>
        }
      />

      <MetricGrid cols={3}>
        <MetricCard
          label="Jenis Semi-Finished"
          value={formatNumber(summary.totalSemiCount)}
          icon={<Layers className="h-4 w-4" />}
          tone="primary"
        />
        <MetricCard
          label="Waiting Release (pcs)"
          value={formatNumber(summary.totalWaitingFinished)}
          icon={<Factory className="h-4 w-4" />}
          tone={summary.totalWaitingFinished > 0 ? "warn" : "ok"}
          hint={summary.totalWaitingFinished > 0 ? "Perlu dirilis ke Sales" : "Semua terilis"}
        />
        <MetricCard
          label="Total Item Aktif"
          value={formatNumber(
            summary.semiFinished.length + summary.waitingFinished.length,
          )}
          icon={<Boxes className="h-4 w-4" />}
        />
      </MetricGrid>

      <SectionCard
        icon={<Package className="h-4 w-4" />}
        title="Semi Finished Product"
        description="Adonan & bahan setengah jadi yang siap dipakai produksi."
        padded={false}
      >
        {summary.semiFinished.length === 0 ? (
          <div className="p-5 sm:p-6">
            <EmptyState
              icon={<Package className="h-5 w-5" />}
              title="Belum ada stok semi-finished"
              description="Buat lewat pencatatan produksi adonan."
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-border/60 hover:bg-transparent">
                <TableHead className="h-11 pl-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Nama
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Stok
                </TableHead>
                <TableHead className="h-11 pr-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Satuan
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {summary.semiFinished.map((s) => (
                <TableRow
                  key={s.itemId}
                  className="border-border/40 transition-colors hover:bg-[var(--pos-surface-2)]"
                >
                  <TableCell className="py-4 pl-6 font-medium">{s.name}</TableCell>
                  <TableCell className="py-4 text-right tabular-nums font-semibold">
                    {formatNumber(s.stock)}
                  </TableCell>
                  <TableCell className="py-4 pr-6 text-muted-foreground">{s.unit}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <SectionCard
        icon={<Factory className="h-4 w-4" />}
        title="Produk Jadi — Waiting Release"
        description="Produk siap namun belum dirilis ke Ready Stock Sales."
        action={
          summary.waitingFinished.length > 0 && (
            <Button
              asChild
              size="sm"
              variant="ghost"
              className="rounded-full text-primary hover:text-primary"
            >
              <Link to="/production/waiting-release">
                Ke Release <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Button>
          )
        }
        padded={false}
      >
        {summary.waitingFinished.length === 0 ? (
          <div className="p-5 sm:p-6">
            <EmptyState
              icon={<Factory className="h-5 w-5" />}
              title="Tidak ada produk menunggu release"
              description="Semua produk jadi sudah dilepas ke Ready Stock Sales."
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-border/60 hover:bg-transparent">
                <TableHead className="h-11 pl-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Produk
                </TableHead>
                <TableHead className="h-11 pr-6 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Qty
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {summary.waitingFinished.map((w) => (
                <TableRow
                  key={w.productId}
                  className="border-border/40 transition-colors hover:bg-[var(--pos-surface-2)]"
                >
                  <TableCell className="py-4 pl-6 font-medium">{w.name}</TableCell>
                  <TableCell className="py-4 pr-6 text-right tabular-nums">
                    <span className="inline-flex items-center rounded-full bg-amber-500/10 px-3 py-1 text-sm font-semibold text-amber-700">
                      {formatNumber(w.qty)}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <SectionCard
        title="Riwayat Pergerakan Semi-Finished"
        description="20 aktivitas stok terbaru untuk item semi-finished."
        padded={false}
      >
        {recentMoves.length === 0 ? (
          <div className="p-5 sm:p-6">
            <EmptyState
              title="Belum ada pergerakan"
              description="Aktivitas produksi semi-finished akan tampil di sini."
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-border/60 hover:bg-transparent">
                <TableHead className="h-11 pl-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Waktu
                </TableHead>
                <TableHead className="h-11 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Item
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Delta
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Saldo
                </TableHead>
                <TableHead className="h-11 pr-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Alasan
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentMoves.map((m) => (
                <TableRow
                  key={m.id}
                  className="border-border/40 transition-colors hover:bg-[var(--pos-surface-2)]"
                >
                  <TableCell className="whitespace-nowrap py-3.5 pl-6 text-xs text-muted-foreground">
                    {formatDateTime(m.createdAt)}
                  </TableCell>
                  <TableCell className="py-3.5 text-sm">{m.itemName}</TableCell>
                  <TableCell className="py-3.5 text-right tabular-nums">
                    <span
                      className={
                        m.delta >= 0
                          ? "font-semibold text-emerald-600 dark:text-emerald-400"
                          : "font-semibold text-destructive"
                      }
                    >
                      {m.delta >= 0 ? "+" : ""}
                      {formatNumber(m.delta)}
                    </span>{" "}
                    <span className="text-xs text-muted-foreground">{m.unit}</span>
                  </TableCell>
                  <TableCell className="py-3.5 text-right tabular-nums">
                    {formatNumber(m.balanceAfter)}
                  </TableCell>
                  <TableCell className="py-3.5 pr-6 text-xs text-muted-foreground">
                    {m.reason ?? "-"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>
    </ProductionShell>
  );
}
