import * as React from "react";
import { cn } from "@/lib/utils";
import { Inbox } from "lucide-react";

/**
 * Shared premium primitives for the Production Module workspace.
 * Sales module & Production module share the same visual language:
 * warm cream page, white cards @ 20px radius, layered soft shadows,
 * quiet typography, generous whitespace.
 *
 * These are presentation-only — no business logic.
 */

/* ---------- Page shell ---------- */
export function ProductionShell({
  children,
  maxWidth = "7xl",
}: {
  children: React.ReactNode;
  maxWidth?: "5xl" | "6xl" | "7xl";
}) {
  const mw = maxWidth === "5xl" ? "max-w-5xl" : maxWidth === "6xl" ? "max-w-6xl" : "max-w-7xl";
  return (
    <div className="min-h-full bg-[var(--pos-page)]">
      <div className={cn("mx-auto flex w-full flex-col gap-6 p-4 sm:p-6 lg:p-8", mw)}>
        {children}
      </div>
    </div>
  );
}

/* ---------- Header ---------- */
export function ProductionHeader({
  eyebrow,
  title,
  description,
  actions,
  meta,
}: {
  eyebrow?: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  meta?: React.ReactNode;
}) {
  return (
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:items-end sm:justify-between">
      <div className="flex min-w-0 flex-col gap-1.5">
        {eyebrow && (
          <span className="inline-flex w-fit items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary/80">
            {eyebrow}
          </span>
        )}
        <h1 className="truncate text-[26px] font-semibold leading-tight tracking-tight text-foreground sm:text-[30px]">
          {title}
        </h1>
        {description && (
          <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
            {description}
          </p>
        )}
        {meta && <div className="mt-1">{meta}</div>}
      </div>
      {actions && (
        <div className="flex shrink-0 flex-wrap items-center justify-end gap-2">
          {actions}
        </div>
      )}
    </header>
  );
}

/* ---------- Metric card grid ---------- */
export function MetricGrid({
  children,
  cols = 4,
}: {
  children: React.ReactNode;
  cols?: 2 | 3 | 4;
}) {
  const g =
    cols === 2
      ? "sm:grid-cols-2"
      : cols === 3
        ? "sm:grid-cols-2 lg:grid-cols-3"
        : "sm:grid-cols-2 lg:grid-cols-4";
  return <div className={cn("grid gap-3", g)}>{children}</div>;
}

export function MetricCard({
  label,
  value,
  hint,
  icon,
  tone,
}: {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  icon?: React.ReactNode;
  tone?: "default" | "primary" | "warn" | "ok" | "danger";
}) {
  const toneRing =
    tone === "primary"
      ? "text-primary"
      : tone === "warn"
        ? "text-amber-600"
        : tone === "ok"
          ? "text-emerald-600"
          : tone === "danger"
            ? "text-destructive"
            : "text-muted-foreground";
  const iconBg =
    tone === "primary"
      ? "bg-primary/10 text-primary"
      : tone === "warn"
        ? "bg-amber-500/10 text-amber-600"
        : tone === "ok"
          ? "bg-emerald-500/10 text-emerald-600"
          : tone === "danger"
            ? "bg-destructive/10 text-destructive"
            : "bg-muted text-muted-foreground";
  return (
    <div className="group relative flex flex-col gap-2 rounded-[18px] border border-border/60 bg-white p-4 shadow-[0_1px_2px_rgba(15,23,42,0.03),0_10px_28px_-20px_rgba(80,45,20,0.18)] transition duration-150 hover:-translate-y-0.5 hover:shadow-[0_1px_2px_rgba(15,23,42,0.04),0_20px_40px_-24px_rgba(80,45,20,0.28)]">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
          {label}
        </span>
        {icon && (
          <span className={cn("grid h-8 w-8 place-items-center rounded-xl", iconBg)}>
            {icon}
          </span>
        )}
      </div>
      <span
        className={cn(
          "truncate text-[22px] font-semibold leading-tight tabular-nums tracking-tight text-foreground",
        )}
      >
        {value}
      </span>
      {hint && (
        <span className={cn("text-[11px] font-medium", toneRing)}>{hint}</span>
      )}
    </div>
  );
}

/* ---------- Section card ---------- */
export function SectionCard({
  icon,
  title,
  description,
  action,
  toolbar,
  children,
  padded = true,
  className,
}: {
  icon?: React.ReactNode;
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  toolbar?: React.ReactNode;
  children: React.ReactNode;
  padded?: boolean;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "overflow-hidden rounded-[20px] border border-border/60 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.03),0_20px_40px_-32px_rgba(15,23,42,0.25)] transition duration-150",
        className,
      )}
    >
      {(title || action || toolbar) && (
        <header className="flex flex-col gap-3 border-b border-border/50 px-5 py-4 sm:px-6 sm:py-5">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 sm:flex sm:flex-wrap sm:items-center sm:justify-between">
            <div className="flex min-w-0 items-start gap-3">
              {icon && (
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/8 text-primary">
                  {icon}
                </div>
              )}
              <div className="flex min-w-0 flex-col gap-0.5">
                {title && (
                  <h2 className="truncate text-[15px] font-semibold tracking-tight text-foreground">
                    {title}
                  </h2>
                )}
                {description && (
                  <p className="text-xs text-muted-foreground">{description}</p>
                )}
              </div>
            </div>
            {action && <div className="shrink-0">{action}</div>}
          </div>
          {toolbar && <div>{toolbar}</div>}
        </header>
      )}
      <div className={cn(padded ? "p-5 sm:p-6" : "")}>{children}</div>
    </section>
  );
}

/* ---------- Empty state ---------- */
export function EmptyState({
  icon,
  title,
  description,
  action,
  compact = false,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-3 rounded-[16px] border border-dashed border-border/60 bg-[var(--pos-surface-2)] text-center",
        compact ? "px-6 py-8" : "px-6 py-14",
      )}
    >
      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white text-primary shadow-[0_1px_2px_rgba(15,23,42,0.04),0_8px_20px_-14px_rgba(80,45,20,0.25)]">
        {icon ?? <Inbox className="h-5 w-5" strokeWidth={1.75} />}
      </div>
      <div className="flex flex-col gap-1">
        <p className="text-sm font-semibold text-foreground">{title}</p>
        {description && (
          <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {action && <div className="pt-1">{action}</div>}
    </div>
  );
}

/* ---------- Status pill ---------- */
export function StatusPill({
  tone = "neutral",
  children,
}: {
  tone?: "neutral" | "primary" | "ok" | "warn" | "danger" | "info";
  children: React.ReactNode;
}) {
  const styles =
    tone === "ok"
      ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/20"
      : tone === "warn"
        ? "bg-amber-500/10 text-amber-700 border-amber-500/20"
        : tone === "danger"
          ? "bg-destructive/10 text-destructive border-destructive/20"
          : tone === "primary"
            ? "bg-primary/10 text-primary border-primary/20"
            : tone === "info"
              ? "bg-sky-500/10 text-sky-700 border-sky-500/20"
              : "bg-muted text-muted-foreground border-border";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10.5px] font-semibold uppercase tracking-[0.10em]",
        styles,
      )}
    >
      {children}
    </span>
  );
}

/* ---------- Toolbar shell for search + filters ---------- */
export function Toolbar({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-wrap items-center gap-2 rounded-[16px] border border-border/60 bg-white p-2 shadow-[0_1px_2px_rgba(15,23,42,0.03),0_10px_28px_-24px_rgba(80,45,20,0.18)]",
        className,
      )}
    >
      {children}
    </div>
  );
}
