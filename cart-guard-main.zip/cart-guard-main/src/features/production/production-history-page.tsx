import { useEffect, useMemo, useState } from "react";
import {
  Hand,
  Sparkles,
  ChefHat,
  User,
  Clock,
  Package,
  AlertTriangle,
  Search,
  Download,
  Trophy,
  Filter,
  X,
  BarChart3,
  Users,
  History,
  Wheat,
} from "lucide-react";
import * as XLSX from "xlsx";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from "recharts";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { productionService } from "@/services/production.service";
import { auditService, type AuditEntry } from "@/services/audit.service";
import type {
  ProductionRun,
  FinishingValidation,
  ProductionActivity,
} from "@/services/types";
import { formatDateTime, formatNumber } from "@/lib/format";
import { useRole } from "@/lib/role-context";
import {
  ProductionShell,
  ProductionHeader,
} from "./_components/production-shell";

// ============================================================
// Types & helpers
// ============================================================

type RangeKey = "today" | "week" | "month" | "custom" | "all";
type StatusKey = "all" | "waiting_release" | "released";
type ActivityFilter = "all" | ProductionActivity;

const RANGE_LABEL: Record<RangeKey, string> = {
  today: "Hari Ini",
  week: "7 Hari Terakhir",
  month: "30 Hari Terakhir",
  custom: "Custom Range",
  all: "Semua",
};

function startOfRange(range: RangeKey, customFrom?: string): Date | null {
  const now = new Date();
  if (range === "all") return null;
  if (range === "custom") {
    if (!customFrom) return null;
    const d = new Date(customFrom);
    d.setHours(0, 0, 0, 0);
    return d;
  }
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  if (range === "today") return d;
  if (range === "week") {
    d.setDate(d.getDate() - 6);
    return d;
  }
  d.setDate(d.getDate() - 29);
  return d;
}

function endOfRange(range: RangeKey, customTo?: string): Date | null {
  if (range !== "custom") return null;
  if (!customTo) return null;
  const d = new Date(customTo);
  d.setHours(23, 59, 59, 999);
  return d;
}

/** Kg estimation for adonan from actualWeight + unit. */
function kulitKg(run: ProductionRun): number {
  if (run.activity !== "create_adonan") return 0;
  if (run.actualWeight == null) return 0;
  return run.actualWeightUnit === "g" ? run.actualWeight / 1000 : run.actualWeight;
}
function panirPcs(run: ProductionRun): number {
  return run.activity === "panir" ? run.producedQuantity : 0;
}
function pelipatPcs(run: ProductionRun): number {
  return run.activity === "produce_finished" ? run.producedQuantity : 0;
}
function totalProduksi(run: ProductionRun): number {
  // Total produksi kombinasi (kulit tidak dihitung pcs, hanya panir + pelipat).
  return panirPcs(run) + pelipatPcs(run);
}

function ymd(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
}
function isSameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}
function isSameMonth(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth();
}

/**
 * Compute release status per run (per outputRefId, oldest-first FIFO):
 * released quantity accumulates up to sum of finishing validations for that product.
 * Only meaningful for activity=produce_finished (WIP → Ready Stock).
 */
function computeStatusMap(
  runs: ProductionRun[],
  validations: FinishingValidation[],
): Map<string, StatusKey> {
  const validatedByProduct = new Map<string, number>();
  for (const v of validations) {
    validatedByProduct.set(
      v.productId,
      (validatedByProduct.get(v.productId) ?? 0) + v.validatedQty,
    );
  }
  const status = new Map<string, StatusKey>();
  const byProduct = new Map<string, ProductionRun[]>();
  for (const r of runs) {
    if (r.activity !== "produce_finished") continue;
    const arr = byProduct.get(r.outputRefId) ?? [];
    arr.push(r);
    byProduct.set(r.outputRefId, arr);
  }
  for (const [pid, list] of byProduct.entries()) {
    let remaining = validatedByProduct.get(pid) ?? 0;
    // FIFO oldest first
    const sorted = list.slice().sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1));
    for (const r of sorted) {
      if (remaining >= r.producedQuantity) {
        status.set(r.id, "released");
        remaining -= r.producedQuantity;
      } else {
        status.set(r.id, "waiting_release");
      }
    }
  }
  return status;
}

const ACTIVITY_LABEL: Record<ProductionActivity, string> = {
  create_adonan: "Kulit / Adonan",
  produce_finished: "Pelipat",
  panir: "Panir",
  finishing_validation: "Validasi",
};

const ACTIVITY_COLOR: Record<ProductionActivity, string> = {
  create_adonan: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30",
  produce_finished: "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30",
  panir: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
  finishing_validation:
    "bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-500/30",
};

// ============================================================
// Main page
// ============================================================

export function ProductionHistoryPage() {
  const { role, profile } = useRole();
  const canSeeAll = role === "admin" || role === "owner";
  const isOperator = role === "production";
  const operatorName = profile?.full_name?.trim() ?? "";

  const [runs, setRuns] = useState<ProductionRun[]>([]);
  const [validations, setValidations] = useState<FinishingValidation[]>([]);
  const [range, setRange] = useState<RangeKey>("today");
  const [customFrom, setCustomFrom] = useState<string>("");
  const [customTo, setCustomTo] = useState<string>("");
  const [operatorFilter, setOperatorFilter] = useState<string>("all");
  const [productFilter, setProductFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<StatusKey>("all");
  const [activityFilter, setActivityFilter] = useState<ActivityFilter>("all");
  const [search, setSearch] = useState<string>("");
  const [selectedRun, setSelectedRun] = useState<ProductionRun | null>(null);

  useEffect(() => {
    setRuns(productionService.runs());
    setValidations(productionService.validations());
  }, []);

  // RBAC: operator hanya melihat data miliknya sendiri.
  const scopedRuns = useMemo(() => {
    if (canSeeAll) return runs;
    if (isOperator && operatorName) {
      return runs.filter(
        (r) => (r.operator ?? "").trim().toLowerCase() === operatorName.toLowerCase(),
      );
    }
    return runs;
  }, [runs, canSeeAll, isOperator, operatorName]);

  const statusMap = useMemo(
    () => computeStatusMap(scopedRuns, validations),
    [scopedRuns, validations],
  );

  const operators = useMemo(() => {
    const set = new Set<string>();
    for (const r of scopedRuns) {
      const op = (r.operator ?? "").trim();
      if (op) set.add(op);
    }
    return Array.from(set).sort();
  }, [scopedRuns]);

  const products = useMemo(() => {
    const set = new Set<string>();
    for (const r of scopedRuns) if (r.outputName) set.add(r.outputName);
    return Array.from(set).sort();
  }, [scopedRuns]);

  // Filter chain
  const filtered = useMemo(() => {
    const start = startOfRange(range, customFrom);
    const end = endOfRange(range, customTo);
    const term = search.trim().toLowerCase();
    return scopedRuns.filter((r) => {
      const d = new Date(r.createdAt);
      if (start && d < start) return false;
      if (end && d > end) return false;
      if (operatorFilter !== "all" && r.operator !== operatorFilter) return false;
      if (productFilter !== "all" && r.outputName !== productFilter) return false;
      if (activityFilter !== "all" && r.activity !== activityFilter) return false;
      if (statusFilter !== "all") {
        const s = statusMap.get(r.id);
        if (r.activity !== "produce_finished") return false;
        if (s !== statusFilter) return false;
      }
      if (term) {
        const hay = [
          r.operator ?? "",
          r.outputName ?? "",
          r.notes ?? "",
          formatDateTime(r.createdAt),
        ]
          .join(" ")
          .toLowerCase();
        if (!hay.includes(term)) return false;
      }
      return true;
    });
  }, [
    scopedRuns,
    range,
    customFrom,
    customTo,
    operatorFilter,
    productFilter,
    activityFilter,
    statusFilter,
    search,
    statusMap,
  ]);

  // KPI (Hari Ini + Bulan Ini) — always computed on scopedRuns (bukan filtered),
  // agar KPI tetap konsisten meski user memfilter.
  const today = useMemo(() => new Date(), []);
  const kpi = useMemo(() => {
    let tKulit = 0,
      tPanir = 0,
      tPelipat = 0;
    let mKulit = 0,
      mPanir = 0,
      mPelipat = 0;
    const opsActiveToday = new Set<string>();
    for (const r of scopedRuns) {
      const d = new Date(r.createdAt);
      if (isSameDay(d, today)) {
        tKulit += kulitKg(r);
        tPanir += panirPcs(r);
        tPelipat += pelipatPcs(r);
        if (r.operator) opsActiveToday.add(r.operator);
      }
      if (isSameMonth(d, today)) {
        mKulit += kulitKg(r);
        mPanir += panirPcs(r);
        mPelipat += pelipatPcs(r);
      }
    }
    return {
      today: {
        total: tPanir + tPelipat,
        kulit: tKulit,
        panir: tPanir,
        pelipat: tPelipat,
        operators: opsActiveToday.size,
      },
      month: {
        total: mPanir + mPelipat,
        kulit: mKulit,
        panir: mPanir,
        pelipat: mPelipat,
      },
    };
  }, [scopedRuns, today]);

  // Rekap operator (berdasarkan filter periode)
  const rekapOperators = useMemo(() => {
    const map = new Map<
      string,
      { operator: string; kulit: number; panir: number; pelipat: number; runs: number }
    >();
    for (const r of filtered) {
      const op = (r.operator ?? "").trim() || "Tidak diketahui";
      const cur =
        map.get(op) ?? { operator: op, kulit: 0, panir: 0, pelipat: 0, runs: 0 };
      cur.kulit += kulitKg(r);
      cur.panir += panirPcs(r);
      cur.pelipat += pelipatPcs(r);
      cur.runs += 1;
      map.set(op, cur);
    }
    return Array.from(map.values())
      .map((x) => ({ ...x, total: x.panir + x.pelipat }))
      .sort((a, b) => b.total - a.total);
  }, [filtered]);

  // Ranking bulan ini (top 5)
  const ranking = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of scopedRuns) {
      const d = new Date(r.createdAt);
      if (!isSameMonth(d, today)) continue;
      const op = (r.operator ?? "").trim() || "Tidak diketahui";
      map.set(op, (map.get(op) ?? 0) + totalProduksi(r));
    }
    return Array.from(map.entries())
      .map(([operator, total]) => ({ operator, total }))
      .filter((x) => x.total > 0)
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  }, [scopedRuns, today]);

  // Chart 30 hari
  const chartData = useMemo(() => {
    const days: { date: string; label: string; kulit: number; panir: number; pelipat: number }[] =
      [];
    const start = new Date(today);
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - 29);
    const buckets = new Map<
      string,
      { kulit: number; panir: number; pelipat: number }
    >();
    for (let i = 0; i < 30; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const key = ymd(d);
      buckets.set(key, { kulit: 0, panir: 0, pelipat: 0 });
      days.push({
        date: key,
        label: d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
        kulit: 0,
        panir: 0,
        pelipat: 0,
      });
    }
    for (const r of scopedRuns) {
      const d = new Date(r.createdAt);
      if (d < start) continue;
      const key = ymd(d);
      const b = buckets.get(key);
      if (!b) continue;
      b.kulit += kulitKg(r);
      b.panir += panirPcs(r);
      b.pelipat += pelipatPcs(r);
    }
    return days.map((d) => ({ ...d, ...(buckets.get(d.date) ?? d) }));
  }, [scopedRuns, today]);

  const canExport = role === "admin" || role === "owner";

  function handleExport() {
    const rows = filtered.map((r) => ({
      Tanggal: formatDateTime(r.createdAt),
      Operator: r.operator ?? "",
      Aktivitas: r.activity ? ACTIVITY_LABEL[r.activity] : "-",
      "Kulit (Kg)": Number(kulitKg(r).toFixed(3)) || "",
      "Panir (pcs)": panirPcs(r) || "",
      "Pelipat (pcs)": pelipatPcs(r) || "",
      Produk: r.outputName,
      Qty: r.producedQuantity,
      Unit: r.outputUnit,
      Status:
        r.activity === "produce_finished"
          ? statusMap.get(r.id) === "released"
            ? "Released"
            : "Waiting Release"
          : "-",
      Catatan: r.notes ?? "",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Production");
    const fname = `production-history-${ymd(new Date())}.xlsx`;
    XLSX.writeFile(wb, fname);
  }

  function resetFilters() {
    setRange("today");
    setCustomFrom("");
    setCustomTo("");
    setOperatorFilter("all");
    setProductFilter("all");
    setStatusFilter("all");
    setActivityFilter("all");
    setSearch("");
  }

  const hasAnyRun = scopedRuns.length > 0;

  return (
    <ProductionShell>
      <ProductionHeader
        eyebrow={
          <>
            <History className="h-3.5 w-3.5" /> Production · History
          </>
        }
        title="Riwayat Produksi"
        description={
          <>
            Buku produksi digital — seluruh hasil kerja operator produksi.
            {isOperator && (
              <span className="ml-1 font-medium text-primary">
                Menampilkan data Anda saja.
              </span>
            )}
          </>
        }
        actions={
          canExport && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleExport}
              disabled={filtered.length === 0}
              className="rounded-full"
            >
              <Download className="mr-1.5 h-4 w-4" /> Export Excel
            </Button>
          )
        }
      />

      {/* KPI */}
      <KpiSection kpi={kpi} />

      {/* Empty state global */}
      {!hasAnyRun ? (
        <EmptyState />
      ) : (
        <>
          {/* Sticky Filter Bar */}
          <div className="sticky top-0 z-10 -mx-4 border-y bg-background/95 px-4 py-3 backdrop-blur sm:-mx-6 sm:px-6">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Filter className="h-3.5 w-3.5" /> Filter
              </div>
              <Select value={range} onValueChange={(v) => setRange(v as RangeKey)}>
                <SelectTrigger className="h-9 w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(RANGE_LABEL) as RangeKey[]).map((k) => (
                    <SelectItem key={k} value={k}>
                      {RANGE_LABEL[k]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {range === "custom" && (
                <>
                  <Input
                    type="date"
                    value={customFrom}
                    onChange={(e) => setCustomFrom(e.target.value)}
                    className="h-9 w-[150px]"
                  />
                  <span className="text-xs text-muted-foreground">→</span>
                  <Input
                    type="date"
                    value={customTo}
                    onChange={(e) => setCustomTo(e.target.value)}
                    className="h-9 w-[150px]"
                  />
                </>
              )}
              {canSeeAll && (
                <Select value={operatorFilter} onValueChange={setOperatorFilter}>
                  <SelectTrigger className="h-9 w-[160px]">
                    <SelectValue placeholder="Operator" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Operator</SelectItem>
                    {operators.map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Select value={productFilter} onValueChange={setProductFilter}>
                <SelectTrigger className="h-9 w-[180px]">
                  <SelectValue placeholder="Produk" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Produk</SelectItem>
                  {products.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={activityFilter}
                onValueChange={(v) => setActivityFilter(v as ActivityFilter)}
              >
                <SelectTrigger className="h-9 w-[150px]">
                  <SelectValue placeholder="Aktivitas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Aktivitas</SelectItem>
                  <SelectItem value="create_adonan">Kulit / Adonan</SelectItem>
                  <SelectItem value="produce_finished">Pelipat</SelectItem>
                  <SelectItem value="panir">Panir</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as StatusKey)}
              >
                <SelectTrigger className="h-9 w-[160px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="waiting_release">Waiting Release</SelectItem>
                  <SelectItem value="released">Released</SelectItem>
                </SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[180px]">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Cari operator, produk, tanggal, catatan…"
                  className="h-9 pl-8"
                />
              </div>
              <Button variant="ghost" size="sm" onClick={resetFilters}>
                <X className="mr-1 h-3.5 w-3.5" /> Reset
              </Button>
            </div>
          </div>

          <Tabs defaultValue="records" className="flex flex-col gap-4">
            <TabsList className="grid h-auto w-full grid-cols-2 gap-1 bg-muted p-1 md:grid-cols-4">
              <TabsTrigger value="records" className="gap-1.5 py-2">
                <History className="h-3.5 w-3.5" /> Record
              </TabsTrigger>
              <TabsTrigger value="rekap" className="gap-1.5 py-2">
                <Users className="h-3.5 w-3.5" /> Rekap Operator
              </TabsTrigger>
              <TabsTrigger value="ranking" className="gap-1.5 py-2">
                <Trophy className="h-3.5 w-3.5" /> Ranking
              </TabsTrigger>
              <TabsTrigger value="chart" className="gap-1.5 py-2">
                <BarChart3 className="h-3.5 w-3.5" /> Grafik
              </TabsTrigger>
            </TabsList>

            <TabsContent value="records" className="mt-0">
              <RecordsTable
                runs={filtered}
                statusMap={statusMap}
                onSelect={setSelectedRun}
              />
            </TabsContent>

            <TabsContent value="rekap" className="mt-0">
              <RekapOperator rows={rekapOperators} />
            </TabsContent>

            <TabsContent value="ranking" className="mt-0">
              <RankingList items={ranking} />
            </TabsContent>

            <TabsContent value="chart" className="mt-0">
              <ChartPanel data={chartData} />
            </TabsContent>
          </Tabs>
        </>
      )}

      <RunDetailSheet
        run={selectedRun}
        open={!!selectedRun}
        onOpenChange={(o) => !o && setSelectedRun(null)}
        statusMap={statusMap}
      />
    </ProductionShell>
  );
}

// ============================================================
// KPI
// ============================================================

function KpiSection({
  kpi,
}: {
  kpi: {
    today: { total: number; kulit: number; panir: number; pelipat: number; operators: number };
    month: { total: number; kulit: number; panir: number; pelipat: number };
  };
}) {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          <Clock className="h-3.5 w-3.5" /> Hari Ini
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <KpiCard label="Total Produksi" value={formatNumber(kpi.today.total)} unit="pcs" tone="primary" />
          <KpiCard label="Kulit" value={formatNumber(Math.round(kpi.today.kulit * 100) / 100)} unit="Kg" tone="amber" />
          <KpiCard label="Panir" value={formatNumber(kpi.today.panir)} unit="pcs" tone="emerald" />
          <KpiCard label="Pelipat" value={formatNumber(kpi.today.pelipat)} unit="pcs" tone="blue" />
          <KpiCard label="Operator Aktif" value={formatNumber(kpi.today.operators)} unit="orang" tone="purple" />
        </div>
      </div>
      <div>
        <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          <BarChart3 className="h-3.5 w-3.5" /> Bulan Ini
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <KpiCard label="Total Produksi" value={formatNumber(kpi.month.total)} unit="pcs" tone="primary" />
          <KpiCard label="Kulit" value={formatNumber(Math.round(kpi.month.kulit * 100) / 100)} unit="Kg" tone="amber" />
          <KpiCard label="Panir" value={formatNumber(kpi.month.panir)} unit="pcs" tone="emerald" />
          <KpiCard label="Pelipat" value={formatNumber(kpi.month.pelipat)} unit="pcs" tone="blue" />
        </div>
      </div>
    </div>
  );
}

function KpiCard({
  label,
  value,
  unit,
  tone = "primary",
}: {
  label: string;
  value: string;
  unit: string;
  tone?: "primary" | "amber" | "emerald" | "blue" | "purple";
}) {
  const toneClass = {
    primary: "border-primary/30 bg-primary/5",
    amber: "border-amber-500/30 bg-amber-500/5",
    emerald: "border-emerald-500/30 bg-emerald-500/5",
    blue: "border-blue-500/30 bg-blue-500/5",
    purple: "border-purple-500/30 bg-purple-500/5",
  }[tone];
  return (
    <Card className={`h-full ${toneClass}`}>
      <CardContent className="flex h-full flex-col justify-between gap-1 p-4">
        <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl font-bold tabular-nums">{value}</span>
          <span className="text-xs font-medium text-muted-foreground">{unit}</span>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// Records Table
// ============================================================

function RecordsTable({
  runs,
  statusMap,
  onSelect,
}: {
  runs: ProductionRun[];
  statusMap: Map<string, StatusKey>;
  onSelect: (r: ProductionRun) => void;
}) {
  if (runs.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-full bg-muted text-muted-foreground">
            <History className="h-6 w-6" strokeWidth={1.5} />
          </div>
          <p className="max-w-md text-sm text-muted-foreground">
            Tidak ada record produksi cocok dengan filter.
          </p>
        </CardContent>
      </Card>
    );
  }
  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="sticky top-0 z-[1] bg-muted/60 backdrop-blur">
            <TableRow>
              <TableHead className="w-[150px]">Tanggal / Jam</TableHead>
              <TableHead className="w-[140px]">Operator</TableHead>
              <TableHead className="w-[120px]">Aktivitas</TableHead>
              <TableHead className="text-right">Kulit (Kg)</TableHead>
              <TableHead className="text-right">Panir</TableHead>
              <TableHead className="text-right">Pelipat</TableHead>
              <TableHead>Produk</TableHead>
              <TableHead className="text-right">Qty</TableHead>
              <TableHead className="w-[140px]">Status</TableHead>
              <TableHead>Catatan</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {runs.map((r) => {
              const status = statusMap.get(r.id);
              return (
                <TableRow
                  key={r.id}
                  onClick={() => onSelect(r)}
                  className="cursor-pointer transition-colors hover:bg-muted/50"
                >
                  <TableCell className="whitespace-nowrap text-xs">
                    {formatDateTime(r.createdAt)}
                  </TableCell>
                  <TableCell className="text-sm font-medium">
                    {r.operator || "—"}
                  </TableCell>
                  <TableCell>
                    {r.activity && (
                      <span
                        className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${ACTIVITY_COLOR[r.activity]}`}
                      >
                        {ACTIVITY_LABEL[r.activity]}
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-xs">
                    {kulitKg(r) > 0 ? formatNumber(Math.round(kulitKg(r) * 100) / 100) : "—"}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-xs">
                    {panirPcs(r) > 0 ? formatNumber(panirPcs(r)) : "—"}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-xs">
                    {pelipatPcs(r) > 0 ? formatNumber(pelipatPcs(r)) : "—"}
                  </TableCell>
                  <TableCell className="text-sm">{r.outputName}</TableCell>
                  <TableCell className="text-right tabular-nums text-xs">
                    {formatNumber(r.producedQuantity)}{" "}
                    <span className="text-muted-foreground">{r.outputUnit}</span>
                  </TableCell>
                  <TableCell>
                    {r.activity === "produce_finished" ? (
                      status === "released" ? (
                        <Badge variant="default" className="bg-emerald-600 hover:bg-emerald-600">
                          Released
                        </Badge>
                      ) : (
                        <Badge variant="secondary">Waiting Release</Badge>
                      )
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="max-w-[220px] truncate text-xs italic text-muted-foreground">
                    {r.notes || ""}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}

// ============================================================
// Rekap Operator
// ============================================================

function RekapOperator({
  rows,
}: {
  rows: {
    operator: string;
    kulit: number;
    panir: number;
    pelipat: number;
    runs: number;
    total: number;
  }[];
}) {
  if (rows.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          Belum ada data untuk direkap pada periode ini.
        </CardContent>
      </Card>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
      {rows.map((r) => (
        <Card key={r.operator} className="h-full">
          <CardContent className="flex flex-col gap-3 p-4">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                {r.operator
                  .split(/\s+/)
                  .filter(Boolean)
                  .slice(0, 2)
                  .map((s) => s[0]?.toUpperCase() ?? "")
                  .join("") || "?"}
              </div>
              <div className="flex min-w-0 flex-1 flex-col">
                <span className="truncate text-sm font-semibold">{r.operator}</span>
                <span className="text-[11px] text-muted-foreground">{r.runs}× aktivitas</span>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <RekapCell
                icon={<Wheat className="h-3 w-3" />}
                label="Kulit"
                value={`${formatNumber(Math.round(r.kulit * 100) / 100)} Kg`}
                tone="amber"
              />
              <RekapCell
                icon={<ChefHat className="h-3 w-3" />}
                label="Panir"
                value={`${formatNumber(r.panir)} pcs`}
                tone="emerald"
              />
              <RekapCell
                icon={<Hand className="h-3 w-3" />}
                label="Pelipat"
                value={`${formatNumber(r.pelipat)} pcs`}
                tone="blue"
              />
            </div>
            <div className="flex items-center justify-between rounded-md border bg-muted/30 px-3 py-2">
              <span className="text-xs font-medium text-muted-foreground">Total Produksi</span>
              <span className="text-lg font-bold tabular-nums">
                {formatNumber(r.total)} <span className="text-xs font-medium text-muted-foreground">pcs</span>
              </span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function RekapCell({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: "amber" | "emerald" | "blue";
}) {
  const cls = {
    amber: "border-amber-500/30 bg-amber-500/5 text-amber-700 dark:text-amber-400",
    emerald: "border-emerald-500/30 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400",
    blue: "border-blue-500/30 bg-blue-500/5 text-blue-700 dark:text-blue-400",
  }[tone];
  return (
    <div className={`flex flex-col gap-0.5 rounded-md border px-2 py-1.5 ${cls}`}>
      <span className="flex items-center gap-1 text-[10px] font-medium uppercase tracking-wider opacity-80">
        {icon} {label}
      </span>
      <span className="text-sm font-bold tabular-nums">{value}</span>
    </div>
  );
}

// ============================================================
// Ranking
// ============================================================

function RankingList({ items }: { items: { operator: string; total: number }[] }) {
  if (items.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-muted-foreground">
          Belum ada ranking bulan ini.
        </CardContent>
      </Card>
    );
  }
  const max = items[0]?.total ?? 1;
  return (
    <Card>
      <CardContent className="flex flex-col gap-3 p-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-amber-500" />
          <span className="text-sm font-semibold">Top Operator Bulan Ini</span>
        </div>
        <div className="flex flex-col gap-2">
          {items.map((r, i) => (
            <div
              key={r.operator}
              className="flex items-center gap-3 rounded-md border bg-muted/20 px-3 py-2.5"
            >
              <div
                className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-bold ${
                  i === 0
                    ? "bg-amber-500 text-white"
                    : i === 1
                      ? "bg-slate-400 text-white"
                      : i === 2
                        ? "bg-amber-700 text-white"
                        : "bg-muted text-muted-foreground"
                }`}
              >
                {i + 1}
              </div>
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <span className="truncate text-sm font-medium">{r.operator}</span>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${Math.max(6, (r.total / max) * 100)}%` }}
                  />
                </div>
              </div>
              <span className="shrink-0 text-sm font-bold tabular-nums">
                {formatNumber(r.total)}{" "}
                <span className="text-xs font-medium text-muted-foreground">pcs</span>
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// Chart
// ============================================================

function ChartPanel({
  data,
}: {
  data: { label: string; kulit: number; panir: number; pelipat: number }[];
}) {
  return (
    <Card>
      <CardContent className="flex flex-col gap-3 p-4">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold">Produksi 30 Hari Terakhir</span>
        </div>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={4} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip
                contentStyle={{
                  fontSize: 12,
                  borderRadius: 8,
                  border: "1px solid var(--border)",
                }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line
                type="monotone"
                dataKey="kulit"
                name="Kulit (Kg)"
                stroke="#f59e0b"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="panir"
                name="Panir (pcs)"
                stroke="#10b981"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="pelipat"
                name="Pelipat (pcs)"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// Empty State
// ============================================================

function EmptyState() {
  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-4 py-20 text-center">
        <div className="grid h-20 w-20 place-items-center rounded-full bg-primary/10 text-primary">
          <Package className="h-10 w-10" strokeWidth={1.5} />
        </div>
        <div className="flex flex-col gap-1">
          <h3 className="text-lg font-semibold">Belum ada riwayat produksi.</h3>
          <p className="max-w-md text-sm text-muted-foreground">
            Riwayat produksi akan muncul setelah operator menyimpan hasil produksi.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// Detail Sheet
// ============================================================

function RunDetailSheet({
  run,
  open,
  onOpenChange,
  statusMap,
}: {
  run: ProductionRun | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  statusMap: Map<string, StatusKey>;
}) {
  const [audits, setAudits] = useState<AuditEntry[]>([]);
  useEffect(() => {
    if (!run) return;
    try {
      const all = auditService.list();
      setAudits(
        all
          .filter((a) => a.entityId === run.id)
          .slice(0, 20),
      );
    } catch {
      setAudits([]);
    }
  }, [run]);

  if (!run) return null;
  const status = statusMap.get(run.id);
  const d = new Date(run.createdAt);
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            {run.activity && (
              <span
                className={`inline-flex rounded-md border px-2 py-0.5 text-[10px] font-semibold ${ACTIVITY_COLOR[run.activity]}`}
              >
                {ACTIVITY_LABEL[run.activity]}
              </span>
            )}
            <span className="truncate">{run.outputName}</span>
          </SheetTitle>
          <SheetDescription>Detail lengkap record produksi.</SheetDescription>
        </SheetHeader>
        <div className="mt-4 flex flex-col gap-4">
          {/* Info produksi */}
          <section className="rounded-md border bg-muted/20 p-3">
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Informasi Produksi
            </h4>
            <dl className="grid grid-cols-2 gap-y-1.5 text-xs">
              <dt className="text-muted-foreground">Operator</dt>
              <dd className="font-medium">
                <User className="mr-1 inline h-3 w-3" />
                {run.operator || "—"}
              </dd>
              <dt className="text-muted-foreground">Tanggal</dt>
              <dd className="font-medium">
                {d.toLocaleDateString("id-ID", {
                  day: "2-digit",
                  month: "long",
                  year: "numeric",
                })}
              </dd>
              <dt className="text-muted-foreground">Jam</dt>
              <dd className="font-medium">
                {d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}
              </dd>
              <dt className="text-muted-foreground">Resep</dt>
              <dd className="font-medium">{run.recipeName}</dd>
              <dt className="text-muted-foreground">Batches</dt>
              <dd className="font-medium tabular-nums">{formatNumber(run.batches)}</dd>
              <dt className="text-muted-foreground">Qty</dt>
              <dd className="font-medium tabular-nums">
                {formatNumber(run.producedQuantity)} {run.outputUnit}
              </dd>
              {kulitKg(run) > 0 && (
                <>
                  <dt className="text-muted-foreground">Kulit</dt>
                  <dd className="font-medium tabular-nums">
                    {formatNumber(Math.round(kulitKg(run) * 100) / 100)} Kg
                  </dd>
                </>
              )}
              {run.folderLabel && (
                <>
                  <dt className="text-muted-foreground">Pelipat</dt>
                  <dd className="font-medium">{run.folderLabel}</dd>
                </>
              )}
              {run.wasteQuantity ? (
                <>
                  <dt className="text-muted-foreground">Waste</dt>
                  <dd className="font-medium tabular-nums text-destructive">
                    {formatNumber(run.wasteQuantity)}
                  </dd>
                </>
              ) : null}
              {run.lossQuantity ? (
                <>
                  <dt className="text-muted-foreground">Loss</dt>
                  <dd className="font-medium tabular-nums text-amber-600">
                    {formatNumber(run.lossQuantity)}
                  </dd>
                </>
              ) : null}
              {run.activity === "produce_finished" && (
                <>
                  <dt className="text-muted-foreground">Status</dt>
                  <dd>
                    {status === "released" ? (
                      <Badge className="bg-emerald-600 hover:bg-emerald-600">Released</Badge>
                    ) : (
                      <Badge variant="secondary">Waiting Release</Badge>
                    )}
                  </dd>
                </>
              )}
            </dl>
          </section>

          {/* Material */}
          {run.consumed && run.consumed.length > 0 && (
            <section className="rounded-md border p-3">
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Material Terpakai
              </h4>
              <ul className="flex flex-col gap-1 text-xs">
                {run.consumed.map((c, i) => (
                  <li
                    key={`${c.itemId}-${i}`}
                    className="flex items-center justify-between border-b py-1 last:border-0"
                  >
                    <span className="truncate">{c.name}</span>
                    <span className="shrink-0 tabular-nums font-medium">
                      {formatNumber(c.quantity)}{" "}
                      <span className="text-muted-foreground">{c.unit}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Catatan */}
          {run.notes && (
            <section className="rounded-md border p-3">
              <h4 className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Catatan
              </h4>
              <p className="text-xs italic">"{run.notes}"</p>
            </section>
          )}

          {/* Audit */}
          {audits.length > 0 && (
            <section className="rounded-md border p-3">
              <h4 className="mb-2 flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                <AlertTriangle className="h-3 w-3" /> Audit
              </h4>
              <ul className="flex flex-col gap-1 text-xs">
                {audits.map((a) => (
                  <li key={a.id} className="flex flex-col border-b py-1 last:border-0">
                    <span className="font-medium">{a.action}</span>
                    <span className="text-[10px] text-muted-foreground">
                      {formatDateTime(a.createdAt)} · {a.actor || "system"}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
