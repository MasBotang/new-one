import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Factory,
  Package,
  AlertTriangle,
  ClipboardList,
  ChefHat,
  History as HistoryIcon,
  Sparkles,
  Layers,
  Boxes,
  UserRound,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  productionRecommendationService,
  type ProductionRecommendation,
} from "@/services/production-recommendation.service";
import { formatNumber } from "@/lib/format";
import { useRole } from "@/lib/role-context";
import {
  ProductionShell,
  ProductionHeader,
  MetricGrid,
  MetricCard,
  SectionCard,
  EmptyState,
  StatusPill,
} from "./_components/production-shell";

/**
 * Home Produksi — pusat monitoring operasional.
 *
 * Bukan dashboard analitik: tidak ada chart, tidak ada KPI berlebihan.
 * Fokus utama:
 *   1. Rekomendasi produksi hari ini (per varian)
 *   2. Ready stock saat ini
 *   3. Minimum stock alert
 *   4. Pre-Order yang belum tertutup ready stock
 */
export function ProductionHomePage() {
  const { profile, user } = useRole();
  const operator = profile?.full_name || user?.email || "";
  const [rows, setRows] = useState<ProductionRecommendation[]>([]);

  function refresh() {
    setRows(productionRecommendationService.build());
  }

  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  const totalRecommended = useMemo(
    () => rows.reduce((s, r) => s + r.recommended, 0),
    [rows],
  );
  const totalReadyStock = useMemo(
    () => rows.reduce((s, r) => s + r.readyStock, 0),
    [rows],
  );
  const alerts = useMemo(() => rows.filter((r) => r.belowMinStock), [rows]);
  const preorderGaps = useMemo(
    () => rows.filter((r) => r.preorderShortfall > 0),
    [rows],
  );

  return (
    <ProductionShell>
      <ProductionHeader
        eyebrow={
          <>
            <Sparkles className="h-3.5 w-3.5" /> Production Workspace
          </>
        }
        title="Home Produksi"
        description="Rekomendasi & monitoring produksi hari ini. Sistem memberi rekomendasi — keputusan akhir tetap di Tim Produksi."
        meta={
          operator && (
            <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-white px-3 py-1 text-xs text-muted-foreground shadow-sm">
              <UserRound className="h-3.5 w-3.5 text-primary/70" />
              <span className="font-medium text-foreground">{operator}</span>
            </div>
          )
        }
        actions={
          <>
            <Button asChild size="sm" variant="ghost" className="rounded-full">
              <Link to="/production/recipes">
                <ChefHat className="h-4 w-4" /> Resep
              </Link>
            </Button>
            <Button asChild size="sm" variant="ghost" className="rounded-full">
              <Link to="/production/history">
                <HistoryIcon className="h-4 w-4" /> Riwayat
              </Link>
            </Button>
            <Button asChild size="sm" variant="outline" className="rounded-full">
              <Link to="/production/ready-stock">
                <Package className="h-4 w-4" /> Ready Stock
              </Link>
            </Button>
            <Button
              asChild
              size="sm"
              className="rounded-full shadow-[0_10px_28px_-12px_rgba(176,38,38,0.55)]"
            >
              <Link to="/production/produksi">
                <Factory className="h-4 w-4" /> Mulai Produksi
              </Link>
            </Button>
          </>
        }
      />

      {alerts.length > 0 && (
        <div className="flex items-start gap-3 rounded-[18px] border border-destructive/25 bg-destructive/[0.05] p-4 shadow-[0_1px_2px_rgba(15,23,42,0.03),0_10px_28px_-24px_rgba(176,38,38,0.35)]">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-destructive/10 text-destructive">
            <AlertTriangle className="h-4 w-4" />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <p className="text-sm font-semibold text-destructive">
              Ready Stock di bawah batas minimum
            </p>
            <p className="text-xs text-muted-foreground">
              {alerts.map((a) => a.name).join(", ")} — pertimbangkan produksi tambahan.
            </p>
          </div>
        </div>
      )}

      <MetricGrid cols={4}>
        <MetricCard
          label="Varian Aktif"
          value={formatNumber(rows.length)}
          icon={<Layers className="h-4 w-4" />}
          tone="primary"
        />
        <MetricCard
          label="Rekomendasi Hari Ini"
          value={formatNumber(totalRecommended)}
          hint={totalRecommended > 0 ? "Siap dieksekusi" : "Semua terpenuhi"}
          icon={<Sparkles className="h-4 w-4" />}
          tone={totalRecommended > 0 ? "primary" : "ok"}
        />
        <MetricCard
          label="Total Ready Stock"
          value={formatNumber(totalReadyStock)}
          icon={<Boxes className="h-4 w-4" />}
        />
        <MetricCard
          label="Perlu Perhatian"
          value={formatNumber(alerts.length + preorderGaps.length)}
          hint={
            alerts.length + preorderGaps.length > 0
              ? `${alerts.length} min · ${preorderGaps.length} PO gap`
              : "Semua aman"
          }
          icon={<AlertTriangle className="h-4 w-4" />}
          tone={alerts.length + preorderGaps.length > 0 ? "warn" : "ok"}
        />
      </MetricGrid>

      <SectionCard
        icon={<Sparkles className="h-4 w-4" />}
        title="Rekomendasi Produksi Hari Ini"
        description="Rekomendasi = Forecast + Pre-Order − Ready Stock. Hanya panduan operasional."
        action={
          <Button
            asChild
            size="sm"
            variant="ghost"
            className="rounded-full text-primary hover:text-primary"
          >
            <Link to="/production/produksi">
              Mulai <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        }
        padded={false}
      >
        {rows.length === 0 ? (
          <div className="p-5 sm:p-6">
            <EmptyState
              icon={<Sparkles className="h-5 w-5" />}
              title="Belum ada produk aktif untuk direkomendasikan"
              description="Aktifkan produk & resep di modul Resep untuk mulai menerima rekomendasi harian."
              action={
                <Button asChild size="sm" className="rounded-full">
                  <Link to="/production/recipes">
                    <ChefHat className="h-4 w-4" /> Ke Resep
                  </Link>
                </Button>
              }
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-border/60 hover:bg-transparent">
                <TableHead className="h-11 pl-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Produk
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Forecast
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Pre-Order
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Ready Stock
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Min. Stock
                </TableHead>
                <TableHead className="h-11 pr-6 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Rekomendasi
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow
                  key={r.productId}
                  className="border-border/40 transition-colors hover:bg-[var(--pos-surface-2)]"
                >
                  <TableCell className="py-4 pl-6 font-medium">
                    <div className="flex items-center gap-2">
                      <span className="truncate">{r.name}</span>
                      {r.belowMinStock && (
                        <StatusPill tone="danger">di bawah min</StatusPill>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="py-4 text-right tabular-nums text-muted-foreground">
                    {formatNumber(Math.round(r.forecast))}
                  </TableCell>
                  <TableCell className="py-4 text-right tabular-nums text-muted-foreground">
                    {formatNumber(r.preorder)}
                  </TableCell>
                  <TableCell className="py-4 text-right tabular-nums font-medium text-foreground">
                    {formatNumber(r.readyStock)}
                  </TableCell>
                  <TableCell className="py-4 text-right tabular-nums text-muted-foreground">
                    {formatNumber(r.minStock)}
                  </TableCell>
                  <TableCell className="py-4 pr-6 text-right tabular-nums">
                    {r.recommended > 0 ? (
                      <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-semibold text-primary">
                        {formatNumber(r.recommended)}
                      </span>
                    ) : (
                      <span className="text-sm text-muted-foreground">—</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      {preorderGaps.length > 0 && (
        <SectionCard
          icon={<ClipboardList className="h-4 w-4" />}
          title="Pre-Order Belum Tertutup Ready Stock"
          description="Order yang perlu diprioritaskan produksinya hari ini."
          padded={false}
        >
          <Table>
            <TableHeader>
              <TableRow className="border-border/60 hover:bg-transparent">
                <TableHead className="h-11 pl-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Produk
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Pre-Order
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Ready Stock
                </TableHead>
                <TableHead className="h-11 pr-6 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Kekurangan
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {preorderGaps.map((r) => (
                <TableRow
                  key={r.productId}
                  className="border-border/40 transition-colors hover:bg-[var(--pos-surface-2)]"
                >
                  <TableCell className="py-4 pl-6 font-medium">{r.name}</TableCell>
                  <TableCell className="py-4 text-right tabular-nums">
                    {formatNumber(r.preorder)}
                  </TableCell>
                  <TableCell className="py-4 text-right tabular-nums">
                    {formatNumber(r.readyStock)}
                  </TableCell>
                  <TableCell className="py-4 pr-6 text-right tabular-nums">
                    <span className="inline-flex items-center rounded-full bg-amber-500/10 px-3 py-1 text-sm font-semibold text-amber-700">
                      {formatNumber(r.preorderShortfall)}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </SectionCard>
      )}
    </ProductionShell>
  );
}
