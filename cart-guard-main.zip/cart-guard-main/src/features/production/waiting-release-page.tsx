import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Factory, Send, RefreshCw, History, Search, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NumberInput } from "@/components/ui/number-input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { productionService } from "@/services/production.service";
import { useRole } from "@/lib/role-context";
import { formatNumber } from "@/lib/format";
import { toast } from "sonner";
import {
  ProductionShell,
  ProductionHeader,
  MetricGrid,
  MetricCard,
  SectionCard,
  EmptyState,
} from "./_components/production-shell";

interface Waiting {
  productId: string;
  name: string;
  wipStock: number;
  readyStock: number;
}

export function WaitingReleasePage() {
  const { role, profile, user } = useRole();
  const operator = profile?.full_name || user?.email || "Operator";

  const [rows, setRows] = useState<Waiting[]>([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Waiting | null>(null);
  const [qty, setQty] = useState<number>(0);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  function refresh() {
    setRows(productionService.pendingFinishing());
  }

  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? rows.filter((r) => r.name.toLowerCase().includes(q)) : rows;
  }, [rows, search]);

  const totalWaiting = useMemo(() => rows.reduce((s, r) => s + r.wipStock, 0), [rows]);

  function openReleaseDialog(r: Waiting) {
    setSelected(r);
    setQty(r.wipStock);
    setNotes("");
  }

  function handleRelease() {
    if (!selected) return;
    if (qty <= 0 || qty > selected.wipStock) {
      toast.error(`Qty release harus antara 1 dan ${selected.wipStock}`);
      return;
    }
    setSaving(true);
    try {
      productionService.release({
        productId: selected.productId,
        quantity: qty,
        operator,
        notes: notes.trim() || undefined,
        role: role ?? undefined,
      });
      toast.success(
        `Release ${formatNumber(qty)} × ${selected.name} — pindah ke Ready Stock Sales.`,
      );
      setSelected(null);
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Gagal release");
    } finally {
      setSaving(false);
    }
  }

  return (
    <ProductionShell maxWidth="6xl">
      <ProductionHeader
        eyebrow={
          <>
            <Send className="h-3.5 w-3.5" /> Production · Release
          </>
        }
        title="Waiting Release"
        description="Produk hasil produksi belum bisa dijual. Tekan Release untuk memindahkan ke Ready Stock Sales."
        meta={
          <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-white px-3 py-1 text-xs text-muted-foreground shadow-sm">
            <UserRound className="h-3.5 w-3.5 text-primary/70" />
            <span className="font-medium text-foreground">{operator}</span>
          </div>
        }
        actions={
          <>
            <Button
              variant="ghost"
              size="sm"
              onClick={refresh}
              className="rounded-full"
            >
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button asChild size="sm" variant="outline" className="rounded-full">
              <Link to="/production/history">
                <History className="h-4 w-4" /> Riwayat
              </Link>
            </Button>
          </>
        }
      />

      <MetricGrid cols={3}>
        <MetricCard
          label="Produk Menunggu"
          value={formatNumber(rows.length)}
          icon={<Factory className="h-4 w-4" />}
          tone={rows.length > 0 ? "warn" : "ok"}
        />
        <MetricCard
          label="Total Qty Menunggu"
          value={formatNumber(totalWaiting)}
          hint={totalWaiting > 0 ? "Menunggu dirilis" : "Semua terilis"}
          tone={totalWaiting > 0 ? "warn" : "ok"}
        />
        <MetricCard
          label="Operator Aktif"
          value={
            <span className="truncate text-base font-semibold">{operator}</span>
          }
          icon={<UserRound className="h-4 w-4" />}
        />
      </MetricGrid>

      <SectionCard
        icon={<Factory className="h-4 w-4" />}
        title="Antrian Release"
        description="Pilih produk yang siap dirilis ke Ready Stock Sales."
        toolbar={
          <div className="relative w-full sm:w-80">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Cari produk…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-10 rounded-full border-border/60 bg-[var(--pos-surface-2)] pl-9 focus-visible:bg-white"
            />
          </div>
        }
        padded={false}
      >
        {filtered.length === 0 ? (
          <div className="p-5 sm:p-6">
            <EmptyState
              icon={<Send className="h-5 w-5" />}
              title={search ? "Tidak ada produk cocok" : "Tidak ada produk menunggu release"}
              description={
                search
                  ? "Coba ubah kata kunci pencarian."
                  : "Semua produk hasil produksi sudah dirilis ke Sales."
              }
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-border/60 hover:bg-transparent">
                <TableHead className="h-11 pl-6 text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Produk
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Ready Produksi
                </TableHead>
                <TableHead className="h-11 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Ready Sales
                </TableHead>
                <TableHead className="h-11 pr-6 text-right text-[11px] font-semibold uppercase tracking-[0.10em] text-muted-foreground">
                  Aksi
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((r) => (
                <TableRow
                  key={r.productId}
                  className="group border-border/40 transition-colors hover:bg-[var(--pos-surface-2)]"
                >
                  <TableCell className="py-4 pl-6 font-medium">{r.name}</TableCell>
                  <TableCell className="py-4 text-right tabular-nums">
                    <span className="inline-flex items-center rounded-full bg-amber-500/10 px-3 py-1 text-sm font-semibold text-amber-700">
                      {formatNumber(r.wipStock)}
                    </span>
                  </TableCell>
                  <TableCell className="py-4 text-right tabular-nums text-muted-foreground">
                    {formatNumber(r.readyStock)}
                  </TableCell>
                  <TableCell className="py-4 pr-6 text-right">
                    <Button
                      size="sm"
                      onClick={() => openReleaseDialog(r)}
                      className="rounded-full transition-transform active:scale-[0.98]"
                    >
                      <Send className="h-3.5 w-3.5" /> Release
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="rounded-[20px] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold tracking-tight">
              Release ke Ready Stock Sales
            </DialogTitle>
            <p className="text-sm text-muted-foreground">
              Konfirmasi jumlah produk yang akan dipindahkan dari Ready Produksi ke Ready Sales.
            </p>
          </DialogHeader>
          {selected && (
            <div className="flex flex-col gap-4">
              <div className="rounded-2xl border border-border/60 bg-[var(--pos-surface-2)] p-4">
                <p className="text-sm font-semibold text-foreground">{selected.name}</p>
                <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                  <span>
                    Ready Produksi:{" "}
                    <span className="font-semibold text-foreground">
                      {formatNumber(selected.wipStock)}
                    </span>
                  </span>
                  <span>
                    Ready Sales:{" "}
                    <span className="font-semibold text-foreground">
                      {formatNumber(selected.readyStock)}
                    </span>
                  </span>
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs font-medium">Qty di-release</Label>
                <NumberInput
                  value={qty}
                  onChange={(v) => setQty(Number(v) || 0)}
                  min={1}
                  max={selected.wipStock}
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs font-medium">Catatan (opsional)</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="rounded-xl"
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button
              variant="ghost"
              onClick={() => setSelected(null)}
              disabled={saving}
              className="rounded-full"
            >
              Batal
            </Button>
            <Button
              onClick={handleRelease}
              disabled={saving || qty <= 0}
              className="rounded-full"
            >
              <Send className="h-3.5 w-3.5" /> Konfirmasi Release
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ProductionShell>
  );
}
