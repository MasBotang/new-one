/**
 * Rule-based Insight & Health generator untuk Inventory Analytics.
 * Deterministik — tidak menggunakan AI, tidak menyentuh storage.
 */
import type { InsightItem } from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";
import type { HealthSignal, InventoryAnalyticsData } from "./data";

function pct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function buildInsights(data: InventoryAnalyticsData): InsightItem[] {
  const items: InsightItem[] = [];
  const { kpi, turnover, composition, opname, shopping, movements, purchases } = data;

  const totalItems = turnover.rows.length || 1;
  const deadShare = turnover.buckets.dead / totalItems;
  if (deadShare >= 0.2) {
    items.push({
      level: "warning",
      title: `${pct(deadShare)} inventory tidak bergerak (dead stock).`,
      detail: `${turnover.buckets.dead} dari ${totalItems} item aktif tidak keluar pada periode ini.`,
    });
  } else if (deadShare > 0 && deadShare < 0.05) {
    items.push({
      level: "positive",
      title: `Hanya ${pct(deadShare)} inventory yang tidak bergerak.`,
    });
  }

  const topGroup = [...composition].sort((a, b) => b.share - a.share)[0];
  if (topGroup && topGroup.share >= 0.4) {
    items.push({
      level: "info",
      title: `${topGroup.label} mendominasi nilai inventory (${pct(topGroup.share)}).`,
      detail: `${formatIDR(topGroup.stockValue)} dari total.`,
    });
  }

  if (kpi.growth.totalStockValue != null) {
    const g = kpi.growth.totalStockValue;
    if (Math.abs(g) >= 0.05) {
      items.push({
        level: g > 0 ? "info" : "warning",
        title: `Nilai inventory ${g > 0 ? "naik" : "turun"} ${pct(Math.abs(g))} vs periode sebelumnya`,
        detail: formatIDR(kpi.totalStockValue),
      });
    }
  }

  if (shopping.count > 0) {
    items.push({
      level: shopping.count >= 10 ? "warning" : "info",
      title: `Shopping list ${shopping.count} item · estimasi ${formatIDR(shopping.estimatedCost)}`,
    });
  }

  if (kpi.outOfStockCount > 0) {
    items.push({
      level: "negative",
      title: `${kpi.outOfStockCount} item habis (out of stock).`,
      detail: "Prioritaskan pembelian ulang.",
    });
  }

  if (opname.count > 0) {
    items.push({
      level: opname.accuracy >= 0.95 ? "positive" : opname.accuracy >= 0.8 ? "info" : "warning",
      title: `Akurasi stok opname ${pct(opname.accuracy)}`,
      detail: `${opname.count} opname · total variance ${formatNumber(opname.totalVariance)} unit`,
    });
  }

  if (movements.totals.outbound > 0) {
    items.push({
      level: "info",
      title: `Movement keluar ${formatNumber(movements.totals.outbound)} unit pada periode ini.`,
    });
  }

  if (purchases.growth.totalCost != null && Math.abs(purchases.growth.totalCost) >= 0.1) {
    const g = purchases.growth.totalCost;
    items.push({
      level: g > 0 ? "info" : "positive",
      title: `Biaya pembelian ${g > 0 ? "naik" : "turun"} ${pct(Math.abs(g))} vs periode sebelumnya`,
      detail: formatIDR(purchases.totalCost),
    });
  }

  return items;
}

export function buildHealth(data: InventoryAnalyticsData): HealthSignal[] {
  const out: HealthSignal[] = [];
  const { kpi, turnover, movements, shopping } = data;

  const totalItems = turnover.rows.length || 1;
  const deadShare = turnover.buckets.dead / totalItems;
  out.push(
    deadShare >= 0.2
      ? {
          level: "negative",
          title: "Dead stock tinggi",
          detail: `${turnover.buckets.dead} item tidak bergerak (${pct(deadShare)}).`,
        }
      : deadShare >= 0.1
        ? {
            level: "warning",
            title: "Dead stock perlu perhatian",
            detail: `${turnover.buckets.dead} item tidak bergerak.`,
          }
        : {
            level: "positive",
            title: "Movement sehat",
            detail: `Hanya ${pct(deadShare)} item tanpa aktivitas.`,
          },
  );

  out.push(
    kpi.lowStockCount === 0
      ? { level: "positive", title: "Tidak ada low stock", detail: "Semua item di atas minimum." }
      : kpi.lowStockCount >= 5
        ? {
            level: "warning",
            title: "Low stock meningkat",
            detail: `${kpi.lowStockCount} item mendekati minimum.`,
          }
        : {
            level: "info",
            title: `${kpi.lowStockCount} item low stock`,
          },
  );

  out.push(
    kpi.outOfStockCount === 0
      ? { level: "positive", title: "Tidak ada out of stock" }
      : kpi.outOfStockCount >= 3
        ? {
            level: "negative",
            title: "Out of stock kritis",
            detail: `${kpi.outOfStockCount} item habis stok.`,
          }
        : {
            level: "warning",
            title: `${kpi.outOfStockCount} item habis stok`,
          },
  );

  out.push(
    shopping.count === 0
      ? { level: "positive", title: "Shopping list kosong" }
      : shopping.count >= 10
        ? {
            level: "warning",
            title: "Shopping list bertambah",
            detail: `${shopping.count} item butuh dibeli · ${formatIDR(shopping.estimatedCost)}`,
          }
        : {
            level: "info",
            title: `${shopping.count} item pada shopping list`,
            detail: formatIDR(shopping.estimatedCost),
          },
  );

  out.push(
    movements.totals.count === 0
      ? { level: "warning", title: "Tidak ada pergerakan stok" }
      : {
          level: "positive",
          title: "Movement aktif",
          detail: `${movements.totals.count} pergerakan tercatat pada periode ini.`,
        },
  );

  return out;
}
