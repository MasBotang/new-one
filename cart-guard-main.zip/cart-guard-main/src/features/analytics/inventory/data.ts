/**
 * Inventory Analytics data layer — READ ONLY.
 *
 * Semua agregasi Inventory Analytics WAJIB melalui file ini agar tidak
 * menduplikasi logika Inventory Module. File ini murni membaca dari service
 * canonical yang sudah ada:
 *   - inventoryService     (list & stats)
 *   - stockMovementService (list)
 *   - stockOpnameService   (list & stats)
 *   - purchaseService      (list)
 *   - shoppingListService  (compute)
 *   - recipeService        (READ ONLY — untuk klasifikasi semi/finished)
 *
 * TIDAK menulis storage. TIDAK mem-mutasi entity. TIDAK mengubah business
 * flow Inventory / Production / Purchase.
 */
import { inventoryService } from "@/services/inventory.service";
import { stockMovementService } from "@/services/stock-movement.service";
import { stockOpnameService } from "@/services/stock-opname.service";
import { purchaseService } from "@/services/purchase.service";
import { shoppingListService, type ShoppingListEntry } from "@/services/shopping-list.service";
import { recipeService } from "@/services/recipe.service";
import {
  INVENTORY_CATEGORY_LABEL,
  STOCK_MOVEMENT_LABEL,
  type InventoryCategory,
  type InventoryItem,
  type StockMovement,
  type StockMovementType,
} from "@/services/types";

/* ---------------- Period ---------------- */

export type PeriodPreset = "today" | "7d" | "30d" | "month" | "custom";

export const PERIOD_LABELS: Record<PeriodPreset, string> = {
  today: "Hari Ini",
  "7d": "7 Hari",
  "30d": "30 Hari",
  month: "Bulan Ini",
  custom: "Custom",
};

export interface DateRange {
  from: Date;
  to: Date;
}

export interface Period {
  preset: PeriodPreset;
  range: DateRange;
  previous: DateRange;
  label: string;
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}
function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function inRange(iso: string, r: DateRange): boolean {
  const t = new Date(iso).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

export function resolvePeriod(
  preset: PeriodPreset,
  custom?: { from: Date; to: Date },
  ref = new Date(),
): Period {
  const today = startOfDay(ref);
  let range: DateRange;
  switch (preset) {
    case "today":
      range = { from: today, to: addDays(today, 1) };
      break;
    case "7d":
      range = { from: addDays(today, -6), to: addDays(today, 1) };
      break;
    case "30d":
      range = { from: addDays(today, -29), to: addDays(today, 1) };
      break;
    case "month": {
      const from = new Date(today.getFullYear(), today.getMonth(), 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      range = { from, to };
      break;
    }
    case "custom": {
      if (!custom) range = { from: today, to: addDays(today, 1) };
      else
        range = {
          from: startOfDay(custom.from),
          to: addDays(startOfDay(custom.to), 1),
        };
      break;
    }
  }
  const spanMs = range.to.getTime() - range.from.getTime();
  const previous: DateRange = {
    from: new Date(range.from.getTime() - spanMs),
    to: new Date(range.from.getTime()),
  };
  const fmt = (d: Date) =>
    d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const lastDay = new Date(range.to.getTime() - 1);
  const label =
    range.to.getTime() - range.from.getTime() <= 86400000
      ? fmt(range.from)
      : `${fmt(range.from)} – ${fmt(lastDay)}`;
  return { preset, range, previous, label };
}

/* ---------------- Helpers ---------------- */

function pctChange(current: number, previous: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return (current - previous) / previous;
}

function valueOf(item: InventoryItem, stock = item.stock): number {
  return Math.max(0, stock) * Math.max(0, item.costPerUnit ?? 0);
}

/** Klasifikasi item (raw / semi_finished / finished / packaging / operational). */
export type InventoryGroup =
  | "raw"
  | "semi_finished"
  | "finished"
  | "packaging"
  | "operational";

export const GROUP_LABEL: Record<InventoryGroup, string> = {
  raw: "Bahan Baku",
  semi_finished: "Semi Finished",
  finished: "Finished Goods",
  packaging: "Kemasan",
  operational: "Operasional",
};

function buildItemGroupMap(): Map<string, InventoryGroup> {
  // Semua item production_item awalnya "finished" kecuali di-override oleh
  // recipe.type === "semi_finished" yang menghasilkannya.
  const map = new Map<string, InventoryGroup>();
  for (const it of inventoryService.list()) {
    if (it.category === "raw") map.set(it.id, "raw");
    else if (it.category === "packaging") map.set(it.id, "packaging");
    else if (it.category === "operational") map.set(it.id, "operational");
    else if (it.category === "production_item") map.set(it.id, "finished");
  }
  for (const r of recipeService.list()) {
    if (r.outputTargetType !== "inventory" || !r.outputRefId) continue;
    if (r.type === "semi_finished") map.set(r.outputRefId, "semi_finished");
  }
  return map;
}

/* ---------------- Historical stock reconstruction ---------------- */

/**
 * Rekonstruksi stok item pada timestamp `atMs` menggunakan riwayat
 * StockMovement (SSoT). Menggunakan `balanceAfter` dari movement terakhir
 * yang createdAt <= atMs. Bila tidak ada movement sebelum atMs, fallback
 * ke stok saat ini dikurangi seluruh delta setelah atMs (reverse).
 */
function historicalStock(item: InventoryItem, movementsOfItem: StockMovement[], atMs: number): number {
  // movementsOfItem diasumsikan sudah descending by createdAt.
  let stock = item.stock;
  for (const m of movementsOfItem) {
    const t = new Date(m.createdAt).getTime();
    if (t <= atMs) break;
    // movement terjadi setelah `atMs` → balik: stock sebelum m = balanceAfter − delta
    stock = stock - m.delta;
  }
  return Math.max(0, stock);
}

/* ---------------- Section 1 — Executive KPI ---------------- */

export interface ExecutiveKPI {
  totalItems: number;
  rawItems: number;
  semiFinishedItems: number;
  finishedGoodsItems: number;
  totalStockValue: number;
  lowStockCount: number;
  outOfStockCount: number;
  shoppingListItems: number;
  growth: {
    totalStockValue: number | null;
    lowStockCount: number | null;
    outOfStockCount: number | null;
    shoppingListItems: number | null;
  };
  trend: {
    stockValue: number[];
  };
}

/* ---------------- Section 2 — Inventory Value trend ---------------- */

export interface ValuePoint {
  date: string;
  label: string;
  value: number;
}

export function inventoryValueTrend(range: DateRange): ValuePoint[] {
  const items = inventoryService.list();
  const movementsByItem = new Map<string, StockMovement[]>();
  for (const m of stockMovementService.list()) {
    // list() sudah descending
    const arr = movementsByItem.get(m.itemId);
    if (arr) arr.push(m);
    else movementsByItem.set(m.itemId, [m]);
  }

  const points: ValuePoint[] = [];
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    const endOfDay = new Date(cursor);
    endOfDay.setHours(23, 59, 59, 999);
    const endMs = Math.min(endOfDay.getTime(), range.to.getTime() - 1);
    let total = 0;
    for (const it of items) {
      const arr = movementsByItem.get(it.id) ?? [];
      const stock = historicalStock(it, arr, endMs);
      total += valueOf(it, stock);
    }
    points.push({
      date: ymd(cursor),
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      value: Math.round(total),
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  return points;
}

/* ---------------- Section 3 — Stock Movement ---------------- */

export interface MovementDailyPoint {
  date: string;
  label: string;
  inbound: number;
  outbound: number;
  adjustment: number;
  productionConsume: number;
  productionOutput: number;
}

export interface MovementTotals {
  inbound: number;
  outbound: number;
  adjustment: number;
  productionConsume: number;
  productionOutput: number;
  count: number;
}

const OUTBOUND_TYPES: StockMovementType[] = ["operational_usage", "sales_packaging_usage"];

type MovementBucket =
  | "inbound"
  | "outbound"
  | "adjustment"
  | "productionConsume"
  | "productionOutput";

function bucketMovement(m: StockMovement): MovementBucket | null {
  if (m.type === "restock") return "inbound";
  if (m.type === "adjustment") return "adjustment";
  if (m.type === "production_consumption") return "productionConsume";
  if (m.type === "production_output") return "productionOutput";
  if (OUTBOUND_TYPES.includes(m.type)) return "outbound";
  return null;
}

export function stockMovementTrend(range: DateRange): {
  daily: MovementDailyPoint[];
  totals: MovementTotals;
} {
  const days: MovementDailyPoint[] = [];
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    days.push({
      date: ymd(cursor),
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      inbound: 0,
      outbound: 0,
      adjustment: 0,
      productionConsume: 0,
      productionOutput: 0,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  const idx = new Map(days.map((d, i) => [d.date, i]));
  const totals: MovementTotals = {
    inbound: 0,
    outbound: 0,
    adjustment: 0,
    productionConsume: 0,
    productionOutput: 0,
    count: 0,
  };
  for (const m of stockMovementService.list()) {
    if (!inRange(m.createdAt, range)) continue;
    const bucket = bucketMovement(m);
    if (!bucket) continue;
    const day = days[idx.get(ymd(new Date(m.createdAt))) ?? -1];
    const qty = Math.abs(m.delta);
    if (day) day[bucket] += qty;
    totals[bucket] += qty;
    totals.count += 1;
  }
  return { daily: days, totals };
}

/* ---------------- Section 4 — Stock Composition ---------------- */

export interface CompositionSlice {
  key: InventoryGroup;
  label: string;
  itemCount: number;
  stockValue: number;
  share: number;
}

export function stockComposition(): CompositionSlice[] {
  const groupMap = buildItemGroupMap();
  const totals: Record<InventoryGroup, { itemCount: number; stockValue: number }> = {
    raw: { itemCount: 0, stockValue: 0 },
    semi_finished: { itemCount: 0, stockValue: 0 },
    finished: { itemCount: 0, stockValue: 0 },
    packaging: { itemCount: 0, stockValue: 0 },
    operational: { itemCount: 0, stockValue: 0 },
  };
  for (const it of inventoryService.list()) {
    if (!it.active) continue;
    const g = groupMap.get(it.id) ?? "raw";
    totals[g].itemCount += 1;
    totals[g].stockValue += valueOf(it);
  }
  const totalVal = Object.values(totals).reduce((a, v) => a + v.stockValue, 0);
  return (Object.keys(totals) as InventoryGroup[]).map((k) => ({
    key: k,
    label: GROUP_LABEL[k],
    itemCount: totals[k].itemCount,
    stockValue: Math.round(totals[k].stockValue),
    share: totalVal > 0 ? totals[k].stockValue / totalVal : 0,
  }));
}

/* ---------------- Section 5 — Low Stock ---------------- */

export interface LowStockRow {
  itemId: string;
  name: string;
  unit: string;
  category: InventoryCategory;
  stock: number;
  minStock: number;
  gap: number;
  status: "critical" | "warning";
}

export function lowStockRanking(limit = 20): LowStockRow[] {
  const rows: LowStockRow[] = [];
  for (const it of inventoryService.list()) {
    if (!it.active) continue;
    if (it.minStock <= 0) continue;
    if (it.stock > it.minStock) continue;
    if (it.stock <= 0) continue; // out of stock — di section 6
    rows.push({
      itemId: it.id,
      name: it.name,
      unit: it.unit,
      category: it.category,
      stock: it.stock,
      minStock: it.minStock,
      gap: it.minStock - it.stock,
      status: it.stock <= it.minStock * 0.5 ? "critical" : "warning",
    });
  }
  return rows.sort((a, b) => b.gap - a.gap || a.stock - b.stock).slice(0, limit);
}

/* ---------------- Section 6 — Out of Stock ---------------- */

export interface OutOfStockRow {
  itemId: string;
  name: string;
  unit: string;
  category: InventoryCategory;
  minStock: number;
  lastMovementAt: string | null;
}

export function outOfStockList(): OutOfStockRow[] {
  const lastMap = new Map<string, string>();
  for (const m of stockMovementService.list()) {
    if (!lastMap.has(m.itemId)) lastMap.set(m.itemId, m.createdAt);
  }
  const rows: OutOfStockRow[] = [];
  for (const it of inventoryService.list()) {
    if (!it.active) continue;
    if (it.stock > 0) continue;
    rows.push({
      itemId: it.id,
      name: it.name,
      unit: it.unit,
      category: it.category,
      minStock: it.minStock,
      lastMovementAt: lastMap.get(it.id) ?? null,
    });
  }
  return rows.sort((a, b) => {
    // prioritas: minStock tinggi + tidak pernah bergerak
    if (b.minStock !== a.minStock) return b.minStock - a.minStock;
    return (a.lastMovementAt ?? "") < (b.lastMovementAt ?? "") ? -1 : 1;
  });
}

/* ---------------- Section 7 — Shopping List ---------------- */

export interface ShoppingSummary {
  count: number;
  estimatedCost: number;
  byPriority: { priority: string; count: number; cost: number }[];
  byCategory: { category: string; count: number; cost: number }[];
  top: {
    name: string;
    priority: string;
    deficit: number;
    recommendedQuantity: number;
    estimatedCost: number;
    unit: string;
  }[];
  entries: ShoppingListEntry[];
}

const CAT_LABEL = INVENTORY_CATEGORY_LABEL;
const PRIORITY_LABEL: Record<string, string> = {
  today: "Beli Hari Ini",
  tomorrow: "Beli Besok",
  watch: "Pantau",
};

export function shoppingSummary(): ShoppingSummary {
  const entries = shoppingListService.compute();
  const priMap = new Map<string, { count: number; cost: number }>();
  const catMap = new Map<string, { count: number; cost: number }>();
  let totalCost = 0;
  const top: ShoppingSummary["top"] = [];
  for (const e of entries) {
    const cost = e.recommendedQuantity * (e.item.costPerUnit || 0);
    totalCost += cost;
    const pk = PRIORITY_LABEL[e.priority] ?? e.priority;
    const p = priMap.get(pk) ?? { count: 0, cost: 0 };
    p.count += 1;
    p.cost += cost;
    priMap.set(pk, p);
    const ck = CAT_LABEL[e.item.category];
    const c = catMap.get(ck) ?? { count: 0, cost: 0 };
    c.count += 1;
    c.cost += cost;
    catMap.set(ck, c);
    top.push({
      name: e.item.name,
      priority: pk,
      deficit: e.deficit,
      recommendedQuantity: e.recommendedQuantity,
      estimatedCost: cost,
      unit: e.item.unit,
    });
  }
  top.sort((a, b) => b.estimatedCost - a.estimatedCost);
  return {
    count: entries.length,
    estimatedCost: Math.round(totalCost),
    byPriority: Array.from(priMap.entries()).map(([priority, v]) => ({
      priority,
      count: v.count,
      cost: Math.round(v.cost),
    })),
    byCategory: Array.from(catMap.entries()).map(([category, v]) => ({
      category,
      count: v.count,
      cost: Math.round(v.cost),
    })),
    top: top.slice(0, 10),
    entries,
  };
}

/* ---------------- Section 8 — Purchase Analytics ---------------- */

export interface PurchaseDaily {
  date: string;
  label: string;
  cost: number;
  count: number;
  quantity: number;
}

export interface PurchaseSummary {
  count: number;
  totalCost: number;
  totalQuantity: number;
  avgCost: number;
  daily: PurchaseDaily[];
  topItems: {
    itemId: string;
    name: string;
    unit: string;
    totalCost: number;
    totalQuantity: number;
    count: number;
  }[];
  growth: { count: number | null; totalCost: number | null };
}

export function purchaseAnalytics(period: Period): PurchaseSummary {
  const list = purchaseService.list();
  const now = list.filter((p) => inRange(p.createdAt, period.range));
  const prev = list.filter((p) => inRange(p.createdAt, period.previous));

  const dailyMap = new Map<string, PurchaseDaily>();
  const cursor = new Date(period.range.from);
  while (cursor.getTime() < period.range.to.getTime()) {
    const key = ymd(cursor);
    dailyMap.set(key, {
      date: key,
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      cost: 0,
      count: 0,
      quantity: 0,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  const byItem = new Map<
    string,
    { itemId: string; name: string; unit: string; totalCost: number; totalQuantity: number; count: number }
  >();
  let totalCost = 0;
  let totalQty = 0;
  for (const p of now) {
    const key = ymd(new Date(p.createdAt));
    const d = dailyMap.get(key);
    if (d) {
      d.cost += p.totalPrice;
      d.count += 1;
      d.quantity += p.totalQuantity;
    }
    totalCost += p.totalPrice;
    totalQty += p.totalQuantity;
    const cur = byItem.get(p.itemId) ?? {
      itemId: p.itemId,
      name: p.itemName,
      unit: p.unit,
      totalCost: 0,
      totalQuantity: 0,
      count: 0,
    };
    cur.totalCost += p.totalPrice;
    cur.totalQuantity += p.totalQuantity;
    cur.count += 1;
    byItem.set(p.itemId, cur);
  }
  const prevCost = prev.reduce((a, p) => a + p.totalPrice, 0);
  return {
    count: now.length,
    totalCost: Math.round(totalCost),
    totalQuantity: Math.round(totalQty * 100) / 100,
    avgCost: now.length ? Math.round(totalCost / now.length) : 0,
    daily: Array.from(dailyMap.values()),
    topItems: Array.from(byItem.values())
      .sort((a, b) => b.totalCost - a.totalCost)
      .slice(0, 10),
    growth: {
      count: pctChange(now.length, prev.length),
      totalCost: pctChange(totalCost, prevCost),
    },
  };
}

/* ---------------- Section 9 — Turnover ---------------- */

export type TurnoverBand = "fast" | "medium" | "slow" | "dead";

export const TURNOVER_LABEL: Record<TurnoverBand, string> = {
  fast: "Fast Moving",
  medium: "Medium Moving",
  slow: "Slow Moving",
  dead: "Dead Stock",
};

export interface TurnoverRow {
  itemId: string;
  name: string;
  unit: string;
  category: InventoryCategory;
  outboundQty: number;
  stock: number;
  band: TurnoverBand;
}

export function turnoverAnalysis(range: DateRange): {
  rows: TurnoverRow[];
  buckets: Record<TurnoverBand, number>;
} {
  const items = inventoryService.list().filter((i) => i.active);
  const outMap = new Map<string, number>();
  for (const m of stockMovementService.list()) {
    if (!inRange(m.createdAt, range)) continue;
    if (m.delta >= 0) continue; // hanya outbound
    if (m.type === "adjustment") continue; // penyesuaian bukan turnover
    outMap.set(m.itemId, (outMap.get(m.itemId) ?? 0) + Math.abs(m.delta));
  }
  const nonZero = items
    .map((i) => outMap.get(i.id) ?? 0)
    .filter((q) => q > 0)
    .sort((a, b) => a - b);
  const q = (p: number) =>
    nonZero.length === 0 ? 0 : nonZero[Math.min(nonZero.length - 1, Math.floor(nonZero.length * p))];
  const p33 = q(0.33);
  const p66 = q(0.66);

  const rows: TurnoverRow[] = items.map((i) => {
    const qty = outMap.get(i.id) ?? 0;
    let band: TurnoverBand;
    if (qty === 0) band = "dead";
    else if (qty >= p66) band = "fast";
    else if (qty >= p33) band = "medium";
    else band = "slow";
    return {
      itemId: i.id,
      name: i.name,
      unit: i.unit,
      category: i.category,
      outboundQty: Math.round(qty * 100) / 100,
      stock: i.stock,
      band,
    };
  });
  const buckets: Record<TurnoverBand, number> = { fast: 0, medium: 0, slow: 0, dead: 0 };
  for (const r of rows) buckets[r.band]++;
  rows.sort((a, b) => b.outboundQty - a.outboundQty);
  return { rows, buckets };
}

/* ---------------- Section 10 — Stock Aging (placeholder) ---------------- */

export interface StockAging {
  available: false;
  message: string;
}

export function stockAging(): StockAging {
  return {
    available: false,
    message: "Stock aging available after batch tracking module.",
  };
}

/* ---------------- Section 11 — Opname Analytics ---------------- */

export interface OpnameDaily {
  date: string;
  label: string;
  count: number;
  variance: number;
}

export interface OpnameSummary {
  count: number;
  totalVariance: number;
  totalAdjustment: number;
  accuracy: number; // 0..1
  daily: OpnameDaily[];
  growth: { count: number | null; totalVariance: number | null };
}

export function opnameAnalytics(period: Period): OpnameSummary {
  const list = stockOpnameService.list();
  const now = list.filter((o) => inRange(o.createdAt, period.range));
  const prev = list.filter((o) => inRange(o.createdAt, period.previous));

  const dailyMap = new Map<string, OpnameDaily>();
  const cursor = new Date(period.range.from);
  while (cursor.getTime() < period.range.to.getTime()) {
    const key = ymd(cursor);
    dailyMap.set(key, {
      date: key,
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      count: 0,
      variance: 0,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  let totalVar = 0;
  let totalAdj = 0;
  let accurate = 0;
  for (const o of now) {
    const key = ymd(new Date(o.createdAt));
    const d = dailyMap.get(key);
    const absDiff = Math.abs(o.diff);
    if (d) {
      d.count += 1;
      d.variance += absDiff;
    }
    totalVar += absDiff;
    totalAdj += o.diff;
    if (o.diff === 0) accurate += 1;
  }
  const prevVar = prev.reduce((a, o) => a + Math.abs(o.diff), 0);
  return {
    count: now.length,
    totalVariance: Math.round(totalVar * 100) / 100,
    totalAdjustment: Math.round(totalAdj * 100) / 100,
    accuracy: now.length ? accurate / now.length : 1,
    daily: Array.from(dailyMap.values()),
    growth: {
      count: pctChange(now.length, prev.length),
      totalVariance: pctChange(totalVar, prevVar),
    },
  };
}

/* ---------------- Section 12 — Category Analytics ---------------- */

export interface CategoryRow {
  category: InventoryCategory;
  label: string;
  itemCount: number;
  stockValue: number;
  movementCount: number;
}

export function categoryAnalytics(range: DateRange): CategoryRow[] {
  const cats: InventoryCategory[] = ["raw", "packaging", "operational", "production_item"];
  const totals = new Map<
    InventoryCategory,
    { itemCount: number; stockValue: number; movementCount: number }
  >(cats.map((c) => [c, { itemCount: 0, stockValue: 0, movementCount: 0 }]));
  const itemCat = new Map<string, InventoryCategory>();
  for (const it of inventoryService.list()) {
    itemCat.set(it.id, it.category);
    if (!it.active) continue;
    const t = totals.get(it.category)!;
    t.itemCount += 1;
    t.stockValue += valueOf(it);
  }
  for (const m of stockMovementService.list()) {
    if (!inRange(m.createdAt, range)) continue;
    const cat = itemCat.get(m.itemId);
    if (!cat) continue;
    totals.get(cat)!.movementCount += 1;
  }
  return cats.map((c) => ({
    category: c,
    label: INVENTORY_CATEGORY_LABEL[c],
    itemCount: totals.get(c)!.itemCount,
    stockValue: Math.round(totals.get(c)!.stockValue),
    movementCount: totals.get(c)!.movementCount,
  }));
}

/* ---------------- Section 13 — Health ---------------- */

export interface HealthSignal {
  level: "positive" | "warning" | "negative" | "info";
  title: string;
  detail?: string;
}

/* ---------------- Aggregate ---------------- */

export interface InventoryAnalyticsData {
  period: Period;
  kpi: ExecutiveKPI;
  valueTrend: ValuePoint[];
  movements: { daily: MovementDailyPoint[]; totals: MovementTotals };
  composition: CompositionSlice[];
  lowStock: LowStockRow[];
  outOfStock: OutOfStockRow[];
  shopping: ShoppingSummary;
  purchases: PurchaseSummary;
  turnover: { rows: TurnoverRow[]; buckets: Record<TurnoverBand, number> };
  aging: StockAging;
  opname: OpnameSummary;
  categories: CategoryRow[];
}

export function computeInventoryAnalytics(period: Period): InventoryAnalyticsData {
  const items = inventoryService.list();
  const activeItems = items.filter((i) => i.active);
  const groupMap = buildItemGroupMap();

  const totalStockValue = Math.round(activeItems.reduce((a, i) => a + valueOf(i), 0));
  const rawItems = activeItems.filter((i) => groupMap.get(i.id) === "raw").length;
  const semiFinishedItems = activeItems.filter((i) => groupMap.get(i.id) === "semi_finished").length;
  const finishedGoodsItems = activeItems.filter((i) => groupMap.get(i.id) === "finished").length;
  const lowStockCount = activeItems.filter(
    (i) => i.minStock > 0 && i.stock > 0 && i.stock <= i.minStock,
  ).length;
  const outOfStockCount = activeItems.filter((i) => i.stock <= 0).length;

  const valueTrend = inventoryValueTrend(period.range);
  const prevValueTrend = inventoryValueTrend(period.previous);
  const shopping = shoppingSummary();
  const purchases = purchaseAnalytics(period);
  const opname = opnameAnalytics(period);
  const movements = stockMovementTrend(period.range);

  const startValue = valueTrend[0]?.value ?? totalStockValue;
  const prevEndValue = prevValueTrend[prevValueTrend.length - 1]?.value ?? startValue;

  const kpi: ExecutiveKPI = {
    totalItems: activeItems.length,
    rawItems,
    semiFinishedItems,
    finishedGoodsItems,
    totalStockValue,
    lowStockCount,
    outOfStockCount,
    shoppingListItems: shopping.count,
    growth: {
      totalStockValue: pctChange(totalStockValue, prevEndValue),
      lowStockCount: null,
      outOfStockCount: null,
      shoppingListItems: null,
    },
    trend: {
      stockValue: valueTrend.map((v) => v.value),
    },
  };

  return {
    period,
    kpi,
    valueTrend,
    movements,
    composition: stockComposition(),
    lowStock: lowStockRanking(20),
    outOfStock: outOfStockList(),
    shopping,
    purchases,
    turnover: turnoverAnalysis(period.range),
    aging: stockAging(),
    opname,
    categories: categoryAnalytics(period.range),
  };
}

/* ---------------- Re-exports for UI convenience ---------------- */

export { STOCK_MOVEMENT_LABEL, INVENTORY_CATEGORY_LABEL };
