import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RechartTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  AlertTriangle,
  Archive,
  Boxes,
  CalendarDays,
  ClipboardList,
  Download,
  FileSpreadsheet,
  FileText,
  Gauge,
  Layers,
  PackageOpen,
  ShoppingCart,
  Truck,
  Wallet,
  XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  ChartCard,
  InsightCard,
  KPICard,
  TableCard,
  type TableColumn,
} from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";
import {
  PERIOD_LABELS,
  TURNOVER_LABEL,
  computeInventoryAnalytics,
  resolvePeriod,
  type CategoryRow,
  type CompositionSlice,
  type InventoryAnalyticsData,
  type LowStockRow,
  type MovementDailyPoint,
  type OutOfStockRow,
  type PeriodPreset,
  type TurnoverRow,
  type ValuePoint,
} from "./data";
import { buildHealth, buildInsights } from "./insights";
import { exportInventoryAnalyticsCSV, exportInventoryAnalyticsXLSX } from "./export";

const PERIOD_ORDER: PeriodPreset[] = ["today", "7d", "30d", "month", "custom"];

const SLICE_COLORS = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

export function InventoryAnalyticsPage() {
  const [preset, setPreset] = useState<PeriodPreset>("30d");
  const [custom, setCustom] = useState<{ from?: Date; to?: Date }>({});

  const period = useMemo(() => {
    if (preset === "custom" && custom.from && custom.to)
      return resolvePeriod("custom", { from: custom.from, to: custom.to });
    if (preset === "custom") return resolvePeriod("today");
    return resolvePeriod(preset);
  }, [preset, custom]);

  const data: InventoryAnalyticsData = useMemo(() => computeInventoryAnalytics(period), [period]);
  const insights = useMemo(() => buildInsights(data), [data]);
  const health = useMemo(() => buildHealth(data), [data]);

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Analytics Module"
        title="Inventory Analytics"
        description="Business Intelligence untuk inventory. Read-only — data langsung dari Inventory Module."
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <Download className="h-3.5 w-3.5" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Quick Export</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => exportInventoryAnalyticsXLSX(data)}>
                <FileSpreadsheet className="mr-2 h-4 w-4" /> Excel (.xlsx)
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => exportInventoryAnalyticsCSV(data)}>
                <FileText className="mr-2 h-4 w-4" /> CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PERIOD_LABELS[p]}
                </Button>
              ))}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={preset === "custom" ? "default" : "ghost"}
                    className="h-7 gap-1 px-2.5 text-xs"
                  >
                    <CalendarDays className="h-3.5 w-3.5" />
                    Custom
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-auto p-0">
                  <Calendar
                    mode="range"
                    numberOfMonths={2}
                    selected={{ from: custom.from, to: custom.to }}
                    onSelect={(r) => {
                      setCustom({ from: r?.from, to: r?.to });
                      if (r?.from && r?.to) setPreset("custom");
                    }}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <Badge variant="secondary" className="text-xs">
              {period.label}
            </Badge>
          </div>
        }
      />

      {/* SECTION 1 — Executive KPI */}
      <AnalyticsSection title="Executive KPI" description="Ringkasan inventory saat ini.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <KPICard
            label="Total Items"
            value={formatNumber(data.kpi.totalItems)}
            icon={Boxes}
          />
          <KPICard
            label="Raw Material"
            value={formatNumber(data.kpi.rawItems)}
            icon={Layers}
          />
          <KPICard
            label="Semi Finished"
            value={formatNumber(data.kpi.semiFinishedItems)}
            icon={Archive}
          />
          <KPICard
            label="Finished Goods"
            value={formatNumber(data.kpi.finishedGoodsItems)}
            icon={PackageOpen}
          />
          <KPICard
            label="Total Stock Value"
            value={formatIDR(data.kpi.totalStockValue)}
            deltaPct={data.kpi.growth.totalStockValue}
            trend={data.kpi.trend.stockValue}
            icon={Wallet}
          />
          <KPICard
            label="Low Stock"
            value={formatNumber(data.kpi.lowStockCount)}
            tone={data.kpi.lowStockCount > 0 ? "warning" : "positive"}
            icon={AlertTriangle}
          />
          <KPICard
            label="Out of Stock"
            value={formatNumber(data.kpi.outOfStockCount)}
            tone={data.kpi.outOfStockCount > 0 ? "destructive" : "positive"}
            icon={XCircle}
          />
          <KPICard
            label="Shopping List"
            value={formatNumber(data.kpi.shoppingListItems)}
            hint={
              data.shopping.estimatedCost > 0
                ? `Estimasi ${formatIDR(data.shopping.estimatedCost)}`
                : undefined
            }
            tone={data.kpi.shoppingListItems > 0 ? "warning" : "muted"}
            icon={ShoppingCart}
          />
        </div>
      </AnalyticsSection>

      {/* SECTION 2 — Inventory Value Trend */}
      <AnalyticsSection title="Inventory Value" description="Perubahan nilai inventory dari waktu ke waktu.">
        <ValueTrendChart rows={data.valueTrend} />
      </AnalyticsSection>

      {/* SECTION 3 — Stock Movement */}
      <AnalyticsSection title="Stock Movement" description="Inbound, outbound, adjustment, dan produksi.">
        <MovementChart rows={data.movements.daily} />
      </AnalyticsSection>

      {/* SECTION 4 & 12 — Composition + Category */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Stock Composition" description="Kontribusi Raw / Semi / Finished.">
          <CompositionChart rows={data.composition} />
        </AnalyticsSection>
        <AnalyticsSection title="Category Analytics" description="Item, nilai, dan movement per kategori.">
          <CategoryChart rows={data.categories} />
        </AnalyticsSection>
      </div>

      {/* SECTION 5 & 6 — Low Stock + Out of Stock */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Low Stock" description="20 stok paling menipis.">
          <LowStockTable rows={data.lowStock} />
        </AnalyticsSection>
        <AnalyticsSection title="Out of Stock" description="Prioritas tertinggi untuk restock.">
          <OutOfStockTable rows={data.outOfStock} />
        </AnalyticsSection>
      </div>

      {/* SECTION 7 — Shopping List */}
      <AnalyticsSection title="Shopping List Analytics" description="Rekomendasi pembelian dari Inventory Module.">
        <ShoppingBlock data={data} />
      </AnalyticsSection>

      {/* SECTION 8 — Purchase */}
      <AnalyticsSection title="Purchase Analytics" description="Tren biaya & jumlah pembelian.">
        <PurchaseBlock data={data} />
      </AnalyticsSection>

      {/* SECTION 9 — Turnover */}
      <AnalyticsSection title="Inventory Turnover" description="Klasifikasi Fast / Medium / Slow / Dead.">
        <TurnoverBlock data={data} />
      </AnalyticsSection>

      {/* SECTION 10 — Aging */}
      <AnalyticsSection title="Stock Aging" description="Kelompok umur stok.">
        <AgingCard />
      </AnalyticsSection>

      {/* SECTION 11 — Opname */}
      <AnalyticsSection title="Opname Analytics" description="Akurasi & variance stock opname.">
        <OpnameBlock data={data} />
      </AnalyticsSection>

      {/* SECTION 13 & 14 — Health + Insight */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Inventory Health" description="Rule-based indikator kesehatan.">
          <InsightCard title="Health Signals" items={health} emptyMessage="Belum ada sinyal." />
        </AnalyticsSection>
        <AnalyticsSection title="Insight" description="Rule-based highlight.">
          <InsightCard items={insights} />
        </AnalyticsSection>
      </div>
    </AnalyticsLayout>
  );
}

/* ---------------- Sub components ---------------- */

function ValueTrendChart({ rows }: { rows: ValuePoint[] }) {
  const config: ChartConfig = {
    value: { label: "Nilai Inventory", color: "var(--color-primary)" },
  };
  return (
    <ChartCard title="Inventory Value">
      <ChartContainer config={config} className="h-[280px] w-full">
        <AreaChart data={rows} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
          <defs>
            <linearGradient id="inv-value-gradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.3} />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} tickMargin={8} fontSize={11} />
          <YAxis
            width={80}
            tickLine={false}
            axisLine={false}
            fontSize={11}
            tickFormatter={(v: number) => formatIDR(v)}
          />
          <ChartTooltip
            content={<ChartTooltipContent formatter={(v) => formatIDR(Number(v))} />}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke="var(--color-primary)"
            strokeWidth={2}
            fill="url(#inv-value-gradient)"
          />
        </AreaChart>
      </ChartContainer>
    </ChartCard>
  );
}

function MovementChart({ rows }: { rows: MovementDailyPoint[] }) {
  const config: ChartConfig = {
    inbound: { label: "Inbound", color: "var(--chart-2)" },
    outbound: { label: "Outbound", color: "var(--chart-1)" },
    adjustment: { label: "Adjustment", color: "var(--chart-4)" },
    productionConsume: { label: "Prod. Consume", color: "var(--chart-5)" },
    productionOutput: { label: "Prod. Output", color: "var(--chart-3)" },
  };
  return (
    <ChartCard title="Movement Trend">
      <ChartContainer config={config} className="h-[280px] w-full">
        <BarChart data={rows} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
          <YAxis
            width={60}
            tickLine={false}
            axisLine={false}
            fontSize={11}
            tickFormatter={(v: number) => formatNumber(v)}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Legend wrapperStyle={{ fontSize: 11 }} />
          <Bar dataKey="inbound" stackId="in" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="productionOutput" stackId="in" fill="var(--chart-3)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="outbound" stackId="out" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="productionConsume" stackId="out" fill="var(--chart-5)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="adjustment" stackId="adj" fill="var(--chart-4)" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ChartContainer>
    </ChartCard>
  );
}

function CompositionChart({ rows }: { rows: CompositionSlice[] }) {
  const active = rows.filter((r) => r.stockValue > 0 || r.itemCount > 0);
  const total = active.reduce((a, r) => a + r.stockValue, 0);
  return (
    <ChartCard title="Composition" subtitle={total > 0 ? `Total ${formatIDR(total)}` : undefined}>
      {active.length === 0 ? (
        <div className="rounded-md border border-dashed py-10 text-center text-sm text-muted-foreground">
          Belum ada data inventory.
        </div>
      ) : (
        <div className="grid grid-cols-1 items-center gap-4 md:grid-cols-2">
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <RechartTooltip formatter={(v: number) => formatIDR(v)} />
                <Pie
                  data={active}
                  dataKey="stockValue"
                  nameKey="label"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                >
                  {active.map((_, i) => (
                    <Cell key={i} fill={SLICE_COLORS[i % SLICE_COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="space-y-2 text-sm">
            {active.map((c, i) => (
              <li key={c.key} className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: SLICE_COLORS[i % SLICE_COLORS.length] }}
                  />
                  <span>{c.label}</span>
                  <Badge variant="secondary" className="text-[10px]">
                    {c.itemCount} item
                  </Badge>
                </span>
                <span className="text-right tabular-nums">
                  <div className="font-medium">{formatIDR(c.stockValue)}</div>
                  <div className="text-xs text-muted-foreground">
                    {(c.share * 100).toFixed(1)}%
                  </div>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </ChartCard>
  );
}

function CategoryChart({ rows }: { rows: CategoryRow[] }) {
  const columns: TableColumn<CategoryRow>[] = [
    { key: "cat", header: "Kategori", render: (r) => r.label },
    { key: "item", header: "Item", align: "right", render: (r) => formatNumber(r.itemCount) },
    {
      key: "value",
      header: "Nilai",
      align: "right",
      render: (r) => formatIDR(r.stockValue),
    },
    { key: "mov", header: "Movement", align: "right", render: (r) => formatNumber(r.movementCount) },
  ];
  return <TableCard title="Per Kategori" columns={columns} rows={rows} />;
}

function LowStockTable({ rows }: { rows: LowStockRow[] }) {
  const columns: TableColumn<LowStockRow>[] = [
    { key: "rank", header: "#", align: "right", render: (_r, i) => i + 1, className: "w-8 text-muted-foreground" },
    { key: "name", header: "Item", render: (r) => (
      <div className="flex flex-col">
        <span className="font-medium">{r.name}</span>
        <span className="text-[11px] text-muted-foreground">{r.unit}</span>
      </div>
    )},
    { key: "stock", header: "Stock", align: "right", render: (r) => formatNumber(r.stock) },
    { key: "min", header: "Min", align: "right", render: (r) => formatNumber(r.minStock) },
    { key: "gap", header: "Gap", align: "right", render: (r) => formatNumber(r.gap) },
    {
      key: "status",
      header: "Status",
      render: (r) => (
        <Badge
          variant={r.status === "critical" ? "destructive" : "secondary"}
          className="text-[10px]"
        >
          {r.status === "critical" ? "Kritis" : "Warning"}
        </Badge>
      ),
    },
  ];
  return (
    <TableCard
      title="Low Stock Ranking"
      columns={columns}
      rows={rows}
      emptyMessage="Tidak ada item di bawah minimum."
    />
  );
}

function OutOfStockTable({ rows }: { rows: OutOfStockRow[] }) {
  const columns: TableColumn<OutOfStockRow>[] = [
    { key: "name", header: "Item", render: (r) => (
      <div className="flex flex-col">
        <span className="font-medium">{r.name}</span>
        <span className="text-[11px] text-muted-foreground">{r.unit}</span>
      </div>
    )},
    { key: "min", header: "Min Stock", align: "right", render: (r) => formatNumber(r.minStock) },
    {
      key: "last",
      header: "Last Movement",
      align: "right",
      render: (r) =>
        r.lastMovementAt
          ? new Date(r.lastMovementAt).toLocaleDateString("id-ID", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            })
          : "—",
    },
  ];
  return (
    <TableCard
      title="Out of Stock"
      columns={columns}
      rows={rows}
      emptyMessage="Semua stok tersedia."
    />
  );
}

function ShoppingBlock({ data }: { data: InventoryAnalyticsData }) {
  const s = data.shopping;
  const topColumns: TableColumn<(typeof s.top)[number]>[] = [
    { key: "name", header: "Item", render: (r) => r.name },
    { key: "pri", header: "Prioritas", render: (r) => <Badge variant="secondary" className="text-[10px]">{r.priority}</Badge> },
    { key: "def", header: "Deficit", align: "right", render: (r) => `${formatNumber(r.deficit)} ${r.unit}` },
    { key: "qty", header: "Rekomendasi", align: "right", render: (r) => `${formatNumber(r.recommendedQuantity)} ${r.unit}` },
    { key: "cost", header: "Estimasi", align: "right", render: (r) => formatIDR(r.estimatedCost) },
  ];
  const priColumns: TableColumn<(typeof s.byPriority)[number]>[] = [
    { key: "p", header: "Prioritas", render: (r) => r.priority },
    { key: "c", header: "Jumlah", align: "right", render: (r) => formatNumber(r.count) },
    { key: "cost", header: "Estimasi", align: "right", render: (r) => formatIDR(r.cost) },
  ];
  const catColumns: TableColumn<(typeof s.byCategory)[number]>[] = [
    { key: "cat", header: "Kategori", render: (r) => r.category },
    { key: "c", header: "Jumlah", align: "right", render: (r) => formatNumber(r.count) },
    { key: "cost", header: "Estimasi", align: "right", render: (r) => formatIDR(r.cost) },
  ];
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <KPICard label="Total Item" value={formatNumber(s.count)} icon={ClipboardList} />
        <KPICard label="Estimasi Biaya" value={formatIDR(s.estimatedCost)} icon={Wallet} />
        <KPICard
          label="Prioritas Tertinggi"
          value={
            s.byPriority.find((p) => p.priority === "Beli Hari Ini")
              ? `${s.byPriority.find((p) => p.priority === "Beli Hari Ini")?.count ?? 0} item`
              : "—"
          }
          tone={s.count > 0 ? "warning" : "muted"}
          icon={AlertTriangle}
        />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <TableCard title="Per Prioritas" columns={priColumns} rows={s.byPriority} emptyMessage="Shopping list kosong." />
        <TableCard title="Per Kategori" columns={catColumns} rows={s.byCategory} emptyMessage="Shopping list kosong." />
      </div>
      <TableCard
        title="Top Kebutuhan Pembelian"
        columns={topColumns}
        rows={s.top}
        emptyMessage="Belum ada rekomendasi pembelian."
      />
    </div>
  );
}

function PurchaseBlock({ data }: { data: InventoryAnalyticsData }) {
  const p = data.purchases;
  const topColumns: TableColumn<(typeof p.topItems)[number]>[] = [
    { key: "name", header: "Item", render: (r) => r.name },
    { key: "qty", header: "Qty", align: "right", render: (r) => `${formatNumber(r.totalQuantity)} ${r.unit}` },
    { key: "cost", header: "Total Biaya", align: "right", render: (r) => formatIDR(r.totalCost) },
    { key: "n", header: "Transaksi", align: "right", render: (r) => formatNumber(r.count) },
  ];
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <KPICard
          label="Jumlah Purchase"
          value={formatNumber(p.count)}
          deltaPct={p.growth.count}
          icon={Truck}
        />
        <KPICard
          label="Total Biaya"
          value={formatIDR(p.totalCost)}
          deltaPct={p.growth.totalCost}
          icon={Wallet}
        />
        <KPICard label="Avg Biaya / Transaksi" value={formatIDR(p.avgCost)} icon={Gauge} />
      </div>
      <ChartCard title="Purchase Trend">
        <ChartContainer
          config={{
            cost: { label: "Biaya", color: "var(--color-primary)" },
            count: { label: "Jumlah", color: "var(--chart-2)" },
          }}
          className="h-[240px] w-full"
        >
          <BarChart data={p.daily} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
            <YAxis
              width={80}
              tickLine={false}
              axisLine={false}
              fontSize={11}
              tickFormatter={(v: number) => formatIDR(v)}
            />
            <ChartTooltip
              content={
                <ChartTooltipContent formatter={(v) => formatIDR(Number(v))} />
              }
            />
            <Bar dataKey="cost" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </ChartCard>
      <TableCard
        title="Top Purchased Item"
        columns={topColumns}
        rows={p.topItems}
        emptyMessage="Belum ada pembelian pada periode ini."
      />
    </div>
  );
}

function TurnoverBlock({ data }: { data: InventoryAnalyticsData }) {
  const b = data.turnover.buckets;
  const columns: TableColumn<TurnoverRow>[] = [
    { key: "rank", header: "#", align: "right", render: (_r, i) => i + 1, className: "w-8 text-muted-foreground" },
    { key: "name", header: "Item", render: (r) => (
      <div className="flex flex-col">
        <span className="font-medium">{r.name}</span>
        <span className="text-[11px] text-muted-foreground">{r.unit}</span>
      </div>
    )},
    { key: "out", header: "Outbound", align: "right", render: (r) => formatNumber(r.outboundQty) },
    { key: "stock", header: "Stock", align: "right", render: (r) => formatNumber(r.stock) },
    {
      key: "band",
      header: "Band",
      render: (r) => (
        <Badge
          variant={r.band === "dead" ? "destructive" : r.band === "fast" ? "default" : "secondary"}
          className="text-[10px]"
        >
          {TURNOVER_LABEL[r.band]}
        </Badge>
      ),
    },
  ];
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <KPICard label={TURNOVER_LABEL.fast} value={formatNumber(b.fast)} tone="positive" />
        <KPICard label={TURNOVER_LABEL.medium} value={formatNumber(b.medium)} />
        <KPICard label={TURNOVER_LABEL.slow} value={formatNumber(b.slow)} tone="warning" />
        <KPICard label={TURNOVER_LABEL.dead} value={formatNumber(b.dead)} tone="destructive" />
      </div>
      <TableCard
        title="Ranking Turnover"
        columns={columns}
        rows={data.turnover.rows.slice(0, 20)}
        emptyMessage="Belum ada data movement."
      />
    </div>
  );
}

function AgingCard() {
  return (
    <Card className="rounded-xl">
      <CardContent className="flex flex-col items-start gap-2 p-5">
        <Badge variant="secondary" className="gap-1 text-[10px]">
          <Layers className="h-3 w-3" /> Coming Soon
        </Badge>
        <p className="text-sm text-muted-foreground">
          Stock aging available after batch tracking module.
        </p>
      </CardContent>
    </Card>
  );
}

function OpnameBlock({ data }: { data: InventoryAnalyticsData }) {
  const o = data.opname;
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <KPICard
          label="Jumlah Opname"
          value={formatNumber(o.count)}
          deltaPct={o.growth.count}
          icon={ClipboardList}
        />
        <KPICard
          label="Variance"
          value={formatNumber(o.totalVariance)}
          deltaPct={o.growth.totalVariance}
          tone={o.totalVariance > 0 ? "warning" : "muted"}
        />
        <KPICard
          label="Adjustment (net)"
          value={formatNumber(o.totalAdjustment)}
          tone={o.totalAdjustment < 0 ? "destructive" : "muted"}
        />
        <KPICard
          label="Akurasi Stok"
          value={`${(o.accuracy * 100).toFixed(1)}%`}
          tone={o.accuracy >= 0.95 ? "positive" : o.accuracy >= 0.8 ? "muted" : "warning"}
        />
      </div>
      <ChartCard title="Trend Opname">
        {o.count === 0 ? (
          <div className="rounded-md border border-dashed py-10 text-center text-sm text-muted-foreground">
            Belum ada opname pada periode ini.
          </div>
        ) : (
          <ChartContainer
            config={{
              count: { label: "Opname", color: "var(--color-primary)" },
              variance: { label: "Variance", color: "var(--chart-4)" },
            }}
            className="h-[240px] w-full"
          >
            <BarChart data={o.daily} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis width={50} tickLine={false} axisLine={false} fontSize={11} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="count" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="variance" fill="var(--chart-4)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartContainer>
        )}
      </ChartCard>
    </div>
  );
}
