/**
 * Export helper Inventory Analytics — memakai canonical downloadCSV / downloadXLSX
 * dari finance-report.service agar tidak menduplikasi kode export.
 */
import { downloadCSV, downloadXLSX } from "@/services/finance-report.service";
import { TURNOVER_LABEL, type InventoryAnalyticsData } from "./data";

function slugPeriod(label: string): string {
  return label.replace(/[^0-9a-zA-Z]+/g, "-").toLowerCase();
}

function buildSheets(data: InventoryAnalyticsData) {
  const {
    kpi,
    valueTrend,
    movements,
    composition,
    lowStock,
    outOfStock,
    shopping,
    purchases,
    turnover,
    opname,
    categories,
  } = data;
  return [
    {
      name: "KPI",
      rows: [
        { Metric: "Total Items", Value: kpi.totalItems },
        { Metric: "Raw Material", Value: kpi.rawItems },
        { Metric: "Semi Finished", Value: kpi.semiFinishedItems },
        { Metric: "Finished Goods", Value: kpi.finishedGoodsItems },
        { Metric: "Total Stock Value", Value: kpi.totalStockValue },
        { Metric: "Low Stock", Value: kpi.lowStockCount },
        { Metric: "Out of Stock", Value: kpi.outOfStockCount },
        { Metric: "Shopping List", Value: kpi.shoppingListItems },
      ],
    },
    {
      name: "InventoryValue",
      rows: valueTrend.map((v) => ({ Tanggal: v.date, Nilai: v.value })),
    },
    {
      name: "Movement",
      rows: movements.daily.map((d) => ({
        Tanggal: d.date,
        Inbound: d.inbound,
        Outbound: d.outbound,
        Adjustment: d.adjustment,
        ProductionConsume: d.productionConsume,
        ProductionOutput: d.productionOutput,
      })),
    },
    {
      name: "Composition",
      rows: composition.map((c) => ({
        Grup: c.label,
        Item: c.itemCount,
        Nilai: c.stockValue,
        Share: c.share,
      })),
    },
    {
      name: "LowStock",
      rows: lowStock.map((r, i) => ({
        Rank: i + 1,
        Item: r.name,
        Unit: r.unit,
        Stock: r.stock,
        MinStock: r.minStock,
        Gap: r.gap,
        Status: r.status,
      })),
    },
    {
      name: "OutOfStock",
      rows: outOfStock.map((r) => ({
        Item: r.name,
        Unit: r.unit,
        MinStock: r.minStock,
        LastMovement: r.lastMovementAt ?? "-",
      })),
    },
    {
      name: "ShoppingList",
      rows: shopping.top.map((r) => ({
        Item: r.name,
        Prioritas: r.priority,
        Deficit: r.deficit,
        Rekomendasi: r.recommendedQuantity,
        Unit: r.unit,
        Estimasi: r.estimatedCost,
      })),
    },
    {
      name: "Purchase",
      rows: purchases.daily.map((d) => ({
        Tanggal: d.date,
        JumlahPurchase: d.count,
        Qty: d.quantity,
        Biaya: d.cost,
      })),
    },
    {
      name: "TopPurchased",
      rows: purchases.topItems.map((p) => ({
        Item: p.name,
        Unit: p.unit,
        Qty: p.totalQuantity,
        TotalBiaya: p.totalCost,
        JumlahTransaksi: p.count,
      })),
    },
    {
      name: "Turnover",
      rows: turnover.rows.map((r) => ({
        Item: r.name,
        Unit: r.unit,
        Kategori: r.category,
        Outbound: r.outboundQty,
        Stock: r.stock,
        Band: TURNOVER_LABEL[r.band],
      })),
    },
    {
      name: "Opname",
      rows: opname.daily.map((d) => ({
        Tanggal: d.date,
        Jumlah: d.count,
        Variance: d.variance,
      })),
    },
    {
      name: "Category",
      rows: categories.map((c) => ({
        Kategori: c.label,
        Item: c.itemCount,
        Nilai: c.stockValue,
        Movement: c.movementCount,
      })),
    },
  ];
}

export function exportInventoryAnalyticsXLSX(data: InventoryAnalyticsData) {
  const slug = slugPeriod(data.period.label);
  downloadXLSX(buildSheets(data), `inventory-analytics-${slug}.xlsx`);
}

export function exportInventoryAnalyticsCSV(data: InventoryAnalyticsData) {
  const slug = slugPeriod(data.period.label);
  const sheets = buildSheets(data);
  const merged: Record<string, unknown>[] = [];
  for (const s of sheets) {
    merged.push({ SECTION: s.name });
    for (const row of s.rows) merged.push(row);
    merged.push({});
  }
  downloadCSV(merged, `inventory-analytics-${slug}.csv`);
}
