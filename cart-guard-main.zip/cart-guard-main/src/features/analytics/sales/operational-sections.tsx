/**
 * Operational Sales Analytics — UI sections (additive).
 *
 * Komponen presentasi murni untuk agregasi di operational-data.ts. Tidak ada
 * mutasi state / storage. Dipasang di bawah section BI yang sudah ada pada
 * SalesAnalyticsPage.
 */

import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import {
  AnalyticsSection,
  ChartCard,
  KPICard,
  TableCard,
  type TableColumn,
} from "@/components/analytics";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { formatIDR, formatNumber } from "@/lib/format";
import type {
  CashierRow,
  OperationalAnalyticsData,
  PeakRow,
  ShiftRow,
  TrendPoint,
} from "./operational-data";

function pct(n: number, digits = 1) {
  return `${(n * 100).toFixed(digits)}%`;
}

/* ---------------- KPI Panel ---------------- */

function KpiPanelSection({ data }: { data: OperationalAnalyticsData }) {
  const k = data.kpiPanel;
  return (
    <AnalyticsSection title="KPI Panel" description="Indikator operasional utama outlet.">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <KPICard
          label="Ready Stock Alert"
          value={formatNumber(k.readyStockAlert)}
          tone={k.readyStockAlert > 0 ? "destructive" : "positive"}
        />
        <KPICard label="Packaging Difference" value={formatNumber(k.packagingDifference)} tone={k.packagingDifference > 0 ? "warning" : "muted"} />
        <KPICard label="Operational Expense %" value={pct(k.opexPct)} tone={k.opexPct >= 0.2 ? "destructive" : "muted"} />
        <KPICard label="Void %" value={pct(k.voidPct, 2)} tone={k.voidPct >= 0.05 ? "destructive" : "muted"} />
        <KPICard label="Refund %" value={pct(k.refundPct, 2)} tone={k.refundPct >= 0.05 ? "destructive" : "muted"} />
        <KPICard label="Repeat Customer %" value={pct(k.repeatCustomerPct)} tone={k.repeatCustomerPct >= 0.3 ? "positive" : "muted"} />
        <KPICard label="Avg Item / Trx" value={k.avgItemPerTrx.toFixed(1)} />
        <KPICard label="Avg Packaging / Trx" value={k.avgPackagingPerTrx.toFixed(1)} />
        <KPICard label="Top Cashier" value={k.topCashier} tone="positive" />
        <KPICard label="Top Shift" value={k.topShift} />
      </div>
    </AnalyticsSection>
  );
}

/* ---------------- Cashier Performance ---------------- */

function CashierSection({ rows }: { rows: CashierRow[] }) {
  const columns: TableColumn<CashierRow>[] = [
    { key: "rank", header: "#", render: (r) => `#${r.rank}` },
    { key: "cashier", header: "Kasir", render: (r) => r.cashier },
    { key: "revenue", header: "Revenue", align: "right", render: (r) => formatIDR(r.revenue) },
    { key: "profit", header: "Profit", align: "right", render: (r) => formatIDR(r.profit) },
    { key: "totalSales", header: "Item Terjual", align: "right", render: (r) => formatNumber(r.totalSales) },
    { key: "transactions", header: "Transaksi", align: "right", render: (r) => formatNumber(r.transactions) },
    { key: "avgOrder", header: "Avg Order", align: "right", render: (r) => formatIDR(r.avgOrder) },
    { key: "refundCount", header: "Refund", align: "right", render: (r) => formatNumber(r.refundCount) },
    { key: "voidCount", header: "Void", align: "right", render: (r) => formatNumber(r.voidCount) },
  ];
  return (
    <AnalyticsSection title="Cashier Performance" description="Peringkat kasir berdasarkan revenue.">
      <TableCard title="Cashier Performance" columns={columns} rows={rows} emptyMessage="Belum ada transaksi kasir pada periode ini." />
    </AnalyticsSection>
  );
}

/* ---------------- Shift Performance ---------------- */

function shiftStatusTone(s: ShiftRow["status"]) {
  return s === "NORMAL" ? "default" : s === "WARNING" ? "secondary" : "destructive";
}

function ShiftSection({ rows }: { rows: ShiftRow[] }) {
  const columns: TableColumn<ShiftRow>[] = [
    {
      key: "shift",
      header: "Shift",
      render: (r) => (
        <div className="flex flex-col">
          <span className="font-medium">{r.cashier}</span>
          <span className="text-xs text-muted-foreground">
            {new Date(r.openedAt).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })}
            {r.closedAt ? "" : " · aktif"}
          </span>
        </div>
      ),
    },
    { key: "openingCash", header: "Opening", align: "right", render: (r) => formatIDR(r.openingCash) },
    { key: "closingCash", header: "Closing", align: "right", render: (r) => formatIDR(r.closingCash) },
    { key: "cashSales", header: "Cash", align: "right", render: (r) => formatIDR(r.cashSales) },
    { key: "qrisSales", header: "QRIS", align: "right", render: (r) => formatIDR(r.qrisSales) },
    { key: "transferSales", header: "Transfer", align: "right", render: (r) => formatIDR(r.transferSales) },
    { key: "cardSales", header: "Card", align: "right", render: (r) => formatIDR(r.cardSales) },
    { key: "marketplaceSales", header: "Marketplace", align: "right", render: (r) => formatIDR(r.marketplaceSales) },
    { key: "operationalExpense", header: "Opex", align: "right", render: (r) => formatIDR(r.operationalExpense) },
    { key: "expectedCash", header: "Expected", align: "right", render: (r) => formatIDR(r.expectedCash) },
    { key: "actualCash", header: "Actual", align: "right", render: (r) => formatIDR(r.actualCash) },
    {
      key: "selisihKas",
      header: "Selisih",
      align: "right",
      render: (r) => (
        <span className={r.selisihKas < 0 ? "text-red-600 dark:text-red-400" : r.selisihKas > 0 ? "text-amber-600 dark:text-amber-400" : ""}>
          {formatIDR(r.selisihKas)}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      align: "center",
      render: (r) => <Badge variant={shiftStatusTone(r.status)} className="text-[10px]">{r.status}</Badge>,
    },
  ];
  return (
    <AnalyticsSection title="Shift Performance" description="Rekonsiliasi kas per shift dengan status selisih.">
      <TableCard title="Shift Performance" columns={columns} rows={rows} emptyMessage="Belum ada shift pada periode ini." />
    </AnalyticsSection>
  );
}

/* ---------------- Peak Day / Month ---------------- */

function PeakBar({ rows, best, title }: { rows: PeakRow[]; best: PeakRow | null; title: string }) {
  return (
    <ChartCard title={title} subtitle={best ? `Terbaik: ${best.label} · ${formatIDR(best.revenue)}` : "Belum ada data"}>
      <ChartContainer config={{ revenue: { label: "Revenue", color: "var(--chart-1)" } }} className="h-[220px] w-full">
        <BarChart data={rows} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
          <YAxis width={64} tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v: number) => formatIDR(v)} />
          <ChartTooltip content={<ChartTooltipContent formatter={(v) => formatIDR(Number(v))} />} />
          <Bar dataKey="revenue" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
        </BarChart>
      </ChartContainer>
    </ChartCard>
  );
}

/* ---------------- Weekly / Monthly Trend ---------------- */

function TrendLine({ rows, title, subtitle }: { rows: TrendPoint[]; title: string; subtitle: string }) {
  return (
    <ChartCard title={title} subtitle={subtitle}>
      <ChartContainer
        config={{
          revenue: { label: "Revenue", color: "var(--chart-1)" },
          profit: { label: "Profit", color: "var(--chart-2)" },
        }}
        className="h-[220px] w-full"
      >
        <LineChart data={rows} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
          <YAxis width={64} tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v: number) => formatIDR(v)} />
          <ChartTooltip content={<ChartTooltipContent formatter={(v) => formatIDR(Number(v))} />} />
          <Line type="monotone" dataKey="revenue" stroke="var(--chart-1)" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="profit" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
        </LineChart>
      </ChartContainer>
    </ChartCard>
  );
}

/* ---------------- Void Analytics ---------------- */

function VoidSection({ data }: { data: OperationalAnalyticsData }) {
  const v = data.voids;
  return (
    <AnalyticsSection title="Void Analytics" description="Pembatalan transaksi (terpisah dari refund).">
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <KPICard label="Total Void" value={formatNumber(v.totalVoid)} tone={v.totalVoid > 0 ? "warning" : "muted"} />
          <KPICard label="Nominal Void" value={formatIDR(v.totalAmount)} tone="warning" />
          <KPICard label="Void Rate" value={pct(v.voidRate, 2)} tone={v.voidRate >= 0.05 ? "destructive" : "muted"} />
        </div>
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          <TableCard
            title="Top Reason"
            columns={[
              { key: "reason", header: "Alasan", render: (r: (typeof v.topReasons)[number]) => r.reason },
              { key: "count", header: "Jumlah", align: "right", render: (r: (typeof v.topReasons)[number]) => formatNumber(r.count) },
              { key: "amount", header: "Nominal", align: "right", render: (r: (typeof v.topReasons)[number]) => formatIDR(r.amount) },
            ]}
            rows={v.topReasons}
            emptyMessage="Tidak ada void pada periode ini."
          />
          <TableCard
            title="Void per Cashier"
            columns={[
              { key: "cashier", header: "Kasir", render: (r: (typeof v.perCashier)[number]) => r.cashier },
              { key: "count", header: "Void", align: "right", render: (r: (typeof v.perCashier)[number]) => formatNumber(r.count) },
              { key: "amount", header: "Nominal", align: "right", render: (r: (typeof v.perCashier)[number]) => formatIDR(r.amount) },
            ]}
            rows={v.perCashier}
            emptyMessage="Tidak ada void pada periode ini."
          />
        </div>
        <ChartCard title="Void Trend">
          <ChartContainer config={{ amount: { label: "Void", color: "var(--destructive)" } }} className="h-[180px] w-full">
            <BarChart data={v.trend} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis width={60} tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v2: number) => formatIDR(v2)} />
              <ChartTooltip content={<ChartTooltipContent formatter={(val) => formatIDR(Number(val))} />} />
              <Bar dataKey="amount" fill="var(--destructive)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ChartContainer>
        </ChartCard>
      </div>
    </AnalyticsSection>
  );
}

/* ---------------- Packaging Analytics ---------------- */

function PackagingSection({ data }: { data: OperationalAnalyticsData }) {
  const p = data.packaging;
  return (
    <AnalyticsSection title="Packaging Analytics" description="Pemakaian kemasan dari stock movement.">
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <KPICard label="Packaging Used" value={formatNumber(p.totalUsedQty)} />
          <KPICard label="Packaging Cost" value={formatIDR(p.totalCost)} tone="warning" />
          <KPICard label="Extra Packaging" value={formatNumber(p.extraPackaging.reduce((a, e) => a + e.qty, 0))} />
          <KPICard label="Avg / Shift" value={p.perShiftAvg.toFixed(1)} />
        </div>
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          <TableCard
            title="Top Packaging"
            columns={[
              { key: "name", header: "Kemasan", render: (r: (typeof p.top)[number]) => r.name },
              { key: "qty", header: "Qty", align: "right", render: (r: (typeof p.top)[number]) => formatNumber(r.qty) },
              { key: "cost", header: "Cost", align: "right", render: (r: (typeof p.top)[number]) => formatIDR(r.cost) },
            ]}
            rows={p.top}
            emptyMessage="Belum ada pemakaian kemasan."
          />
          <TableCard
            title="Extra Packaging"
            columns={[
              { key: "name", header: "Kemasan", render: (r: (typeof p.extraPackaging)[number]) => r.name },
              { key: "qty", header: "Qty", align: "right", render: (r: (typeof p.extraPackaging)[number]) => formatNumber(r.qty) },
            ]}
            rows={p.extraPackaging}
            emptyMessage="Tidak ada extra packaging."
          />
        </div>
        <ChartCard title="Packaging Trend">
          <ChartContainer config={{ qty: { label: "Qty", color: "var(--chart-3)" } }} className="h-[180px] w-full">
            <BarChart data={p.trend} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis width={44} tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v: number) => formatNumber(v)} />
              <ChartTooltip content={<ChartTooltipContent formatter={(val) => formatNumber(Number(val))} />} />
              <Bar dataKey="qty" fill="var(--chart-3)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ChartContainer>
        </ChartCard>
      </div>
    </AnalyticsSection>
  );
}

/* ---------------- Operational Expense Analytics ---------------- */

function OpexSection({ data }: { data: OperationalAnalyticsData }) {
  const o = data.opex;
  return (
    <AnalyticsSection title="Operational Expense" description="Pengeluaran operasional per shift.">
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <KPICard label="Total Expense" value={formatIDR(o.totalExpense)} tone="warning" />
          <KPICard label="Avg / Shift" value={formatIDR(o.perShiftAvg)} />
          <KPICard label="Expense vs Revenue" value={pct(o.expenseVsRevenue)} tone={o.expenseVsRevenue >= 0.2 ? "destructive" : "muted"} />
          <KPICard label="Expense vs Profit" value={pct(o.expenseVsProfit)} tone={o.expenseVsProfit >= 0.5 ? "destructive" : "muted"} />
        </div>
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          <TableCard
            title="Expense by Category"
            columns={[
              { key: "name", header: "Kategori", render: (r: (typeof o.byCategory)[number]) => r.name },
              { key: "count", header: "Entri", align: "right", render: (r: (typeof o.byCategory)[number]) => formatNumber(r.count) },
              { key: "amount", header: "Nominal", align: "right", render: (r: (typeof o.byCategory)[number]) => formatIDR(r.amount) },
            ]}
            rows={o.byCategory}
            emptyMessage="Belum ada pengeluaran operasional."
          />
          <ChartCard title="Expense Trend">
            <ChartContainer config={{ amount: { label: "Expense", color: "var(--chart-4)" } }} className="h-[180px] w-full">
              <BarChart data={o.trend} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
                <YAxis width={60} tickLine={false} axisLine={false} fontSize={11} tickFormatter={(v: number) => formatIDR(v)} />
                <ChartTooltip content={<ChartTooltipContent formatter={(val) => formatIDR(Number(val))} />} />
                <Bar dataKey="amount" fill="var(--chart-4)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ChartContainer>
          </ChartCard>
        </div>
      </div>
    </AnalyticsSection>
  );
}

/* ---------------- Public composite ---------------- */

export function OperationalAnalyticsSections({ data }: { data: OperationalAnalyticsData }) {
  return (
    <>
      <KpiPanelSection data={data} />
      <CashierSection rows={data.cashiers} />
      <ShiftSection rows={data.shifts} />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Peak Day" description="Hari dengan performa terbaik.">
          <PeakBar rows={data.peakDay.rows} best={data.peakDay.best} title="Peak Day" />
        </AnalyticsSection>
        <AnalyticsSection title="Peak Month" description="Bulan dengan performa terbaik.">
          <PeakBar rows={data.peakMonth.rows} best={data.peakMonth.best} title="Peak Month" />
        </AnalyticsSection>
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Weekly Trend" description="Tren 12 minggu terakhir.">
          <TrendLine rows={data.weekly} title="Weekly Trend" subtitle="Revenue & profit per minggu" />
        </AnalyticsSection>
        <AnalyticsSection title="Monthly Trend" description="Tren 12 bulan terakhir.">
          <TrendLine rows={data.monthly} title="Monthly Trend" subtitle="Revenue & profit per bulan" />
        </AnalyticsSection>
      </div>
      <VoidSection data={data} />
      <PackagingSection data={data} />
      <OpexSection data={data} />
    </>
  );
}
