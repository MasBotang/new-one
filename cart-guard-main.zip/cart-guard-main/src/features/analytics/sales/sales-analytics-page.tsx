import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RechartTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  BarChart3,
  DollarSign,
  Percent,
  ReceiptText,
  ShoppingBag,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Undo2,
  Wallet,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";
import { Download, CalendarDays, FileSpreadsheet, FileText } from "lucide-react";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  ChartCard,
  InsightCard,
  KPICard,
  TableCard,
  type TableColumn,
} from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";
import {
  PERIOD_LABELS,
  computeSalesAnalytics,
  resolvePeriod,
  type PeriodPreset,
  type SalesAnalyticsData,
} from "./data";
import { buildInsights } from "./insights";
import { computeOperationalAnalytics } from "./operational-data";
import { OperationalAnalyticsSections } from "./operational-sections";
import { exportSalesAnalyticsCSV, exportSalesAnalyticsXLSX } from "./export";
import type { ProductRow, CategoryRow, MarketplaceRow } from "./data";

const PERIOD_ORDER: PeriodPreset[] = [
  "today",
  "yesterday",
  "7d",
  "30d",
  "month",
  "last-month",
  "custom",
];

const CHANNEL_COLORS = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

type TrendMetric = "revenue" | "orders" | "profit";

export function SalesAnalyticsPage() {
  const [preset, setPreset] = useState<PeriodPreset>("7d");
  const [custom, setCustom] = useState<{ from?: Date; to?: Date }>({});
  const [metric, setMetric] = useState<TrendMetric>("revenue");

  const period = useMemo(() => {
    if (preset === "custom" && custom.from && custom.to) {
      return resolvePeriod("custom", { from: custom.from, to: custom.to });
    }
    if (preset === "custom") return resolvePeriod("today");
    return resolvePeriod(preset);
  }, [preset, custom]);

  const data: SalesAnalyticsData = useMemo(() => computeSalesAnalytics(period), [period]);
  const operational = useMemo(() => computeOperationalAnalytics(period), [period]);
  const insights = useMemo(() => buildInsights(data), [data]);

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Analytics Module"
        title="Sales Analytics"
        description="Business Intelligence untuk performa penjualan. Read-only — data langsung dari Sales Module."
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <Download className="h-3.5 w-3.5" />
                Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Quick Export</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => exportSalesAnalyticsXLSX(data)}>
                <FileSpreadsheet className="mr-2 h-4 w-4" /> Excel (.xlsx)
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => exportSalesAnalyticsCSV(data)}>
                <FileText className="mr-2 h-4 w-4" /> CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PERIOD_LABELS[p]}
                </Button>
              ))}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={preset === "custom" ? "default" : "ghost"}
                    className="h-7 gap-1 px-2.5 text-xs"
                  >
                    <CalendarDays className="h-3.5 w-3.5" />
                    Custom
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-auto p-0">
                  <Calendar
                    mode="range"
                    numberOfMonths={2}
                    selected={{ from: custom.from, to: custom.to }}
                    onSelect={(r) => {
                      setCustom({ from: r?.from, to: r?.to });
                      if (r?.from && r?.to) setPreset("custom");
                    }}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <Badge variant="secondary" className="text-xs">
              {period.label}
            </Badge>
          </div>
        }
      />

      {/* SECTION 1 — Executive KPI */}
      <AnalyticsSection title="Executive KPI" description="Ringkasan performa vs periode sebelumnya.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <KPICard
            label="Revenue"
            value={formatIDR(data.kpi.revenue)}
            deltaPct={data.kpi.growth.revenue}
            trend={data.kpi.trend.revenue}
            icon={Wallet}
          />
          <KPICard
            label="Orders"
            value={formatNumber(data.kpi.orders)}
            deltaPct={data.kpi.growth.orders}
            trend={data.kpi.trend.orders}
            icon={ShoppingBag}
          />
          <KPICard
            label="Avg. Order Value"
            value={formatIDR(data.kpi.aov)}
            deltaPct={data.kpi.growth.aov}
            icon={ReceiptText}
          />
          <KPICard
            label="Gross Profit"
            value={formatIDR(data.kpi.grossProfit)}
            deltaPct={data.kpi.growth.grossProfit}
            trend={data.kpi.trend.profit}
            tone={data.kpi.grossProfit >= 0 ? "positive" : "destructive"}
            icon={TrendingUp}
          />
          <KPICard
            label="Net Profit"
            hint="Proksi = gross profit (net perusahaan penuh ada di Finance Analytics)"
            value={formatIDR(data.kpi.netProfit)}
            deltaPct={data.kpi.growth.netProfit}
            tone={data.kpi.netProfit >= 0 ? "positive" : "destructive"}
            icon={DollarSign}
          />
          <KPICard
            label="Refund Total"
            value={formatIDR(data.kpi.refundTotal)}
            tone={data.kpi.refundTotal > 0 ? "warning" : "muted"}
            icon={Undo2}
          />
          <KPICard
            label="Refund Rate"
            value={`${(data.kpi.refundRate * 100).toFixed(2)}%`}
            tone={data.kpi.refundRate >= 0.05 ? "destructive" : "muted"}
            icon={Percent}
          />
          <KPICard
            label="Growth Revenue"
            value={
              data.kpi.growth.revenue == null
                ? "—"
                : `${(data.kpi.growth.revenue * 100).toFixed(1)}%`
            }
            deltaPct={data.kpi.growth.revenue}
            tone={
              data.kpi.growth.revenue == null
                ? "muted"
                : data.kpi.growth.revenue >= 0
                  ? "positive"
                  : "destructive"
            }
            icon={data.kpi.growth.revenue != null && data.kpi.growth.revenue < 0 ? TrendingDown : TrendingUp}
          />
        </div>
      </AnalyticsSection>

      {/* SECTION 2 — Revenue Trend */}
      <AnalyticsSection
        title="Revenue Trend"
        description="Tren harian revenue, orders, dan profit."
        action={
          <Tabs value={metric} onValueChange={(v) => setMetric(v as TrendMetric)}>
            <TabsList className="h-8">
              <TabsTrigger value="revenue" className="text-xs">
                Revenue
              </TabsTrigger>
              <TabsTrigger value="profit" className="text-xs">
                Profit
              </TabsTrigger>
              <TabsTrigger value="orders" className="text-xs">
                Orders
              </TabsTrigger>
            </TabsList>
          </Tabs>
        }
      >
        <RevenueTrendChart data={data} metric={metric} />
      </AnalyticsSection>

      {/* SECTION 3 & 4 — Channel + Marketplace */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Sales Channel" description="Distribusi pembayaran & marketplace.">
          <ChannelDonut data={data} />
        </AnalyticsSection>
        <AnalyticsSection title="Marketplace Analytics" description="Ranking marketplace aktif.">
          <MarketplaceTable rows={data.marketplaces} />
        </AnalyticsSection>
      </div>

      {/* SECTION 5 & 6 — Top / Worst Product */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Top 10 Produk" description="Kontributor revenue tertinggi.">
          <ProductTable rows={data.top} showShare />
        </AnalyticsSection>
        <AnalyticsSection title="Worst 10 Produk" description="Produk aktif dengan revenue terendah / tidak terjual.">
          <ProductTable rows={data.worst} showShare={false} emptyMessage="Semua produk terjual." />
        </AnalyticsSection>
      </div>

      {/* SECTION 7 — Kategori */}
      <AnalyticsSection title="Kategori Produk" description="Kontribusi per kategori.">
        <CategoryChart rows={data.categories} />
      </AnalyticsSection>

      {/* SECTION 8 — Hourly */}
      <AnalyticsSection title="Hourly Sales" description="Distribusi order per jam.">
        <HourlyChart data={data} />
      </AnalyticsSection>

      {/* SECTION 9 — Payment breakdown */}
      <AnalyticsSection title="Payment Analytics" description="Breakdown per metode pembayaran.">
        <PaymentTable data={data} />
      </AnalyticsSection>

      {/* SECTION 10 & 11 — Customer + Refund */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Customer Analytics" description="New vs returning.">
          <CustomerCard data={data} />
        </AnalyticsSection>
        <AnalyticsSection title="Refund Analytics" description="Nilai refund & tren harian.">
          <RefundCard data={data} />
        </AnalyticsSection>
      </div>

      <AnalyticsSection title="Top Refund Product" description="Produk paling sering direfund.">
        <TableCard
          title="Top Refund Product"
          rows={data.refunds.topProducts}
          columns={[
            { key: "name", header: "Produk", render: (r) => r.name },
            { key: "qty", header: "Qty", align: "right", render: (r) => formatNumber(r.qty) },
            {
              key: "amount",
              header: "Nominal",
              align: "right",
              render: (r) => formatIDR(r.amount),
            },
          ]}
          emptyMessage="Tidak ada refund pada periode ini."
        />
      </AnalyticsSection>

      {/* SECTION 12 — Preorder */}
      <AnalyticsSection title="Preorder Analytics" description="Status pre order & completion.">
        <PreorderCard data={data} />
      </AnalyticsSection>

      {/* SECTION 13 & 14 — Forecast + Insight */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <AnalyticsSection title="Forecast" description="Proyeksi berbasis moving average 30 hari (tanpa AI).">
          <ForecastCard data={data} />
        </AnalyticsSection>
        <AnalyticsSection title="Insight" description="Rule-based highlight.">
          <InsightCard items={insights} />
        </AnalyticsSection>
      </div>

      {/* SECTION 15+ — Operational Analytics (additive) */}
      <OperationalAnalyticsSections data={operational} />
    </AnalyticsLayout>
  );
}

/* ---------------- Sub components ---------------- */

function RevenueTrendChart({ data, metric }: { data: SalesAnalyticsData; metric: TrendMetric }) {
  const config: ChartConfig = {
    value: {
      label: metric === "revenue" ? "Revenue" : metric === "profit" ? "Profit" : "Orders",
      color: "var(--color-primary)",
    },
  };
  const rows = data.daily.map((d) => ({
    label: d.label,
    value: metric === "revenue" ? d.revenue : metric === "profit" ? d.profit : d.orders,
  }));
  const isMoney = metric !== "orders";
  return (
    <ChartCard title="" subtitle={data.period.label}>
      <ChartContainer config={config} className="h-[280px] w-full">
        <AreaChart data={rows} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
          <defs>
            <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.3} />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} tickMargin={8} fontSize={11} />
          <YAxis
            width={70}
            tickLine={false}
            axisLine={false}
            fontSize={11}
            tickFormatter={(v: number) => (isMoney ? formatIDR(v) : formatNumber(v))}
          />
          <ChartTooltip
            content={
              <ChartTooltipContent
                formatter={(value) =>
                  isMoney ? formatIDR(Number(value)) : formatNumber(Number(value))
                }
              />
            }
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke="var(--color-primary)"
            strokeWidth={2}
            fill="url(#areaGradient)"
          />
        </AreaChart>
      </ChartContainer>
    </ChartCard>
  );
}

function ChannelDonut({ data }: { data: SalesAnalyticsData }) {
  const total = data.channels.reduce((a, c) => a + c.amount, 0);
  const rows = data.channels.filter((c) => c.amount > 0);
  return (
    <ChartCard title="Sales Channel" subtitle={`Total ${formatIDR(total)}`}>
      {rows.length === 0 ? (
        <div className="rounded-md border border-dashed py-10 text-center text-sm text-muted-foreground">
          Belum ada penjualan.
        </div>
      ) : (
        <div className="grid grid-cols-1 items-center gap-4 md:grid-cols-2">
          <div className="h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <RechartTooltip formatter={(v: number) => formatIDR(v)} />
                <Pie
                  data={rows}
                  dataKey="amount"
                  nameKey="label"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                >
                  {rows.map((_, i) => (
                    <Cell key={i} fill={CHANNEL_COLORS[i % CHANNEL_COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="space-y-2 text-sm">
            {rows.map((c, i) => (
              <li key={c.key} className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2">
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: CHANNEL_COLORS[i % CHANNEL_COLORS.length] }}
                  />
                  <span>{c.label}</span>
                  <Badge variant="secondary" className="text-[10px]">
                    {c.orders} order
                  </Badge>
                </span>
                <span className="text-right tabular-nums">
                  <div className="font-medium">{formatIDR(c.amount)}</div>
                  <div className="text-xs text-muted-foreground">
                    {(c.share * 100).toFixed(1)}%
                  </div>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </ChartCard>
  );
}

function MarketplaceTable({ rows }: { rows: MarketplaceRow[] }) {
  const active = rows.filter((r) => r.revenue > 0 || r.orders > 0);
  const columns: TableColumn<MarketplaceRow>[] = [
    { key: "label", header: "Marketplace", render: (r) => r.label },
    { key: "revenue", header: "Revenue", align: "right", render: (r) => formatIDR(r.revenue) },
    { key: "orders", header: "Orders", align: "right", render: (r) => formatNumber(r.orders) },
    { key: "aov", header: "AOV", align: "right", render: (r) => formatIDR(r.aov) },
    {
      key: "share",
      header: "Contribution",
      align: "right",
      render: (r) => `${(r.share * 100).toFixed(1)}%`,
    },
  ];
  return (
    <TableCard
      title="Marketplace Ranking"
      columns={columns}
      rows={active}
      emptyMessage="Belum ada transaksi marketplace pada periode ini."
    />
  );
}

function ProductTable({
  rows,
  showShare,
  emptyMessage,
}: {
  rows: ProductRow[];
  showShare: boolean;
  emptyMessage?: string;
}) {
  const columns: TableColumn<ProductRow>[] = [
    {
      key: "rank",
      header: "#",
      align: "right",
      render: (_r, i) => i + 1,
      className: "w-8 text-muted-foreground",
    },
    { key: "name", header: "Produk", render: (r) => (
      <div className="flex flex-col">
        <span className="font-medium">{r.name}</span>
        <span className="text-[11px] text-muted-foreground">{r.category}</span>
      </div>
    ) },
    { key: "qty", header: "Qty", align: "right", render: (r) => formatNumber(r.qty) },
    {
      key: "revenue",
      header: "Revenue",
      align: "right",
      render: (r) => formatIDR(r.revenue),
    },
    { key: "profit", header: "Profit", align: "right", render: (r) => formatIDR(r.profit) },
    ...(showShare
      ? [
          {
            key: "share",
            header: "Share",
            align: "right" as const,
            render: (r: ProductRow) => `${(r.share * 100).toFixed(1)}%`,
          },
        ]
      : []),
  ];
  return (
    <TableCard
      title="Ranking Produk"
      columns={columns}
      rows={rows}
      emptyMessage={emptyMessage ?? "Belum ada produk terjual."}
    />
  );
}

function CategoryChart({ rows }: { rows: CategoryRow[] }) {
  const chartRows = rows.map((r) => ({
    category: r.category,
    revenue: r.revenue,
    qty: r.qty,
    profit: r.profit,
  }));
  const columns: TableColumn<CategoryRow>[] = [
    { key: "cat", header: "Kategori", render: (r) => r.category },
    { key: "revenue", header: "Revenue", align: "right", render: (r) => formatIDR(r.revenue) },
    { key: "qty", header: "Qty", align: "right", render: (r) => formatNumber(r.qty) },
    { key: "profit", header: "Profit", align: "right", render: (r) => formatIDR(r.profit) },
    {
      key: "share",
      header: "Share",
      align: "right",
      render: (r) => `${(r.share * 100).toFixed(1)}%`,
    },
  ];
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <ChartCard title="Revenue per Kategori">
        {chartRows.length === 0 ? (
          <div className="rounded-md border border-dashed py-10 text-center text-sm text-muted-foreground">
            Belum ada data.
          </div>
        ) : (
          <ChartContainer config={{ revenue: { label: "Revenue", color: "var(--color-primary)" } }} className="h-[260px] w-full">
            <BarChart data={chartRows} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="category" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis
                width={70}
                tickLine={false}
                axisLine={false}
                fontSize={11}
                tickFormatter={(v: number) => formatIDR(v)}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent formatter={(v) => formatIDR(Number(v))} />
                }
              />
              <Bar dataKey="revenue" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartContainer>
        )}
      </ChartCard>
      <TableCard title="Detail Kategori" columns={columns} rows={rows} />
    </div>
  );
}

function HourlyChart({ data }: { data: SalesAnalyticsData }) {
  const peak = data.hourly.reduce((a, b) => (b.orders > a.orders ? b : a), data.hourly[0]);
  return (
    <ChartCard
      title="Distribusi Order per Jam"
      subtitle={peak.orders > 0 ? `Peak hour ${peak.label} (${peak.orders} order)` : undefined}
    >
      <ChartContainer
        config={{ orders: { label: "Orders", color: "var(--color-primary)" } }}
        className="h-[240px] w-full"
      >
        <BarChart data={data.hourly} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
          <CartesianGrid vertical={false} strokeDasharray="3 3" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={10} interval={1} />
          <YAxis width={40} tickLine={false} axisLine={false} fontSize={11} />
          <ChartTooltip
            content={
              <ChartTooltipContent
                formatter={(v, _n, entry) => {
                  const revenue = (entry?.payload as { revenue?: number } | undefined)?.revenue ?? 0;
                  return `${formatNumber(Number(v))} order · ${formatIDR(revenue)}`;
                }}
              />
            }
          />
          <Bar dataKey="orders" fill="var(--color-primary)" radius={[3, 3, 0, 0]} />
        </BarChart>
      </ChartContainer>
    </ChartCard>
  );
}

function PaymentTable({ data }: { data: SalesAnalyticsData }) {
  const columns = [
    { key: "label", header: "Metode", render: (r: (typeof data.payments)[number]) => r.label },
    {
      key: "amount",
      header: "Nominal",
      align: "right" as const,
      render: (r: (typeof data.payments)[number]) => formatIDR(r.amount),
    },
    {
      key: "orders",
      header: "Orders",
      align: "right" as const,
      render: (r: (typeof data.payments)[number]) => formatNumber(r.orders),
    },
    {
      key: "aov",
      header: "AOV",
      align: "right" as const,
      render: (r: (typeof data.payments)[number]) => formatIDR(r.aov),
    },
  ];
  return <TableCard title="Payment Breakdown" columns={columns} rows={data.payments} />;
}

function CustomerCard({ data }: { data: SalesAnalyticsData }) {
  const c = data.customers;
  if (!c.available) {
    return (
      <Card className="rounded-xl">
        <CardContent className="flex flex-col items-start gap-2 p-5">
          <Badge variant="secondary" className="gap-1 text-[10px]">
            <Sparkles className="h-3 w-3" /> Coming Soon
          </Badge>
          <p className="text-sm text-muted-foreground">
            {c.message ?? "Customer analytics available after CRM module."}
          </p>
        </CardContent>
      </Card>
    );
  }
  return (
    <div className="grid grid-cols-3 gap-3">
      <KPICard label="New Customer" value={formatNumber(c.newCustomers)} />
      <KPICard label="Returning" value={formatNumber(c.returning)} />
      <KPICard
        label="Repeat Rate"
        value={`${(c.repeatRate * 100).toFixed(1)}%`}
        tone={c.repeatRate >= 0.3 ? "positive" : "muted"}
      />
    </div>
  );
}

function RefundCard({ data }: { data: SalesAnalyticsData }) {
  const r = data.refunds;
  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-3 gap-3">
        <KPICard label="Refund" value={formatNumber(r.totalRefunds)} />
        <KPICard label="Nominal" value={formatIDR(r.totalAmount)} tone="warning" />
        <KPICard
          label="Refund Rate"
          value={`${(r.refundRate * 100).toFixed(2)}%`}
          tone={r.refundRate >= 0.05 ? "destructive" : "muted"}
        />
      </div>
      <ChartCard title="Trend Refund">
        <ChartContainer
          config={{ amount: { label: "Refund", color: "var(--destructive)" } }}
          className="h-[180px] w-full"
        >
          <BarChart data={r.trend} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
            <CartesianGrid vertical={false} strokeDasharray="3 3" />
            <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
            <YAxis
              width={60}
              tickLine={false}
              axisLine={false}
              fontSize={11}
              tickFormatter={(v: number) => formatIDR(v)}
            />
            <ChartTooltip
              content={<ChartTooltipContent formatter={(v) => formatIDR(Number(v))} />}
            />
            <Bar dataKey="amount" fill="var(--destructive)" radius={[3, 3, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </ChartCard>
    </div>
  );
}

function PreorderCard({ data }: { data: SalesAnalyticsData }) {
  const p = data.preorders;
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      <KPICard label="Preorder Aktif" value={formatNumber(p.active)} icon={BarChart3} />
      <KPICard label="Revenue Selesai" value={formatIDR(p.revenue)} tone="positive" />
      <KPICard label="Outstanding" value={formatIDR(p.outstanding)} tone="warning" />
      <KPICard
        label="Completion Rate"
        value={`${(p.completionRate * 100).toFixed(0)}%`}
        tone={p.completionRate >= 0.8 ? "positive" : "muted"}
      />
    </div>
  );
}

function ForecastCard({ data }: { data: SalesAnalyticsData }) {
  const f = data.forecast;
  return (
    <Card className="rounded-xl">
      <CardContent className="flex flex-col gap-4 p-5">
        <div className="text-xs text-muted-foreground">
          Proyeksi {f.days} hari berbasis moving average 30 hari (
          {formatIDR(f.basisDailyRevenue)}/hari · {f.basisDailyOrders.toFixed(1)} order/hari)
        </div>
        <div className="grid grid-cols-3 gap-3">
          <KPICard label="Projected Revenue" value={formatIDR(f.revenue)} tone="positive" />
          <KPICard label="Projected Orders" value={formatNumber(Math.round(f.orders))} />
          <KPICard label="Projected Profit" value={formatIDR(f.profit)} tone="positive" />
        </div>
      </CardContent>
    </Card>
  );
}
