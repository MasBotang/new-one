/**
 * Export helper Sales Analytics — memakai canonical downloadCSV / downloadXLSX
 * dari finance-report.service agar tidak menduplikasi kode export.
 */
import { downloadCSV, downloadXLSX } from "@/services/finance-report.service";
import type { SalesAnalyticsData } from "./data";

function slugPeriod(label: string): string {
  return label.replace(/[^0-9a-zA-Z]+/g, "-").toLowerCase();
}

function buildSheets(data: SalesAnalyticsData) {
  const { kpi, daily, channels, marketplaces, top, worst, categories, hourly, payments, refunds, preorders, forecast } =
    data;
  return [
    {
      name: "KPI",
      rows: [
        { Metric: "Revenue", Value: kpi.revenue },
        { Metric: "Orders", Value: kpi.orders },
        { Metric: "AOV", Value: kpi.aov },
        { Metric: "Gross Profit", Value: kpi.grossProfit },
        { Metric: "Net Profit (proxy = gross)", Value: kpi.netProfit },
        { Metric: "Refund Total", Value: kpi.refundTotal },
        { Metric: "Refund Rate", Value: kpi.refundRate },
      ],
    },
    {
      name: "Daily",
      rows: daily.map((d) => ({
        Tanggal: d.date,
        Revenue: d.revenue,
        Orders: d.orders,
        Profit: d.profit,
      })),
    },
    {
      name: "Channel",
      rows: channels.map((c) => ({
        Channel: c.label,
        Nominal: c.amount,
        Orders: c.orders,
        Share: c.share,
      })),
    },
    {
      name: "Marketplace",
      rows: marketplaces.map((m) => ({
        Marketplace: m.label,
        Revenue: m.revenue,
        Orders: m.orders,
        AOV: m.aov,
        Share: m.share,
      })),
    },
    {
      name: "TopProduct",
      rows: top.map((p, i) => ({
        Rank: i + 1,
        Produk: p.name,
        Kategori: p.category,
        Qty: p.qty,
        Revenue: p.revenue,
        Profit: p.profit,
        Share: p.share,
      })),
    },
    {
      name: "WorstProduct",
      rows: worst.map((p, i) => ({
        Rank: i + 1,
        Produk: p.name,
        Kategori: p.category,
        Qty: p.qty,
        Revenue: p.revenue,
      })),
    },
    {
      name: "Kategori",
      rows: categories.map((c) => ({
        Kategori: c.category,
        Revenue: c.revenue,
        Qty: c.qty,
        Profit: c.profit,
        Share: c.share,
      })),
    },
    {
      name: "Hourly",
      rows: hourly.map((h) => ({ Jam: h.label, Orders: h.orders, Revenue: h.revenue })),
    },
    {
      name: "Payment",
      rows: payments.map((p) => ({
        Metode: p.label,
        Nominal: p.amount,
        Orders: p.orders,
        AOV: p.aov,
      })),
    },
    {
      name: "Refund",
      rows: refunds.trend.map((t) => ({
        Tanggal: t.date,
        Jumlah: t.count,
        Nominal: t.amount,
      })),
    },
    {
      name: "Preorder",
      rows: [
        { Metric: "Aktif", Value: preorders.active },
        { Metric: "Outstanding", Value: preorders.outstanding },
        { Metric: "Revenue Selesai", Value: preorders.revenue },
        { Metric: "Completion Rate", Value: preorders.completionRate },
      ],
    },
    {
      name: "Forecast",
      rows: [
        { Metric: "Hari Diproyeksi", Value: forecast.days },
        { Metric: "Projected Revenue", Value: forecast.revenue },
        { Metric: "Projected Orders", Value: forecast.orders },
        { Metric: "Projected Profit", Value: forecast.profit },
        { Metric: "Basis Harian Revenue", Value: forecast.basisDailyRevenue },
        { Metric: "Basis Harian Orders", Value: forecast.basisDailyOrders },
        { Metric: "Basis Harian Profit", Value: forecast.basisDailyProfit },
      ],
    },
  ];
}

export function exportSalesAnalyticsXLSX(data: SalesAnalyticsData) {
  const slug = slugPeriod(data.period.label);
  downloadXLSX(buildSheets(data), `sales-analytics-${slug}.xlsx`);
}

export function exportSalesAnalyticsCSV(data: SalesAnalyticsData) {
  const slug = slugPeriod(data.period.label);
  // CSV = flat file → gabung tiap sheet dengan header "SECTION:".
  const sheets = buildSheets(data);
  const merged: Record<string, unknown>[] = [];
  for (const s of sheets) {
    merged.push({ SECTION: s.name });
    for (const row of s.rows) merged.push(row);
    merged.push({});
  }
  downloadCSV(merged, `sales-analytics-${slug}.csv`);
}
