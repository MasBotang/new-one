/**
 * Rule-based insight generator untuk Sales Analytics.
 * Deterministik — tidak menggunakan AI. Aman dijalankan setiap render.
 */
import type { InsightItem } from "@/components/analytics";
import { formatIDR } from "@/lib/format";
import type { SalesAnalyticsData } from "./data";

function pct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function buildInsights(data: SalesAnalyticsData): InsightItem[] {
  const items: InsightItem[] = [];
  const { kpi, channels, top, hourly, refunds, preorders, categories } = data;

  // Revenue growth
  if (kpi.growth.revenue != null) {
    const g = kpi.growth.revenue;
    if (g >= 0.1) {
      items.push({
        level: "positive",
        title: `Revenue naik ${pct(g)} dibanding periode sebelumnya`,
        detail: `${formatIDR(kpi.revenue)} vs periode lalu`,
      });
    } else if (g <= -0.1) {
      items.push({
        level: "negative",
        title: `Revenue turun ${pct(Math.abs(g))} dibanding periode sebelumnya`,
        detail: `${formatIDR(kpi.revenue)} vs periode lalu`,
      });
    } else {
      items.push({
        level: "info",
        title: `Revenue relatif stabil (${g >= 0 ? "+" : ""}${pct(g)})`,
      });
    }
  }

  // Order trend
  if (kpi.growth.orders != null && kpi.growth.orders <= -0.1) {
    items.push({
      level: "warning",
      title: `Jumlah order turun ${pct(Math.abs(kpi.growth.orders))} dari periode sebelumnya`,
    });
  }

  // Dominant channel
  const dominant = [...channels].sort((a, b) => b.share - a.share)[0];
  if (dominant && dominant.share > 0.4) {
    items.push({
      level: "info",
      title: `${dominant.label} mendominasi pembayaran (${pct(dominant.share)})`,
      detail: `${formatIDR(dominant.amount)} dari ${dominant.orders} order`,
    });
  }

  // Top product contribution
  if (top[0] && top[0].revenue > 0) {
    items.push({
      level: "info",
      title: `Top product ${top[0].name} menyumbang ${pct(top[0].share)} revenue`,
      detail: `${formatIDR(top[0].revenue)} · ${top[0].qty} pcs`,
    });
  }

  // Top category
  if (categories[0] && categories[0].share > 0.5) {
    items.push({
      level: "info",
      title: `Kategori ${categories[0].category} mendominasi (${pct(categories[0].share)})`,
    });
  }

  // Refund alert
  if (refunds.refundRate >= 0.05) {
    items.push({
      level: "negative",
      title: `Refund rate tinggi: ${pct(refunds.refundRate)}`,
      detail: `${refunds.totalRefunds} transaksi · ${formatIDR(refunds.totalAmount)}`,
    });
  } else if (refunds.totalRefunds > 0) {
    items.push({
      level: "warning",
      title: `${refunds.totalRefunds} refund pada periode ini`,
      detail: formatIDR(refunds.totalAmount),
    });
  }

  // Peak hour
  const peak = [...hourly].sort((a, b) => b.orders - a.orders)[0];
  if (peak && peak.orders > 0) {
    const secondPeak = [...hourly]
      .filter((h) => h.hour !== peak.hour)
      .sort((a, b) => b.orders - a.orders)[0];
    const label =
      secondPeak && secondPeak.orders >= peak.orders * 0.6
        ? `${peak.label}–${secondPeak.label}`
        : peak.label;
    items.push({
      level: "info",
      title: `Jam paling ramai ${label}`,
      detail: `${peak.orders} order di jam ${peak.label}`,
    });
  }

  // Preorder outstanding
  if (preorders.active > 0) {
    items.push({
      level: preorders.completionRate >= 0.8 ? "positive" : "info",
      title: `${preorders.active} pre order aktif · outstanding ${formatIDR(
        preorders.outstanding,
      )}`,
      detail:
        preorders.completionRate > 0
          ? `Completion rate ${pct(preorders.completionRate)}`
          : undefined,
    });
  }

  return items;
}
