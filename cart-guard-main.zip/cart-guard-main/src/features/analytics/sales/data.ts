/**
 * Sales Analytics data layer — read-only.
 *
 * SEMUA agregasi Sales Analytics WAJIB melalui file ini agar tidak
 * menduplikasi logika Finance / Sales. File ini murni membaca dari service
 * canonical yang sudah ada:
 *   - salesService      (list transaksi)
 *   - refundService     (approved refund requests)
 *   - preorderService   (pre order aktif / completed)
 *   - productService    (kategori & metadata produk)
 *   - shiftService      (dipakai tidak langsung — melalui sale.shiftId)
 *   - aggregateSalesRange / aggregateSalesList (canonical Finance helper)
 *   - MARKETPLACE_SOURCES, SOURCE_ORDER_LABEL (types)
 *
 * TIDAK menulis storage. TIDAK mem-mutasi entity. TIDAK mengubah business
 * flow Sales/Finance.
 */

import { saleAmountByMethod } from "@/lib/payment";
import {
  aggregateSalesList,
  aggregateSalesRange,
  type DateRange,
  type SalesAggregate,
} from "@/services/finance-aggregation";
import { salesService } from "@/services/sales.service";
import { refundService } from "@/services/refund.service";
import { preorderService } from "@/services/preorder.service";
import { productService } from "@/services/product.service";
import {
  MARKETPLACE_SOURCES,
  SOURCE_ORDER_LABEL,
  type MarketplaceSource,
  type PaymentBucket,
  type Sale,
  type SourceOrder,
} from "@/services/types";

/* ---------------------- Period presets ---------------------- */

export type PeriodPreset =
  | "today"
  | "yesterday"
  | "7d"
  | "30d"
  | "month"
  | "last-month"
  | "custom";

export const PERIOD_LABELS: Record<PeriodPreset, string> = {
  today: "Hari Ini",
  yesterday: "Kemarin",
  "7d": "7 Hari",
  "30d": "30 Hari",
  month: "Bulan Ini",
  "last-month": "Bulan Lalu",
  custom: "Custom",
};

export interface Period {
  preset: PeriodPreset;
  range: DateRange;
  /** Rentang periode sebelumnya dengan durasi yang sama (untuk growth). */
  previous: DateRange;
  label: string;
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

export function resolvePeriod(
  preset: PeriodPreset,
  custom?: { from: Date; to: Date },
  ref = new Date(),
): Period {
  const today = startOfDay(ref);
  let range: DateRange;
  switch (preset) {
    case "today":
      range = { from: today, to: addDays(today, 1) };
      break;
    case "yesterday":
      range = { from: addDays(today, -1), to: today };
      break;
    case "7d":
      range = { from: addDays(today, -6), to: addDays(today, 1) };
      break;
    case "30d":
      range = { from: addDays(today, -29), to: addDays(today, 1) };
      break;
    case "month": {
      const from = new Date(today.getFullYear(), today.getMonth(), 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      range = { from, to };
      break;
    }
    case "last-month": {
      const from = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const to = new Date(today.getFullYear(), today.getMonth(), 1);
      range = { from, to };
      break;
    }
    case "custom": {
      if (!custom) {
        range = { from: today, to: addDays(today, 1) };
      } else {
        range = {
          from: startOfDay(custom.from),
          to: addDays(startOfDay(custom.to), 1),
        };
      }
      break;
    }
  }
  const spanMs = range.to.getTime() - range.from.getTime();
  const previous: DateRange = {
    from: new Date(range.from.getTime() - spanMs),
    to: new Date(range.from.getTime()),
  };
  const fmt = (d: Date) =>
    d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const lastDay = new Date(range.to.getTime() - 1);
  const label =
    range.to.getTime() - range.from.getTime() <= 86400000
      ? fmt(range.from)
      : `${fmt(range.from)} – ${fmt(lastDay)}`;
  return { preset, range, previous, label };
}

/* ---------------------- Internal helpers ---------------------- */

function inRange(iso: string, r: DateRange): boolean {
  const t = new Date(iso).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

function activeSalesInRange(range: DateRange): Sale[] {
  return salesService.list().filter((s) => !s.voided && inRange(s.createdAt, range));
}

/**
 * @deprecated Sprint 7 Split Payment: gunakan `saleAmountByMethod` +
 * split ke tiap bucket. Fungsi ini masih memakai dominan (nominal
 * terbesar) untuk kompatibilitas — hindari untuk agregasi baru.
 */
function bucketOf(s: Sale): PaymentBucket {
  const src = s.sourceOrder;
  if (src && (MARKETPLACE_SOURCES as string[]).includes(src)) return "marketplace";
  const parts = saleAmountByMethod(s);
  const cash = parts.cash + parts.card;
  const best = Math.max(cash, parts.qris, parts.transfer);
  if (best === parts.qris && parts.qris > 0) return "qris";
  if (best === parts.transfer && parts.transfer > 0) return "transfer";
  return "cash";
}

function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/* ---------------------- Executive KPI ---------------------- */

export interface ExecutiveKPI {
  revenue: number;
  orders: number;
  aov: number;
  grossProfit: number;
  netProfit: number;
  refundTotal: number;
  refundRate: number;
  growth: {
    revenue: number | null;
    orders: number | null;
    aov: number | null;
    grossProfit: number | null;
    netProfit: number | null;
  };
  trend: {
    revenue: number[];
    orders: number[];
    profit: number[];
  };
}

function pctChange(current: number, previous: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return (current - previous) / previous;
}

/**
 * Executive KPI. Net profit di sini = gross profit − 0 (karena pengeluaran
 * operasional bukan bagian Sales Module). Sales Analytics adalah BI khusus
 * Sales, sedangkan Net Profit tingkat perusahaan hidup di Finance Analytics.
 * Kami tetap menampilkan card Net Profit sebagai proksi = grossProfit agar
 * kontrak SECTION 1 terpenuhi tanpa mengganggu Finance.
 */
export function computeExecutiveKPI(period: Period): ExecutiveKPI {
  const agg = aggregateSalesRange(period.range);
  const prev = aggregateSalesRange(period.previous);

  const refundedNow = salesService
    .list()
    .filter((s) => s.voided && s.voidedAt && inRange(s.voidedAt, period.range));
  const refundTotal = refundedNow.reduce((a, s) => a + (s.total ?? 0), 0);
  // Refund rate = nilai refund ÷ (revenue non-void + refund) untuk periode ini.
  const denom = agg.revenue + refundTotal;
  const refundRate = denom > 0 ? refundTotal / denom : 0;

  const trend = dailyTrend(period.range);
  return {
    revenue: agg.revenue,
    orders: agg.orders,
    aov: agg.orders > 0 ? agg.revenue / agg.orders : 0,
    grossProfit: agg.grossProfit,
    netProfit: agg.grossProfit,
    refundTotal,
    refundRate,
    growth: {
      revenue: pctChange(agg.revenue, prev.revenue),
      orders: pctChange(agg.orders, prev.orders),
      aov: pctChange(
        agg.orders > 0 ? agg.revenue / agg.orders : 0,
        prev.orders > 0 ? prev.revenue / prev.orders : 0,
      ),
      grossProfit: pctChange(agg.grossProfit, prev.grossProfit),
      netProfit: pctChange(agg.grossProfit, prev.grossProfit),
    },
    trend: {
      revenue: trend.map((d) => d.revenue),
      orders: trend.map((d) => d.orders),
      profit: trend.map((d) => d.profit),
    },
  };
}

/* ---------------------- Revenue Trend (daily) ---------------------- */

export interface DailyPoint {
  date: string; // YYYY-MM-DD
  label: string;
  revenue: number;
  orders: number;
  profit: number;
}

export function dailyTrend(range: DateRange): DailyPoint[] {
  const days: DailyPoint[] = [];
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    days.push({
      date: ymd(cursor),
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      revenue: 0,
      orders: 0,
      profit: 0,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  const idx = new Map(days.map((d, i) => [d.date, i]));
  for (const s of activeSalesInRange(range)) {
    const key = ymd(new Date(s.createdAt));
    const i = idx.get(key);
    if (i == null) continue;
    days[i].revenue += s.total ?? 0;
    days[i].orders += 1;
    let hpp = 0;
    for (const it of s.items) hpp += (it.cost ?? 0) * it.qty;
    days[i].profit += (s.total ?? 0) - hpp;
  }
  return days;
}

/* ---------------------- Channel breakdown ---------------------- */

export interface ChannelSlice {
  key: PaymentBucket;
  label: string;
  amount: number;
  orders: number;
  share: number;
}

const BUCKET_LABEL: Record<PaymentBucket, string> = {
  cash: "Cash",
  qris: "QRIS",
  transfer: "Transfer",
  marketplace: "Marketplace",
};

export function channelBreakdown(range: DateRange): ChannelSlice[] {
  const active = activeSalesInRange(range);
  const totals: Record<PaymentBucket, { amount: number; orders: number }> = {
    cash: { amount: 0, orders: 0 },
    qris: { amount: 0, orders: 0 },
    transfer: { amount: 0, orders: 0 },
    marketplace: { amount: 0, orders: 0 },
  };
  for (const s of active) {
    const b = bucketOf(s);
    totals[b].amount += s.total ?? 0;
    totals[b].orders += 1;
  }
  const totalAmount = Object.values(totals).reduce((a, v) => a + v.amount, 0);
  return (Object.keys(totals) as PaymentBucket[]).map((k) => ({
    key: k,
    label: BUCKET_LABEL[k],
    amount: totals[k].amount,
    orders: totals[k].orders,
    share: totalAmount > 0 ? totals[k].amount / totalAmount : 0,
  }));
}

/* ---------------------- Marketplace ranking ---------------------- */

export interface MarketplaceRow {
  key: MarketplaceSource;
  label: string;
  revenue: number;
  orders: number;
  aov: number;
  share: number;
}

export function marketplaceRanking(range: DateRange): MarketplaceRow[] {
  const active = activeSalesInRange(range);
  const marketplaceRevenue = active
    .filter((s) => s.sourceOrder && (MARKETPLACE_SOURCES as string[]).includes(s.sourceOrder))
    .reduce((a, s) => a + (s.total ?? 0), 0);
  return MARKETPLACE_SOURCES.map((m) => {
    const rows = active.filter((s) => s.sourceOrder === m);
    const revenue = rows.reduce((a, s) => a + (s.total ?? 0), 0);
    return {
      key: m,
      label: SOURCE_ORDER_LABEL[m as SourceOrder],
      revenue,
      orders: rows.length,
      aov: rows.length ? revenue / rows.length : 0,
      share: marketplaceRevenue > 0 ? revenue / marketplaceRevenue : 0,
    };
  }).sort((a, b) => b.revenue - a.revenue);
}

/* ---------------------- Product ranking ---------------------- */

export interface ProductRow {
  productId: string;
  name: string;
  category: string;
  qty: number;
  revenue: number;
  profit: number;
  share: number;
}

export function productPerformance(range: DateRange): ProductRow[] {
  const products = productService.list();
  const productIdx = new Map(products.map((p) => [p.id, p]));
  const map = new Map<string, ProductRow>();
  const active = activeSalesInRange(range);
  let totalRevenue = 0;
  for (const s of active) {
    for (const it of s.items) {
      const key = it.productId;
      const cur = map.get(key) ?? {
        productId: key,
        name: it.name,
        category: productIdx.get(key)?.category ?? "-",
        qty: 0,
        revenue: 0,
        profit: 0,
        share: 0,
      };
      const rev = it.price * it.qty;
      const cost = (it.cost ?? 0) * it.qty;
      cur.qty += it.qty;
      cur.revenue += rev;
      cur.profit += rev - cost;
      totalRevenue += rev;
      map.set(key, cur);
    }
  }
  return Array.from(map.values())
    .map((r) => ({ ...r, share: totalRevenue > 0 ? r.revenue / totalRevenue : 0 }))
    .sort((a, b) => b.revenue - a.revenue);
}

export function topProducts(range: DateRange, limit = 10): ProductRow[] {
  return productPerformance(range).slice(0, limit);
}

export function worstProducts(range: DateRange, limit = 10): ProductRow[] {
  // Berdasarkan product katalog yang aktif — meski tidak terjual sekalipun.
  const perf = productPerformance(range);
  const sold = new Map(perf.map((p) => [p.productId, p]));
  const products = productService.list().filter((p) => p.active !== false);
  const rows: ProductRow[] = products.map((p) => {
    const s = sold.get(p.id);
    if (s) return s;
    return {
      productId: p.id,
      name: p.name,
      category: p.category ?? "-",
      qty: 0,
      revenue: 0,
      profit: 0,
      share: 0,
    };
  });
  return rows
    .sort((a, b) => a.revenue - b.revenue || a.qty - b.qty)
    .slice(0, limit);
}

/* ---------------------- Category breakdown ---------------------- */

export interface CategoryRow {
  category: string;
  revenue: number;
  qty: number;
  profit: number;
  share: number;
}

export function categoryBreakdown(range: DateRange): CategoryRow[] {
  const perf = productPerformance(range);
  const totalRevenue = perf.reduce((a, p) => a + p.revenue, 0);
  const map = new Map<string, CategoryRow>();
  for (const p of perf) {
    const key = p.category || "-";
    const cur = map.get(key) ?? { category: key, revenue: 0, qty: 0, profit: 0, share: 0 };
    cur.revenue += p.revenue;
    cur.qty += p.qty;
    cur.profit += p.profit;
    map.set(key, cur);
  }
  return Array.from(map.values())
    .map((r) => ({ ...r, share: totalRevenue > 0 ? r.revenue / totalRevenue : 0 }))
    .sort((a, b) => b.revenue - a.revenue);
}

/* ---------------------- Hourly sales ---------------------- */

export interface HourlyRow {
  hour: number;
  label: string;
  orders: number;
  revenue: number;
}

export function hourlySales(range: DateRange): HourlyRow[] {
  const rows: HourlyRow[] = Array.from({ length: 24 }, (_, h) => ({
    hour: h,
    label: `${String(h).padStart(2, "0")}.00`,
    orders: 0,
    revenue: 0,
  }));
  for (const s of activeSalesInRange(range)) {
    const h = new Date(s.createdAt).getHours();
    rows[h].orders += 1;
    rows[h].revenue += s.total ?? 0;
  }
  return rows;
}

/* ---------------------- Payment analytics ---------------------- */

export interface PaymentRow {
  key: PaymentBucket;
  label: string;
  amount: number;
  orders: number;
  aov: number;
}

export function paymentBreakdownDetailed(range: DateRange): PaymentRow[] {
  return channelBreakdown(range).map((c) => ({
    key: c.key,
    label: c.label,
    amount: c.amount,
    orders: c.orders,
    aov: c.orders > 0 ? c.amount / c.orders : 0,
  }));
}

/* ---------------------- Customer analytics ---------------------- */

export interface CustomerStats {
  available: boolean;
  newCustomers: number;
  returning: number;
  repeatRate: number;
  message?: string;
}

/**
 * Sales Module tidak memiliki entity Customer canonical (hanya nama bebas
 * pada Sale). Kami tetap menghitung heuristik berdasarkan pasangan
 * nama+telepon bila tersedia — akan digantikan CRM Module ke depan.
 */
export function customerStats(range: DateRange): CustomerStats {
  const active = activeSalesInRange(range);
  const identified = active.filter(
    (s) => (s.customerPhone && s.customerPhone.trim().length > 3) || (s.customerName && s.customerName.trim().length > 0 && s.customerName !== "-"),
  );
  if (identified.length === 0) {
    return {
      available: false,
      newCustomers: 0,
      returning: 0,
      repeatRate: 0,
      message: "Customer analytics available after CRM module.",
    };
  }
  const historyBefore = new Set<string>();
  for (const s of salesService.list()) {
    if (s.voided) continue;
    if (new Date(s.createdAt).getTime() >= range.from.getTime()) continue;
    const key = (s.customerPhone || s.customerName || "").trim().toLowerCase();
    if (key && key !== "-") historyBefore.add(key);
  }
  const seenInRange = new Set<string>();
  let returning = 0;
  let newC = 0;
  for (const s of identified) {
    const key = (s.customerPhone || s.customerName || "").trim().toLowerCase();
    if (!key || key === "-") continue;
    if (seenInRange.has(key)) {
      returning++;
      continue;
    }
    seenInRange.add(key);
    if (historyBefore.has(key)) returning++;
    else newC++;
  }
  const totalKnown = newC + returning;
  return {
    available: true,
    newCustomers: newC,
    returning,
    repeatRate: totalKnown > 0 ? returning / totalKnown : 0,
  };
}

/* ---------------------- Refund analytics ---------------------- */

export interface RefundAnalytics {
  totalRefunds: number;
  totalAmount: number;
  refundRate: number;
  trend: { date: string; label: string; amount: number; count: number }[];
  topProducts: { productId: string; name: string; qty: number; amount: number }[];
}

export function refundAnalytics(range: DateRange): RefundAnalytics {
  const refunded = salesService
    .list()
    .filter((s) => s.voided && s.voidedAt && inRange(s.voidedAt, range));
  const totalAmount = refunded.reduce((a, s) => a + (s.total ?? 0), 0);

  const activeAgg = aggregateSalesRange(range);
  const refundRate =
    activeAgg.revenue + totalAmount > 0 ? totalAmount / (activeAgg.revenue + totalAmount) : 0;

  const trend = dailyTrend(range).map((d) => ({
    date: d.date,
    label: d.label,
    amount: 0,
    count: 0,
  }));
  const idx = new Map(trend.map((d, i) => [d.date, i]));
  for (const s of refunded) {
    const key = ymd(new Date(s.voidedAt!));
    const i = idx.get(key);
    if (i == null) continue;
    trend[i].amount += s.total ?? 0;
    trend[i].count += 1;
  }

  const productMap = new Map<string, { productId: string; name: string; qty: number; amount: number }>();
  for (const s of refunded) {
    for (const it of s.items) {
      const cur = productMap.get(it.productId) ?? {
        productId: it.productId,
        name: it.name,
        qty: 0,
        amount: 0,
      };
      cur.qty += it.qty;
      cur.amount += it.price * it.qty;
      productMap.set(it.productId, cur);
    }
  }
  const topRefundProducts = Array.from(productMap.values())
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 10);

  // Sanity link ke refund module (approved requests) — informasi saja.
  void refundService;

  return {
    totalRefunds: refunded.length,
    totalAmount,
    refundRate,
    trend,
    topProducts: topRefundProducts,
  };
}

/* ---------------------- Preorder analytics ---------------------- */

export interface PreorderAnalytics {
  active: number;
  outstanding: number;
  revenue: number;
  completionRate: number;
}

export function preorderAnalytics(range: DateRange): PreorderAnalytics {
  const all = preorderService.list();
  const inPeriod = all.filter((p) => {
    const t = new Date(p.createdAt).getTime();
    return t >= range.from.getTime() && t < range.to.getTime();
  });
  const active = all.filter((p) => p.status === "scheduled" || p.status === "ready_to_process")
    .length;
  const outstanding = all
    .filter((p) => p.status === "scheduled" || p.status === "ready_to_process")
    .reduce((a, p) => a + (p.total ?? 0), 0);
  const revenue = inPeriod
    .filter((p) => p.status === "completed")
    .reduce((a, p) => a + (p.total ?? 0), 0);
  const completed = inPeriod.filter((p) => p.status === "completed").length;
  const finished = inPeriod.filter(
    (p) => p.status === "completed" || p.status === "cancelled",
  ).length;
  const completionRate = finished > 0 ? completed / finished : 0;
  return { active, outstanding, revenue, completionRate };
}

/* ---------------------- Forecast (sederhana) ---------------------- */

export interface ForecastSummary {
  days: number;
  revenue: number;
  orders: number;
  profit: number;
  basisDailyRevenue: number;
  basisDailyOrders: number;
  basisDailyProfit: number;
}

/**
 * Forecast sederhana berbasis moving average 30 hari terakhir dari data
 * historis (tanpa AI). Proyeksi dilakukan untuk durasi periode terpilih.
 */
export function forecastSummary(period: Period): ForecastSummary {
  const today = startOfDay(new Date());
  const from = addDays(today, -30);
  const to = today; // exclusive today's incomplete data
  const base = aggregateSalesRange({ from, to });
  const basisDays = 30;
  const basisRev = base.revenue / basisDays;
  const basisOrders = base.orders / basisDays;
  const basisProfit = base.grossProfit / basisDays;
  const days = Math.max(
    1,
    Math.round((period.range.to.getTime() - period.range.from.getTime()) / 86400000),
  );
  return {
    days,
    revenue: basisRev * days,
    orders: basisOrders * days,
    profit: basisProfit * days,
    basisDailyRevenue: basisRev,
    basisDailyOrders: basisOrders,
    basisDailyProfit: basisProfit,
  };
}

/* ---------------------- Compound summary ---------------------- */

export interface SalesAnalyticsData {
  period: Period;
  aggregate: SalesAggregate;
  kpi: ExecutiveKPI;
  daily: DailyPoint[];
  channels: ChannelSlice[];
  marketplaces: MarketplaceRow[];
  top: ProductRow[];
  worst: ProductRow[];
  categories: CategoryRow[];
  hourly: HourlyRow[];
  payments: PaymentRow[];
  customers: CustomerStats;
  refunds: RefundAnalytics;
  preorders: PreorderAnalytics;
  forecast: ForecastSummary;
}

export function computeSalesAnalytics(period: Period): SalesAnalyticsData {
  const daily = dailyTrend(period.range);
  const active = activeSalesInRange(period.range);
  const aggregate = aggregateSalesList(active);
  return {
    period,
    aggregate,
    kpi: computeExecutiveKPI(period),
    daily,
    channels: channelBreakdown(period.range),
    marketplaces: marketplaceRanking(period.range),
    top: topProducts(period.range, 10),
    worst: worstProducts(period.range, 10),
    categories: categoryBreakdown(period.range),
    hourly: hourlySales(period.range),
    payments: paymentBreakdownDetailed(period.range),
    customers: customerStats(period.range),
    refunds: refundAnalytics(period.range),
    preorders: preorderAnalytics(period.range),
    forecast: forecastSummary(period),
  };
}
