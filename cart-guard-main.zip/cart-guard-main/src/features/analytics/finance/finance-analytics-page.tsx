/**
 * Finance Analytics Page — Business Intelligence khusus keuangan.
 * READ-ONLY. Tidak ada CRUD. Semua data via `computeFinanceAnalytics`.
 */
import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Receipt,
  PiggyBank,
  AlertTriangle,
  CalendarDays,
  Download,
  FileSpreadsheet,
  FileText,
  Landmark,
  Percent,
  Gauge,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  ChartCard,
  InsightCard,
  KPICard,
  TableCard,
  type TableColumn,
} from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";
import {
  computeFinanceAnalytics,
  resolvePeriod,
  PERIOD_LABELS,
  type PeriodPreset,
  type FinanceAnalyticsData,
  type ExpenseCategoryRow,
  type ExpensePotRow,
  type TopExpenseRow,
  type DebtRowLite,
  type FundRow,
  type CashChannelRow,
  type MonthlyCompareRow,
} from "./data";
import { buildFinanceInsights } from "./insights";
import {
  exportFinanceAnalyticsCSV,
  exportFinanceAnalyticsXLSX,
} from "./export";
import type { BudgetRow } from "@/services/finance-budget.service";
import type { ProjectionHorizon } from "@/services/finance-projection.service";

const PERIOD_ORDER: PeriodPreset[] = ["today", "7d", "30d", "month", "year", "custom"];

const CHART_COLORS = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

function pctText(n: number | null | undefined, digits = 1): string {
  if (n == null || !Number.isFinite(n)) return "—";
  return `${(n * 100).toFixed(digits)}%`;
}

export function FinanceAnalyticsPage() {
  const [preset, setPreset] = useState<PeriodPreset>("30d");
  const [custom, setCustom] = useState<{ from?: Date; to?: Date }>({});

  const period = useMemo(() => {
    if (preset === "custom" && custom.from && custom.to) {
      return resolvePeriod("custom", { from: custom.from, to: custom.to });
    }
    if (preset === "custom") return resolvePeriod("30d");
    return resolvePeriod(preset);
  }, [preset, custom]);

  const data: FinanceAnalyticsData = useMemo(
    () => computeFinanceAnalytics(period),
    [period],
  );
  const insights = useMemo(() => buildFinanceInsights(data), [data]);

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Analytics Module"
        title="Finance Analytics"
        description="Business Intelligence keuangan. Read-only — data langsung dari Finance Module."
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <Download className="h-3.5 w-3.5" /> Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Quick Export</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => exportFinanceAnalyticsXLSX(data)}>
                <FileSpreadsheet className="mr-2 h-4 w-4" /> Excel (.xlsx)
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => exportFinanceAnalyticsCSV(data)}>
                <FileText className="mr-2 h-4 w-4" /> CSV per sheet
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PERIOD_LABELS[p]}
                </Button>
              ))}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={preset === "custom" ? "default" : "ghost"}
                    className="h-7 gap-1 px-2.5 text-xs"
                  >
                    <CalendarDays className="h-3.5 w-3.5" /> Custom
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-auto p-0">
                  <Calendar
                    mode="range"
                    numberOfMonths={2}
                    selected={{ from: custom.from, to: custom.to }}
                    onSelect={(r) => {
                      setCustom({ from: r?.from, to: r?.to });
                      if (r?.from && r?.to) setPreset("custom");
                    }}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <Badge variant="secondary" className="text-xs">{period.label}</Badge>
          </div>
        }
      />

      {/* 1 — Executive KPI */}
      <AnalyticsSection
        title="Executive KPI"
        description="Snapshot performa keuangan vs periode sebelumnya."
      >
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <KPICard
            label="Revenue"
            value={formatIDR(data.kpi.revenue)}
            deltaPct={data.kpi.growth.revenue}
            trend={data.kpi.trend.revenue}
            icon={Wallet}
          />
          <KPICard
            label="Gross Profit"
            value={formatIDR(data.kpi.grossProfit)}
            deltaPct={data.kpi.growth.grossProfit}
            trend={data.kpi.trend.profit}
            tone={data.kpi.grossProfit >= 0 ? "positive" : "destructive"}
            icon={TrendingUp}
          />
          <KPICard
            label="Net Profit"
            value={formatIDR(data.kpi.netProfit)}
            deltaPct={data.kpi.growth.netProfit}
            tone={data.kpi.netProfit >= 0 ? "positive" : "destructive"}
            icon={data.kpi.netProfit >= 0 ? TrendingUp : TrendingDown}
          />
          <KPICard
            label="Total Expense"
            value={formatIDR(data.kpi.expenses)}
            deltaPct={data.kpi.growth.expenses}
            trend={data.kpi.trend.expense}
            tone={data.kpi.growth.expenses != null && data.kpi.growth.expenses > 0.15 ? "warning" : "default"}
            icon={Receipt}
          />
          <KPICard
            label="Cash Position"
            value={formatIDR(data.kpi.cashPosition)}
            hint={`Opening ${formatIDR(data.cash.opening)}`}
            icon={Landmark}
          />
          <KPICard
            label="Debt Outstanding"
            value={formatIDR(data.kpi.debtOutstanding)}
            hint={`Progress ${(data.debt.progress * 100).toFixed(0)}%`}
            tone={data.kpi.debtOutstanding > 0 ? "warning" : "muted"}
            icon={PiggyBank}
          />
          <KPICard
            label="Budget Usage (Bulan Ini)"
            value={pctText(data.kpi.budgetUsage)}
            hint={`${formatIDR(data.budget.totalActual)} / ${formatIDR(data.budget.totalBudget)}`}
            tone={
              data.kpi.budgetUsage >= 1
                ? "destructive"
                : data.kpi.budgetUsage >= 0.8
                  ? "warning"
                  : "default"
            }
            icon={Gauge}
          />
          <KPICard
            label="Runway"
            value={data.kpi.runwayDays == null ? "Tidak terbatas" : `${data.kpi.runwayDays} hari`}
            tone={
              data.kpi.runwayDays == null
                ? "positive"
                : data.kpi.runwayDays <= 30
                  ? "destructive"
                  : data.kpi.runwayDays <= 60
                    ? "warning"
                    : "default"
            }
            icon={AlertTriangle}
          />
        </div>
      </AnalyticsSection>

      {/* 2 — Profit Trend */}
      <AnalyticsSection
        title="Profit Trend"
        description="Revenue, expense, dan profit harian."
      >
        <ChartCard title="" subtitle={period.label}>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data.daily} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} tickMargin={8} />
                <YAxis
                  width={80}
                  tickLine={false}
                  axisLine={false}
                  fontSize={11}
                  tickFormatter={(v: number) => formatIDR(v)}
                />
                <RTooltip
                  formatter={(v: number, name) => [formatIDR(v), name]}
                  labelClassName="text-xs"
                  contentStyle={{ borderRadius: 8, fontSize: 12 }}
                />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  name="Revenue"
                  stroke="var(--chart-1)"
                  strokeWidth={2}
                  fill="url(#revGrad)"
                />
                <Bar dataKey="expense" name="Expense" fill="var(--chart-4)" radius={[3, 3, 0, 0]} />
                <Line
                  type="monotone"
                  dataKey="profit"
                  name="Profit"
                  stroke="var(--chart-2)"
                  strokeWidth={2}
                  dot={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </AnalyticsSection>

      {/* 3 — Cashflow */}
      <AnalyticsSection
        title="Cashflow"
        description="Arus kas masuk, keluar, net, dan saldo berjalan."
      >
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <ChartCard title="Cash In vs Cash Out" subtitle="Harian">
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.daily}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
                  <YAxis
                    width={80}
                    tickLine={false}
                    axisLine={false}
                    fontSize={11}
                    tickFormatter={(v: number) => formatIDR(v)}
                  />
                  <RTooltip
                    formatter={(v: number, n) => [formatIDR(v), n]}
                    contentStyle={{ borderRadius: 8, fontSize: 12 }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="cashIn" name="Cash In" fill="var(--chart-2)" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="cashOut" name="Cash Out" fill="var(--chart-4)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          <ChartCard title="Running Balance" subtitle="Saldo kas akumulatif">
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.daily}>
                  <defs>
                    <linearGradient id="runGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
                  <YAxis
                    width={80}
                    tickLine={false}
                    axisLine={false}
                    fontSize={11}
                    tickFormatter={(v: number) => formatIDR(v)}
                  />
                  <RTooltip
                    formatter={(v: number) => [formatIDR(v), "Running"]}
                    contentStyle={{ borderRadius: 8, fontSize: 12 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="running"
                    stroke="var(--chart-3)"
                    strokeWidth={2}
                    fill="url(#runGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <ChartCard title="Cash Position per Channel" subtitle={`Total ${formatIDR(data.cash.total)}`}>
            <CashChannelChart channels={data.cash.channels} />
          </ChartCard>
          <TableCard
            title="Detail Channel Kas"
            columns={cashChannelColumns}
            rows={data.cash.channels}
            className="lg:col-span-2"
          />
        </div>
      </AnalyticsSection>

      {/* 4 — Expense Analytics */}
      <AnalyticsSection
        title="Expense Analytics"
        description="Breakdown pengeluaran per kategori & fund pot."
      >
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <ChartCard title="Per Kategori" subtitle={`Total ${formatIDR(data.expense.total)}`}>
            <BreakdownDonut
              rows={data.expense.byCategory.map((r) => ({
                key: r.category,
                label: r.label,
                amount: r.amount,
              }))}
            />
          </ChartCard>
          <ChartCard title="Per Fund Pot" subtitle="Distribusi asal dana">
            <BreakdownDonut
              rows={data.expense.byPot.map((r) => ({
                key: r.pot,
                label: r.label,
                amount: r.amount,
              }))}
            />
          </ChartCard>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <TableCard
            title="Ranking Kategori"
            columns={expenseCategoryColumns}
            rows={data.expense.byCategory}
          />
          <TableCard
            title="Top 10 Expense"
            columns={topExpenseColumns}
            rows={data.expense.top}
          />
        </div>
      </AnalyticsSection>

      {/* 5 — Budget Analytics */}
      <AnalyticsSection
        title="Budget Analytics"
        description={`Realisasi bulan berjalan — ${formatIDR(data.budget.totalActual)} dari ${formatIDR(data.budget.totalBudget)}`}
      >
        <ChartCard title="Budget vs Realisasi" subtitle="Per kategori bulan ini">
          {data.budget.rows.length === 0 ? (
            <div className="rounded-md border border-dashed py-8 text-center text-sm text-muted-foreground">
              Belum ada budget yang diset. Set di Finance › Budget.
            </div>
          ) : (
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.budget.rows}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
                  <YAxis
                    width={80}
                    tickLine={false}
                    axisLine={false}
                    fontSize={11}
                    tickFormatter={(v: number) => formatIDR(v)}
                  />
                  <RTooltip
                    formatter={(v: number, n) => [formatIDR(v), n]}
                    contentStyle={{ borderRadius: 8, fontSize: 12 }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="budget" name="Budget" fill="var(--chart-3)" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="actual" name="Realisasi" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>

        <TableCard
          title="Detail Budget"
          columns={budgetColumns}
          rows={data.budget.rows}
          emptyMessage="Belum ada budget."
        />
      </AnalyticsSection>

      {/* 6 — Debt Analytics */}
      <AnalyticsSection
        title="Debt Analytics"
        description="Progres pembayaran hutang & tren pelunasan."
      >
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <KPICard label="Total Principal" value={formatIDR(data.debt.outstanding)} icon={PiggyBank} />
          <KPICard
            label="Terbayar"
            value={formatIDR(data.debt.paid)}
            hint={pctText(data.debt.progress)}
            tone="positive"
          />
          <KPICard
            label="Sisa"
            value={formatIDR(data.debt.remaining)}
            tone={data.debt.remaining > 0 ? "warning" : "muted"}
          />
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <ChartCard title="Tren Pembayaran Hutang" subtitle={period.label}>
            <div className="h-[240px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.debt.paymentTrend}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} />
                  <YAxis
                    width={80}
                    tickLine={false}
                    axisLine={false}
                    fontSize={11}
                    tickFormatter={(v: number) => formatIDR(v)}
                  />
                  <RTooltip formatter={(v: number) => [formatIDR(v), "Pembayaran"]} />
                  <Bar dataKey="amount" fill="var(--chart-2)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          <TableCard
            title="Jatuh Tempo ≤ 30 Hari"
            rows={data.debt.dueSoon}
            columns={debtDueColumns}
            emptyMessage="Tidak ada hutang jatuh tempo dalam 30 hari."
          />
        </div>

        <TableCard title="Daftar Hutang" rows={data.debt.rows} columns={debtColumns} />
      </AnalyticsSection>

      {/* 7 — Fund Analytics */}
      <AnalyticsSection
        title="Fund Analytics"
        description="Alokasi & penggunaan 4 pot dana."
      >
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {data.fund.map((f) => (
            <KPICard
              key={f.pot}
              label={f.label}
              value={formatIDR(f.balance)}
              hint={`Alokasi ${pctText(f.allocationPct, 0)} • Withdraw periode ${formatIDR(f.withdrawnPeriod)}`}
              tone={f.balance < 0 ? "destructive" : "default"}
            />
          ))}
        </div>
        <TableCard title="Detail Fund Pot" rows={data.fund} columns={fundColumns} />
      </AnalyticsSection>

      {/* 8 — Financial Health */}
      <AnalyticsSection
        title="Financial Health"
        description="Skor kesehatan keuangan berbasis rule."
      >
        <ChartCard
          title={
            data.health.status === "waiting-data"
              ? "Menunggu data"
              : `Score ${data.health.score ?? 0} — ${"★".repeat(data.health.stars) + "☆".repeat(5 - data.health.stars)}`
          }
          subtitle={data.health.dataQuality.label}
        >
          <p className="mb-3 text-sm text-muted-foreground">{data.health.insight}</p>
          {data.health.status === "ready" ? (
            <>
              <div className="mb-3">
                <Progress value={data.health.score ?? 0} />
              </div>
              <ul className="space-y-1.5 text-sm">
                {data.health.reasons.map((r, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span
                      className={
                        r.tone === "positive"
                          ? "mt-1.5 h-2 w-2 shrink-0 rounded-full bg-emerald-500"
                          : r.tone === "negative"
                            ? "mt-1.5 h-2 w-2 shrink-0 rounded-full bg-red-500"
                            : "mt-1.5 h-2 w-2 shrink-0 rounded-full bg-muted-foreground/60"
                      }
                    />
                    <span>{r.label}</span>
                  </li>
                ))}
              </ul>
            </>
          ) : null}
        </ChartCard>
      </AnalyticsSection>

      {/* 9 — Financial Ratios */}
      <AnalyticsSection title="Financial Ratios" description="Rasio-rasio kunci periode berjalan.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <KPICard
            label="Gross Margin"
            value={pctText(data.ratios.grossMargin)}
            tone={data.ratios.grossMargin >= 0.25 ? "positive" : "warning"}
            icon={Percent}
          />
          <KPICard
            label="Net Margin"
            value={pctText(data.ratios.netMargin)}
            tone={data.ratios.netMargin >= 0.1 ? "positive" : data.ratios.netMargin < 0 ? "destructive" : "warning"}
            icon={Percent}
          />
          <KPICard
            label="Expense Ratio"
            value={pctText(data.ratios.expenseRatio)}
            tone={data.ratios.expenseRatio <= 0.4 ? "positive" : "warning"}
            icon={Gauge}
          />
          <KPICard
            label="Operating Ratio"
            value={pctText(data.ratios.operatingRatio)}
            tone={data.ratios.operatingRatio <= 0.8 ? "positive" : "warning"}
            icon={Gauge}
          />
          <KPICard
            label="Debt Ratio"
            value={pctText(data.ratios.debtRatio)}
            tone={data.ratios.debtRatio <= 0.5 ? "positive" : "warning"}
            icon={ShieldCheck}
          />
        </div>
      </AnalyticsSection>

      {/* 10 — Projections */}
      <AnalyticsSection
        title="Cash Projection"
        description="Proyeksi 30/60/90 hari berbasis moving average (tanpa AI)."
      >
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {data.projection.horizons.map((h) => (
            <ProjectionCard key={h.horizonDays} h={h} />
          ))}
        </div>
        <ChartCard
          title="Rata-rata Harian (30 hari)"
          subtitle={`Berbasis ${data.projection.avgs.days} hari aktif`}
        >
          <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            <MiniStat label="Avg Revenue/hari" value={formatIDR(data.projection.avgs.avgRevenue)} />
            <MiniStat label="Avg Expense/hari" value={formatIDR(data.projection.avgs.avgExpense)} />
            <MiniStat label="Avg Outflow/hari" value={formatIDR(data.projection.avgs.avgOutflow)} />
            <MiniStat
              label="Avg Net Cashflow/hari"
              value={formatIDR(data.projection.avgs.avgNetCashflow)}
              tone={data.projection.avgs.avgNetCashflow >= 0 ? "positive" : "destructive"}
            />
          </div>
        </ChartCard>
      </AnalyticsSection>

      {/* 11 — Monthly Comparison */}
      <AnalyticsSection
        title="Monthly Comparison"
        description="Bulan ini vs bulan lalu."
      >
        <TableCard title="Perbandingan Bulanan" columns={monthlyColumns} rows={data.monthlyCompare} />
      </AnalyticsSection>

      {/* 12 — Alerts */}
      <AnalyticsSection title="Alerts" description="Sinyal dari rule finance-projection.">
        {data.alerts.length === 0 ? (
          <ChartCard title="Tidak ada alert" subtitle="Semua indikator dalam batas aman.">
            <div className="py-6 text-center text-sm text-muted-foreground">
              Kondisi keuangan stabil.
            </div>
          </ChartCard>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {data.alerts.map((a) => (
              <ChartCard key={a.id} title={a.title} subtitle={a.detail}>
                <Badge
                  className="text-xs"
                  variant={
                    a.level === "red" ? "destructive" : a.level === "yellow" ? "secondary" : "default"
                  }
                >
                  {a.level.toUpperCase()}
                </Badge>
              </ChartCard>
            ))}
          </div>
        )}
      </AnalyticsSection>

      {/* 13 — Insights */}
      <AnalyticsSection title="Insight" description="Rule-based highlight otomatis.">
        <InsightCard items={insights} />
      </AnalyticsSection>
    </AnalyticsLayout>
  );
}

/* ---------------- Sub components ---------------- */

function MiniStat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "positive" | "destructive";
}) {
  const cls =
    tone === "positive"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "destructive"
        ? "text-destructive"
        : "text-foreground";
  return (
    <div className="rounded-lg border p-3">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className={`mt-1 font-display text-lg font-semibold tabular-nums ${cls}`}>{value}</div>
    </div>
  );
}

function ProjectionCard({ h }: { h: ProjectionHorizon }) {
  return (
    <ChartCard title={`Proyeksi ${h.horizonDays} hari`} subtitle="Berbasis average 30 hari">
      <dl className="grid grid-cols-2 gap-y-1.5 text-sm">
        <dt className="text-muted-foreground">Revenue</dt>
        <dd className="text-right tabular-nums">{formatIDR(h.projectedRevenue)}</dd>
        <dt className="text-muted-foreground">Outflow</dt>
        <dd className="text-right tabular-nums">{formatIDR(h.projectedOutflow)}</dd>
        <dt className="text-muted-foreground">Gross Profit</dt>
        <dd className="text-right tabular-nums">{formatIDR(h.projectedGrossProfit)}</dd>
        <dt className="text-muted-foreground">Cash Balance</dt>
        <dd
          className={`text-right tabular-nums ${h.projectedCashBalance < 0 ? "text-destructive" : ""}`}
        >
          {formatIDR(h.projectedCashBalance)}
        </dd>
        <dt className="text-muted-foreground">Runway</dt>
        <dd className="text-right tabular-nums">
          {h.runwayDays == null ? "Tidak terbatas" : `${h.runwayDays} hari`}
        </dd>
      </dl>
    </ChartCard>
  );
}

function BreakdownDonut({
  rows,
}: {
  rows: { key: string; label: string; amount: number }[];
}) {
  if (rows.length === 0) {
    return (
      <div className="rounded-md border border-dashed py-8 text-center text-sm text-muted-foreground">
        Belum ada data.
      </div>
    );
  }
  return (
    <div className="h-[240px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <RTooltip formatter={(v: number, n) => [formatIDR(v), n]} />
          <Pie
            data={rows}
            dataKey="amount"
            nameKey="label"
            innerRadius={55}
            outerRadius={90}
            paddingAngle={2}
          >
            {rows.map((_, i) => (
              <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
            ))}
          </Pie>
          <Legend wrapperStyle={{ fontSize: 11 }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

function CashChannelChart({ channels }: { channels: CashChannelRow[] }) {
  if (channels.length === 0) return null;
  return (
    <div className="h-[240px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={channels} layout="vertical" margin={{ left: 20, right: 12 }}>
          <CartesianGrid horizontal={false} strokeDasharray="3 3" />
          <XAxis
            type="number"
            tickLine={false}
            axisLine={false}
            fontSize={11}
            tickFormatter={(v: number) => formatIDR(v)}
          />
          <YAxis dataKey="label" type="category" tickLine={false} axisLine={false} fontSize={11} width={70} />
          <RTooltip formatter={(v: number) => [formatIDR(v), "Saldo"]} />
          <Bar dataKey="balance" radius={[0, 4, 4, 0]}>
            {channels.map((_, i) => (
              <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ---------------- Columns ---------------- */

const cashChannelColumns: TableColumn<CashChannelRow>[] = [
  { key: "label", header: "Channel", render: (r) => r.label },
  { key: "balance", header: "Saldo", align: "right", render: (r) => formatIDR(r.balance) },
  { key: "share", header: "Share", align: "right", render: (r) => pctText(r.share) },
];

const expenseCategoryColumns: TableColumn<ExpenseCategoryRow>[] = [
  { key: "label", header: "Kategori", render: (r) => r.label },
  { key: "amount", header: "Nominal", align: "right", render: (r) => formatIDR(r.amount) },
  { key: "share", header: "Share", align: "right", render: (r) => pctText(r.share) },
];

const topExpenseColumns: TableColumn<TopExpenseRow>[] = [
  { key: "at", header: "Tanggal", render: (r) => new Date(r.at).toLocaleDateString("id-ID") },
  { key: "desc", header: "Deskripsi", render: (r) => r.description },
  { key: "cat", header: "Kategori", render: (r) => r.category },
  { key: "amount", header: "Nominal", align: "right", render: (r) => formatIDR(r.amount) },
];

const budgetColumns: TableColumn<BudgetRow>[] = [
  { key: "label", header: "Kategori", render: (r) => r.label },
  { key: "budget", header: "Budget", align: "right", render: (r) => formatIDR(r.budget) },
  { key: "actual", header: "Realisasi", align: "right", render: (r) => formatIDR(r.actual) },
  {
    key: "remaining",
    header: "Sisa",
    align: "right",
    render: (r) => (
      <span className={r.remaining < 0 ? "text-destructive" : ""}>{formatIDR(r.remaining)}</span>
    ),
  },
  {
    key: "percent",
    header: "%",
    align: "right",
    render: (r) => (
      <Badge
        variant={
          r.status === "over"
            ? "destructive"
            : r.status === "warning"
              ? "secondary"
              : "outline"
        }
      >
        {r.percent.toFixed(0)}%
      </Badge>
    ),
  },
];

const debtColumns: TableColumn<DebtRowLite>[] = [
  { key: "name", header: "Nama", render: (r) => r.name },
  { key: "principal", header: "Principal", align: "right", render: (r) => formatIDR(r.principal) },
  { key: "paid", header: "Terbayar", align: "right", render: (r) => formatIDR(r.paid) },
  { key: "remaining", header: "Sisa", align: "right", render: (r) => formatIDR(r.remaining) },
  {
    key: "progress",
    header: "Progress",
    align: "right",
    render: (r) => `${(r.progress * 100).toFixed(0)}%`,
  },
  {
    key: "status",
    header: "Status",
    render: (r) => (
      <Badge variant={r.active ? "secondary" : "outline"}>
        {r.active ? "Aktif" : "Lunas"}
      </Badge>
    ),
  },
];

const debtDueColumns: TableColumn<DebtRowLite>[] = [
  { key: "name", header: "Nama", render: (r) => r.name },
  { key: "remaining", header: "Sisa", align: "right", render: (r) => formatIDR(r.remaining) },
  {
    key: "days",
    header: "Jatuh Tempo",
    align: "right",
    render: (r) => (
      <Badge
        variant={
          r.daysToDue != null && r.daysToDue <= 7
            ? "destructive"
            : r.daysToDue != null && r.daysToDue <= 14
              ? "secondary"
              : "outline"
        }
      >
        {r.daysToDue == null ? "—" : `${r.daysToDue} hari`}
      </Badge>
    ),
  },
];

const fundColumns: TableColumn<FundRow>[] = [
  { key: "label", header: "Pot", render: (r) => r.label },
  { key: "alloc", header: "Alokasi", align: "right", render: (r) => pctText(r.allocationPct, 0) },
  { key: "balance", header: "Saldo", align: "right", render: (r) => formatIDR(r.balance) },
  {
    key: "wp",
    header: "Withdraw Periode",
    align: "right",
    render: (r) => formatIDR(r.withdrawnPeriod),
  },
  {
    key: "wt",
    header: "Withdraw Total",
    align: "right",
    render: (r) => formatIDR(r.withdrawnTotal),
  },
  {
    key: "share",
    header: "Share Outflow",
    align: "right",
    render: (r) => pctText(r.shareOfOutflow),
  },
];

const monthlyColumns: TableColumn<MonthlyCompareRow>[] = [
  { key: "metric", header: "Metric", render: (r) => r.metric },
  { key: "current", header: "Bulan Ini", align: "right", render: (r) => formatIDR(r.current) },
  { key: "previous", header: "Bulan Lalu", align: "right", render: (r) => formatIDR(r.previous) },
  {
    key: "delta",
    header: "Delta",
    align: "right",
    render: (r) =>
      r.delta == null ? (
        "—"
      ) : (
        <span
          className={
            r.delta > 0
              ? "text-emerald-600 dark:text-emerald-400"
              : r.delta < 0
                ? "text-destructive"
                : "text-muted-foreground"
          }
        >
          {(r.delta * 100).toFixed(1)}%
        </span>
      ),
  },
];
