/**
 * Finance Analytics data layer — read-only.
 *
 * SEMUA agregasi Finance Analytics WAJIB memakai service canonical yang
 * sudah ada:
 *   - financeAnalytics (cashPosition, ledger, profitTrend, healthScore, ...)
 *   - financeExpenses / financeDebts / financeFundWithdraws / financeSettings
 *   - financeBudgets + budgetRows / budgetActuals
 *   - finance-aggregation (aggregateSalesRange, sumExpensesRange, ...)
 *   - finance-projection (dailyAverages, projectHorizon, financialKpis,
 *     financeAlerts, currentCashBalance)
 *
 * TIDAK menulis storage. TIDAK menduplikasi kalkulasi revenue / profit.
 * TIDAK mengubah Finance Module (Feature Freeze).
 */

import {
  aggregateSalesRange,
  sumExpensesRange,
  sumWithdrawRange,
  sumDebtPaymentsRange,
  type DateRange,
} from "@/services/finance-aggregation";
import {
  financeAnalytics,
  financeExpenses,
  financeDebts,
  financeFundWithdraws,
  financeSettings,
} from "@/services/finance.service";
import {
  budgetRows,
  BUDGET_CATEGORY_LABEL,
  type BudgetRow,
} from "@/services/finance-budget.service";
import {
  dailyAverages,
  projectHorizon,
  currentCashBalance,
  financialKpis,
  financeAlerts,
  type FinanceAlert,
  type ProjectionHorizon,
  type FinancialKpis,
} from "@/services/finance-projection.service";
import {
  DEFAULT_HISTORY_DAYS,
  PROJECTION_HORIZONS,
  type ProjectionHorizonDays,
} from "@/services/finance.constants";
import {
  EXPENSE_CATEGORY_LABEL,
  FUND_POT_LABEL,
  FINANCE_PAYMENT_LABEL,
  type ExpenseCategory,
  type FinancePayment,
  type FundPot,
} from "@/services/types";

/* ---------------------- Period presets ---------------------- */

export type PeriodPreset =
  | "today"
  | "7d"
  | "30d"
  | "month"
  | "year"
  | "custom";

export const PERIOD_LABELS: Record<PeriodPreset, string> = {
  today: "Hari Ini",
  "7d": "7 Hari",
  "30d": "30 Hari",
  month: "Bulan Ini",
  year: "Tahun Ini",
  custom: "Custom",
};

export interface Period {
  preset: PeriodPreset;
  range: DateRange;
  previous: DateRange;
  label: string;
  days: number;
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function diffDays(r: DateRange): number {
  return Math.max(1, Math.round((r.to.getTime() - r.from.getTime()) / 86400000));
}

export function resolvePeriod(
  preset: PeriodPreset,
  custom?: { from: Date; to: Date },
  ref = new Date(),
): Period {
  const today = startOfDay(ref);
  let range: DateRange;
  let label: string;
  switch (preset) {
    case "today":
      range = { from: today, to: addDays(today, 1) };
      label = "Hari Ini";
      break;
    case "7d":
      range = { from: addDays(today, -6), to: addDays(today, 1) };
      label = "7 Hari Terakhir";
      break;
    case "30d":
      range = { from: addDays(today, -29), to: addDays(today, 1) };
      label = "30 Hari Terakhir";
      break;
    case "month": {
      const from = new Date(today.getFullYear(), today.getMonth(), 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      range = { from, to };
      label = from.toLocaleDateString("id-ID", { month: "long", year: "numeric" });
      break;
    }
    case "year": {
      const from = new Date(today.getFullYear(), 0, 1);
      const to = new Date(today.getFullYear() + 1, 0, 1);
      range = { from, to };
      label = `Tahun ${from.getFullYear()}`;
      break;
    }
    case "custom": {
      const from = custom?.from ?? today;
      const to = custom?.to ? addDays(startOfDay(custom.to), 1) : addDays(today, 1);
      range = { from: startOfDay(from), to };
      label = `${range.from.toLocaleDateString("id-ID")} – ${addDays(range.to, -1).toLocaleDateString("id-ID")}`;
      break;
    }
  }
  const days = diffDays(range);
  const previous: DateRange = {
    from: addDays(range.from, -days),
    to: range.from,
  };
  return { preset, range, previous, label, days };
}

/* ---------------------- Types ---------------------- */

export interface KPIBlock {
  revenue: number;
  grossProfit: number;
  netProfit: number;
  expenses: number;
  cashPosition: number;
  debtOutstanding: number;
  budgetUsage: number; // 0..1 (actual / total budget of period-month)
  runwayDays: number | null;
  // deltas vs previous period
  growth: {
    revenue: number | null;
    grossProfit: number | null;
    netProfit: number | null;
    expenses: number | null;
  };
  trend: {
    revenue: number[];
    expense: number[];
    profit: number[];
    netCash: number[];
  };
}

export interface DailyRow {
  date: string;
  label: string;
  revenue: number;
  expense: number;
  profit: number;
  cashIn: number;
  cashOut: number;
  netCash: number;
  running: number;
}

export interface ExpenseCategoryRow {
  category: ExpenseCategory;
  label: string;
  amount: number;
  share: number;
}

export interface ExpensePotRow {
  pot: FundPot;
  label: string;
  amount: number;
  share: number;
}

export interface TopExpenseRow {
  id: string;
  at: string;
  description: string;
  amount: number;
  category: ExpenseCategory;
  pot: FundPot;
}

export interface DebtRowLite {
  id: string;
  name: string;
  principal: number;
  paid: number;
  remaining: number;
  progress: number;
  active: boolean;
  targetDate?: string;
  daysToDue: number | null;
}

export interface DebtPaymentTrendRow {
  date: string;
  label: string;
  amount: number;
}

export interface FundRow {
  pot: FundPot;
  label: string;
  balance: number;
  allocationPct: number;
  withdrawnTotal: number;
  withdrawnPeriod: number;
  shareOfOutflow: number;
}

export interface CashChannelRow {
  channel: FinancePayment;
  label: string;
  balance: number;
  share: number;
}

export interface RatioBlock {
  grossMargin: number;
  netMargin: number;
  expenseRatio: number;
  operatingRatio: number;
  debtRatio: number;
}

export interface MonthlyCompareRow {
  metric: string;
  current: number;
  previous: number;
  delta: number | null;
}

export interface ProjectionBlock {
  horizons: ProjectionHorizon[];
  avgs: ReturnType<typeof dailyAverages>;
  currentCash: number;
}

export interface FinanceAnalyticsData {
  period: Period;
  kpi: KPIBlock;
  daily: DailyRow[];
  expense: {
    byCategory: ExpenseCategoryRow[];
    byPot: ExpensePotRow[];
    top: TopExpenseRow[];
    total: number;
  };
  budget: {
    rows: BudgetRow[];
    totalBudget: number;
    totalActual: number;
    over: BudgetRow[];
    under: BudgetRow[];
  };
  debt: {
    outstanding: number;
    paid: number;
    remaining: number;
    progress: number;
    rows: DebtRowLite[];
    dueSoon: DebtRowLite[];
    paymentTrend: DebtPaymentTrendRow[];
  };
  fund: FundRow[];
  cash: {
    total: number;
    opening: number;
    channels: CashChannelRow[];
  };
  health: ReturnType<typeof financeAnalytics.healthScore>;
  ratios: RatioBlock;
  kpis: FinancialKpis;
  projection: ProjectionBlock;
  monthlyCompare: MonthlyCompareRow[];
  alerts: FinanceAlert[];
}

/* ---------------------- Helpers ---------------------- */

function bucketByDay(range: DateRange): { date: string; label: string; from: Date; to: Date }[] {
  const out: { date: string; label: string; from: Date; to: Date }[] = [];
  const cursor = new Date(range.from);
  cursor.setHours(0, 0, 0, 0);
  while (cursor < range.to) {
    const next = new Date(cursor);
    next.setDate(next.getDate() + 1);
    out.push({
      date: cursor.toISOString().slice(0, 10),
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      from: new Date(cursor),
      to: next,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  return out;
}

function growth(cur: number, prev: number): number | null {
  if (prev === 0) return cur === 0 ? 0 : null;
  return (cur - prev) / Math.abs(prev);
}

function monthOf(iso: string): string {
  return iso.slice(0, 7);
}

/* ---------------------- Main compute ---------------------- */

export function computeFinanceAnalytics(period: Period): FinanceAnalyticsData {
  const range = period.range;
  const prev = period.previous;

  // --- Aggregates via canonical helpers ---
  const salesAgg = aggregateSalesRange(range);
  const prevSalesAgg = aggregateSalesRange(prev);
  const expenses = sumExpensesRange(range);
  const prevExpenses = sumExpensesRange(prev);
  const withdraws = sumWithdrawRange(range);
  const debtPaymentsSum = sumDebtPaymentsRange(range);

  const cashInflow = salesAgg.revenue;
  const cashOutflow = expenses + withdraws + debtPaymentsSum;

  // --- Daily buckets (revenue/expense/profit/cash) ---
  const buckets = bucketByDay(range);
  const running0 = currentCashBalance() - (cashInflow - cashOutflow);
  let running = running0;
  const daily: DailyRow[] = buckets.map((b) => {
    const r: DateRange = { from: b.from, to: b.to };
    const s = aggregateSalesRange(r);
    const e = sumExpensesRange(r);
    const w = sumWithdrawRange(r);
    const dp = sumDebtPaymentsRange(r);
    const cashIn = s.revenue;
    const cashOut = e + w + dp;
    const netCash = cashIn - cashOut;
    running += netCash;
    return {
      date: b.date,
      label: b.label,
      revenue: s.revenue,
      expense: e,
      profit: s.grossProfit - e,
      cashIn,
      cashOut,
      netCash,
      running,
    };
  });

  const kpiTrend = {
    revenue: daily.map((d) => d.revenue),
    expense: daily.map((d) => d.expense),
    profit: daily.map((d) => d.profit),
    netCash: daily.map((d) => d.netCash),
  };

  // --- Expense breakdown ---
  const expenseListPeriod = financeExpenses
    .list()
    .filter((e) => {
      const d = new Date(e.at);
      return d >= range.from && d < range.to;
    });
  const totalExp = expenseListPeriod.reduce((a, e) => a + e.amount, 0);
  const byCatMap = new Map<ExpenseCategory, number>();
  const byPotMap = new Map<FundPot, number>();
  for (const e of expenseListPeriod) {
    byCatMap.set(e.category, (byCatMap.get(e.category) ?? 0) + e.amount);
    byPotMap.set(e.pot, (byPotMap.get(e.pot) ?? 0) + e.amount);
  }
  const byCategory: ExpenseCategoryRow[] = Array.from(byCatMap.entries())
    .map(([category, amount]) => ({
      category,
      label: EXPENSE_CATEGORY_LABEL[category],
      amount,
      share: totalExp > 0 ? amount / totalExp : 0,
    }))
    .sort((a, b) => b.amount - a.amount);
  const byPot: ExpensePotRow[] = Array.from(byPotMap.entries())
    .map(([pot, amount]) => ({
      pot,
      label: FUND_POT_LABEL[pot],
      amount,
      share: totalExp > 0 ? amount / totalExp : 0,
    }))
    .sort((a, b) => b.amount - a.amount);
  const topExpense: TopExpenseRow[] = expenseListPeriod
    .slice()
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 10)
    .map((e) => ({
      id: e.id,
      at: e.at,
      description: e.description,
      amount: e.amount,
      category: e.category,
      pot: e.pot,
    }));

  // --- Budget (bulan berjalan — canonical) ---
  const bRows = budgetRows();
  const totalBudget = bRows.reduce((a, r) => a + r.budget, 0);
  const totalActual = bRows.reduce((a, r) => a + r.actual, 0);
  const overRows = bRows.filter((r) => r.status === "over");
  const underRows = bRows.filter((r) => r.status === "ok");
  const budgetUsage = totalBudget > 0 ? totalActual / totalBudget : 0;

  // --- Debt ---
  const dTotals = financeDebts.totals();
  const debts = financeDebts.list();
  const allPayments = financeDebts.payments();
  const paidById = new Map<string, number>();
  for (const p of allPayments) {
    paidById.set(p.debtId, (paidById.get(p.debtId) ?? 0) + p.amount);
  }
  const now = Date.now();
  const debtRows: DebtRowLite[] = debts.map((d) => {
    const paid = paidById.get(d.id) ?? 0;
    const remaining = Math.max(0, d.principal - paid);
    const progress = d.principal > 0 ? Math.min(1, paid / d.principal) : 0;
    const daysToDue = d.targetDate
      ? Math.ceil((new Date(d.targetDate).getTime() - now) / 86400000)
      : null;
    return {
      id: d.id,
      name: d.name,
      principal: d.principal,
      paid,
      remaining,
      progress,
      active: d.active,
      targetDate: d.targetDate,
      daysToDue,
    };
  });
  const dueSoon = debtRows
    .filter((d) => d.active && d.daysToDue !== null && d.daysToDue <= 30)
    .sort((a, b) => (a.daysToDue ?? 0) - (b.daysToDue ?? 0));
  const paymentTrendMap = new Map<string, number>();
  for (const b of buckets) paymentTrendMap.set(b.date, 0);
  for (const p of allPayments) {
    const d = new Date(p.at);
    if (d < range.from || d >= range.to) continue;
    const key = p.at.slice(0, 10);
    paymentTrendMap.set(key, (paymentTrendMap.get(key) ?? 0) + p.amount);
  }
  const paymentTrend: DebtPaymentTrendRow[] = buckets.map((b) => ({
    date: b.date,
    label: b.label,
    amount: paymentTrendMap.get(b.date) ?? 0,
  }));

  // --- Funds ---
  const settings = financeSettings.get();
  const pots: FundPot[] = ["owner", "development", "operational", "debt"];
  const withdrawsAll = financeFundWithdraws.list();
  const fund: FundRow[] = pots.map((pot) => {
    const bal = financeAnalytics.potBalance(pot);
    const withdrawnTotal = withdrawsAll
      .filter((w) => w.pot === pot)
      .reduce((a, w) => a + w.amount, 0);
    const withdrawnPeriod = withdrawsAll
      .filter((w) => {
        if (w.pot !== pot) return false;
        const d = new Date(w.at);
        return d >= range.from && d < range.to;
      })
      .reduce((a, w) => a + w.amount, 0);
    const potExpense =
      (byPotMap.get(pot) ?? 0) + withdrawnPeriod + (pot === "debt" ? debtPaymentsSum : 0);
    return {
      pot,
      label: FUND_POT_LABEL[pot],
      balance: bal.balance,
      allocationPct: settings.allocation[pot] / 100,
      withdrawnTotal,
      withdrawnPeriod,
      shareOfOutflow: cashOutflow > 0 ? potExpense / cashOutflow : 0,
    };
  });

  // --- Cash position ---
  const positions = financeAnalytics.cashPosition();
  const openingTotal =
    settings.openingBalance.cash +
    settings.openingBalance.qris +
    settings.openingBalance.bank +
    settings.openingBalance.dompet;
  const cashTotal = positions.reduce((a, p) => a + p.balance, 0);
  const channels: CashChannelRow[] = positions.map((p) => ({
    channel: p.channel,
    label: FINANCE_PAYMENT_LABEL[p.channel],
    balance: p.balance,
    share: cashTotal !== 0 ? p.balance / cashTotal : 0,
  }));

  // --- Ratios ---
  const revenue = salesAgg.revenue;
  const grossProfit = salesAgg.grossProfit;
  const netProfit = grossProfit - expenses;
  const ratios: RatioBlock = {
    grossMargin: revenue > 0 ? grossProfit / revenue : 0,
    netMargin: revenue > 0 ? netProfit / revenue : 0,
    expenseRatio: revenue > 0 ? expenses / revenue : 0,
    operatingRatio: revenue > 0 ? (salesAgg.hpp + expenses) / revenue : 0,
    debtRatio: revenue > 0 ? dTotals.remaining / revenue : 0,
  };

  // --- Projection & KPI (canonical) ---
  const avgs = dailyAverages(DEFAULT_HISTORY_DAYS);
  const horizons: ProjectionHorizon[] = (PROJECTION_HORIZONS as readonly ProjectionHorizonDays[])
    .map((d) => projectHorizon(d, avgs));
  const kpis = financialKpis();

  // --- Monthly comparison (bulan ini vs bulan lalu) ---
  const now2 = new Date();
  const curMonth: DateRange = {
    from: new Date(now2.getFullYear(), now2.getMonth(), 1),
    to: new Date(now2.getFullYear(), now2.getMonth() + 1, 1),
  };
  const prevMonth: DateRange = {
    from: new Date(now2.getFullYear(), now2.getMonth() - 1, 1),
    to: new Date(now2.getFullYear(), now2.getMonth(), 1),
  };
  const cM = aggregateSalesRange(curMonth);
  const pM = aggregateSalesRange(prevMonth);
  const cMExp = sumExpensesRange(curMonth);
  const pMExp = sumExpensesRange(prevMonth);
  const cMCashIn = cM.revenue;
  const pMCashIn = pM.revenue;
  const cMCashOut = cMExp + sumWithdrawRange(curMonth) + sumDebtPaymentsRange(curMonth);
  const pMCashOut = pMExp + sumWithdrawRange(prevMonth) + sumDebtPaymentsRange(prevMonth);
  // budget total realisasi ~ totalActual month = sum expense pots this month
  const cmBudget = cMExp;
  const pmBudget = pMExp;
  const monthlyCompare: MonthlyCompareRow[] = [
    { metric: "Revenue", current: cM.revenue, previous: pM.revenue, delta: growth(cM.revenue, pM.revenue) },
    { metric: "Expense", current: cMExp, previous: pMExp, delta: growth(cMExp, pMExp) },
    {
      metric: "Profit",
      current: cM.grossProfit - cMExp,
      previous: pM.grossProfit - pMExp,
      delta: growth(cM.grossProfit - cMExp, pM.grossProfit - pMExp),
    },
    { metric: "Budget Realisasi", current: cmBudget, previous: pmBudget, delta: growth(cmBudget, pmBudget) },
    {
      metric: "Net Cashflow",
      current: cMCashIn - cMCashOut,
      previous: pMCashIn - pMCashOut,
      delta: growth(cMCashIn - cMCashOut, pMCashIn - pMCashOut),
    },
  ];

  // --- Alerts ---
  const alerts = financeAlerts();
  // --- Health ---
  const health = financeAnalytics.healthScore();

  void monthOf; // reserved util
  void BUDGET_CATEGORY_LABEL;

  return {
    period,
    kpi: {
      revenue,
      grossProfit,
      netProfit,
      expenses,
      cashPosition: cashTotal,
      debtOutstanding: dTotals.remaining,
      budgetUsage,
      runwayDays: kpis.runwayDays,
      growth: {
        revenue: growth(revenue, prevSalesAgg.revenue),
        grossProfit: growth(grossProfit, prevSalesAgg.grossProfit),
        netProfit: growth(netProfit, prevSalesAgg.grossProfit - prevExpenses),
        expenses: growth(expenses, prevExpenses),
      },
      trend: kpiTrend,
    },
    daily,
    expense: {
      byCategory,
      byPot,
      top: topExpense,
      total: totalExp,
    },
    budget: {
      rows: bRows,
      totalBudget,
      totalActual,
      over: overRows,
      under: underRows,
    },
    debt: {
      outstanding: dTotals.principal,
      paid: dTotals.paid,
      remaining: dTotals.remaining,
      progress: dTotals.progress,
      rows: debtRows,
      dueSoon,
      paymentTrend,
    },
    fund,
    cash: {
      total: cashTotal,
      opening: openingTotal,
      channels,
    },
    health,
    ratios,
    kpis,
    projection: {
      horizons,
      avgs,
      currentCash: currentCashBalance(),
    },
    monthlyCompare,
    alerts,
  };
}
