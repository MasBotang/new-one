/**
 * Rule-based insight generator untuk Finance Analytics.
 * Deterministik — tidak menggunakan AI. Membaca hasil compute
 * dari data.ts (tidak menghitung ulang metrik apapun).
 */
import type { InsightItem } from "@/components/analytics";
import { formatIDR } from "@/lib/format";
import type { FinanceAnalyticsData } from "./data";

function pct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function buildFinanceInsights(data: FinanceAnalyticsData): InsightItem[] {
  const items: InsightItem[] = [];
  const { kpi, expense, budget, debt, fund, ratios, projection, monthlyCompare } = data;

  // Revenue growth
  if (kpi.growth.revenue != null) {
    const g = kpi.growth.revenue;
    if (g >= 0.1) {
      items.push({
        level: "positive",
        title: `Revenue naik ${pct(g)} vs periode sebelumnya`,
        detail: formatIDR(kpi.revenue),
      });
    } else if (g <= -0.1) {
      items.push({
        level: "negative",
        title: `Revenue turun ${pct(Math.abs(g))} vs periode sebelumnya`,
        detail: formatIDR(kpi.revenue),
      });
    }
  }

  // Expense growth
  if (kpi.growth.expenses != null) {
    const g = kpi.growth.expenses;
    if (g >= 0.15) {
      items.push({
        level: "warning",
        title: `Pengeluaran naik ${pct(g)} vs periode sebelumnya`,
        detail: formatIDR(kpi.expenses),
      });
    } else if (g <= -0.15) {
      items.push({
        level: "positive",
        title: `Pengeluaran turun ${pct(Math.abs(g))} vs periode sebelumnya`,
        detail: formatIDR(kpi.expenses),
      });
    }
  }

  // Net profit
  if (kpi.netProfit < 0) {
    items.push({
      level: "negative",
      title: "Net profit periode ini negatif",
      detail: `${formatIDR(kpi.netProfit)} — pengeluaran melampaui laba kotor`,
    });
  } else if (kpi.growth.netProfit != null && kpi.growth.netProfit <= -0.1) {
    items.push({
      level: "warning",
      title: `Net profit turun ${pct(Math.abs(kpi.growth.netProfit))}`,
      detail: `${formatIDR(kpi.netProfit)} vs periode sebelumnya`,
    });
  }

  // Top expense category
  const topCat = expense.byCategory[0];
  if (topCat && topCat.amount > 0) {
    items.push({
      level: "info",
      title: `Kategori pengeluaran terbesar: ${topCat.label}`,
      detail: `${formatIDR(topCat.amount)} (${pct(topCat.share)} dari total)`,
    });
  }

  // Fund with biggest outflow share
  const topFund = [...fund].sort((a, b) => b.shareOfOutflow - a.shareOfOutflow)[0];
  if (topFund && topFund.shareOfOutflow > 0) {
    items.push({
      level: "info",
      title: `${topFund.label} paling banyak digunakan`,
      detail: `${pct(topFund.shareOfOutflow)} dari total outflow periode ini`,
    });
  }

  // Budget usage
  for (const b of budget.over) {
    items.push({
      level: "negative",
      title: `Budget ${b.label} sudah terlampaui`,
      detail: `Realisasi ${formatIDR(b.actual)} dari ${formatIDR(b.budget)} (${b.percent.toFixed(0)}%)`,
    });
  }
  const nearOver = budget.rows.filter((b) => b.status === "warning");
  for (const b of nearOver) {
    items.push({
      level: "warning",
      title: `Budget ${b.label} terserap ${b.percent.toFixed(0)}%`,
      detail: `${formatIDR(b.actual)} dari ${formatIDR(b.budget)}`,
    });
  }

  // Debt due soon
  if (debt.dueSoon.length > 0) {
    const d = debt.dueSoon[0];
    items.push({
      level: "warning",
      title: `Hutang ${d.name} jatuh tempo ${d.daysToDue} hari lagi`,
      detail: `Sisa ${formatIDR(d.remaining)}`,
    });
  }
  if (debt.remaining > 0) {
    items.push({
      level: debt.progress >= 0.5 ? "positive" : "info",
      title: `Progress hutang ${(debt.progress * 100).toFixed(0)}%`,
      detail: `Sisa ${formatIDR(debt.remaining)} dari ${formatIDR(debt.outstanding)}`,
    });
  }

  // Runway
  if (kpi.runwayDays !== null) {
    if (kpi.runwayDays <= 30) {
      items.push({
        level: "negative",
        title: `Runway kas ${kpi.runwayDays} hari`,
        detail: "Kurangi pengeluaran atau tingkatkan omset segera.",
      });
    } else if (kpi.runwayDays <= 60) {
      items.push({
        level: "warning",
        title: `Runway kas ${kpi.runwayDays} hari`,
        detail: "Waspadai arus kas 2 bulan ke depan.",
      });
    } else {
      items.push({
        level: "positive",
        title: `Runway kas diperkirakan ${kpi.runwayDays} hari`,
      });
    }
  } else if (projection.avgs.avgNetCashflow > 0) {
    items.push({ level: "positive", title: "Cashflow harian positif — tanpa risiko runway" });
  }

  // Margins
  if (ratios.netMargin < 0) {
    items.push({
      level: "negative",
      title: `Net margin negatif (${pct(ratios.netMargin)})`,
    });
  } else if (ratios.netMargin >= 0.2) {
    items.push({
      level: "positive",
      title: `Net margin sehat (${pct(ratios.netMargin)})`,
    });
  }

  // Monthly compare — cashflow streak
  const nc = monthlyCompare.find((m) => m.metric === "Net Cashflow");
  if (nc) {
    if (nc.current >= 0 && nc.previous >= 0) {
      items.push({
        level: "positive",
        title: "Net cashflow bulanan positif dua bulan berturut-turut",
      });
    } else if (nc.current < 0) {
      items.push({
        level: "warning",
        title: "Net cashflow bulan ini negatif",
        detail: formatIDR(nc.current),
      });
    }
  }

  return items.slice(0, 12);
}
