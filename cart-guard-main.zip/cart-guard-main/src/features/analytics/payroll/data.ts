/**
 * Payroll Analytics — read-only data adapter.
 *
 * Reuses features/payroll/data (computePayroll) and features/payroll-settlement
 * (buildSettlementRows + KPI) to produce a merged read-only view for
 * /analytics/payroll. No new calculation lives here.
 */
import {
  computePayroll,
  resolvePayrollPeriod,
  type PayrollData,
  type PayrollPeriod,
  type PayrollPeriodPreset,
} from "@/features/payroll/data";
import {
  buildSettlementRows,
  computeSettlementKPI,
  type SettlementKPI,
  type SettlementRow,
} from "@/features/payroll-settlement/data";
import type { OperatorDirectory } from "@/features/attendance/data";
import { payrollService, type PayrollRecord } from "@/features/payroll/payroll.service";

export {
  resolvePayrollPeriod,
  type PayrollPeriod,
  type PayrollPeriodPreset,
} from "@/features/payroll/data";

export interface PayrollTrendPoint {
  periodStart: string;
  label: string;
  totalGross: number;
  totalNet: number;
  totalBonus: number;
  totalAdditional: number;
  totalDeduction: number;
  totalIncentive: number;
}

function fmtLabel(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("id-ID", { month: "short", year: "numeric" });
}

export function payrollTrend(limit = 6): PayrollTrendPoint[] {
  const recs = [...payrollService.list()].sort((a, b) =>
    a.periodStart < b.periodStart ? -1 : 1,
  );
  const tail = recs.slice(-limit);
  return tail.map<PayrollTrendPoint>((r: PayrollRecord) => ({
    periodStart: r.periodStart,
    label: fmtLabel(r.periodStart),
    totalGross: r.totals.totalGross,
    totalNet: r.totals.totalNet,
    totalBonus: r.totals.totalBonus,
    totalAdditional: r.totals.totalAdditional,
    totalDeduction: r.totals.totalDeduction,
    totalIncentive: r.totals.totalProductionIncentive,
  }));
}

export interface PayrollAnalyticsData {
  period: PayrollPeriod;
  payroll: PayrollData;
  settlementRows: SettlementRow[];
  settlementKPI: SettlementKPI;
  trend: PayrollTrendPoint[];
}

export function computePayrollAnalytics(
  period: PayrollPeriod,
  operators: OperatorDirectory[],
): PayrollAnalyticsData {
  const payroll = computePayroll(period, operators);
  const settlementRows = buildSettlementRows({
    periodFrom: period.range.from.toISOString(),
    periodTo: period.range.to.toISOString(),
  });
  const settlementKPI = computeSettlementKPI(settlementRows);
  return {
    period,
    payroll,
    settlementRows,
    settlementKPI,
    trend: payrollTrend(6),
  };
}

export function buildPayrollAnalyticsInsights(
  data: PayrollAnalyticsData,
): { level: "positive" | "warning" | "negative" | "info"; title: string; detail?: string }[] {
  const items: {
    level: "positive" | "warning" | "negative" | "info";
    title: string;
    detail?: string;
  }[] = [];
  const kpi = data.payroll.kpi;
  const sk = data.settlementKPI;

  if (sk.totalOutstanding > 0) {
    items.push({
      level: "warning",
      title: "Ada payroll outstanding",
      detail: `Sisa yang belum dibayar: Rp ${sk.totalOutstanding.toLocaleString("id-ID")}.`,
    });
  } else if (sk.totalPayroll > 0) {
    items.push({
      level: "positive",
      title: "Semua payroll terselesaikan",
      detail: "Tidak ada outstanding pada periode ini.",
    });
  }

  if (kpi.laborCostGrowth != null && Math.abs(kpi.laborCostGrowth) > 0.05) {
    const up = kpi.laborCostGrowth > 0;
    items.push({
      level: up ? "warning" : "positive",
      title: `Labor cost ${up ? "naik" : "turun"} ${(Math.abs(kpi.laborCostGrowth) * 100).toFixed(1)}%`,
      detail: "Dibandingkan periode sebelumnya.",
    });
  }

  if (kpi.totalDeduction > 0) {
    items.push({
      level: "info",
      title: "Ada potongan aktif",
      detail: `Total potongan periode: Rp ${kpi.totalDeduction.toLocaleString("id-ID")}.`,
    });
  }

  const top = [...data.payroll.rows].sort((a, b) => b.netSalary - a.netSalary)[0];
  if (top && top.netSalary > 0) {
    items.push({
      level: "positive",
      title: `Top earner: ${top.operator}`,
      detail: `Net Rp ${top.netSalary.toLocaleString("id-ID")}.`,
    });
  }
  return items;
}

