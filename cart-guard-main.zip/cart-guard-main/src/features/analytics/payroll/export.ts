/**
 * Payroll Analytics — CSV/XLSX export via finance-report.service downloaders.
 */
import { downloadCSV, downloadXLSX } from "@/services/finance-report.service";
import type { PayrollAnalyticsData } from "./data";

function slug(label: string): string {
  return label.replace(/[^0-9a-zA-Z]+/g, "-").toLowerCase();
}

function buildSheets(data: PayrollAnalyticsData) {
  const { payroll, settlementRows, settlementKPI, trend } = data;
  return [
    {
      name: "KPI",
      rows: [
        { Metric: "Total Operators", Value: payroll.kpi.totalOperators },
        { Metric: "Gross Payroll", Value: payroll.rows.reduce((s, r) => s + r.grossSalary, 0) },
        { Metric: "Net Payroll", Value: payroll.kpi.totalPayroll },
        { Metric: "Total Bonus", Value: payroll.kpi.totalBonus },
        { Metric: "Total Additional", Value: payroll.kpi.totalAdditional },
        { Metric: "Total Deduction", Value: payroll.kpi.totalDeduction },
        { Metric: "Total Production Incentive", Value: payroll.kpi.totalIncentive },
        { Metric: "Average Net Salary", Value: payroll.kpi.averageSalary },
        { Metric: "Outstanding Payroll", Value: settlementKPI.totalOutstanding },
        { Metric: "Paid Payroll", Value: settlementKPI.totalPaid },
        { Metric: "Paid Ratio", Value: settlementKPI.paidRatio },
      ],
    },
    {
      name: "Operator",
      rows: payroll.rows.map((r) => ({
        Operator: r.operator,
        Role: r.role,
        WorkingDays: r.workingDays,
        WorkingHours: r.workingHours,
        ProductionQty: r.productionQty,
        Incentive: r.productionIncentive,
        Bonus: r.bonus,
        Additional: r.additional,
        Deduction: r.deduction,
        Gross: r.grossSalary,
        Net: r.netSalary,
      })),
    },
    {
      name: "Settlement",
      rows: settlementRows.map((r) => ({
        Operator: r.operator,
        Periode: r.periodLabel,
        Status: r.settlementStatus,
        Net: r.netSalary,
        Paid: r.totalPaid,
        Outstanding: r.outstanding,
      })),
    },
    {
      name: "Trend",
      rows: trend.map((t) => ({
        Periode: t.label,
        Gross: t.totalGross,
        Net: t.totalNet,
        Bonus: t.totalBonus,
        Additional: t.totalAdditional,
        Deduction: t.totalDeduction,
        Incentive: t.totalIncentive,
      })),
    },
  ];
}

export function exportPayrollAnalyticsCSV(data: PayrollAnalyticsData, periodLabel: string) {
  for (const s of buildSheets(data)) {
    downloadCSV(s.rows, `payroll-${slug(s.name)}-${slug(periodLabel)}.csv`);
  }
}

export function exportPayrollAnalyticsXLSX(data: PayrollAnalyticsData, periodLabel: string) {
  downloadXLSX(buildSheets(data), `payroll-analytics-${slug(periodLabel)}.xlsx`);
}
