/**
 * /analytics/payroll — read-only Payroll Analytics.
 *
 * Reuses features/payroll data + features/payroll-settlement rows for
 * settlement progress. No CRUD, no settlement creation — only aggregation,
 * charts, tables, insights, and export.
 */
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as RechartTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  BadgeDollarSign,
  Banknote,
  Coins,
  Download,
  FileSpreadsheet,
  FileText,
  Minus,
  Percent,
  Plus,
  Search,
  Users,
  Wallet,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  ChartCard,
  InsightCard,
  KPICard,
  TableCard,
} from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";

import { loadOperators } from "@/features/payroll/data";
import {
  PAYROLL_PERIOD_LABEL,
  type PayrollPeriodPreset,
} from "@/features/payroll/constants";
import {
  computePayrollAnalytics,
  buildPayrollAnalyticsInsights,
  resolvePayrollPeriod,
} from "./data";
import { exportPayrollAnalyticsCSV, exportPayrollAnalyticsXLSX } from "./export";

const PERIOD_ORDER: PayrollPeriodPreset[] = ["this_month", "last_month", "custom"];

function pct(n: number, digits = 1): string {
  return `${(n * 100).toFixed(digits)}%`;
}

export function PayrollAnalyticsPage() {
  const [preset, setPreset] = useState<PayrollPeriodPreset>("this_month");
  const [customFrom, setCustomFrom] = useState<string>("");
  const [customTo, setCustomTo] = useState<string>("");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"net" | "gross" | "operator">("net");
  const [page, setPage] = useState(0);
  const pageSize = 25;

  const period = useMemo(
    () =>
      resolvePayrollPeriod(
        preset,
        preset === "custom" && customFrom && customTo
          ? { from: new Date(`${customFrom}T00:00:00`), to: new Date(`${customTo}T00:00:00`) }
          : undefined,
      ),
    [preset, customFrom, customTo],
  );

  const operatorsQ = useQuery({ queryKey: ["payroll-operators"], queryFn: loadOperators });
  const operators = operatorsQ.data ?? [];

  const data = useMemo(() => computePayrollAnalytics(period, operators), [period, operators]);
  const insights = useMemo(() => buildPayrollAnalyticsInsights(data), [data]);

  const totalGross = useMemo(
    () => data.payroll.rows.reduce((s, r) => s + r.grossSalary, 0),
    [data.payroll.rows],
  );

  const filteredRows = useMemo(() => {
    const needle = search.trim().toLowerCase();
    let rows = data.payroll.rows;
    if (needle) rows = rows.filter((r) => r.operator.toLowerCase().includes(needle));
    const sorted = [...rows];
    if (sortBy === "operator") sorted.sort((a, b) => a.operator.localeCompare(b.operator));
    else if (sortBy === "gross") sorted.sort((a, b) => b.grossSalary - a.grossSalary);
    else sorted.sort((a, b) => b.netSalary - a.netSalary);
    return sorted;
  }, [data.payroll.rows, search, sortBy]);

  const paged = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page],
  );
  const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));

  const componentPie = useMemo(
    () => [
      { name: "Incentive", value: data.payroll.kpi.totalIncentive },
      { name: "Bonus", value: data.payroll.kpi.totalBonus },
      { name: "Additional", value: data.payroll.kpi.totalAdditional },
      { name: "Deduction", value: data.payroll.kpi.totalDeduction },
    ].filter((s) => s.value > 0),
    [data.payroll.kpi],
  );
  const PIE_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-5)"];

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Analytics Module"
        title="Payroll Analytics"
        description="Business Intelligence untuk payroll. Read-only — data langsung dari Payroll & Payroll Settlement Modules."
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <Download className="h-3.5 w-3.5" /> Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Export Payroll</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => exportPayrollAnalyticsXLSX(data, period.label)}>
                <FileSpreadsheet className="mr-2 h-4 w-4" /> Excel (XLSX)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportPayrollAnalyticsCSV(data, period.label)}>
                <FileText className="mr-2 h-4 w-4" /> CSV
              </DropdownMenuItem>
              <DropdownMenuItem disabled>
                <FileText className="mr-2 h-4 w-4" /> PDF (placeholder)
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PAYROLL_PERIOD_LABEL[p]}
                </Button>
              ))}
              <div className="flex items-center gap-1 rounded-md border bg-background px-2 py-0.5">
                <Input
                  type="date"
                  value={customFrom}
                  onChange={(e) => {
                    setCustomFrom(e.target.value);
                    if (e.target.value && customTo) setPreset("custom");
                  }}
                  className="h-6 border-0 p-0 text-xs shadow-none focus-visible:ring-0"
                />
                <span className="text-xs text-muted-foreground">–</span>
                <Input
                  type="date"
                  value={customTo}
                  onChange={(e) => {
                    setCustomTo(e.target.value);
                    if (customFrom && e.target.value) setPreset("custom");
                  }}
                  className="h-6 border-0 p-0 text-xs shadow-none focus-visible:ring-0"
                />
              </div>
            </div>
            <Badge variant="secondary" className="text-xs">{period.label}</Badge>
          </div>
        }
      />

      <AnalyticsSection title="Summary KPI" description="Ringkasan payroll periode aktif.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <KPICard label="Total Operators" value={formatNumber(data.payroll.kpi.totalOperators)} icon={Users} />
          <KPICard label="Gross Payroll" value={formatIDR(totalGross)} icon={Wallet} />
          <KPICard
            label="Net Payroll"
            value={formatIDR(data.payroll.kpi.totalPayroll)}
            deltaPct={data.payroll.kpi.laborCostGrowth}
            icon={Banknote}
          />
          <KPICard label="Total Bonus" value={formatIDR(data.payroll.kpi.totalBonus)} icon={BadgeDollarSign} tone="positive" />
          <KPICard label="Total Additional" value={formatIDR(data.payroll.kpi.totalAdditional)} icon={Plus} />
          <KPICard
            label="Total Deduction"
            value={formatIDR(data.payroll.kpi.totalDeduction)}
            icon={Minus}
            tone={data.payroll.kpi.totalDeduction > 0 ? "warning" : "muted"}
          />
        </div>
        <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <KPICard label="Outstanding Payroll" value={formatIDR(data.settlementKPI.totalOutstanding)} icon={Coins} tone={data.settlementKPI.totalOutstanding > 0 ? "warning" : "muted"} />
          <KPICard label="Paid Payroll" value={formatIDR(data.settlementKPI.totalPaid)} icon={Wallet} tone="positive" />
          <KPICard label="Settlement Progress" value={pct(data.settlementKPI.paidRatio)} icon={Percent} />
          <KPICard label="Average Net Salary" value={formatIDR(data.payroll.kpi.averageSalary)} icon={Banknote} />
        </div>
      </AnalyticsSection>

      <AnalyticsSection title="Trend" description="Payroll historis (max 6 periode terakhir).">
        <div className="grid gap-3 lg:grid-cols-2">
          <ChartCard title="Payroll Trend" subtitle="Gross vs Net">
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={data.trend}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => formatIDR(v)} width={80} />
                <RechartTooltip formatter={(v: number) => formatIDR(v)} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="totalGross" stroke="var(--chart-1)" name="Gross" strokeWidth={2} />
                <Line type="monotone" dataKey="totalNet" stroke="var(--chart-2)" name="Net" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Komponen Payroll" subtitle="Breakdown periode aktif">
            {componentPie.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={componentPie} dataKey="value" nameKey="name" innerRadius={60} outerRadius={90}>
                    {componentPie.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartTooltip formatter={(v: number) => formatIDR(v)} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="grid h-[260px] place-items-center text-sm text-muted-foreground">
                Belum ada komponen payroll pada periode ini.
              </div>
            )}
          </ChartCard>
        </div>
        <div className="mt-3">
          <ChartCard title="Bonus vs Deduction" subtitle="Historis per periode">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={data.trend}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => formatIDR(v)} width={80} />
                <RechartTooltip formatter={(v: number) => formatIDR(v)} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="totalBonus" fill="var(--chart-2)" name="Bonus" />
                <Bar dataKey="totalAdditional" fill="var(--chart-3)" name="Additional" />
                <Bar dataKey="totalDeduction" fill="var(--chart-5)" name="Deduction" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </AnalyticsSection>

      <AnalyticsSection
        title="Operator Payroll Table"
        description="Payroll per operator pada periode aktif."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(0);
                }}
                placeholder="Cari operator…"
                className="h-8 w-48 pl-8 text-xs"
              />
            </div>
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
              <SelectTrigger className="h-8 w-40 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="net">Sort: Net Salary</SelectItem>
                <SelectItem value="gross">Sort: Gross Salary</SelectItem>
                <SelectItem value="operator">Sort: Operator</SelectItem>
              </SelectContent>
            </Select>
          </div>
        }
      >
        <TableCard
          title="Operator Payroll"
          subtitle={`${filteredRows.length} operator`}
          columns={[
            { key: "operator", header: "Operator", render: (r) => r.operator },
            { key: "role", header: "Role", render: (r) => <span className="capitalize">{r.role}</span> },
            { key: "wd", header: "Hari Kerja", align: "right", render: (r) => formatNumber(r.workingDays) },
            { key: "wh", header: "Jam Kerja", align: "right", render: (r) => `${r.workingHours.toFixed(1)}j` },
            { key: "prod", header: "Produksi", align: "right", render: (r) => formatNumber(r.productionQty) },
            { key: "inc", header: "Incentive", align: "right", render: (r) => formatIDR(r.productionIncentive) },
            { key: "bonus", header: "Bonus", align: "right", render: (r) => formatIDR(r.bonus) },
            { key: "add", header: "Additional", align: "right", render: (r) => formatIDR(r.additional) },
            { key: "ded", header: "Deduction", align: "right", render: (r) => (r.deduction > 0 ? <span className="text-destructive">-{formatIDR(r.deduction)}</span> : formatIDR(0)) },
            { key: "gross", header: "Gross", align: "right", render: (r) => formatIDR(r.grossSalary) },
            { key: "net", header: "Net", align: "right", render: (r) => <span className="font-semibold">{formatIDR(r.netSalary)}</span> },
          ]}
          rows={paged}
          emptyMessage="Belum ada payroll pada periode ini."
        />
        {totalPages > 1 ? (
          <div className="flex items-center justify-end gap-2 pt-2 text-xs text-muted-foreground">
            <Button size="sm" variant="outline" className="h-7" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
              Prev
            </Button>
            <span>
              {page + 1} / {totalPages}
            </span>
            <Button
              size="sm"
              variant="outline"
              className="h-7"
              disabled={page + 1 >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
            >
              Next
            </Button>
          </div>
        ) : null}
      </AnalyticsSection>

      <AnalyticsSection title="Insight" description="Rule-based — bukan AI.">
        <InsightCard items={insights} emptyMessage="Belum ada highlight untuk periode ini." />
      </AnalyticsSection>
    </AnalyticsLayout>
  );
}
