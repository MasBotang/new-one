/**
 * Attendance Analytics — CSV/XLSX export via canonical downloader from
 * finance-report.service. No new export engine.
 */
import { downloadCSV, downloadXLSX } from "@/services/finance-report.service";
import type { AttendanceData } from "@/features/attendance/data";
import type { AttendanceTrendPoint } from "./data";

function slug(label: string): string {
  return label.replace(/[^0-9a-zA-Z]+/g, "-").toLowerCase();
}

function buildSheets(data: AttendanceData, trend: AttendanceTrendPoint[]) {
  return [
    {
      name: "KPI",
      rows: [
        { Metric: "Total Operators", Value: data.kpi.totalOperators },
        { Metric: "Present Today", Value: data.kpi.presentToday },
        { Metric: "Absent Today", Value: data.kpi.absentToday },
        { Metric: "Late Today", Value: data.kpi.lateToday },
        { Metric: "Avg Working Hours", Value: data.kpi.avgWorkingHours },
        { Metric: "Attendance Rate", Value: data.kpi.attendanceRate },
        { Metric: "Working Days", Value: data.workingDays },
      ],
    },
    {
      name: "Trend",
      rows: trend.map((t) => ({
        Tanggal: t.date,
        Present: t.present,
        Late: t.late,
        Absent: t.absent,
        Leave: t.leave,
        WorkingHours: t.workingHours,
        Rate: t.rate,
      })),
    },
    {
      name: "Operator",
      rows: data.stats.map((s) => ({
        Operator: s.operator,
        Role: s.role,
        Present: s.totalPresent,
        Late: s.totalLate,
        Absent: s.totalAbsent,
        Leave: s.totalLeave,
        AvgHours: s.avgWorkingHours,
        TotalHours: s.workingHours,
        AttendanceRate: s.attendanceRate,
      })),
    },
    {
      name: "Records",
      rows: data.rows.map((r) => ({
        Tanggal: r.date,
        Operator: r.operatorName,
        CheckIn: r.checkIn ?? "",
        CheckOut: r.checkOut ?? "",
        WorkingHours: r.workingHours,
        Status: r.status,
      })),
    },
  ];
}

export function exportAttendanceAnalyticsCSV(
  data: AttendanceData,
  trend: AttendanceTrendPoint[],
  periodLabel: string,
) {
  const sheets = buildSheets(data, trend);
  for (const s of sheets) {
    downloadCSV(s.rows, `attendance-${slug(s.name)}-${slug(periodLabel)}.csv`);
  }
}

export function exportAttendanceAnalyticsXLSX(
  data: AttendanceData,
  trend: AttendanceTrendPoint[],
  periodLabel: string,
) {
  downloadXLSX(buildSheets(data, trend), `attendance-analytics-${slug(periodLabel)}.xlsx`);
}

