/**
 * Attendance Analytics — read-only data adapter.
 *
 * Reuses `features/attendance/data` (computeAttendance, operatorStatistics)
 * and adds a daily trend series for charting. No new business logic.
 */
import {
  computeAttendance,
  resolvePeriod,
  workingDaysInRange,
  ymd,
  type AttendanceData,
  type DateRange,
  type OperatorDirectory,
  type Period,
  type PeriodPreset,
} from "@/features/attendance/data";
import { attendanceService, computeWorkingHours } from "@/features/attendance/attendance.service";

export {
  PERIOD_LABELS,
  resolvePeriod,
  workingDaysInRange,
  ymd,
  type AttendanceData,
  type OperatorDirectory,
  type Period,
  type PeriodPreset,
} from "@/features/attendance/data";

export interface AttendanceTrendPoint {
  date: string; // yyyy-mm-dd
  present: number;
  late: number;
  absent: number;
  leave: number;
  workingHours: number;
  rate: number; // present / activeOperators
}

function inRangeYmd(dateStr: string, r: DateRange): boolean {
  const t = new Date(`${dateStr}T00:00:00`).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

export function attendanceTrend(
  period: Period,
  operators: OperatorDirectory[],
): AttendanceTrendPoint[] {
  const activeOps = operators.filter((o) => o.status === "active").length;
  const recs = attendanceService.list().filter((r) => inRangeYmd(r.date, period.range));
  const byDate = new Map<string, AttendanceTrendPoint>();

  const cursor = new Date(period.range.from);
  while (cursor.getTime() < period.range.to.getTime()) {
    const key = ymd(cursor);
    byDate.set(key, {
      date: key,
      present: 0,
      late: 0,
      absent: 0,
      leave: 0,
      workingHours: 0,
      rate: 0,
    });
    cursor.setDate(cursor.getDate() + 1);
  }

  for (const r of recs) {
    const p = byDate.get(r.date);
    if (!p) continue;
    switch (r.status) {
      case "present":
      case "half_day":
        p.present += 1;
        break;
      case "late":
        p.late += 1;
        p.present += 1;
        break;
      case "absent":
        p.absent += 1;
        break;
      case "leave":
        p.leave += 1;
        break;
    }
    p.workingHours += computeWorkingHours(r);
  }

  const result = Array.from(byDate.values());
  for (const p of result) {
    p.rate = activeOps > 0 ? p.present / activeOps : 0;
  }
  return result;
}

export function computeAttendanceAnalytics(
  period: Period,
  operators: OperatorDirectory[],
): AttendanceData & { trend: AttendanceTrendPoint[] } {
  const base = computeAttendance(period, operators);
  return { ...base, trend: attendanceTrend(period, operators) };
}
