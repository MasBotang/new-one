/**
 * /analytics/attendance — read-only Attendance Analytics.
 *
 * Reuses features/attendance data + insights. Adds daily trend chart and
 * CSV/XLSX export via finance-report.service. No CRUD controls.
 */
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip as RechartTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  CalendarDays,
  Clock,
  Download,
  FileSpreadsheet,
  FileText,
  Percent,
  Search,
  UserCheck,
  UserMinus,
  Users,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  ChartCard,
  InsightCard,
  KPICard,
  TableCard,
} from "@/components/analytics";
import { formatNumber } from "@/lib/format";

import { loadOperators } from "@/features/attendance/data";
import { attendanceService } from "@/features/attendance/attendance.service";
import { buildAttendanceInsights } from "@/features/attendance/insights";
import {
  ATTENDANCE_STATUSES,
  ATTENDANCE_STATUS_LABEL,
  type AttendanceStatus,
} from "@/features/attendance/constants";
import {
  PERIOD_LABELS,
  computeAttendanceAnalytics,
  resolvePeriod,
  type PeriodPreset,
} from "./data";
import {
  exportAttendanceAnalyticsCSV,
  exportAttendanceAnalyticsXLSX,
} from "./export";

const PERIOD_ORDER: PeriodPreset[] = ["today", "week", "month", "custom"];
const ATTENDANCE_QUERY_KEY = ["attendance"] as const;

function pct(n: number, digits = 1): string {
  return `${(n * 100).toFixed(digits)}%`;
}
function fmtShortDate(dateStr: string): string {
  const d = new Date(`${dateStr}T00:00:00`);
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" });
}

export function AttendanceAnalyticsPage() {
  const [preset, setPreset] = useState<PeriodPreset>("month");
  const [custom, setCustom] = useState<{ from?: Date; to?: Date }>({});
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | AttendanceStatus>("all");
  const [sortBy, setSortBy] = useState<"date" | "operator" | "hours">("date");
  const [page, setPage] = useState(0);
  const pageSize = 25;

  const period = useMemo(() => {
    if (preset === "custom" && custom.from && custom.to) {
      return resolvePeriod("custom", { from: custom.from, to: custom.to });
    }
    if (preset === "custom") return resolvePeriod("today");
    return resolvePeriod(preset);
  }, [preset, custom]);

  const operatorsQ = useQuery({ queryKey: ["attendance-operators"], queryFn: loadOperators });
  const store = useQuery({
    queryKey: ATTENDANCE_QUERY_KEY,
    queryFn: () => attendanceService.list(),
    initialData: attendanceService.list(),
  });

  const data = useMemo(() => {
    const ops = operatorsQ.data ?? [];
    void store.data;
    return computeAttendanceAnalytics(period, ops);
  }, [period, operatorsQ.data, store.data]);

  const insights = useMemo(() => buildAttendanceInsights(data), [data]);

  const filteredRows = useMemo(() => {
    const needle = search.trim().toLowerCase();
    let rows = data.rows;
    if (statusFilter !== "all") rows = rows.filter((r) => r.status === statusFilter);
    if (needle) rows = rows.filter((r) => r.operatorName.toLowerCase().includes(needle));
    const sorted = [...rows];
    if (sortBy === "operator") sorted.sort((a, b) => a.operatorName.localeCompare(b.operatorName));
    else if (sortBy === "hours") sorted.sort((a, b) => b.workingHours - a.workingHours);
    return sorted;
  }, [data.rows, search, statusFilter, sortBy]);

  const paged = useMemo(
    () => filteredRows.slice(page * pageSize, page * pageSize + pageSize),
    [filteredRows, page],
  );
  const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Analytics Module"
        title="Attendance Analytics"
        description="Business Intelligence untuk kehadiran operator. Read-only — data langsung dari Attendance Module."
        actions={
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <Download className="h-3.5 w-3.5" /> Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Export Attendance</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => exportAttendanceAnalyticsXLSX(data, data.trend, period.label)}
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" /> Excel (XLSX)
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => exportAttendanceAnalyticsCSV(data, data.trend, period.label)}
              >
                <FileText className="mr-2 h-4 w-4" /> CSV
              </DropdownMenuItem>
              <DropdownMenuItem disabled>
                <FileText className="mr-2 h-4 w-4" /> PDF (placeholder)
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        }
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PERIOD_LABELS[p]}
                </Button>
              ))}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={preset === "custom" ? "default" : "ghost"}
                    className="h-7 gap-1 px-2.5 text-xs"
                  >
                    <CalendarDays className="h-3.5 w-3.5" /> Custom
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-auto p-0">
                  <Calendar
                    mode="range"
                    numberOfMonths={2}
                    selected={{ from: custom.from, to: custom.to }}
                    onSelect={(r) => {
                      setCustom({ from: r?.from, to: r?.to });
                      if (r?.from && r?.to) setPreset("custom");
                    }}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <Badge variant="secondary" className="text-xs">{period.label}</Badge>
          </div>
        }
      />

      <AnalyticsSection title="Summary KPI" description="Ringkasan kehadiran periode aktif.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <KPICard label="Total Operators" value={formatNumber(data.kpi.totalOperators)} icon={Users} hint="Aktif" />
          <KPICard label="Present Today" value={formatNumber(data.kpi.presentToday)} icon={UserCheck} tone="positive" />
          <KPICard
            label="Late Today"
            value={formatNumber(data.kpi.lateToday)}
            icon={Clock}
            tone={data.kpi.lateToday > 0 ? "warning" : "muted"}
          />
          <KPICard
            label="Absent Today"
            value={formatNumber(data.kpi.absentToday)}
            icon={UserMinus}
            tone={data.kpi.absentToday > 0 ? "warning" : "muted"}
          />
          <KPICard
            label="Avg Working Hours"
            value={`${data.kpi.avgWorkingHours.toFixed(1)}j`}
            deltaPct={data.kpi.growth.avgWorkingHours}
            icon={Clock}
            hint="rata-rata / record"
          />
          <KPICard
            label="Attendance Rate"
            value={pct(data.kpi.attendanceRate)}
            deltaPct={data.kpi.growth.attendanceRate}
            icon={Percent}
            hint={`${data.workingDays} hari kerja`}
          />
        </div>
      </AnalyticsSection>

      <AnalyticsSection title="Trend" description="Kehadiran harian periode aktif.">
        <div className="grid gap-3 lg:grid-cols-2">
          <ChartCard title="Attendance Rate" subtitle="Present / operator aktif">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={data.trend}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="date" tickFormatter={fmtShortDate} tick={{ fontSize: 11 }} />
                <YAxis tickFormatter={(v) => `${Math.round(v * 100)}%`} tick={{ fontSize: 11 }} />
                <RechartTooltip
                  labelFormatter={fmtShortDate}
                  formatter={(v: number) => `${(v * 100).toFixed(1)}%`}
                />
                <Area
                  type="monotone"
                  dataKey="rate"
                  stroke="var(--chart-1)"
                  fill="var(--chart-1)"
                  fillOpacity={0.25}
                  name="Attendance Rate"
                />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
          <ChartCard title="Present · Late · Absent" subtitle="Distribusi status harian">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={data.trend}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="date" tickFormatter={fmtShortDate} tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <RechartTooltip labelFormatter={fmtShortDate} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="present" stackId="a" fill="var(--chart-2)" name="Present" />
                <Bar dataKey="late" stackId="a" fill="var(--chart-4)" name="Late" />
                <Bar dataKey="absent" stackId="a" fill="var(--chart-5)" name="Absent" />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </AnalyticsSection>

      <AnalyticsSection
        title="Operator Table"
        description="Ringkasan per operator pada periode aktif."
      >
        <TableCard
          title="Statistik Operator"
          subtitle={`${data.workingDays} hari kerja`}
          columns={[
            { key: "operator", header: "Operator", render: (r) => r.operator },
            { key: "role", header: "Role", render: (r) => <span className="capitalize">{r.role}</span> },
            { key: "present", header: "Present", align: "right", render: (r) => formatNumber(r.totalPresent) },
            { key: "late", header: "Late", align: "right", render: (r) => formatNumber(r.totalLate) },
            { key: "absent", header: "Absent", align: "right", render: (r) => formatNumber(r.totalAbsent) },
            { key: "leave", header: "Leave", align: "right", render: (r) => formatNumber(r.totalLeave) },
            { key: "avg", header: "Avg Hours", align: "right", render: (r) => r.avgWorkingHours.toFixed(2) },
            { key: "rate", header: "Attendance %", align: "right", render: (r) => pct(r.attendanceRate) },
          ]}
          rows={data.stats}
          emptyMessage="Belum ada operator."
        />
      </AnalyticsSection>

      <AnalyticsSection
        title="Report Table"
        description="Record kehadiran periode aktif."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(0);
                }}
                placeholder="Cari operator…"
                className="h-8 w-48 pl-8 text-xs"
              />
            </div>
            <Select
              value={statusFilter}
              onValueChange={(v) => {
                setStatusFilter(v as "all" | AttendanceStatus);
                setPage(0);
              }}
            >
              <SelectTrigger className="h-8 w-36 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                {ATTENDANCE_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {ATTENDANCE_STATUS_LABEL[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
              <SelectTrigger className="h-8 w-36 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Sort: Tanggal</SelectItem>
                <SelectItem value="operator">Sort: Operator</SelectItem>
                <SelectItem value="hours">Sort: Working Hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
        }
      >
        <TableCard
          title="Record Kehadiran"
          subtitle={`${filteredRows.length} record`}
          columns={[
            { key: "date", header: "Tanggal", render: (r) => fmtShortDate(r.date) },
            { key: "op", header: "Operator", render: (r) => r.operatorName },
            { key: "in", header: "In", render: (r) => (r.checkIn ? new Date(r.checkIn).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }) : "—") },
            { key: "out", header: "Out", render: (r) => (r.checkOut ? new Date(r.checkOut).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }) : "—") },
            { key: "wh", header: "Working Hours", align: "right", render: (r) => r.workingHours.toFixed(2) },
            { key: "status", header: "Status", render: (r) => ATTENDANCE_STATUS_LABEL[r.status] },
          ]}
          rows={paged}
          emptyMessage="Belum ada record pada periode ini."
        />
        {totalPages > 1 ? (
          <div className="flex items-center justify-end gap-2 pt-2 text-xs text-muted-foreground">
            <Button size="sm" variant="outline" className="h-7" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
              Prev
            </Button>
            <span>
              {page + 1} / {totalPages}
            </span>
            <Button
              size="sm"
              variant="outline"
              className="h-7"
              disabled={page + 1 >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
            >
              Next
            </Button>
          </div>
        ) : null}
      </AnalyticsSection>

      <AnalyticsSection title="Insight" description="Rule-based — bukan AI.">
        <InsightCard items={insights} emptyMessage="Belum ada highlight untuk periode ini." />
      </AnalyticsSection>
    </AnalyticsLayout>
  );
}
