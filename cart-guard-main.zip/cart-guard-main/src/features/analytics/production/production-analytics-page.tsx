/**
 * /analytics/production — Production Performance module.
 *
 * READ-ONLY. Tidak ada CRUD, form, atau dialog input.
 * Sumber data tunggal: `./data.ts` (agregasi dari productionService & userService).
 * Ambang & rumus badge: `./constants.ts` — jangan hardcode di UI.
 */
import { useMemo, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as RechartTooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  BadgeCheck,
  CalendarDays,
  Factory,
  Gauge,
  PackageCheck,
  Percent,
  Trash2,
  Users,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  ChartCard,
  InsightCard,
  KPICard,
  TableCard,
} from "@/components/analytics";
import { formatNumber } from "@/lib/format";
import {
  PERIOD_LABELS,
  computeProductionPerformance,
  resolvePeriod,
  type OperatorRow,
  type PeriodPreset,
} from "./data";
import { buildInsights } from "./insights";
import { PERFORMANCE_BADGE_LABEL, type PerformanceBadge } from "./constants";

const PERIOD_ORDER: PeriodPreset[] = ["today", "week", "month", "custom"];

function fmtPct(n: number, digits = 1): string {
  return `${(n * 100).toFixed(digits)}%`;
}

function fmtDate(iso?: string): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

const BADGE_TONE: Record<PerformanceBadge, "default" | "secondary" | "destructive" | "outline"> = {
  excellent: "default",
  good: "secondary",
  average: "outline",
  need_improvement: "destructive",
};

export function ProductionAnalyticsPage() {
  const [preset, setPreset] = useState<PeriodPreset>("week");
  const [custom, setCustom] = useState<{ from?: Date; to?: Date }>({});

  const period = useMemo(() => {
    if (preset === "custom" && custom.from && custom.to) {
      return resolvePeriod("custom", { from: custom.from, to: custom.to });
    }
    if (preset === "custom") return resolvePeriod("today");
    return resolvePeriod(preset);
  }, [preset, custom]);

  const data = useMemo(() => computeProductionPerformance(period), [period]);
  const insights = useMemo(() => buildInsights(data), [data]);

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Analytics Module"
        title="Production Performance"
        description="Performa operator & produktivitas. Read-only — sumber data untuk Payroll."
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PERIOD_LABELS[p]}
                </Button>
              ))}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={preset === "custom" ? "default" : "ghost"}
                    className="h-7 gap-1 px-2.5 text-xs"
                  >
                    <CalendarDays className="h-3.5 w-3.5" />
                    Custom
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-auto p-0">
                  <Calendar
                    mode="range"
                    numberOfMonths={2}
                    selected={{ from: custom.from, to: custom.to }}
                    onSelect={(r) => {
                      setCustom({ from: r?.from, to: r?.to });
                      if (r?.from && r?.to) setPreset("custom");
                    }}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <Badge variant="secondary" className="text-xs">
              {period.label}
            </Badge>
          </div>
        }
      />

      {/* Summary KPI */}
      <AnalyticsSection title="Summary KPI" description="Ringkasan performa periode aktif.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <KPICard
            label="Total Production"
            value={formatNumber(data.kpi.totalProduction)}
            deltaPct={data.kpi.growth.totalProduction}
            icon={Factory}
          />
          <KPICard
            label="Total Release"
            value={formatNumber(data.kpi.totalRelease)}
            deltaPct={data.kpi.growth.totalRelease}
            icon={PackageCheck}
          />
          <KPICard
            label="Total Waste"
            value={formatNumber(data.kpi.totalWaste)}
            deltaPct={data.kpi.growth.totalWaste}
            tone={data.kpi.totalWaste > 0 ? "warning" : "muted"}
            icon={Trash2}
          />
          <KPICard
            label="Avg / Operator"
            value={formatNumber(Math.round(data.kpi.avgProductionPerOperator))}
            deltaPct={data.kpi.growth.avgProductionPerOperator}
            hint="produksi rata-rata per operator"
            icon={Zap}
          />
          <KPICard
            label="Avg Waste %"
            value={fmtPct(data.kpi.wastePct)}
            deltaPct={data.kpi.growth.wastePct}
            tone={data.kpi.wastePct >= 0.05 ? "warning" : "default"}
            icon={Percent}
          />
          <KPICard
            label="Active Operators"
            value={formatNumber(data.kpi.activeOperators)}
            hint="dengan produksi > 0"
            icon={Users}
          />
        </div>
      </AnalyticsSection>

      {/* Performance Chart */}
      <AnalyticsSection title="Performance Chart" description="Produksi per hari.">
        <ChartCard title="Produksi Harian" subtitle={period.label}>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.daily} margin={{ left: 4, right: 8, top: 8, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis
                  dataKey="label"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  fontSize={11}
                />
                <YAxis
                  width={48}
                  tickLine={false}
                  axisLine={false}
                  fontSize={11}
                  tickFormatter={(v: number) => formatNumber(v)}
                />
                <RechartTooltip
                  formatter={(v: number) => [formatNumber(v), "Production"]}
                  contentStyle={{
                    background: "var(--color-popover)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="production"
                  name="Production"
                  stroke="var(--color-primary)"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </AnalyticsSection>

      {/* Operator Ranking */}
      <AnalyticsSection
        title="Operator Ranking"
        description="Diurutkan berdasarkan total produksi (Top Operator)."
      >
        <TableCard
          title="Top Operator"
          columns={[
            { key: "rank", header: "#", render: (r: OperatorRow) => r.rank },
            { key: "operator", header: "Operator", render: (r: OperatorRow) => r.operator },
            {
              key: "production",
              header: "Produksi",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.production),
            },
            {
              key: "release",
              header: "Release",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.release),
            },
            {
              key: "waste",
              header: "Waste",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.waste),
            },
            {
              key: "efficiency",
              header: "Efficiency %",
              align: "right",
              render: (r: OperatorRow) => fmtPct(r.efficiency),
            },
            {
              key: "badge",
              header: "Performance",
              render: (r: OperatorRow) => (
                <Badge variant={BADGE_TONE[r.badge]} className="text-[10px]">
                  {PERFORMANCE_BADGE_LABEL[r.badge]}
                </Badge>
              ),
            },
          ]}
          rows={data.operators}
          emptyMessage="Belum ada operator aktif pada periode ini."
        />
      </AnalyticsSection>

      {/* Operator Detail Table */}
      <AnalyticsSection
        title="Operator Detail"
        description="Detail lengkap per operator. Slot Working Days/Hours disiapkan untuk Attendance/Payroll berikutnya."
      >
        <TableCard
          title="Detail Operator"
          subtitle="operatorId = Account.id (join basis untuk Payroll)"
          columns={[
            { key: "operator", header: "Operator", render: (r: OperatorRow) => r.operator },
            {
              key: "firstProductionAt",
              header: "Hari Masuk Produksi",
              render: (r: OperatorRow) => fmtDate(r.firstProductionAt),
            },
            {
              key: "batches",
              header: "Total Batch",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.batches),
            },
            {
              key: "production",
              header: "Total Produksi",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.production),
            },
            {
              key: "release",
              header: "Total Release",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.release),
            },
            {
              key: "waste",
              header: "Total Waste",
              align: "right",
              render: (r: OperatorRow) => formatNumber(r.waste),
            },
            {
              key: "efficiency",
              header: "Efficiency",
              align: "right",
              render: (r: OperatorRow) => fmtPct(r.efficiency),
            },
            {
              key: "lastProductionAt",
              header: "Last Production",
              render: (r: OperatorRow) => fmtDate(r.lastProductionAt),
            },
          ]}
          rows={data.operators}
          emptyMessage="Belum ada operator aktif pada periode ini."
        />
      </AnalyticsSection>

      {/* Insight Box */}
      <AnalyticsSection title="Insight" description="Rule-based — bukan AI.">
        <InsightCard items={insights} emptyMessage="Belum ada highlight untuk periode ini." />
      </AnalyticsSection>
    </AnalyticsLayout>
  );
}

// Referenced by KPICard iconography — kept to preserve stable icon set for
// future extensions (efficiency, gauge, activity, badge-check).
void [Gauge, BadgeCheck, Activity];
