/**
 * Production Performance — konstanta ambang badge & rumus.
 *
 * DILARANG mengubah rumus di UI. Semua ambang & rumus WAJIB dari file ini
 * agar sumber tunggal untuk operator badge dan future Payroll module.
 */

/** Ambang efficiency untuk operator performance badge. */
export const OPERATOR_BADGE_THRESHOLDS = {
  excellent: 0.95, // efficiency ≥ 95%
  good: 0.85, // efficiency ≥ 85%
  average: 0.7, // efficiency ≥ 70%
  // < 70% → need_improvement
} as const;

export type PerformanceBadge = "excellent" | "good" | "average" | "need_improvement";

export const PERFORMANCE_BADGE_LABEL: Record<PerformanceBadge, string> = {
  excellent: "Excellent",
  good: "Good",
  average: "Average",
  need_improvement: "Need Improvement",
};

/**
 * Klasifikasi badge berdasarkan efficiency.
 * Operator tanpa produksi diberi "need_improvement" agar netral.
 */
export function classifyBadge(efficiency: number, production: number): PerformanceBadge {
  if (production <= 0) return "need_improvement";
  if (efficiency >= OPERATOR_BADGE_THRESHOLDS.excellent) return "excellent";
  if (efficiency >= OPERATOR_BADGE_THRESHOLDS.good) return "good";
  if (efficiency >= OPERATOR_BADGE_THRESHOLDS.average) return "average";
  return "need_improvement";
}

/**
 * Ambang insight rule-based (produktivitas & efisiensi vs periode sebelumnya).
 * Insight WAJIB rule-based, bukan AI.
 */
export const INSIGHT_THRESHOLDS = {
  productivityUpPct: 0.1, // naik ≥ 10%
  productivityDownPct: 0.1,
  efficiencyDropPct: 0.05, // turun ≥ 5 percentage points
  highWastePct: 0.05, // waste ≥ 5%
} as const;
