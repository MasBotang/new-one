/**
 * Rule-based insight generator untuk Production Performance.
 * Deterministik — bukan AI. Aman dieksekusi setiap render.
 * Semua ambang diambil dari `constants.ts`.
 */
import type { InsightItem } from "@/components/analytics";
import { formatNumber } from "@/lib/format";
import { INSIGHT_THRESHOLDS } from "./constants";
import type { ProductionPerformanceData } from "./data";

function pct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function buildInsights(data: ProductionPerformanceData): InsightItem[] {
  const items: InsightItem[] = [];
  const { kpi, operators } = data;

  // Top operator (output tertinggi)
  const topOp = operators[0];
  if (topOp && topOp.production > 0) {
    items.push({
      level: "positive",
      title: `Output tertinggi: ${topOp.operator}`,
      detail: `${formatNumber(topOp.production)} pcs · efficiency ${pct(topOp.efficiency)}`,
    });
  }

  // Operator dengan waste tertinggi
  const worstWaste = [...operators]
    .filter((o) => o.production > 0)
    .sort((a, b) => b.wastePct - a.wastePct)[0];
  if (worstWaste && worstWaste.wastePct >= INSIGHT_THRESHOLDS.highWastePct) {
    items.push({
      level: "warning",
      title: `Waste tertinggi: ${worstWaste.operator}`,
      detail: `${pct(worstWaste.wastePct)} dari produksi (${formatNumber(worstWaste.waste)} pcs)`,
    });
  }

  // Produktivitas vs periode sebelumnya (avg/operator)
  const g = kpi.growth.avgProductionPerOperator;
  if (g != null) {
    if (g >= INSIGHT_THRESHOLDS.productivityUpPct) {
      items.push({
        level: "positive",
        title: `Produktivitas meningkat ${pct(g)}`,
        detail: `Rata-rata ${formatNumber(Math.round(kpi.avgProductionPerOperator))} pcs / operator`,
      });
    } else if (g <= -INSIGHT_THRESHOLDS.productivityDownPct) {
      items.push({
        level: "negative",
        title: `Produktivitas turun ${pct(Math.abs(g))}`,
        detail: `Rata-rata ${formatNumber(Math.round(kpi.avgProductionPerOperator))} pcs / operator`,
      });
    }
  }

  // Efisiensi (release / production) vs periode sebelumnya
  const releaseGrowth = kpi.growth.totalRelease;
  const prodGrowth = kpi.growth.totalProduction;
  if (releaseGrowth != null && prodGrowth != null) {
    const drop = prodGrowth - releaseGrowth;
    if (drop >= INSIGHT_THRESHOLDS.efficiencyDropPct) {
      items.push({
        level: "warning",
        title: `Efisiensi menurun dibanding periode sebelumnya`,
        detail: `Release ${pct(releaseGrowth)} vs Produksi ${pct(prodGrowth)}`,
      });
    }
  }

  // High waste (global)
  if (kpi.wastePct >= INSIGHT_THRESHOLDS.highWastePct) {
    items.push({
      level: "warning",
      title: `Waste global ${pct(kpi.wastePct)}`,
      detail: `${formatNumber(kpi.totalWaste)} pcs waste periode ini`,
    });
  }

  return items;
}
