/**
 * Production Performance — data layer (READ-ONLY).
 *
 * SUMBER DATA TUNGGAL untuk halaman /analytics/production.
 *
 * Modul ini adalah "Production Performance" — modul analitik operasional
 * yang menjadi basis future Payroll module. BUKAN modul produksi.
 *
 * WAJIB:
 * - Read-only. Tidak menulis storage. Tidak memutasi entity.
 * - Semua statistik operator menggunakan `operatorId` (User.id / Account.id).
 *   Nama operator hanya untuk display; join tetap berbasis id.
 * - Rumus efficiency & waste diambil dari file ini + `constants.ts`.
 *   Jangan menghitung ulang di UI atau di modul lain.
 * - Struktur `workingDays` / `workingHours` sudah disediakan sebagai slot
 *   Attendance — tidak dihitung sekarang, tapi field-nya harus ada agar
 *   Payroll module tinggal menggabungkan Attendance.
 *
 * SUMBER (read-only, tidak dimodifikasi):
 *   - productionService  → runs (produksi, release, waste)
 *   - recipeService      → daftar resep aktif (untuk display context)
 *   - userService        → mapping nama operator ↔ User.id (Account.id)
 */

import { productionService } from "@/services/production.service";
import { userService } from "@/services/user.service";
import type { ProductionRun } from "@/services/types";
import {
  classifyBadge,
  INSIGHT_THRESHOLDS,
  type PerformanceBadge,
} from "./constants";

/* ---------------------- Period presets ---------------------- */

export type PeriodPreset = "today" | "week" | "month" | "custom";

export const PERIOD_LABELS: Record<PeriodPreset, string> = {
  today: "Hari Ini",
  week: "Minggu Ini",
  month: "Bulan Ini",
  custom: "Custom",
};

export interface DateRange {
  from: Date;
  to: Date;
}

export interface Period {
  preset: PeriodPreset;
  range: DateRange;
  previous: DateRange;
  label: string;
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}
function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function startOfWeekMonday(d: Date): Date {
  const s = startOfDay(d);
  const day = s.getDay(); // 0..6, 0 = Sunday
  const diff = (day + 6) % 7; // Monday-based
  return addDays(s, -diff);
}

export function resolvePeriod(
  preset: PeriodPreset,
  custom?: { from: Date; to: Date },
  ref = new Date(),
): Period {
  const today = startOfDay(ref);
  let range: DateRange;
  switch (preset) {
    case "today":
      range = { from: today, to: addDays(today, 1) };
      break;
    case "week": {
      const from = startOfWeekMonday(today);
      range = { from, to: addDays(from, 7) };
      break;
    }
    case "month": {
      const from = new Date(today.getFullYear(), today.getMonth(), 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      range = { from, to };
      break;
    }
    case "custom": {
      if (!custom) {
        range = { from: today, to: addDays(today, 1) };
      } else {
        range = {
          from: startOfDay(custom.from),
          to: addDays(startOfDay(custom.to), 1),
        };
      }
      break;
    }
  }
  const spanMs = range.to.getTime() - range.from.getTime();
  const previous: DateRange = {
    from: new Date(range.from.getTime() - spanMs),
    to: new Date(range.from.getTime()),
  };
  const fmt = (d: Date) =>
    d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const lastDay = new Date(range.to.getTime() - 1);
  const label =
    range.to.getTime() - range.from.getTime() <= 86400000
      ? fmt(range.from)
      : `${fmt(range.from)} – ${fmt(lastDay)}`;
  return { preset, range, previous, label };
}

/* ---------------------- Helpers ---------------------- */

function inRange(iso: string, r: DateRange): boolean {
  const t = new Date(iso).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

function pctChange(current: number, previous: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return (current - previous) / previous;
}

function runsInRange(range: DateRange): ProductionRun[] {
  return productionService.runs().filter((r) => inRange(r.createdAt, range));
}

function isProductionActivity(r: ProductionRun): boolean {
  return r.activity === "produce_finished";
}
function isReleaseActivity(r: ProductionRun): boolean {
  return r.activity === "finishing_validation";
}

/* ---------------------- Operator identity (Account.id) ---------------------- */

/**
 * Resolve operator name → operatorId (User.id / Account.id).
 * Production runs saat ini hanya menyimpan nama; untuk menyiapkan Payroll,
 * mapping id dilakukan di sini. Jika nama tidak ditemukan di daftar user,
 * gunakan slug nama sebagai id stabil.
 */
function slug(name: string): string {
  return `op:${name.trim().toLowerCase().replace(/\s+/g, "-")}`;
}

interface OperatorIdentity {
  operatorId: string;
  name: string;
}

function operatorIdentity(name: string, users = userService.list()): OperatorIdentity {
  const clean = (name || "—").trim() || "—";
  const match = users.find((u) => u.name.trim().toLowerCase() === clean.toLowerCase());
  return { operatorId: match ? match.id : slug(clean), name: clean };
}

/* ---------------------- Summary KPI ---------------------- */

export interface PerformanceKPI {
  totalProduction: number; // produce_finished qty
  totalRelease: number; // finishing_validation qty
  totalWaste: number; // waste qty
  wastePct: number; // waste / production
  activeOperators: number; // distinct operator dengan produksi > 0
  avgProductionPerOperator: number; // production / activeOperators
  growth: {
    totalProduction: number | null;
    totalRelease: number | null;
    totalWaste: number | null;
    avgProductionPerOperator: number | null;
    wastePct: number | null;
  };
}

interface RangeAgg {
  production: number;
  release: number;
  waste: number;
  operators: Set<string>; // operatorId
}

function aggregate(range: DateRange): RangeAgg {
  const users = userService.list();
  const acc: RangeAgg = {
    production: 0,
    release: 0,
    waste: 0,
    operators: new Set<string>(),
  };
  for (const r of runsInRange(range)) {
    if (isProductionActivity(r)) {
      acc.production += r.producedQuantity || 0;
      acc.waste += r.wasteQuantity || 0;
      if ((r.producedQuantity || 0) > 0 && r.operator) {
        acc.operators.add(operatorIdentity(r.operator, users).operatorId);
      }
    }
    if (isReleaseActivity(r)) {
      acc.release += r.producedQuantity || 0;
    }
  }
  return acc;
}

export function computeKPI(period: Period): PerformanceKPI {
  const cur = aggregate(period.range);
  const prev = aggregate(period.previous);
  const wastePct = cur.production > 0 ? cur.waste / cur.production : 0;
  const prevWastePct = prev.production > 0 ? prev.waste / prev.production : 0;
  const avgProd = cur.operators.size > 0 ? cur.production / cur.operators.size : 0;
  const prevAvgProd = prev.operators.size > 0 ? prev.production / prev.operators.size : 0;
  return {
    totalProduction: cur.production,
    totalRelease: cur.release,
    totalWaste: cur.waste,
    wastePct,
    activeOperators: cur.operators.size,
    avgProductionPerOperator: avgProd,
    growth: {
      totalProduction: pctChange(cur.production, prev.production),
      totalRelease: pctChange(cur.release, prev.release),
      totalWaste: pctChange(cur.waste, prev.waste),
      avgProductionPerOperator: pctChange(avgProd, prevAvgProd),
      wastePct: pctChange(wastePct, prevWastePct),
    },
  };
}

/* ---------------------- Daily trend ---------------------- */

export interface DailyPoint {
  date: string;
  label: string;
  production: number;
}

export function dailyTrend(range: DateRange): DailyPoint[] {
  const days: DailyPoint[] = [];
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    days.push({
      date: ymd(cursor),
      label: cursor.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
      production: 0,
    });
    cursor.setDate(cursor.getDate() + 1);
  }
  const idx = new Map(days.map((d, i) => [d.date, i]));
  for (const r of runsInRange(range)) {
    if (!isProductionActivity(r)) continue;
    const key = ymd(new Date(r.createdAt));
    const i = idx.get(key);
    if (i == null) continue;
    days[i].production += r.producedQuantity || 0;
  }
  return days;
}

/* ---------------------- Operator performance ---------------------- */

export interface OperatorRow {
  rank: number;
  operatorId: string; // User.id (Account.id) — key untuk Payroll
  operator: string; // display name
  production: number;
  batches: number;
  release: number;
  waste: number;
  efficiency: number; // release / production
  wastePct: number; // waste / production
  badge: PerformanceBadge;
  firstProductionAt?: string; // ISO — "Hari Masuk Produksi" (first run overall)
  lastProductionAt?: string; // ISO — last run in period
  activeDays: number; // distinct produksi days dalam period
  /** Slot Attendance — belum dihitung. Payroll akan mengisi. */
  workingDays?: number;
  /** Slot Attendance — belum dihitung. Payroll akan mengisi. */
  workingHours?: number;
}

export function operatorPerformance(range: DateRange): OperatorRow[] {
  const users = userService.list();
  const runs = runsInRange(range);
  const allRuns = productionService.runs();

  // First production overall (Hari Masuk Produksi) per operatorId
  const firstEver = new Map<string, string>();
  for (const r of allRuns) {
    if (!isProductionActivity(r)) continue;
    if (!r.operator) continue;
    const id = operatorIdentity(r.operator, users).operatorId;
    const cur = firstEver.get(id);
    if (!cur || r.createdAt < cur) firstEver.set(id, r.createdAt);
  }

  interface Acc {
    operatorId: string;
    operator: string;
    production: number;
    batches: number;
    release: number;
    waste: number;
    days: Set<string>;
    lastAt?: string;
  }
  const acc = new Map<string, Acc>();

  for (const r of runs) {
    if (!r.operator) continue;
    const { operatorId, name } = operatorIdentity(r.operator, users);
    const cur =
      acc.get(operatorId) ??
      ({
        operatorId,
        operator: name,
        production: 0,
        batches: 0,
        release: 0,
        waste: 0,
        days: new Set<string>(),
      } as Acc);
    cur.batches += r.batches || 0;
    if (isProductionActivity(r)) {
      cur.production += r.producedQuantity || 0;
      cur.waste += r.wasteQuantity || 0;
      cur.days.add(ymd(new Date(r.createdAt)));
      if (!cur.lastAt || r.createdAt > cur.lastAt) cur.lastAt = r.createdAt;
    }
    if (isReleaseActivity(r)) {
      cur.release += r.producedQuantity || 0;
    }
    acc.set(operatorId, cur);
  }

  const rows: OperatorRow[] = Array.from(acc.values()).map((v) => {
    const efficiency = v.production > 0 ? v.release / v.production : 0;
    const wastePct = v.production > 0 ? v.waste / v.production : 0;
    return {
      rank: 0,
      operatorId: v.operatorId,
      operator: v.operator,
      production: v.production,
      batches: v.batches,
      release: v.release,
      waste: v.waste,
      efficiency,
      wastePct,
      badge: classifyBadge(efficiency, v.production),
      firstProductionAt: firstEver.get(v.operatorId),
      lastProductionAt: v.lastAt,
      activeDays: v.days.size,
      workingDays: undefined,
      workingHours: undefined,
    };
  });

  rows.sort((a, b) => b.production - a.production || b.release - a.release);
  rows.forEach((r, i) => (r.rank = i + 1));
  return rows;
}

/* ---------------------- Bundled compute ---------------------- */

export interface ProductionPerformanceData {
  period: Period;
  kpi: PerformanceKPI;
  daily: DailyPoint[];
  operators: OperatorRow[];
}

export function computeProductionPerformance(period: Period): ProductionPerformanceData {
  return {
    period,
    kpi: computeKPI(period),
    daily: dailyTrend(period.range),
    operators: operatorPerformance(period.range),
  };
}

/* ---------------------- Insight thresholds (re-export) ---------------------- */

export { INSIGHT_THRESHOLDS };
