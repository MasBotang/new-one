import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Pencil,
  Plus,
  Trash2,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Lock,
  Search,
  Wallet,
  Receipt,
  Package,
  CreditCard,
  Store,
  ClipboardCheck,
  ShieldCheck,
  Clock3,
  User2,
  Building2,
  TrendingUp,
  ShoppingBag,
  ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { shiftService, isShiftLocked } from "@/services/shift.service";
import { marketplaceSettlementService } from "@/services/marketplace-settlement.service";
import { inventoryService } from "@/services/inventory.service";
import { salesSummaryService } from "@/services/sales-summary.service";
import { stockMovementService } from "@/services/stock-movement.service";
import { useRole } from "@/lib/role-context";
import { usePermission } from "@/lib/permissions";
import type {
  Shift,
  ShiftMarketplaceReconciliation,
  ShiftOperationalExpense,
  ShiftPaymentReconciliation,
  MarketplaceSource,
  PaymentBucket,
} from "@/services/types";
import { MARKETPLACE_SOURCES, SOURCE_ORDER_LABEL } from "@/services/types";
import { formatIDR, formatDateTime } from "@/lib/format";
import { toast } from "sonner";

function toLocalDatetimeInput(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalDatetimeInput(v: string): string {
  const d = new Date(v);
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}
function formatTime(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const PAYMENT_BUCKET_LABEL: Record<PaymentBucket, string> = {
  cash: "Cash",
  qris: "QRIS",
  transfer: "Transfer",
  marketplace: "Marketplace",
};

type AuditStatusLevel = "ok" | "warn" | "error";
interface AuditStatusItem {
  level: AuditStatusLevel;
  label: string;
}

export function ShiftsPage() {
  const { role, profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "Kasir";
  const { can } = usePermission();
  const canEditExpense = can("shift.editExpense");
  const isReadOnly = !can("shift.operate");
  const isCashier = can("shift.cashierNote");


  const [current, setCurrent] = useState<Shift | null>(null);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [opening, setOpening] = useState<number>(0);

  // Cash reconciliation
  const [closing, setClosing] = useState<number>(0);
  const [closingTouched, setClosingTouched] = useState(false);
  const [cashReason, setCashReason] = useState("");

  // Marketplace settlement inputs (per marketplace, in the closing dialog)
  const [settlementInputs, setSettlementInputs] = useState<
    Record<MarketplaceSource, { amount: string; notes: string }>
  >(() =>
    MARKETPLACE_SOURCES.reduce(
      (acc, m) => {
        acc[m] = { amount: "", notes: "" };
        return acc;
      },
      {} as Record<MarketplaceSource, { amount: string; notes: string }>,
    ),
  );

  // Detail & dialogs
  const [detail, setDetail] = useState<Shift | null>(null);
  const [expenseDialog, setExpenseDialog] = useState<
    { mode: "add" } | { mode: "edit"; entry: ShiftOperationalExpense; shiftId: string } | null
  >(null);
  const [confirmDelete, setConfirmDelete] =
    useState<{ shiftId: string; entry: ShiftOperationalExpense } | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);

  const opItems = useMemo(
    () => inventoryService.list().filter((i) => i.active && i.category === "operational"),
    [current?.id],
  );
  const pkgItems = useMemo(
    () => inventoryService.list().filter((i) => i.active && i.category === "packaging"),
    [current?.id],
  );

  function refresh() {
    setCurrent(shiftService.current());
    setShifts(shiftService.list());
  }
  useEffect(refresh, []);

  // SSoT: shift summary dari sales-summary.service
  const summary = useMemo(
    () => (current ? salesSummaryService.forShift(current.id) : null),
    [current?.id, shifts.length],
  );

  const totalOpExpense = current?.totalOperationalExpense ?? 0;
  const totalPackagingQty = current?.totalPackagingQty ?? 0;
  const packagingEverSaved = !!current?.packagingUsageSavedAt;

  const expectedCash = summary && current
    ? current.openingCash + summary.payments.cash - totalOpExpense
    : 0;
  const cashDifference = closing - expectedCash;

  // Rekonsiliasi marketplace berdasar input & totals sistem
  const marketplaceRecons: ShiftMarketplaceReconciliation[] = useMemo(() => {
    if (!summary) return [];
    return summary.marketplaces.map((m) => {
      const raw = settlementInputs[m.marketplace]?.amount ?? "";
      const notes = settlementInputs[m.marketplace]?.notes ?? "";
      const trimmed = raw.trim();
      const amount = trimmed === "" ? null : Number(trimmed.replace(/[^\d-]/g, ""));
      const settlementAmount = amount != null && Number.isFinite(amount) ? amount : null;
      return {
        marketplace: m.marketplace,
        systemTotal: m.total,
        systemOrders: m.orders,
        settlementAmount,
        difference: settlementAmount != null ? settlementAmount - m.total : 0,
        notes: notes.trim() || undefined,
      };
    });
  }, [summary, settlementInputs]);

  // Rekonsiliasi pembayaran (system-only untuk saat ini; kasir bisa cross-check)
  const paymentRecons: ShiftPaymentReconciliation[] = useMemo(() => {
    if (!summary) return [];
    const buckets: PaymentBucket[] = ["cash", "qris", "transfer", "marketplace"];
    return buckets.map((b) => ({
      bucket: b,
      systemTotal: summary.payments[b],
      // Actual cash sudah tercakup di Cash Audit; bucket lainnya read-only.
      actualTotal: b === "cash" ? closing : undefined,
      difference: b === "cash" ? closing - summary.payments.cash : undefined,
    }));
  }, [summary, closing]);

  // Status audit — jawaban ringkas "apakah semuanya sesuai?"
  const auditStatuses: AuditStatusItem[] = useMemo(() => {
    if (!summary) return [];
    const list: AuditStatusItem[] = [];

    // Cash
    if (!closingTouched) {
      list.push({ level: "warn", label: "Actual Cash belum diinput" });
    } else if (cashDifference === 0) {
      list.push({ level: "ok", label: "Cash sesuai" });
    } else if (cashDifference !== 0 && !cashReason.trim()) {
      list.push({
        level: "error",
        label: `Cash selisih ${formatIDR(cashDifference)} — alasan wajib`,
      });
    } else {
      list.push({
        level: "warn",
        label: `Cash selisih ${formatIDR(cashDifference)} (alasan tercatat)`,
      });
    }

    // Marketplace
    for (const r of marketplaceRecons) {
      const label = SOURCE_ORDER_LABEL[r.marketplace];
      if (r.systemTotal === 0 && r.settlementAmount == null) continue; // skip idle
      if (r.settlementAmount == null) {
        list.push({ level: "error", label: `${label} settlement belum diinput` });
      } else if (r.difference === 0) {
        list.push({ level: "ok", label: `${label} sesuai` });
      } else {
        list.push({
          level: "warn",
          label: `${label} selisih ${formatIDR(r.difference)}`,
        });
      }
    }

    // Pengeluaran operasional tanpa keterangan
    const opsMissingNote = (current?.operationalExpenses ?? []).filter(
      (e) => !e.notes || !e.notes.trim(),
    );
    if (opsMissingNote.length > 0) {
      list.push({
        level: "warn",
        label: `${opsMissingNote.length} pengeluaran operasional belum memiliki keterangan`,
      });
    }

    // Packaging
    if (!packagingEverSaved) {
      list.push({ level: "warn", label: "Pemakaian Packaging belum disimpan" });
    }

    return list;
  }, [
    summary,
    closingTouched,
    cashDifference,
    cashReason,
    marketplaceRecons,
    current?.operationalExpenses,
    packagingEverSaved,
  ]);

  const hasBlockingError = auditStatuses.some((s) => s.level === "error");

  // Sprint 6 (Finding #9): guard tombol Buka Shift terhadap double-click.
  const openingShiftRef = useRef(false);
  const [openingShift, setOpeningShift] = useState(false);
  function openShift() {
    if (openingShiftRef.current) return;
    if (opening < 0) return toast.error("Kas pembuka tidak valid");
    if (isReadOnly) return toast.error("Owner tidak dapat membuka shift");
    // Fail-safe UI: bila entah bagaimana sudah ada shift aktif, jangan
    // proses lagi. Service juga menerapkan guard yang sama.
    if (shiftService.current()) {
      toast.error("Shift aktif sudah ada");
      refresh();
      return;
    }
    openingShiftRef.current = true;
    setOpeningShift(true);
    try {
      shiftService.open(actor, opening, role ?? undefined);
      toast.success("Shift dibuka");
      setOpening(0);
      refresh();
    } finally {
      openingShiftRef.current = false;
      setOpeningShift(false);
    }
  }

  function doCloseShift() {
    if (!current || !summary) return;
    if (!closingTouched) return toast.error("Masukkan jumlah kas penutup (Actual Cash)");
    if (closing < 0) return toast.error("Kas penutup tidak valid");
    if (cashDifference !== 0 && !cashReason.trim())
      return toast.error("Alasan wajib diisi bila cash difference ≠ 0");

    // Blokir jika ada status error (contoh: marketplace settlement kosong sementara ada transaksi)
    const errorEntries = auditStatuses.filter((s) => s.level === "error");
    if (errorEntries.length > 0) {
      return toast.error(errorEntries[0].label);
    }

    // Sinkronkan input settlement ke marketplaceSettlementService supaya
    // Dashboard admin tetap konsisten (single source of truth di level data).
    const closeDateKey = (() => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    })();
    for (const r of marketplaceRecons) {
      if (r.settlementAmount == null) continue;
      marketplaceSettlementService.upsert({
        date: closeDateKey,
        marketplace: r.marketplace,
        orderCount: r.systemOrders,
        grossSales: r.systemTotal,
        marketplaceFee: Math.max(0, r.systemTotal - r.settlementAmount),
        netReceived: r.settlementAmount,
        notes: r.notes,
        createdBy: actor,
      });
    }


    shiftService.close({
      closingCash: closing,
      expectedCash,
      cashDifferenceReason: cashDifference !== 0 ? cashReason.trim() : undefined,
      totalOrders: summary.totalOrders,
      totalRevenue: summary.totalRevenue,
      cashSales: summary.payments.cash,
      qrisSales: summary.payments.qris,
      transferSales: summary.payments.transfer,
      marketplaceSales: summary.payments.marketplace,
      marketplaceReconciliations: marketplaceRecons,
      paymentReconciliations: paymentRecons,
      actor,
      actorRole: role ?? undefined,
    });
    toast.success("Shift ditutup");
    setClosing(0);
    setClosingTouched(false);
    setCashReason("");
    setConfirmClose(false);
    refresh();
  }

  function tryCloseShift() {
    if (!current || !summary) return;
    if (!closingTouched) return toast.error("Masukkan jumlah kas penutup (Actual Cash)");
    if (closing < 0) return toast.error("Kas penutup tidak valid");
    if (cashDifference !== 0 && !cashReason.trim())
      return toast.error("Alasan wajib diisi bila cash difference ≠ 0");
    if (!packagingEverSaved) {
      setConfirmClose(true);
      return;
    }
    doCloseShift();
  }

  const [historyQuery, setHistoryQuery] = useState("");
  const filteredShifts = useMemo(() => {
    const q = historyQuery.trim().toLowerCase();
    if (!q) return shifts;
    return shifts.filter((s) =>
      [s.cashier, s.id, s.cashDifferenceReason ?? ""]
        .join(" ")
        .toLowerCase()
        .includes(q),
    );
  }, [shifts, historyQuery]);

  const shiftStatus: { label: string; tone: "live" | "closed" | "waiting" } = current
    ? { label: "Shift Open", tone: "live" }
    : isReadOnly
      ? { label: "Menunggu Shift", tone: "waiting" }
      : { label: "Shift Closed", tone: "closed" };

  return (
    <div className="min-h-screen bg-[oklch(0.975_0.012_75)]">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 py-8 md:px-8 md:py-10">
        {/* Header */}
        <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:items-end sm:justify-between">
          <div className="flex min-w-0 flex-col gap-2">
            <div className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              <span>Sales</span>
              <ChevronRight className="h-3 w-3" />
              <span className="text-foreground/80">Shift</span>
            </div>
            <h1 className="truncate text-[30px] font-semibold leading-[1.1] tracking-tight text-foreground">
              Shift Closing Workspace
            </h1>
            <p className="max-w-2xl text-sm text-muted-foreground">
              Buka, audit, rekonsiliasi, dan tutup shift kasir dari satu pusat operasional.
              Setiap langkah dirancang berurutan agar tidak ada transaksi yang terlewat.
            </p>
          </div>
          <StatusBadge tone={shiftStatus.tone} label={shiftStatus.label} />
        </header>

        {!current && !isReadOnly && (
          <section className="rounded-[20px] border border-dashed border-border/70 bg-white/70 p-8 shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
            <div className="grid gap-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
              <div className="flex min-w-0 flex-col gap-2">
                <div className="inline-flex w-fit items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-primary">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Mulai Shift
                </div>
                <h2 className="text-xl font-semibold tracking-tight">Belum ada shift terbuka</h2>
                <p className="text-sm text-muted-foreground">
                  Masukkan kas pembuka untuk mulai menerima transaksi. Setelah shift dibuka,
                  seluruh langkah audit akan tersedia di bawah.
                </p>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="opening" className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                    Kas Pembuka
                  </Label>
                  <NumberInput
                    id="opening"
                    min={0}
                    value={opening}
                    onChange={setOpening}
                    onKeyDown={(e) => e.key === "Enter" && openShift()}
                    className="h-11 w-full rounded-xl sm:w-52"
                  />
                </div>
                <Button
                  onClick={openShift}
                  disabled={openingShift}
                  className="h-11 rounded-xl px-6 shadow-[0_10px_24px_-12px_rgba(15,23,42,0.35)] transition active:scale-[0.98]"
                >
                  {openingShift ? "Membuka…" : "Buka Shift"}
                </Button>
              </div>
            </div>
          </section>
        )}

        {!current && isReadOnly && (
          <section className="rounded-[20px] border border-border/60 bg-white p-8 text-sm text-muted-foreground shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
            Tidak ada shift aktif untuk diaudit saat ini.
          </section>
        )}

        {current && summary && (
          <>
            {/* HERO — Current Shift */}
            <section className="relative overflow-hidden rounded-[22px] border border-border/60 bg-white shadow-[0_20px_60px_-32px_rgba(15,23,42,0.35)]">
              <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(120%_120%_at_0%_0%,oklch(0.98_0.02_75)_0%,transparent_55%),radial-gradient(80%_80%_at_100%_0%,oklch(0.94_0.04_75)_0%,transparent_60%)]" />
              <div className="relative p-6 md:p-8">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/12 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-emerald-700">
                      <span className="relative flex h-2 w-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                      </span>
                      Shift Open
                    </span>
                    <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                      Current Shift · #{current.id.slice(0, 6).toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <Clock3 className="h-3.5 w-3.5" />
                    Dibuka {formatDateTime(current.openedAt)}
                  </div>
                </div>

                <div className="mt-6 grid gap-6 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
                  <div className="flex flex-col gap-1">
                    <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                      Cashier on Duty
                    </span>
                    <div className="mt-1 flex items-center gap-3">
                      <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary">
                        <User2 className="h-5 w-5" />
                      </div>
                      <div className="flex min-w-0 flex-col">
                        <span className="truncate text-lg font-semibold tracking-tight">
                          {current.cashier}
                        </span>
                        <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Building2 className="h-3.5 w-3.5" />
                          Outlet Utama
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <HeroStat
                      icon={<Wallet className="h-4 w-4" />}
                      label="Opening Cash"
                      value={formatIDR(current.openingCash)}
                    />
                    <HeroStat
                      icon={<TrendingUp className="h-4 w-4" />}
                      label="Current Revenue"
                      value={formatIDR(summary.totalRevenue)}
                      accent
                    />
                    <HeroStat
                      icon={<ShoppingBag className="h-4 w-4" />}
                      label="Current Orders"
                      value={String(summary.totalOrders)}
                    />
                    <HeroStat
                      icon={<ShieldCheck className="h-4 w-4" />}
                      label="Audit Status"
                      value={
                        hasBlockingError
                          ? "Perlu Perbaikan"
                          : auditStatuses.some((s) => s.level === "warn")
                            ? "Perlu Ditinjau"
                            : "Siap Ditutup"
                      }
                      tone={
                        hasBlockingError
                          ? "danger"
                          : auditStatuses.some((s) => s.level === "warn")
                            ? "warn"
                            : "ok"
                      }
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* Step 1 — Operational Expenses */}
            <SectionCard
              step={1}
              icon={<Receipt className="h-4 w-4" />}
              title="Pengeluaran Operasional"
              description="Catat setiap pengeluaran kas selama shift. Total akan mengurangi Expected Cash."
              action={
                !isReadOnly && (
                  <Button
                    size="sm"
                    onClick={() => setExpenseDialog({ mode: "add" })}
                    className="h-9 rounded-xl px-4 transition active:scale-[0.98]"
                  >
                    <Plus className="h-4 w-4" /> Tambah
                  </Button>
                )
              }
            >
              {opItems.length === 0 && (
                <p className="mb-3 rounded-xl border border-dashed border-border/70 bg-muted/30 p-3 text-xs text-muted-foreground">
                  Belum ada item Inventory kategori <strong>Operasional</strong>.
                </p>
              )}
              <OperationalExpenseTable
                entries={current.operationalExpenses ?? []}
                canEdit={canEditExpense && !isReadOnly}
                onEdit={(e) => setExpenseDialog({ mode: "edit", entry: e, shiftId: current.id })}
                onDelete={(e) => setConfirmDelete({ shiftId: current.id, entry: e })}
              />
              <div className="mt-4 flex items-center justify-end gap-3 rounded-xl bg-muted/40 px-4 py-2.5 text-sm">
                <span className="text-muted-foreground">Total (mengurangi Expected Cash)</span>
                <strong className="tabular-nums">{formatIDR(totalOpExpense)}</strong>
              </div>
            </SectionCard>

            {/* Step 2 — Packaging Audit */}
            <SectionCard
              step={2}
              icon={<Package className="h-4 w-4" />}
              title="Packaging Audit"
              description="Audit pemakaian packaging selama shift untuk sinkron dengan stok inventory."
              meta={
                current.packagingUsageSavedAt && (
                  <span className="text-[11px] text-muted-foreground">
                    Terakhir disimpan {formatDateTime(current.packagingUsageSavedAt)}
                    {current.packagingUsageSavedBy ? ` · ${current.packagingUsageSavedBy}` : ""}
                  </span>
                )
              }
            >
              <PackagingUsageCard
                shift={current}
                pkgItems={pkgItems}
                actor={actor}
                role={role}
                readOnly={isReadOnly}
                onSaved={refresh}
              />
            </SectionCard>

            {/* Step 3 — Payment Reconciliation */}
            <SectionCard
              step={3}
              icon={<CreditCard className="h-4 w-4" />}
              title="Rekonsiliasi Pembayaran"
              description="Bandingkan total setiap metode pembayaran dari sistem dengan yang diterima."
            >
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {paymentRecons.map((r) => {
                  const isCash = r.bucket === "cash";
                  return (
                    <div
                      key={r.bucket}
                      className="group relative flex flex-col gap-1 rounded-2xl border border-border/60 bg-white p-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] transition duration-150 hover:-translate-y-0.5 hover:shadow-[0_12px_30px_-16px_rgba(15,23,42,0.25)]"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                          {PAYMENT_BUCKET_LABEL[r.bucket]}
                        </span>
                        <PaymentIcon bucket={r.bucket} />
                      </div>
                      <span className="text-[22px] font-semibold tabular-nums tracking-tight">
                        {formatIDR(r.systemTotal)}
                      </span>
                      {isCash && closingTouched ? (
                        <span
                          className={cn(
                            "mt-1 inline-flex w-fit items-center gap-1 rounded-full px-2 py-0.5 text-[11px] tabular-nums",
                            cashDifference === 0
                              ? "bg-emerald-500/10 text-emerald-700"
                              : cashDifference > 0
                                ? "bg-emerald-500/10 text-emerald-700"
                                : "bg-destructive/10 text-destructive",
                          )}
                        >
                          Δ {cashDifference > 0 ? "+" : ""}
                          {formatIDR(cashDifference)}
                        </span>
                      ) : (
                        <span className="mt-1 text-[11px] text-muted-foreground">
                          {isCash ? "Belum ada input actual" : "System-only, read-only"}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </SectionCard>

            {/* Step 4 — Marketplace Reconciliation */}
            <SectionCard
              step={4}
              icon={<Store className="h-4 w-4" />}
              title="Rekonsiliasi Marketplace"
              description="Bandingkan total sistem dengan settlement yang diterima dari tiap marketplace."
            >
              <div className="flex flex-col gap-3">
                {marketplaceRecons.map((r) => (
                  <div
                    key={r.marketplace}
                    className="grid gap-3 rounded-2xl border border-border/60 bg-white p-4 shadow-[0_1px_2px_rgba(15,23,42,0.03)] transition duration-150 hover:-translate-y-0.5 hover:shadow-[0_12px_30px_-16px_rgba(15,23,42,0.25)] sm:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)] sm:items-center"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                        <Store className="h-4 w-4" />
                      </div>
                      <div className="flex min-w-0 flex-col">
                        <span className="truncate text-sm font-semibold">
                          {SOURCE_ORDER_LABEL[r.marketplace]}
                        </span>
                        <span className="text-[11px] text-muted-foreground">
                          {r.systemOrders} order · Sistem {formatIDR(r.systemTotal)}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <Label
                        htmlFor={`settle-${r.marketplace}`}
                        className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground"
                      >
                        Settlement
                      </Label>
                      <Input
                        id={`settle-${r.marketplace}`}
                        inputMode="numeric"
                        value={settlementInputs[r.marketplace].amount}
                        onChange={(e) =>
                          setSettlementInputs((prev) => ({
                            ...prev,
                            [r.marketplace]: {
                              ...prev[r.marketplace],
                              amount: e.target.value,
                            },
                          }))
                        }
                        placeholder={r.systemTotal === 0 ? "—" : "0"}
                        className="h-10 rounded-xl"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                        Selisih
                      </span>
                      <span
                        className={cn(
                          "text-sm font-semibold tabular-nums",
                          r.settlementAmount == null
                            ? "text-muted-foreground"
                            : r.difference === 0
                              ? "text-foreground"
                              : r.difference > 0
                                ? "text-emerald-600"
                                : "text-destructive",
                        )}
                      >
                        {r.settlementAmount == null
                          ? "—"
                          : `${r.difference > 0 ? "+" : ""}${formatIDR(r.difference)}`}
                      </span>
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                        Status
                      </span>
                      <MarketplaceStatusPill
                        systemTotal={r.systemTotal}
                        settlementAmount={r.settlementAmount}
                        difference={r.difference}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>

            {/* Step 5 — Shift Summary */}
            {!isReadOnly && (
              <SectionCard
                step={5}
                icon={<ClipboardCheck className="h-4 w-4" />}
                title="Ringkasan Shift"
                description="Tinjau angka kunci sebelum menutup shift. Selisih kas harus dijelaskan."
              >
                <div className="grid gap-3 sm:grid-cols-3">
                  <SummaryTile label="Revenue" value={formatIDR(summary.totalRevenue)} />
                  <SummaryTile label="Expense Operasional" value={`− ${formatIDR(totalOpExpense)}`} />
                  <SummaryTile
                    label="Expected Cash"
                    value={formatIDR(expectedCash)}
                    hint="Opening + Cash Sales − Pengeluaran"
                  />
                </div>

                <div className="mt-4 grid gap-3 rounded-2xl border border-border/60 bg-muted/25 p-4 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1.1fr)] sm:items-end">
                  <div className="flex flex-col gap-1">
                    <Label
                      htmlFor="closing"
                      className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground"
                    >
                      Actual Cash
                    </Label>
                    <NumberInput
                      id="closing"
                      min={0}
                      value={closing}
                      onChange={(v) => {
                        setClosing(v);
                        setClosingTouched(true);
                      }}
                      className="h-11 w-full rounded-xl bg-white"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      Expected
                    </span>
                    <span className="text-lg font-semibold tabular-nums">
                      {formatIDR(expectedCash)}
                    </span>
                  </div>
                  <div
                    className={cn(
                      "flex flex-col gap-1 rounded-xl px-4 py-3",
                      !closingTouched
                        ? "bg-white/70 text-muted-foreground"
                        : cashDifference === 0
                          ? "bg-emerald-500/10 text-emerald-700"
                          : cashDifference > 0
                            ? "bg-emerald-500/10 text-emerald-700"
                            : "bg-destructive/10 text-destructive",
                    )}
                  >
                    <span className="text-[10px] font-medium uppercase tracking-wider opacity-80">
                      Difference
                    </span>
                    <span className="text-xl font-bold tabular-nums">
                      {!closingTouched
                        ? "—"
                        : `${cashDifference > 0 ? "+" : ""}${formatIDR(cashDifference)}`}
                    </span>
                  </div>
                </div>

                {cashDifference !== 0 && closingTouched && (
                  <div className="mt-3 flex flex-col gap-1.5">
                    <Label htmlFor="reason" className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      Alasan Selisih (wajib)
                    </Label>
                    <Input
                      id="reason"
                      value={cashReason}
                      onChange={(e) => setCashReason(e.target.value)}
                      placeholder="Contoh: kembalian kurang, uang tips masuk kas, dll"
                      className="h-11 rounded-xl"
                    />
                  </div>
                )}

                <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  <SummaryTile compact label="Total Order" value={String(summary.totalOrders)} />
                  <SummaryTile compact label="QRIS" value={formatIDR(summary.payments.qris)} />
                  <SummaryTile compact label="Transfer" value={formatIDR(summary.payments.transfer)} />
                  <SummaryTile compact label="Marketplace" value={formatIDR(summary.payments.marketplace)} />
                  <SummaryTile compact label="Opening Cash" value={formatIDR(current.openingCash)} />
                  <SummaryTile compact label="Packaging" value={`${totalPackagingQty} pcs`} />
                </div>
              </SectionCard>
            )}

            {/* Audit status */}
            {auditStatuses.length > 0 && (
              <SectionCard
                icon={<ShieldCheck className="h-4 w-4" />}
                title="Status Audit"
                description="Ringkasan kondisi audit sebelum shift ditutup."
              >
                <ul className="grid gap-2 sm:grid-cols-2">
                  {auditStatuses.map((s, i) => (
                    <AuditStatusRow key={i} item={s} />
                  ))}
                </ul>
              </SectionCard>
            )}

            {/* Step 6 — Close shift */}
            {!isReadOnly && (
              <section
                className={cn(
                  "relative overflow-hidden rounded-[22px] border p-6 md:p-8 shadow-[0_20px_60px_-32px_rgba(15,23,42,0.35)]",
                  hasBlockingError
                    ? "border-destructive/30 bg-gradient-to-br from-destructive/8 via-white to-white"
                    : "border-primary/25 bg-gradient-to-br from-primary/8 via-white to-white",
                )}
              >
                <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
                  <div className="flex min-w-0 flex-col gap-2">
                    <div className="inline-flex w-fit items-center gap-2 rounded-full bg-foreground/5 px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-foreground/70">
                      <span className="grid h-4 w-4 place-items-center rounded-full bg-foreground text-[10px] font-bold text-background">
                        6
                      </span>
                      Tutup Shift
                    </div>
                    <h2 className="text-xl font-semibold tracking-tight">
                      {hasBlockingError
                        ? "Perbaiki status audit sebelum menutup shift"
                        : "Siap menutup shift?"}
                    </h2>
                    <p className="max-w-xl text-sm text-muted-foreground">
                      {hasBlockingError
                        ? "Ada item audit yang perlu diselesaikan. Selesaikan terlebih dahulu untuk mengaktifkan tombol tutup."
                        : "Semua transaksi, pengeluaran, dan settlement akan dikunci setelah shift ditutup. Aktivitas akan tercatat pada Audit Log."}
                    </p>
                  </div>
                  <div className="flex flex-col items-stretch gap-2 md:items-end">
                    <Button
                      size="lg"
                      onClick={tryCloseShift}
                      disabled={hasBlockingError}
                      className={cn(
                        "h-12 rounded-2xl px-6 text-sm font-semibold transition active:scale-[0.98]",
                        !hasBlockingError &&
                          "bg-gradient-to-r from-primary to-primary/85 text-primary-foreground shadow-[0_18px_40px_-16px_rgba(15,23,42,0.5)] hover:brightness-[1.03]",
                      )}
                    >
                      Tutup Shift
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                    {hasBlockingError && (
                      <p className="text-xs text-destructive">
                        Ada status merah — perbaiki sebelum menutup shift.
                      </p>
                    )}
                  </div>
                </div>
              </section>
            )}
          </>
        )}

        {/* History */}
        <SectionCard
          icon={<ClipboardCheck className="h-4 w-4" />}
          title="Riwayat Shift"
          description="Semua shift yang tercatat, terkunci setelah ditutup."
          action={
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={historyQuery}
                onChange={(e) => setHistoryQuery(e.target.value)}
                placeholder="Cari kasir, ID, alasan…"
                className="h-9 w-56 rounded-xl pl-8 text-sm"
              />
            </div>
          }
        >
          <div className="overflow-hidden rounded-2xl border border-border/50 bg-white">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50 bg-muted/30 hover:bg-muted/30">
                  <TableHead className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Kasir</TableHead>
                  <TableHead className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Dibuka</TableHead>
                  <TableHead className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Ditutup</TableHead>
                  <TableHead className="text-right text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Kas Pembuka</TableHead>
                  <TableHead className="text-right text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Omzet</TableHead>
                  <TableHead className="text-right text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Op. Expense</TableHead>
                  <TableHead className="text-right text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Selisih</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredShifts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="py-12 text-center text-sm text-muted-foreground">
                      {historyQuery ? "Tidak ada shift yang cocok." : "Belum ada shift."}
                    </TableCell>
                  </TableRow>
                )}
                {filteredShifts.map((s) => {
                  const variance =
                    s.closingCash != null && s.expectedCash != null
                      ? s.closingCash - s.expectedCash
                      : null;
                  const locked = isShiftLocked(s);
                  return (
                    <TableRow
                      key={s.id}
                      className="cursor-pointer border-border/40 transition-colors duration-150 hover:bg-muted/40"
                      onClick={() => setDetail(s)}
                    >
                      <TableCell className="py-3">
                        <div className="flex items-center gap-2">
                          {locked ? (
                            <span className="grid h-6 w-6 place-items-center rounded-full bg-muted text-muted-foreground">
                              <Lock className="h-3 w-3" />
                            </span>
                          ) : (
                            <span className="grid h-6 w-6 place-items-center rounded-full bg-emerald-500/10 text-emerald-600">
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            </span>
                          )}
                          <span className="text-sm font-medium">{s.cashier}</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-3 text-xs text-muted-foreground">
                        {formatDateTime(s.openedAt)}
                      </TableCell>
                      <TableCell className="py-3 text-xs text-muted-foreground">
                        {s.closedAt ? formatDateTime(s.closedAt) : "—"}
                      </TableCell>
                      <TableCell className="py-3 text-right text-sm tabular-nums">
                        {formatIDR(s.openingCash)}
                      </TableCell>
                      <TableCell className="py-3 text-right text-sm tabular-nums">
                        {s.totalRevenue != null ? formatIDR(s.totalRevenue) : "—"}
                      </TableCell>
                      <TableCell className="py-3 text-right text-sm tabular-nums">
                        {s.totalOperationalExpense != null
                          ? formatIDR(s.totalOperationalExpense)
                          : "—"}
                      </TableCell>
                      <TableCell className="py-3 text-right text-sm tabular-nums">
                        {variance == null ? (
                          "—"
                        ) : (
                          <span
                            className={cn(
                              "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
                              variance === 0
                                ? "bg-muted text-muted-foreground"
                                : variance > 0
                                  ? "bg-emerald-500/10 text-emerald-700"
                                  : "bg-destructive/10 text-destructive",
                            )}
                          >
                            {variance > 0 ? "+" : ""}
                            {formatIDR(variance)}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="py-3">
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </SectionCard>

        <ShiftDetailDialog shift={detail} onClose={() => setDetail(null)} />

        {expenseDialog && (
          <OperationalExpenseDialog
            mode={expenseDialog.mode}
            initial={expenseDialog.mode === "edit" ? expenseDialog.entry : undefined}
            shiftId={
              expenseDialog.mode === "edit"
                ? expenseDialog.shiftId
                : current?.id ?? ""
            }
            opItems={opItems}
            actor={actor}
            role={role}
            onClose={() => setExpenseDialog(null)}
            onSaved={() => {
              setExpenseDialog(null);
              refresh();
            }}
          />
        )}

        {confirmDelete && (
          <AlertDialog open onOpenChange={(o) => !o && setConfirmDelete(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Hapus pengeluaran ini?</AlertDialogTitle>
                <AlertDialogDescription>
                  Stok Inventory <strong>{confirmDelete.entry.itemName}</strong> akan
                  dikembalikan sebanyak {confirmDelete.entry.qty} {confirmDelete.entry.unit}.
                  Aktivitas ini tercatat pada Audit Log.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Batal</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => {
                    try {
                      shiftService.deleteOperationalExpense({
                        shiftId: confirmDelete.shiftId,
                        expenseId: confirmDelete.entry.id,
                        actor,
                        actorRole: role ?? undefined,
                      });
                      toast.success("Pengeluaran dihapus");
                      setConfirmDelete(null);
                      refresh();
                    } catch (err) {
                      toast.error((err as Error).message);
                    }
                  }}
                >
                  Hapus
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        {confirmClose && (
          <AlertDialog open onOpenChange={(o) => !o && setConfirmClose(false)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Pemakaian Packaging belum diinput</AlertDialogTitle>
                <AlertDialogDescription>
                  Anda belum menyimpan Pemakaian Packaging pada shift ini. Tetap
                  tutup Shift?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Kembali</AlertDialogCancel>
                <AlertDialogAction onClick={doCloseShift}>Ya, Tutup</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}

        {isCashier && current && (
          <p className="text-xs text-muted-foreground">
            Kasir hanya dapat menambah Pengeluaran Operasional saat shift aktif. Edit/hapus
            dilakukan oleh Admin. Shift yang sudah ditutup terkunci untuk kasir.
          </p>
        )}
      </div>
    </div>
  );
}

function SectionCard({
  step,
  icon,
  title,
  description,
  action,
  meta,
  children,
}: {
  step?: number;
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  meta?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-[20px] border border-border/60 bg-white p-6 shadow-[0_1px_2px_rgba(15,23,42,0.03),0_20px_40px_-32px_rgba(15,23,42,0.25)] transition duration-150 md:p-7">
      <header className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          {(step != null || icon) && (
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/8 text-primary">
              {step != null ? (
                <span className="text-sm font-semibold tabular-nums">{step}</span>
              ) : (
                icon
              )}
            </div>
          )}
          <div className="flex min-w-0 flex-col gap-0.5">
            <div className="flex items-center gap-2">
              <h2 className="truncate text-[17px] font-semibold tracking-tight">{title}</h2>
              {icon && step != null && (
                <span className="text-muted-foreground/70">{icon}</span>
              )}
            </div>
            {description && (
              <p className="text-sm text-muted-foreground">{description}</p>
            )}
            {meta}
          </div>
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </header>
      {children}
    </section>
  );
}

function HeroStat({
  icon,
  label,
  value,
  accent,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent?: boolean;
  tone?: "ok" | "warn" | "danger";
}) {
  const toneClass =
    tone === "danger"
      ? "text-destructive"
      : tone === "warn"
        ? "text-amber-600"
        : tone === "ok"
          ? "text-emerald-600"
          : "";
  return (
    <div
      className={cn(
        "flex flex-col gap-1 rounded-2xl border border-border/50 bg-white/80 p-3.5 backdrop-blur-sm",
        accent && "border-primary/25 bg-primary/[0.04]",
      )}
    >
      <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        <span className="text-muted-foreground/80">{icon}</span>
        {label}
      </span>
      <span className={cn("text-base font-semibold tabular-nums tracking-tight", toneClass)}>
        {value}
      </span>
    </div>
  );
}

function SummaryTile({
  label,
  value,
  hint,
  compact,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-1 rounded-2xl border border-border/50 bg-white",
        compact ? "px-3 py-2.5" : "px-4 py-3.5",
      )}
    >
      <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <span
        className={cn(
          "font-semibold tabular-nums tracking-tight",
          compact ? "text-sm" : "text-lg",
        )}
      >
        {value}
      </span>
      {hint && <span className="text-[10px] text-muted-foreground/70">{hint}</span>}
    </div>
  );
}

function StatusBadge({ tone, label }: { tone: "live" | "closed" | "waiting"; label: string }) {
  const styles =
    tone === "live"
      ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/20"
      : tone === "waiting"
        ? "bg-amber-500/10 text-amber-700 border-amber-500/20"
        : "bg-muted text-muted-foreground border-border";
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider",
        styles,
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full",
          tone === "live"
            ? "bg-emerald-500"
            : tone === "waiting"
              ? "bg-amber-500"
              : "bg-muted-foreground/50",
        )}
      />
      {label}
    </div>
  );
}

function PaymentIcon({ bucket }: { bucket: PaymentBucket }) {
  const map: Record<PaymentBucket, React.ReactNode> = {
    cash: <Wallet className="h-3.5 w-3.5" />,
    qris: <CreditCard className="h-3.5 w-3.5" />,
    transfer: <CreditCard className="h-3.5 w-3.5" />,
    marketplace: <Store className="h-3.5 w-3.5" />,
  };
  return (
    <span className="grid h-7 w-7 place-items-center rounded-full bg-muted text-muted-foreground">
      {map[bucket]}
    </span>
  );
}

function MarketplaceStatusPill({
  systemTotal,
  settlementAmount,
  difference,
}: {
  systemTotal: number;
  settlementAmount: number | null;
  difference: number;
}) {
  if (systemTotal === 0 && settlementAmount == null) {
    return (
      <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
        <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" />
        Idle
      </span>
    );
  }
  if (settlementAmount == null) {
    return (
      <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-destructive/10 px-2.5 py-1 text-[11px] font-medium text-destructive">
        <span className="h-1.5 w-1.5 rounded-full bg-destructive" />
        Belum Diinput
      </span>
    );
  }
  if (difference === 0) {
    return (
      <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-1 text-[11px] font-medium text-emerald-700">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
        Sesuai
      </span>
    );
  }
  return (
    <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-amber-500/10 px-2.5 py-1 text-[11px] font-medium text-amber-700">
      <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
      Selisih
    </span>
  );
}


function AuditStatusRow({ item }: { item: AuditStatusItem }) {
  const icon =
    item.level === "ok" ? (
      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
    ) : item.level === "warn" ? (
      <AlertTriangle className="h-4 w-4 text-amber-500" />
    ) : (
      <XCircle className="h-4 w-4 text-destructive" />
    );
  const toneBg =
    item.level === "ok"
      ? "border-emerald-500/20 bg-emerald-500/5"
      : item.level === "warn"
        ? "border-amber-500/20 bg-amber-500/5"
        : "border-destructive/25 bg-destructive/5";
  return (
    <li className={cn("flex items-start gap-2 rounded-xl border px-3 py-2 text-sm", toneBg)}>
      <span className="mt-0.5 shrink-0">{icon}</span>
      <span
        className={
          item.level === "error"
            ? "text-destructive"
            : item.level === "warn"
              ? "text-amber-800"
              : "text-emerald-800"
        }
      >
        {item.label}
      </span>
    </li>
  );
}


function OperationalExpenseTable({
  entries,
  canEdit,
  onEdit,
  onDelete,
}: {
  entries: ShiftOperationalExpense[];
  canEdit: boolean;
  onEdit: (e: ShiftOperationalExpense) => void;
  onDelete: (e: ShiftOperationalExpense) => void;
}) {
  if (entries.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">Belum ada pengeluaran.</p>
    );
  }
  return (
    <div className="overflow-x-auto rounded-lg border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-16">Jam</TableHead>
            <TableHead>Barang</TableHead>
            <TableHead className="w-20 text-right">Qty</TableHead>
            <TableHead className="w-32 text-right">Harga</TableHead>
            <TableHead className="w-32 text-right">Total</TableHead>
            <TableHead>Catatan</TableHead>
            {canEdit && <TableHead className="w-24"></TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {entries.map((e) => (
            <TableRow key={e.id}>
              <TableCell className="text-xs text-muted-foreground">
                {formatTime(e.at)}
              </TableCell>
              <TableCell>
                {e.itemName}{" "}
                <span className="text-xs text-muted-foreground">({e.unit})</span>
              </TableCell>
              <TableCell className="text-right tabular-nums">{e.qty}</TableCell>
              <TableCell className="text-right tabular-nums">
                {formatIDR(e.price)}
              </TableCell>
              <TableCell className="text-right tabular-nums">
                {formatIDR(e.total)}
              </TableCell>
              <TableCell className="text-xs text-muted-foreground">
                {e.notes ?? "—"}
              </TableCell>
              {canEdit && (
                <TableCell className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => onEdit(e)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onDelete(e)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function OperationalExpenseDialog({
  mode,
  initial,
  shiftId,
  opItems,
  actor,
  role,
  onClose,
  onSaved,
}: {
  mode: "add" | "edit";
  initial?: ShiftOperationalExpense;
  shiftId: string;
  opItems: ReturnType<typeof inventoryService.list>;
  actor: string;
  role: string | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [at, setAt] = useState<string>(
    initial ? toLocalDatetimeInput(initial.at) : toLocalDatetimeInput(new Date().toISOString()),
  );
  const [itemId, setItemId] = useState(initial?.itemId ?? "");
  const [qty, setQty] = useState<number>(initial?.qty ?? 1);
  const [price, setPrice] = useState<number>(initial?.price ?? 0);
  const [notes, setNotes] = useState(initial?.notes ?? "");

  const total = Math.max(0, qty) * Math.max(0, price);

  function pickItem(v: string) {
    setItemId(v);
    if (mode === "add" && price === 0) {
      const it = inventoryService.get(v);
      if (it) setPrice(it.purchasePrice);
    }
  }

  function submit() {
    if (!itemId) return toast.error("Pilih barang");
    if (qty <= 0) return toast.error("Qty harus > 0");
    if (price < 0) return toast.error("Harga tidak valid");
    try {
      if (mode === "add") {
        shiftService.addOperationalExpense({
          at: fromLocalDatetimeInput(at),
          itemId,
          qty,
          price,
          notes,
          actor,
          actorRole: role ?? undefined,
        });
        toast.success("Pengeluaran ditambahkan");
      } else if (initial) {
        shiftService.updateOperationalExpense({
          shiftId,
          expenseId: initial.id,
          at: fromLocalDatetimeInput(at),
          itemId,
          qty,
          price,
          notes,
          actor,
          actorRole: role ?? undefined,
        });
        toast.success("Pengeluaran diubah");
      }
      onSaved();
    } catch (err) {
      toast.error((err as Error).message);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {mode === "add" ? "Tambah Pengeluaran Operasional" : "Ubah Pengeluaran"}
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="flex flex-col gap-1">
            <Label htmlFor="at">Jam</Label>
            <Input
              id="at"
              type="datetime-local"
              value={at}
              onChange={(e) => setAt(e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-1">
            <Label>Barang</Label>
            <Select value={itemId} onValueChange={pickItem}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih barang…" />
              </SelectTrigger>
              <SelectContent>
                {opItems.map((it) => (
                  <SelectItem key={it.id} value={it.id}>
                    {it.name} ({it.unit})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="flex flex-col gap-1">
              <Label htmlFor="qty">Qty</Label>
              <NumberInput id="qty" min={0} value={qty} onChange={setQty} />
            </div>
            <div className="flex flex-col gap-1">
              <Label htmlFor="price">Harga</Label>
              <NumberInput id="price" min={0} value={price} onChange={setPrice} />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 text-sm">
            <span className="text-muted-foreground">Total</span>
            <strong className="tabular-nums">{formatIDR(total)}</strong>
          </div>
          <div className="flex flex-col gap-1">
            <Label htmlFor="notes">Catatan</Label>
            <Input
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Opsional"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Batal
          </Button>
          <Button onClick={submit}>Simpan</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PackagingUsageCard({
  shift,
  pkgItems,
  actor,
  role,
  readOnly,
  onSaved,
}: {
  shift: Shift;
  pkgItems: ReturnType<typeof inventoryService.list>;
  actor: string;
  role: string | null;
  readOnly: boolean;
  onSaved: () => void;
}) {
  const savedMap = useMemo(() => {
    const m = new Map<string, number>();
    (shift.packagingUsage ?? []).forEach((p) => m.set(p.itemId, p.qty));
    return m;
  }, [shift.packagingUsage]);

  // Auto-aggregate packaging usage from POS stock movements recorded during
  // this shift (type === "sales_packaging_usage"). This mirrors what actually
  // happened at checkout so the cashier doesn't have to key it in manually.
  const autoMap = useMemo(() => {
    const m = new Map<string, number>();
    const openedAt = new Date(shift.openedAt).getTime();
    const now = Date.now();
    const movements = stockMovementService.list();
    for (const mv of movements) {
      if (mv.type !== "sales_packaging_usage") continue;
      const t = new Date(mv.createdAt).getTime();
      if (Number.isNaN(t) || t < openedAt || t > now) continue;
      m.set(mv.itemId, (m.get(mv.itemId) ?? 0) + (mv.quantity ?? 0));
    }
    return m;
  }, [shift.id, shift.openedAt]);

  const [draft, setDraft] = useState<Record<string, number>>({});
  // Track which item ids the cashier has manually adjusted so re-renders
  // (e.g. after a re-fetch) never clobber their correction.
  const [manualEdits, setManualEdits] = useState<Record<string, boolean>>({});
  // Snapshot of the auto-prefill values used at initialization, so we can
  // show a "from POS" badge next to numbers that came from checkout.
  const [autoSources, setAutoSources] = useState<Record<string, number>>({});
  const initializedShiftRef = useRef<string | null>(null);

  useEffect(() => {
    // Only prefill once per shift. Subsequent re-renders / re-fetches must
    // not overwrite manual corrections the cashier has already made.
    if (initializedShiftRef.current === shift.id) return;
    initializedShiftRef.current = shift.id;

    const autoObj: Record<string, number> = {};
    autoMap.forEach((v, k) => {
      autoObj[k] = v;
    });

    const next: Record<string, number> = {};
    pkgItems.forEach((it) => {
      // Saved values (previously confirmed by cashier) win over the auto
      // prefill. Otherwise fall back to the POS-aggregated value, then 0.
      const saved = savedMap.get(it.id);
      if (saved != null) next[it.id] = saved;
      else next[it.id] = autoObj[it.id] ?? 0;
    });
    setDraft(next);
    setAutoSources(autoObj);
    setManualEdits({});
  }, [shift.id, pkgItems, savedMap, autoMap]);

  function save() {
    try {
      shiftService.savePackagingUsage({
        shiftId: shift.id,
        entries: pkgItems.map((it) => ({ itemId: it.id, qty: draft[it.id] ?? 0 })),
        actor,
        actorRole: role ?? undefined,
      });
      toast.success("Pemakaian Packaging disimpan");
      onSaved();
    } catch (err) {
      toast.error((err as Error).message);
    }
  }

  return (
    <>
      {pkgItems.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border/70 bg-muted/30 p-3 text-xs text-muted-foreground">
          Belum ada item Inventory kategori <strong>Packaging</strong>.
        </p>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {pkgItems.map((it) => {
              const autoQty = autoSources[it.id] ?? 0;
              const isManual = !!manualEdits[it.id];
              const isSaved = savedMap.has(it.id);
              const currentQty = draft[it.id] ?? 0;
              // Source of the currently displayed value, used for the badge.
              const source: "manual" | "saved" | "auto" | "empty" = isManual
                ? "manual"
                : isSaved
                  ? "saved"
                  : autoQty > 0
                    ? "auto"
                    : "empty";
              return (
              <div
                key={it.id}
                className={`group flex flex-col gap-2 rounded-2xl border bg-white p-3.5 shadow-[0_1px_2px_rgba(15,23,42,0.03)] transition duration-150 hover:-translate-y-0.5 hover:shadow-[0_12px_30px_-16px_rgba(15,23,42,0.25)] ${
                  source === "manual"
                    ? "border-amber-300/70"
                    : source === "auto"
                      ? "border-primary/25"
                      : "border-border/60"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex min-w-0 flex-col">
                    <span className="truncate text-sm font-semibold">{it.name}</span>
                    <span className="text-[11px] text-muted-foreground">
                      Stok tersedia · {it.stock} {it.unit}
                    </span>
                  </div>
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary/8 text-primary">
                    <Package className="h-3.5 w-3.5" />
                  </span>
                </div>
                <div className="flex items-center gap-1.5 min-h-[18px]">
                  {source === "auto" && (
                    <span
                      className="inline-flex animate-in fade-in slide-in-from-left-1 duration-300 items-center gap-1 rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary"
                      title={`Terisi otomatis dari ${autoQty} pemakaian di POS selama shift ini`}
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                      Dari POS
                    </span>
                  )}
                  {source === "manual" && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-medium text-amber-700">
                      <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
                      Dikoreksi kasir
                    </span>
                  )}
                  {source === "saved" && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                      Tersimpan
                    </span>
                  )}
                  {source === "auto" && autoQty !== currentQty && (
                    <span className="text-[10px] text-muted-foreground">
                      · POS: {autoQty}
                    </span>
                  )}
                </div>
                <div className="flex items-end justify-between gap-2">
                  <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                    Dipakai
                  </span>
                  <div className="flex items-center gap-2">
                    <NumberInput
                      min={0}
                      value={draft[it.id] ?? 0}
                      onChange={(v) => {
                        setDraft((d) => ({ ...d, [it.id]: v }));
                        setManualEdits((m) =>
                          m[it.id] ? m : { ...m, [it.id]: true },
                        );
                      }}
                      className="h-9 w-24 rounded-lg"
                      disabled={readOnly}
                    />
                    <span className="text-xs text-muted-foreground">{it.unit}</span>
                  </div>
                </div>
              </div>
              );
            })}
          </div>
          {!readOnly && (
            <div className="mt-4 flex justify-end">
              <Button
                onClick={save}
                className="h-10 rounded-xl px-5 transition active:scale-[0.98]"
              >
                Simpan Packaging
              </Button>
            </div>
          )}
        </>
      )}
    </>
  );
}

function SummaryRow({
  label,
  value,
  hint,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-md border bg-muted/20 px-3 py-2">
      <div className="flex flex-col">
        <span className="text-xs text-muted-foreground">{label}</span>
        {hint && <span className="text-[10px] text-muted-foreground/70">{hint}</span>}
      </div>
      <span className="text-sm font-medium tabular-nums">{value}</span>
    </div>
  );
}

function ShiftDetailDialog({
  shift,
  onClose,
}: {
  shift: Shift | null;
  onClose: () => void;
}) {
  if (!shift) return null;
  const ops = shift.operationalExpenses ?? [];
  const pkg = shift.packagingUsage ?? [];
  const variance =
    shift.closingCash != null && shift.expectedCash != null
      ? shift.closingCash - shift.expectedCash
      : null;
  return (
    <Dialog open={!!shift} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Detail Shift · {shift.cashier}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4 text-sm">
          <div className="grid gap-2 sm:grid-cols-2">
            <SummaryRow label="Dibuka" value={formatDateTime(shift.openedAt)} />
            <SummaryRow
              label="Ditutup"
              value={shift.closedAt ? formatDateTime(shift.closedAt) : "—"}
            />
            <SummaryRow label="Opening Cash" value={formatIDR(shift.openingCash)} />
            <SummaryRow label="Total Order" value={String(shift.totalOrders ?? 0)} />
            <SummaryRow label="Total Omzet" value={formatIDR(shift.totalRevenue ?? 0)} />
            <SummaryRow label="Cash" value={formatIDR(shift.cashSales ?? 0)} />
            <SummaryRow label="QRIS" value={formatIDR(shift.qrisSales ?? 0)} />
            <SummaryRow label="Marketplace" value={formatIDR(shift.marketplaceSales ?? 0)} />
            <SummaryRow
              label="Total Pengeluaran Operasional"
              value={formatIDR(shift.totalOperationalExpense ?? 0)}
            />
            <SummaryRow
              label="Total Pemakaian Packaging"
              value={`${shift.totalPackagingQty ?? 0} pcs`}
            />
            <SummaryRow
              label="Expected Cash"
              value={shift.expectedCash != null ? formatIDR(shift.expectedCash) : "—"}
            />
            <SummaryRow
              label="Actual Cash"
              value={shift.closingCash != null ? formatIDR(shift.closingCash) : "—"}
            />
            <SummaryRow
              label="Cash Difference"
              value={
                variance == null ? (
                  "—"
                ) : (
                  <span
                    className={
                      variance === 0
                        ? ""
                        : variance > 0
                          ? "text-emerald-600"
                          : "text-destructive"
                    }
                  >
                    {variance > 0 ? "+" : ""}
                    {formatIDR(variance)}
                  </span>
                )
              }
            />
            {shift.cashDifferenceReason && (
              <div className="sm:col-span-2">
                <SummaryRow
                  label="Alasan Selisih"
                  value={shift.cashDifferenceReason}
                />
              </div>
            )}
          </div>

          <section className="flex flex-col gap-2">
            <h3 className="text-sm font-semibold">Pengeluaran Operasional</h3>
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Jam</TableHead>
                    <TableHead>Barang</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Harga</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead>Catatan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ops.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="py-4 text-center text-xs text-muted-foreground">
                        Tidak ada pengeluaran.
                      </TableCell>
                    </TableRow>
                  )}
                  {ops.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell className="text-xs text-muted-foreground">
                        {formatTime(e.at)}
                      </TableCell>
                      <TableCell>
                        {e.itemName}
                        <span className="ml-1 text-xs text-muted-foreground">({e.unit})</span>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">{e.qty}</TableCell>
                      <TableCell className="text-right tabular-nums">{formatIDR(e.price)}</TableCell>
                      <TableCell className="text-right tabular-nums">{formatIDR(e.total)}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {e.notes ?? "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </section>

          <section className="flex flex-col gap-2">
            <h3 className="text-sm font-semibold">Pemakaian Packaging</h3>
            <div className="overflow-x-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nama Packaging</TableHead>
                    <TableHead className="text-right">Qty Dipakai</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pkg.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={2} className="py-4 text-center text-xs text-muted-foreground">
                        Tidak ada pemakaian packaging.
                      </TableCell>
                    </TableRow>
                  )}
                  {pkg.map((p, i) => (
                    <TableRow key={i}>
                      <TableCell>{p.itemName}</TableCell>
                      <TableCell className="text-right tabular-nums">
                        {p.qty} {p.unit}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
