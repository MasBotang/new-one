/**
 * /finance/payroll-settlement — Payroll Settlement Module.
 *
 * Responsibility: mencatat pembayaran payroll operator (bukan menghitung).
 * READ-ONLY dari payrollService. Menulis ke:
 *   - payrollSettlementService (storage baru)
 *   - financeExpenses (Finance service, via public API)
 */
import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Banknote,
  Coins,
  CircleDollarSign,
  Users,
  Wallet,
  Receipt,
  Eye,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  InsightCard,
  KPICard,
  TableCard,
  type TableColumn,
} from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";

import {
  PAYMENT_METHOD_LABEL,
  PAYMENT_METHOD_TO_FINANCE,
  PAYMENT_METHODS,
  SETTLEMENT_STATUS_LABEL,
  SETTLEMENT_STATUS_TONE,
  type PaymentMethod,
  type SettlementStatus,
} from "./constants";
import {
  PAYROLL_STATUS_LABEL,
  PAYROLL_STATUS_TONE,
} from "@/features/payroll/constants";
import {
  buildSettlementRows,
  withPeriodComparison,
  type SettlementRow,
} from "./data";
import {
  payrollSettlementService,
  type PayrollSettlement,
} from "./payroll-settlement.service";
import { buildSettlementInsights } from "./insights";
import { payrollService } from "@/features/payroll/payroll.service";
import { financeExpenses } from "@/services/finance.service";

/* ---------------- Helpers ---------------- */

function fmtDateTime(iso: string): string {
  return new Date(iso).toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtDate(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function firstOfMonth(ref = new Date()): string {
  return ymd(new Date(ref.getFullYear(), ref.getMonth(), 1));
}
function firstOfNextMonth(ref = new Date()): string {
  return ymd(new Date(ref.getFullYear(), ref.getMonth() + 1, 1));
}

function deriveStatus(net: number, paid: number): SettlementStatus {
  if (paid <= 0) return "UNPAID";
  if (paid >= net) return "PAID";
  return "PARTIALLY_PAID";
}

/* ---------------- Component ---------------- */

export function PayrollSettlementPage() {
  const [from, setFrom] = useState<string>(firstOfMonth());
  const [to, setTo] = useState<string>(firstOfNextMonth());
  const [tick, setTick] = useState(0);
  const bump = () => setTick((t) => t + 1);

  const filter = useMemo(
    () => ({
      periodFrom: new Date(`${from}T00:00:00`).toISOString(),
      periodTo: new Date(`${to}T00:00:00`).toISOString(),
    }),
    [from, to],
  );

  const rows = useMemo(() => buildSettlementRows(filter), [filter, tick]);
  const kpi = useMemo(() => withPeriodComparison(rows, filter), [rows, filter]);
  const insights = useMemo(() => buildSettlementInsights(rows, kpi), [rows, kpi]);

  const history: PayrollSettlement[] = useMemo(() => {
    const inWindow = new Set(rows.map((r) => `${r.payrollId}:${r.operatorId}`));
    return payrollSettlementService
      .list()
      .filter((s) => inWindow.has(`${s.payrollId}:${s.operatorId}`));
  }, [rows]);

  const [payTarget, setPayTarget] = useState<SettlementRow | null>(null);
  const [detailTarget, setDetailTarget] = useState<SettlementRow | null>(null);

  /* ---------- Table columns ---------- */

  const operatorLookup = useMemo(() => {
    const m = new Map<string, SettlementRow>();
    for (const r of rows) m.set(`${r.payrollId}:${r.operatorId}`, r);
    return m;
  }, [rows]);

  const cols: TableColumn<SettlementRow>[] = [
    {
      key: "operator",
      header: "Operator",
      render: (r) => (
        <button
          className="font-medium text-foreground hover:underline"
          onClick={() => setDetailTarget(r)}
        >
          {r.operator}
        </button>
      ),
    },
    {
      key: "role",
      header: "Position",
      render: (r) => <span className="capitalize">{r.role}</span>,
    },
    {
      key: "period",
      header: "Periode",
      render: (r) => <span className="text-xs">{r.periodLabel}</span>,
    },
    {
      key: "net",
      header: "Net Salary",
      align: "right",
      render: (r) => <span className="font-semibold">{formatIDR(r.netSalary)}</span>,
    },
    {
      key: "payroll",
      header: "Payroll Status",
      align: "center",
      render: (r) => (
        <Badge variant={PAYROLL_STATUS_TONE[r.payrollStatus]} className="text-[10px]">
          {PAYROLL_STATUS_LABEL[r.payrollStatus]}
        </Badge>
      ),
    },
    {
      key: "settlement",
      header: "Settlement",
      align: "center",
      render: (r) => (
        <Badge
          variant={SETTLEMENT_STATUS_TONE[r.settlementStatus]}
          className="text-[10px]"
        >
          {SETTLEMENT_STATUS_LABEL[r.settlementStatus]}
        </Badge>
      ),
    },
    {
      key: "method",
      header: "Metode",
      render: (r) =>
        r.lastSettlement ? (
          <span className="text-xs">
            {PAYMENT_METHOD_LABEL[r.lastSettlement.paymentMethod]}
          </span>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        ),
    },
    {
      key: "paidAt",
      header: "Tanggal",
      render: (r) =>
        r.lastSettlement ? (
          <span className="text-xs">{fmtDate(r.lastSettlement.paymentDate)}</span>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        ),
    },
    {
      key: "action",
      header: "Aksi",
      align: "right",
      render: (r) => (
        <div className="flex justify-end gap-1.5">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setDetailTarget(r)}
            className="h-7 px-2 text-xs"
          >
            <Eye className="mr-1 h-3 w-3" /> Detail
          </Button>
          <Button
            size="sm"
            disabled={r.settlementStatus === "PAID" || r.netSalary <= 0}
            onClick={() => setPayTarget(r)}
            className="h-7 px-2 text-xs"
          >
            <Banknote className="mr-1 h-3 w-3" /> Bayar
          </Button>
        </div>
      ),
    },
  ];

  const historyCols: TableColumn<PayrollSettlement>[] = [
    {
      key: "date",
      header: "Tanggal",
      render: (s) => <span className="text-xs">{fmtDateTime(s.paymentDate)}</span>,
    },
    {
      key: "operator",
      header: "Operator",
      render: (s) => {
        const key = `${s.payrollId}:${s.operatorId}`;
        const r = operatorLookup.get(key);
        return <span>{r?.operator ?? s.operatorId}</span>;
      },
    },
    {
      key: "period",
      header: "Payroll Period",
      render: (s) => {
        const key = `${s.payrollId}:${s.operatorId}`;
        const r = operatorLookup.get(key);
        return <span className="text-xs">{r?.periodLabel ?? "—"}</span>;
      },
    },
    {
      key: "amount",
      header: "Paid Amount",
      align: "right",
      render: (s) => <span className="font-semibold">{formatIDR(s.paidAmount)}</span>,
    },
    {
      key: "method",
      header: "Metode",
      render: (s) => PAYMENT_METHOD_LABEL[s.paymentMethod],
    },
    {
      key: "status",
      header: "Status",
      align: "center",
      render: (s) => (
        <Badge variant={SETTLEMENT_STATUS_TONE[s.status]} className="text-[10px]">
          {SETTLEMENT_STATUS_LABEL[s.status]}
        </Badge>
      ),
    },
    {
      key: "notes",
      header: "Notes",
      render: (s) => (
        <span className="text-xs text-muted-foreground">{s.notes ?? "—"}</span>
      ),
    },
  ];

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Finance"
        title="Payroll Settlement"
        description="Catat pembayaran payroll dan sinkron otomatis ke Finance Expense."
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <Label className="text-xs text-muted-foreground">Periode</Label>
            <Input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="h-8 w-[150px]"
            />
            <span className="text-muted-foreground">–</span>
            <Input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="h-8 w-[150px]"
            />
          </div>
        }
      />

      {/* KPI */}
      <AnalyticsSection title="Ringkasan Settlement">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
          <KPICard
            label="Total Payroll"
            value={formatIDR(kpi.totalPayroll)}
            icon={CircleDollarSign}
            deltaPct={kpi.payrollGrowth}
          />
          <KPICard
            label="Total Paid"
            value={formatIDR(kpi.totalPaid)}
            tone="positive"
            icon={Banknote}
            hint={`${Math.round(kpi.paidRatio * 100)}% dari total`}
          />
          <KPICard
            label="Total Unpaid"
            value={formatIDR(kpi.totalUnpaid)}
            tone={kpi.totalUnpaid > 0 ? "warning" : "muted"}
            icon={Wallet}
          />
          <KPICard
            label="Outstanding"
            value={formatIDR(kpi.totalOutstanding)}
            tone={kpi.totalOutstanding > 0 ? "destructive" : "muted"}
            icon={Coins}
          />
          <KPICard
            label="Operator Paid"
            value={formatNumber(kpi.operatorPaid)}
            hint={`dari ${rows.length} operator`}
            icon={Users}
          />
          <KPICard
            label="Rata-rata Payroll"
            value={formatIDR(kpi.averagePayroll)}
            icon={Receipt}
          />
        </div>
      </AnalyticsSection>

      {/* Pending table + Insights */}
      <div className="grid gap-4 lg:grid-cols-[minmax(0,2.4fr)_minmax(0,1fr)]">
        <TableCard<SettlementRow>
          title="Payroll & Settlement"
          subtitle="Payroll periode aktif — klik Bayar untuk mencatat pembayaran."
          columns={cols}
          rows={rows}
          emptyMessage="Belum ada payroll pada periode ini. Jalankan Payroll Calculation dulu."
        />
        <InsightCard items={insights} />
      </div>

      {/* History */}
      <TableCard<PayrollSettlement>
        title="Settlement History"
        subtitle="Riwayat pembayaran payroll pada periode aktif."
        columns={historyCols}
        rows={history}
        emptyMessage="Belum ada pembayaran tercatat."
      />

      <PaymentDialog
        target={payTarget}
        onClose={() => setPayTarget(null)}
        onSaved={() => {
          bump();
          setPayTarget(null);
        }}
      />

      <OperatorDetailSheet
        target={detailTarget}
        onClose={() => setDetailTarget(null)}
      />
    </AnalyticsLayout>
  );
}

/* ---------------- Payment Dialog ---------------- */

function PaymentDialog({
  target,
  onClose,
  onSaved,
}: {
  target: SettlementRow | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [amount, setAmount] = useState<string>("");
  const [method, setMethod] = useState<PaymentMethod>("CASH");
  const [date, setDate] = useState<string>(ymd(new Date()));
  const [notes, setNotes] = useState<string>("");

  useMemo(() => {
    if (target) {
      setAmount(String(target.outstanding || target.netSalary));
      setMethod("CASH");
      setDate(ymd(new Date()));
      setNotes("");
    }
  }, [target]);

  if (!target) return null;

  function submit() {
    if (!target) return;
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast.error("Jumlah pembayaran tidak valid.");
      return;
    }
    if (amt > target.netSalary) {
      toast.error("Jumlah tidak boleh melebihi Net Salary.");
      return;
    }
    const nextPaid = target.totalPaid + amt;
    const status = deriveStatus(target.netSalary, nextPaid);
    const paymentDateIso = new Date(`${date}T00:00:00`).toISOString();

    // 1) Tulis Finance Expense terlebih dulu — Settlement menjaga referensinya.
    const expense = financeExpenses.create({
      at: paymentDateIso,
      description: `Payroll ${target.operator}`,
      category: "payroll",
      pot: "operational",
      payment: PAYMENT_METHOD_TO_FINANCE[method],
      amount: Math.round(amt),
    });

    // 2) Catat Settlement.
    payrollSettlementService.create({
      payrollId: target.payrollId,
      operatorId: target.operatorId,
      paidAmount: amt,
      paymentMethod: method,
      paymentDate: paymentDateIso,
      notes,
      status,
      financeExpenseId: expense.id,
    });

    // 3) Jika lunas — tandai payroll record sebagai PAID (jika semua operator lunas).
    if (status === "PAID") {
      const allRecords = payrollService.list();
      const rec = allRecords.find((r) => r.id === target.payrollId);
      if (rec) {
        const rows = buildRemainingCheck(rec.id, target.operatorId);
        const stillOutstanding = rec.rows.some((snap) => {
          if (snap.operatorId === target.operatorId) return false; // this one now paid
          const paid = rows.get(snap.operatorId) ?? 0;
          return paid < snap.netSalary && snap.netSalary > 0;
        });
        if (!stillOutstanding) {
          payrollService.setStatus(rec.id, "PAID");
        }
      }
    }

    toast.success(`Pembayaran ${target.operator} tercatat (${SETTLEMENT_STATUS_LABEL[status]}).`);
    onSaved();
  }

  return (
    <Dialog open={!!target} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Bayar Payroll</DialogTitle>
          <DialogDescription>
            Catat pembayaran untuk {target.operator}. Transaksi akan otomatis
            masuk ke Finance sebagai Expense kategori Payroll.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-2 text-sm">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-xs text-muted-foreground">Operator</Label>
              <div className="mt-1 font-medium">{target.operator}</div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Payroll Period</Label>
              <div className="mt-1 text-xs">{target.periodLabel}</div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Net Salary</Label>
              <div className="mt-1 font-semibold">{formatIDR(target.netSalary)}</div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Sudah Dibayar</Label>
              <div className="mt-1">{formatIDR(target.totalPaid)}</div>
            </div>
          </div>

          <div>
            <Label htmlFor="paid-amount">Paid Amount</Label>
            <Input
              id="paid-amount"
              type="number"
              min={0}
              max={target.netSalary}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <p className="mt-1 text-xs text-muted-foreground">
              Outstanding: {formatIDR(target.outstanding)}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label>Payment Method</Label>
              <Select value={method} onValueChange={(v) => setMethod(v as PaymentMethod)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => (
                    <SelectItem key={m} value={m}>
                      {PAYMENT_METHOD_LABEL[m]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="paid-date">Payment Date</Label>
              <Input
                id="paid-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="paid-notes">Notes</Label>
            <Textarea
              id="paid-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Opsional…"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={submit}>
            <Banknote className="mr-1.5 h-4 w-4" /> Confirm Payment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Baca ulang settlement per operator untuk 1 payroll (exclude satu operator target). */
function buildRemainingCheck(payrollId: string, _excludeOperatorId: string) {
  const settlements = payrollSettlementService.listByPayroll(payrollId);
  const paidBy = new Map<string, number>();
  for (const s of settlements) {
    if (s.status === "VOID") continue;
    paidBy.set(s.operatorId, (paidBy.get(s.operatorId) ?? 0) + s.paidAmount);
  }
  return paidBy;
}

/* ---------------- Operator Detail Sheet ---------------- */

function OperatorDetailSheet({
  target,
  onClose,
}: {
  target: SettlementRow | null;
  onClose: () => void;
}) {
  const settlements = useMemo(() => {
    if (!target) return [];
    return payrollSettlementService.listByOperator(target.payrollId, target.operatorId);
  }, [target]);

  const snapshot = useMemo(() => {
    if (!target) return null;
    const rec = payrollService.list().find((r) => r.id === target.payrollId);
    return rec?.rows.find((r) => r.operatorId === target.operatorId) ?? null;
  }, [target]);

  if (!target) return null;

  return (
    <Sheet open={!!target} onOpenChange={(v) => !v && onClose()}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>{target.operator}</SheetTitle>
          <SheetDescription>
            {target.periodLabel} · {target.role}
          </SheetDescription>
        </SheetHeader>

        <div className="mt-4 space-y-4 text-sm">
          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Attendance Summary
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Hari Kerja" value={formatNumber(snapshot?.workingDays ?? 0)} />
              <Stat
                label="Jam Kerja"
                value={`${(snapshot?.workingHours ?? 0).toFixed(1)}j`}
              />
            </div>
          </section>

          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Production Summary
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Produksi" value={formatNumber(snapshot?.productionQty ?? 0)} />
              <Stat
                label="Insentif Produksi"
                value={formatIDR(snapshot?.productionIncentive ?? 0)}
              />
              <Stat label="Bonus" value={formatIDR(snapshot?.bonus ?? 0)} />
              <Stat label="Additional" value={formatIDR(snapshot?.additional ?? 0)} />
              <Stat
                label="Potongan"
                value={formatIDR(snapshot?.deduction ?? 0)}
                tone={
                  (snapshot?.deduction ?? 0) > 0 ? "destructive" : undefined
                }
              />
              <Stat
                label="Net Salary"
                value={formatIDR(snapshot?.netSalary ?? target.netSalary)}
                tone="strong"
              />
            </div>
          </section>

          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Settlement History
            </h3>
            {settlements.length === 0 ? (
              <p className="rounded-md border border-dashed py-4 text-center text-xs text-muted-foreground">
                Belum ada pembayaran.
              </p>
            ) : (
              <ul className="space-y-2">
                {settlements.map((s) => (
                  <li
                    key={s.settlementId}
                    className="rounded-md border p-2.5 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{formatIDR(s.paidAmount)}</span>
                      <Badge
                        variant={SETTLEMENT_STATUS_TONE[s.status]}
                        className="text-[10px]"
                      >
                        {SETTLEMENT_STATUS_LABEL[s.status]}
                      </Badge>
                    </div>
                    <div className="mt-1 flex items-center justify-between text-muted-foreground">
                      <span>{fmtDateTime(s.paymentDate)}</span>
                      <span>{PAYMENT_METHOD_LABEL[s.paymentMethod]}</span>
                    </div>
                    {s.notes ? (
                      <p className="mt-1 text-muted-foreground">{s.notes}</p>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "destructive" | "strong";
}) {
  const cls =
    tone === "destructive"
      ? "text-destructive"
      : tone === "strong"
        ? "font-semibold"
        : "";
  return (
    <div className="rounded-md border bg-muted/30 px-2.5 py-2">
      <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </div>
      <div className={`mt-0.5 tabular-nums ${cls}`}>{value}</div>
    </div>
  );
}