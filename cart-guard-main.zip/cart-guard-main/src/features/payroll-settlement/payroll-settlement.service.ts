/**
 * Payroll Settlement Service — mencatat pembayaran payroll operator.
 *
 * Storage:
 *   - StorageKeys.payrollSettlements → daftar settlement (satu record per pembayaran)
 *
 * PRINSIP:
 *   - Settlement TIDAK menyimpan ulang attendance / production / salary rules.
 *   - Settlement TIDAK menghitung payroll. Amount diambil dari Payroll snapshot.
 *   - Satu payroll+operator dapat memiliki beberapa settlement (partial payment).
 */
import { storage, StorageKeys } from "@/services/storage";
import type { PaymentMethod, SettlementStatus } from "./constants";

export interface PayrollSettlement {
  settlementId: string;
  payrollId: string;
  operatorId: string;
  paidAmount: number;
  paymentMethod: PaymentMethod;
  paymentDate: string; // ISO
  notes?: string;
  status: SettlementStatus;
  /** Finance Expense ID hasil integrasi (jika ada). */
  financeExpenseId?: string;
  createdAt: string;
  updatedAt: string;
}

function now(): string {
  return new Date().toISOString();
}

function readAll(): PayrollSettlement[] {
  return storage.get<PayrollSettlement[]>(StorageKeys.payrollSettlements) ?? [];
}
function writeAll(list: PayrollSettlement[]): void {
  storage.set(StorageKeys.payrollSettlements, list);
}

export interface CreateSettlementInput {
  payrollId: string;
  operatorId: string;
  paidAmount: number;
  paymentMethod: PaymentMethod;
  paymentDate: string;
  notes?: string;
  status: SettlementStatus;
  financeExpenseId?: string;
}

export const payrollSettlementService = {
  list(): PayrollSettlement[] {
    return readAll().sort((a, b) =>
      a.paymentDate < b.paymentDate ? 1 : a.paymentDate > b.paymentDate ? -1 : 0,
    );
  },
  listByPayroll(payrollId: string): PayrollSettlement[] {
    return readAll().filter((s) => s.payrollId === payrollId);
  },
  listByOperator(payrollId: string, operatorId: string): PayrollSettlement[] {
    return readAll().filter(
      (s) => s.payrollId === payrollId && s.operatorId === operatorId,
    );
  },
  create(input: CreateSettlementInput): PayrollSettlement {
    const rec: PayrollSettlement = {
      settlementId: crypto.randomUUID(),
      payrollId: input.payrollId,
      operatorId: input.operatorId,
      paidAmount: Math.max(0, Math.round(input.paidAmount)),
      paymentMethod: input.paymentMethod,
      paymentDate: input.paymentDate,
      notes: input.notes?.trim() || undefined,
      status: input.status,
      financeExpenseId: input.financeExpenseId,
      createdAt: now(),
      updatedAt: now(),
    };
    writeAll([...readAll(), rec]);
    return rec;
  },
  update(
    settlementId: string,
    patch: Partial<Omit<PayrollSettlement, "settlementId" | "createdAt">>,
  ): void {
    const list = readAll();
    const idx = list.findIndex((s) => s.settlementId === settlementId);
    if (idx === -1) return;
    const arr = [...list];
    arr[idx] = { ...arr[idx], ...patch, updatedAt: now() };
    writeAll(arr);
  },
  remove(settlementId: string): void {
    writeAll(readAll().filter((s) => s.settlementId !== settlementId));
  },
  /** Total nilai yang sudah dibayar untuk 1 operator di 1 payroll (exclude VOID). */
  totalPaidFor(payrollId: string, operatorId: string): number {
    return readAll()
      .filter(
        (s) =>
          s.payrollId === payrollId &&
          s.operatorId === operatorId &&
          s.status !== "VOID",
      )
      .reduce((sum, s) => sum + s.paidAmount, 0);
  },
};