/**
 * Payroll Settlement — rule-based insights (BUKAN AI).
 */
import type { InsightItem } from "@/components/analytics";
import { formatIDR } from "@/lib/format";
import { SETTLEMENT_INSIGHT_THRESHOLDS } from "./constants";
import type { SettlementKPI, SettlementRow } from "./data";

export function buildSettlementInsights(
  rows: SettlementRow[],
  kpi: SettlementKPI,
): InsightItem[] {
  const items: InsightItem[] = [];
  if (rows.length === 0) return items;

  const pct = Math.round(kpi.paidRatio * 100);
  if (kpi.paidRatio >= SETTLEMENT_INSIGHT_THRESHOLDS.nearComplete && kpi.paidRatio < 1) {
    items.push({
      level: "positive",
      title: `Payroll sudah dibayar ${pct}%`,
      detail: `Sisa outstanding ${formatIDR(kpi.totalOutstanding)}.`,
    });
  } else if (kpi.paidRatio >= 1 && kpi.totalPayroll > 0) {
    items.push({
      level: "positive",
      title: "Semua payroll periode ini sudah lunas",
      detail: `Total dibayar ${formatIDR(kpi.totalPaid)}.`,
    });
  } else if (kpi.totalPayroll > 0) {
    items.push({
      level: "info",
      title: `Baru ${pct}% payroll terbayar`,
      detail: `Outstanding ${formatIDR(kpi.totalOutstanding)}.`,
    });
  }

  if (kpi.totalOutstanding > 0) {
    items.push({
      level: "warning",
      title: `Outstanding payroll ${formatIDR(kpi.totalOutstanding)}`,
      detail: `${rows.filter((r) => r.outstanding > 0).length} operator belum lunas.`,
    });
  }

  if (kpi.topOperator && kpi.topOperator.netSalary > 0) {
    items.push({
      level: "info",
      title: `Payroll terbesar: ${kpi.topOperator.operator}`,
      detail: `Net ${formatIDR(kpi.topOperator.netSalary)} untuk periode ini.`,
    });
  }

  if (typeof kpi.payrollGrowth === "number") {
    const g = kpi.payrollGrowth;
    if (g >= SETTLEMENT_INSIGHT_THRESHOLDS.expenseGrowthWarn) {
      items.push({
        level: "warning",
        title: "Pengeluaran payroll naik",
        detail: `Naik ${(g * 100).toFixed(1)}% vs periode sebelumnya (${formatIDR(kpi.previousPayroll)}).`,
      });
    } else if (g <= -SETTLEMENT_INSIGHT_THRESHOLDS.expenseGrowthWarn) {
      items.push({
        level: "info",
        title: "Pengeluaran payroll turun",
        detail: `Turun ${(Math.abs(g) * 100).toFixed(1)}% vs periode sebelumnya.`,
      });
    }
  }

  return items;
}