/**
 * Payroll Settlement — data layer (READ-ONLY dari Payroll Module).
 *
 * Sumber:
 *   - payrollService.list() → daftar payroll period dengan snapshot per operator
 *   - payrollSettlementService → catatan pembayaran
 *
 * Modul ini TIDAK menghitung ulang payroll. Nilai netSalary dibaca apa adanya
 * dari snapshot payroll (Payroll adalah owner data-nya).
 */
import { payrollService, type PayrollRecord } from "@/features/payroll/payroll.service";
import type { PayrollStatus } from "@/features/payroll/constants";
import {
  payrollSettlementService,
  type PayrollSettlement,
} from "./payroll-settlement.service";
import type { SettlementStatus } from "./constants";

export interface SettlementRow {
  payrollId: string;
  operatorId: string;
  operator: string;
  role: string;
  periodStart: string;
  periodEnd: string;
  periodLabel: string;
  payrollStatus: PayrollStatus;
  netSalary: number;
  totalPaid: number;
  outstanding: number;
  settlementStatus: SettlementStatus;
  /** Settlement terakhir (jika ada). */
  lastSettlement?: PayrollSettlement;
}

function fmtDate(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function periodLabelOf(rec: PayrollRecord): string {
  const from = new Date(rec.periodStart);
  const to = new Date(rec.periodEnd);
  to.setDate(to.getDate() - 1);
  return `${fmtDate(rec.periodStart)} – ${fmtDate(to.toISOString())}`;
}

function deriveStatus(net: number, paid: number): SettlementStatus {
  if (paid <= 0) return "UNPAID";
  if (paid >= net) return "PAID";
  return "PARTIALLY_PAID";
}

export interface SettlementFilter {
  /** Filter payroll periods intersecting this ISO range [from, to). */
  periodFrom?: string;
  periodTo?: string;
}

function inFilter(rec: PayrollRecord, f: SettlementFilter): boolean {
  if (!f.periodFrom && !f.periodTo) return true;
  const start = new Date(rec.periodStart).getTime();
  const end = new Date(rec.periodEnd).getTime();
  const from = f.periodFrom ? new Date(f.periodFrom).getTime() : -Infinity;
  const to = f.periodTo ? new Date(f.periodTo).getTime() : Infinity;
  return end > from && start < to;
}

export function buildSettlementRows(filter: SettlementFilter = {}): SettlementRow[] {
  const payrolls = payrollService.list();
  const all = payrollSettlementService.list();
  const byKey = new Map<string, PayrollSettlement[]>();
  for (const s of all) {
    const key = `${s.payrollId}:${s.operatorId}`;
    const arr = byKey.get(key) ?? [];
    arr.push(s);
    byKey.set(key, arr);
  }

  const rows: SettlementRow[] = [];
  for (const rec of payrolls) {
    if (!inFilter(rec, filter)) continue;
    const label = periodLabelOf(rec);
    for (const snap of rec.rows) {
      const key = `${rec.id}:${snap.operatorId}`;
      const settlements = byKey.get(key) ?? [];
      const active = settlements.filter((s) => s.status !== "VOID");
      const totalPaid = active.reduce((sum, s) => sum + s.paidAmount, 0);
      const outstanding = Math.max(0, snap.netSalary - totalPaid);
      const settlementStatus = deriveStatus(snap.netSalary, totalPaid);
      const lastSettlement = [...settlements].sort((a, b) =>
        a.paymentDate < b.paymentDate ? 1 : -1,
      )[0];
      rows.push({
        payrollId: rec.id,
        operatorId: snap.operatorId,
        operator: snap.operator,
        role: snap.role,
        periodStart: rec.periodStart,
        periodEnd: rec.periodEnd,
        periodLabel: label,
        payrollStatus: rec.status,
        netSalary: snap.netSalary,
        totalPaid,
        outstanding,
        settlementStatus,
        lastSettlement,
      });
    }
  }
  return rows;
}

export interface SettlementKPI {
  totalPayroll: number;
  totalPaid: number;
  totalUnpaid: number;
  totalOutstanding: number;
  operatorPaid: number;
  averagePayroll: number;
  paidRatio: number;
  previousPayroll: number;
  payrollGrowth: number | null;
  topOperator?: { operator: string; netSalary: number };
}

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur === 0 ? 0 : null;
  return (cur - prev) / prev;
}

export function computeSettlementKPI(rows: SettlementRow[]): SettlementKPI {
  const totalPayroll = rows.reduce((s, r) => s + r.netSalary, 0);
  const totalPaid = rows.reduce((s, r) => s + r.totalPaid, 0);
  const totalOutstanding = rows.reduce((s, r) => s + r.outstanding, 0);
  const totalUnpaid = rows
    .filter((r) => r.settlementStatus === "UNPAID")
    .reduce((s, r) => s + r.netSalary, 0);
  const operatorPaid = rows.filter((r) => r.settlementStatus === "PAID").length;
  const paidRows = rows.filter((r) => r.netSalary > 0);
  const averagePayroll =
    paidRows.length > 0 ? totalPayroll / paidRows.length : 0;
  const paidRatio = totalPayroll > 0 ? totalPaid / totalPayroll : 0;
  const top = [...rows].sort((a, b) => b.netSalary - a.netSalary)[0];
  return {
    totalPayroll,
    totalPaid,
    totalUnpaid,
    totalOutstanding,
    operatorPaid,
    averagePayroll,
    paidRatio,
    previousPayroll: 0,
    payrollGrowth: null,
    topOperator: top ? { operator: top.operator, netSalary: top.netSalary } : undefined,
  };
}

/**
 * Untuk perbandingan periode: hitung total payroll pada payroll records yang
 * berada SEBELUM `filter.periodFrom` (dibatasi durasi yang sama).
 */
export function previousPeriodPayroll(filter: SettlementFilter): number {
  if (!filter.periodFrom || !filter.periodTo) return 0;
  const from = new Date(filter.periodFrom).getTime();
  const to = new Date(filter.periodTo).getTime();
  const span = to - from;
  const prevFrom = new Date(from - span).toISOString();
  const prevTo = new Date(from).toISOString();
  const prev = buildSettlementRows({ periodFrom: prevFrom, periodTo: prevTo });
  return prev.reduce((s, r) => s + r.netSalary, 0);
}

export function withPeriodComparison(
  rows: SettlementRow[],
  filter: SettlementFilter,
): SettlementKPI {
  const kpi = computeSettlementKPI(rows);
  const previousPayroll = previousPeriodPayroll(filter);
  return {
    ...kpi,
    previousPayroll,
    payrollGrowth: pctChange(kpi.totalPayroll, previousPayroll),
  };
}

export type { PayrollRecord };