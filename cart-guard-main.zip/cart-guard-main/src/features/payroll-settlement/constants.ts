/**
 * Payroll Settlement Module — enum & label constants.
 *
 * WAJIB: semua enum & label untuk Settlement diambil dari file ini.
 * Dilarang hardcode string status/metode di UI.
 */
import type { FinancePayment } from "@/services/types";

/* -------- Settlement Status -------- */

export type SettlementStatus = "UNPAID" | "PARTIALLY_PAID" | "PAID" | "VOID";

export const SETTLEMENT_STATUSES: SettlementStatus[] = [
  "UNPAID",
  "PARTIALLY_PAID",
  "PAID",
  "VOID",
];

export const SETTLEMENT_STATUS_LABEL: Record<SettlementStatus, string> = {
  UNPAID: "Belum Dibayar",
  PARTIALLY_PAID: "Sebagian",
  PAID: "Lunas",
  VOID: "Void",
};

export const SETTLEMENT_STATUS_TONE: Record<
  SettlementStatus,
  "default" | "secondary" | "outline" | "destructive"
> = {
  UNPAID: "outline",
  PARTIALLY_PAID: "secondary",
  PAID: "default",
  VOID: "destructive",
};

/* -------- Payment Method -------- */

export type PaymentMethod =
  | "CASH"
  | "BANK_TRANSFER"
  | "QRIS"
  | "EWALLET"
  | "OTHER";

export const PAYMENT_METHODS: PaymentMethod[] = [
  "CASH",
  "BANK_TRANSFER",
  "QRIS",
  "EWALLET",
  "OTHER",
];

export const PAYMENT_METHOD_LABEL: Record<PaymentMethod, string> = {
  CASH: "Cash",
  BANK_TRANSFER: "Transfer Bank",
  QRIS: "QRIS",
  EWALLET: "E-Wallet",
  OTHER: "Lainnya",
};

/**
 * Mapping ke Finance payment channel (untuk pencatatan Expense).
 */
export const PAYMENT_METHOD_TO_FINANCE: Record<PaymentMethod, FinancePayment> = {
  CASH: "cash",
  BANK_TRANSFER: "bank",
  QRIS: "qris",
  EWALLET: "dompet",
  OTHER: "cash",
};

/* -------- Insight Thresholds -------- */

export const SETTLEMENT_INSIGHT_THRESHOLDS = {
  /** Persentase pembayaran yang dianggap "hampir selesai". */
  nearComplete: 0.8,
  /** Persentase kenaikan pengeluaran payroll vs periode sebelumnya. */
  expenseGrowthWarn: 0.1,
} as const;