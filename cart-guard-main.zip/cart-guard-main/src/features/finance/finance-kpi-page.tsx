import { useMemo } from "react";
import { formatIDR } from "@/lib/format";
import { financialKpis } from "@/services/finance-projection.service";
import { useFinanceRefresh } from "@/hooks/use-finance-refresh";
import { FinancePageHeader, SectionTitle } from "./_shared";
import { FinanceSummaryCard } from "./_shared-v2";

export function FinanceKpiPage() {
  const tick = useFinanceRefresh();
  const k = useMemo(() => financialKpis(), [tick]);
  const pct = (n: number) => `${(n * 100).toFixed(1)}%`;
  return (
    <div className="space-y-8">
      <FinancePageHeader
        title="Financial KPI"
        description="Indikator performa keuangan turunan dari data yang sudah ada."
      />
      <section>
        <SectionTitle title="KPI Bulan Berjalan" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <FinanceSummaryCard label="Average Order Value" value={formatIDR(k.averageOrderValue)} />
          <FinanceSummaryCard
            label="Expense Ratio"
            value={pct(k.expenseRatio)}
            tone={k.expenseRatio > 0.4 ? "warning" : "default"}
            hint="Opex / Omset"
          />
          <FinanceSummaryCard
            label="Operating Ratio"
            value={pct(k.operatingRatio)}
            hint="(HPP + Opex) / Omset"
            tone={k.operatingRatio > 0.85 ? "warning" : "default"}
          />
          <FinanceSummaryCard
            label="Debt Ratio"
            value={pct(k.debtRatio)}
            hint="Sisa Hutang / Omset"
          />
          <FinanceSummaryCard
            label="Revenue Growth"
            value={pct(k.revenueGrowth)}
            tone={k.revenueGrowth >= 0 ? "positive" : "warning"}
            hint="vs bulan sebelumnya"
          />
          <FinanceSummaryCard
            label="Profit Growth"
            value={pct(k.profitGrowth)}
            tone={k.profitGrowth >= 0 ? "positive" : "warning"}
            hint="vs bulan sebelumnya"
          />
          <FinanceSummaryCard
            label="Cash Burn / Hari"
            value={formatIDR(k.cashBurnPerDay)}
            tone={k.cashBurnPerDay > 0 ? "warning" : "positive"}
          />
          <FinanceSummaryCard
            label="Runway"
            value={k.runwayDays === null ? "Tak terbatas" : `${k.runwayDays} hari`}
            tone={k.runwayDays !== null && k.runwayDays <= 30 ? "destructive" : "default"}
          />
        </div>
      </section>
    </div>
  );
}
