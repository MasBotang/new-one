/**
 * Finance V2 shared components — additive, tidak mengubah _shared.tsx.
 */

import type { ComponentType, ReactNode } from "react";
import { Download, FileSpreadsheet, FileText, Sheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { googleSpreadsheetService } from "@/services/google-spreadsheet.service";

/* ---------------- Chart / Summary / Trend / Insight Cards ---------------- */

export function FinanceChartCard({
  title,
  subtitle,
  action,
  children,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <Card className="rounded-xl">
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0">
        <div className="min-w-0">
          <CardTitle className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            {title}
          </CardTitle>
          {subtitle ? (
            <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>
          ) : null}
        </div>
        {action}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export function FinanceSummaryCard({
  label,
  value,
  hint,
  tone = "default",
  icon: Icon,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "positive" | "warning" | "muted" | "destructive";
  icon?: ComponentType<{ className?: string }>;
}) {
  const toneCls =
    tone === "positive"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "warning"
        ? "text-amber-600 dark:text-amber-400"
        : tone === "destructive"
          ? "text-destructive"
          : tone === "muted"
            ? "text-muted-foreground"
            : "text-foreground";
  return (
    <Card className="rounded-xl">
      <CardContent className="flex flex-col gap-2 p-5">
        <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          {Icon ? <Icon className="h-3.5 w-3.5" /> : null}
          <span className="truncate">{label}</span>
        </div>
        <div className={`font-display text-2xl font-semibold tabular-nums ${toneCls}`}>
          {value}
        </div>
        {hint ? <div className="text-xs text-muted-foreground">{hint}</div> : null}
      </CardContent>
    </Card>
  );
}

export function FinanceTrendCard({
  title,
  values,
  formatValue,
}: {
  title: string;
  values: number[];
  formatValue?: (n: number) => string;
}) {
  const max = Math.max(1, ...values.map((v) => Math.abs(v)));
  return (
    <FinanceChartCard title={title}>
      <div className="flex h-24 items-end gap-1">
        {values.map((v, i) => (
          <div
            key={i}
            title={formatValue ? formatValue(v) : String(v)}
            className={`flex-1 rounded-sm ${v >= 0 ? "bg-primary/70" : "bg-amber-500/70"}`}
            style={{ height: `${(Math.abs(v) / max) * 100}%` }}
          />
        ))}
      </div>
    </FinanceChartCard>
  );
}

export function FinanceInsightCard({
  title,
  items,
}: {
  title: string;
  items: { level: "green" | "yellow" | "red" | "info"; text: string; detail?: string }[];
}) {
  const dot: Record<string, string> = {
    green: "bg-emerald-500",
    yellow: "bg-amber-500",
    red: "bg-red-500",
    info: "bg-muted-foreground/60",
  };
  return (
    <Card className="rounded-xl">
      <CardHeader>
        <CardTitle className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground">Belum ada notifikasi.</p>
        ) : (
          <ul className="space-y-2.5">
            {items.map((it, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm">
                <span className={`mt-1.5 h-2 w-2 rounded-full ${dot[it.level]}`} />
                <div className="min-w-0">
                  <div className="font-medium text-foreground">{it.text}</div>
                  {it.detail ? (
                    <div className="text-xs text-muted-foreground">{it.detail}</div>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

/* ---------------- Table toolbar ---------------- */

export function FinanceTableToolbar({
  title,
  count,
  children,
}: {
  title?: string;
  count?: number;
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 px-3 py-2">
      <div className="flex items-center gap-2">
        {title ? <span className="text-sm font-medium">{title}</span> : null}
        {typeof count === "number" ? (
          <Badge variant="secondary" className="text-[10px]">
            {count}
          </Badge>
        ) : null}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

/* ---------------- Export menu ---------------- */

export function FinanceExportMenu({
  label = "Export",
  onExportExcel,
  onExportCSV,
  size = "sm",
}: {
  label?: string;
  onExportExcel?: () => void;
  onExportCSV?: () => void;
  size?: "sm" | "default";
}) {
  const handlePush = async () => {
    if (!googleSpreadsheetService.isConfigured()) {
      toast.info("Push ke Google Spreadsheet — Coming Soon", {
        description: "Integrasi akan aktif setelah OAuth Google dikonfigurasi.",
      });
      return;
    }
    const res = await googleSpreadsheetService.pushLedger([]);
    if (!res.ok) toast.info(res.message ?? "Coming Soon");
  };
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size={size} className="gap-1.5">
          <Download className="h-3.5 w-3.5" />
          {label}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Export</DropdownMenuLabel>
        <DropdownMenuItem onClick={onExportExcel} disabled={!onExportExcel}>
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          Excel (.xlsx)
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onExportCSV} disabled={!onExportCSV}>
          <FileText className="mr-2 h-4 w-4" />
          CSV
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handlePush}>
          <Sheet className="mr-2 h-4 w-4" />
          Push to Google Spreadsheet
          <Badge variant="secondary" className="ml-auto text-[10px]">
            Soon
          </Badge>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
