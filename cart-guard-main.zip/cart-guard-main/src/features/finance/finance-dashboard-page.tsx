import { useEffect, useMemo, useState } from "react";
import { useFinanceRefresh } from "@/hooks/use-finance-refresh";
import { Link } from "@tanstack/react-router";
import {
  BadgePercent,
  Coins,
  Landmark,
  PiggyBank,
  Plus,
  ReceiptText,
  Sparkles,
  Wallet,
  Wrench,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatIDR } from "@/lib/format";
import { financeAnalytics, financeSettings } from "@/services/finance.service";
import { financeAlerts } from "@/services/finance-projection.service";
import { FinanceInsightCard } from "./_shared-v2";
import {
  FUND_POT_LABEL,
  FINANCE_PAYMENT_LABEL,
  type FundPot,
  type FinancePayment,
} from "@/services/types";
import { FinancePageHeader, SectionTitle } from "./_shared";

// Finance Overview — operational only.
// TODO(analytics): Financial Health score, Top Insight, Expense Distribution
// (pie), Profit Trend (area chart), Cashflow 30-day summary, dan recap "Bulan
// berjalan" telah dihapus dari Overview. Semua elemen tersebut akan dipindahkan
// ke Analytics Module pada Phase berikutnya.

const POT_ICON: Record<FundPot, React.ComponentType<{ className?: string }>> = {
  owner: PiggyBank,
  development: Sparkles,
  operational: Wrench,
  debt: Landmark,
};

const POT_ROUTE: Record<FundPot, string> = {
  owner: "/finance/owner-fund",
  development: "/finance/development-fund",
  operational: "/finance/operational-fund",
  debt: "/finance/debt",
};

const CHANNEL_ICON: Record<FinancePayment, React.ComponentType<{ className?: string }>> = {
  cash: Coins,
  qris: BadgePercent,
  bank: Landmark,
  dompet: Wallet,
};

const OVERVIEW_POTS: FundPot[] = ["owner", "development", "operational", "debt"];

export function FinanceDashboardPage() {
  const tick = useFinanceRefresh();
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  useEffect(() => {
    setLastRefresh(new Date());
  }, [tick]);

  const today = useMemo(() => financeAnalytics.today(), [tick]);
  const cashPos = useMemo(() => financeAnalytics.cashPosition(), [tick]);
  const settings = useMemo(() => financeSettings.get(), [tick]);
  const alerts = useMemo(() => financeAlerts(), [tick]);

  const potStats = useMemo(
    () => OVERVIEW_POTS.map((p) => ({ pot: p, ...financeAnalytics.potBalance(p) })),
    [tick],
  );

  const refreshLabel = lastRefresh.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div className="space-y-8">
      <FinancePageHeader
        title="Finance Overview"
        description="Ringkasan operasional keuangan: saldo dana, posisi kas, dan alert."
        meta={
          <>
            <span>Periode: Bulan berjalan</span>
            <span aria-hidden>·</span>
            <span>Last refresh {refreshLabel}</span>
          </>
        }
        actions={
          <>
            <Button asChild variant="outline" size="sm">
              <Link to="/finance/ledger">Buka Ledger</Link>
            </Button>
            <Button asChild size="sm">
              <Link to="/finance/expenses">Catat Pengeluaran</Link>
            </Button>
          </>
        }
      />

      {/* Section 1 — Saldo Dana per Pos (operational) */}
      <section>
        <SectionTitle
          title="Saldo Dana"
          subtitle={`Alokasi ${settings.allocation.owner}/${settings.allocation.development}/${settings.allocation.operational}/${settings.allocation.debt}`}
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {potStats.map(({ pot, balance }) => {
            const Icon = POT_ICON[pot];
            return (
              <Link
                key={pot}
                to={POT_ROUTE[pot]}
                className="group block rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                aria-label={`Buka ${FUND_POT_LABEL[pot]}`}
              >
                <Card className="h-full rounded-xl transition-all duration-200 group-hover:-translate-y-0.5 group-hover:border-primary/40 group-hover:shadow-md">
                  <CardContent className="flex h-full flex-col gap-3 p-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                        <Icon className="h-3.5 w-3.5" aria-hidden />
                        {FUND_POT_LABEL[pot]}
                      </div>
                      <Badge variant="secondary" className="text-[10px]">
                        {settings.allocation[pot]}%
                      </Badge>
                    </div>
                    <div
                      className={`font-display text-2xl font-semibold tabular-nums leading-tight ${
                        balance < 0 ? "text-amber-600 dark:text-amber-400" : ""
                      }`}
                    >
                      {formatIDR(balance)}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Section 2 — Cash Position per Channel */}
      <section>
        <SectionTitle title="Cash Position" subtitle="Saldo per channel pembayaran" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cashPos.map(({ channel, balance }) => {
            const Icon = CHANNEL_ICON[channel];
            return (
              <Card
                key={channel}
                className="h-full rounded-xl transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md"
              >
                <CardContent className="flex h-full items-center gap-4 p-5">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border bg-muted/40 text-foreground">
                    <Icon className="h-5 w-5" aria-hidden />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                      {FINANCE_PAYMENT_LABEL[channel]}
                    </div>
                    <div
                      className={`font-display text-xl font-semibold tabular-nums ${
                        balance < 0 ? "text-amber-600 dark:text-amber-400" : ""
                      }`}
                    >
                      {formatIDR(balance)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Section 3 — Quick Actions */}
      <section>
        <SectionTitle title="Quick Action" subtitle="Aksi cepat harian" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Button asChild size="lg" className="h-auto justify-start gap-3 py-3">
            <Link to="/finance/expenses">
              <Plus className="h-4 w-4" aria-hidden />
              <span className="flex flex-col items-start leading-tight">
                <span className="text-sm font-semibold">Catat Pengeluaran</span>
                <span className="text-[11px] font-normal opacity-80">Tambah expense baru</span>
              </span>
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="h-auto justify-start gap-3 py-3">
            <Link to="/finance/debt">
              <Landmark className="h-4 w-4" aria-hidden />
              <span className="flex flex-col items-start leading-tight">
                <span className="text-sm font-semibold">Kelola Hutang</span>
                <span className="text-[11px] font-normal text-muted-foreground">Bayar / tambah</span>
              </span>
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="h-auto justify-start gap-3 py-3">
            <Link to="/finance/owner-fund">
              <PiggyBank className="h-4 w-4" aria-hidden />
              <span className="flex flex-col items-start leading-tight">
                <span className="text-sm font-semibold">Pencairan Fund</span>
                <span className="text-[11px] font-normal text-muted-foreground">Owner / Dev / Op</span>
              </span>
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="h-auto justify-start gap-3 py-3">
            <Link to="/finance/ledger">
              <ReceiptText className="h-4 w-4" aria-hidden />
              <span className="flex flex-col items-start leading-tight">
                <span className="text-sm font-semibold">Buka Ledger</span>
                <span className="text-[11px] font-normal text-muted-foreground">Semua transaksi</span>
              </span>
            </Link>
          </Button>
        </div>
      </section>

      {/* Section 4 — Alert Kas Kritis */}
      <section>
        <SectionTitle title="Alert Kas" subtitle="Notifikasi rule-based dari data terkini" />
        <FinanceInsightCard
          title="Alert Center"
          items={alerts.map((a) => ({ level: a.level, text: a.title, detail: a.detail }))}
        />
      </section>

      {/* Section 5 — Ringkasan Transaksi Hari Ini (opsional, non-analytics) */}
      <section>
        <SectionTitle title="Ringkasan Hari Ini" subtitle="Aktivitas transaksi hari berjalan" />
        <Card className="rounded-xl">
          <CardContent className="flex flex-wrap items-center gap-x-8 gap-y-3 p-5 text-sm">
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Transaksi
              </div>
              <div className="font-display text-xl font-semibold tabular-nums">
                {today.orders}
              </div>
            </div>
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Omset
              </div>
              <div className="font-display text-xl font-semibold tabular-nums">
                {formatIDR(today.revenue)}
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
