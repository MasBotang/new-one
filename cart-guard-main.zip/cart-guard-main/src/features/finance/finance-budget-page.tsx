import { useMemo, useState } from "react";
import { Save, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { formatIDR } from "@/lib/format";
import {
  BUDGET_CATEGORY_LABEL,
  budgetRows,
  financeBudgets,
  type BudgetCategory,
} from "@/services/finance-budget.service";
import { FinancePageHeader, SectionTitle } from "./_shared";

const CATS: BudgetCategory[] = [
  "operational",
  "development",
  "marketing",
  "owner_salary",
  "debt",
];

// TODO(analytics): trend/growth/forecasting Budget vs Actual per bulan dan
// chart historis dipindahkan ke Analytics Module pada Phase berikutnya.
// Halaman ini murni operasional: CRUD target bulanan + realisasi bulan berjalan.
export function FinanceBudgetPage() {
  const [tick, setTick] = useState(0);
  const rows = useMemo(() => budgetRows(), [tick]);

  const [draft, setDraft] = useState<Record<BudgetCategory, string>>(() => {
    const init: Record<BudgetCategory, string> = {
      operational: "",
      development: "",
      marketing: "",
      owner_salary: "",
      debt: "",
    };
    for (const b of financeBudgets.list()) init[b.category] = String(b.monthlyAmount);
    return init;
  });

  const save = (c: BudgetCategory) => {
    const n = Number(draft[c].replace(/[^0-9]/g, "")) || 0;
    financeBudgets.upsert(c, n);
    toast.success(`Budget ${BUDGET_CATEGORY_LABEL[c]} disimpan`);
    setTick((t) => t + 1);
  };
  const remove = (c: BudgetCategory) => {
    financeBudgets.remove(c);
    setDraft((d) => ({ ...d, [c]: "" }));
    toast.success(`Budget ${BUDGET_CATEGORY_LABEL[c]} dihapus`);
    setTick((t) => t + 1);
  };

  return (
    <div className="space-y-8">
      <FinancePageHeader
        title="Budget Planning"
        description="Tentukan target budget bulanan per kategori dan pantau realisasinya."
      />

      <section>
        <SectionTitle title="Target Budget Bulanan" />
        <div className="grid gap-3 md:grid-cols-2">
          {CATS.map((c) => (
            <Card key={c} className="rounded-xl">
              <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
                <div className="flex-1">
                  <Label className="text-xs">{BUDGET_CATEGORY_LABEL[c]}</Label>
                  <Input
                    inputMode="numeric"
                    placeholder="0"
                    value={draft[c]}
                    onChange={(e) => setDraft((d) => ({ ...d, [c]: e.target.value }))}
                  />
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => save(c)}>
                    <Save className="mr-1.5 h-3.5 w-3.5" />
                    Simpan
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => remove(c)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle
          title="Realisasi Bulan Berjalan"
          subtitle="Actual dihitung dari expense, withdraw, dan pembayaran hutang bulan berjalan."
        />
        <div className="overflow-hidden rounded-xl border">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-3 py-2">Kategori</th>
                <th className="px-3 py-2 text-right">Budget</th>
                <th className="px-3 py-2 text-right">Actual</th>
                <th className="px-3 py-2 text-right">Remaining</th>
                <th className="px-3 py-2">%</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const pctW = Math.min(100, r.percent);
                const barCls =
                  r.status === "over"
                    ? "bg-red-500"
                    : r.status === "warning"
                      ? "bg-amber-500"
                      : r.status === "empty"
                        ? "bg-muted-foreground/30"
                        : "bg-emerald-500";
                const badgeCls: Record<typeof r.status, string> = {
                  ok: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
                  warning: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
                  over: "bg-red-500/15 text-red-700 dark:text-red-400",
                  empty: "bg-muted text-muted-foreground",
                };
                const badgeText: Record<typeof r.status, string> = {
                  ok: "On track",
                  warning: "Hampir habis",
                  over: "Terlampaui",
                  empty: "Belum diset",
                };
                return (
                  <tr key={r.category} className="border-t">
                    <td className="px-3 py-2 font-medium">{r.label}</td>
                    <td className="px-3 py-2 text-right tabular-nums">
                      {r.budget > 0 ? formatIDR(r.budget) : "—"}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums">{formatIDR(r.actual)}</td>
                    <td
                      className={`px-3 py-2 text-right tabular-nums ${
                        r.remaining < 0 ? "text-red-600 dark:text-red-400" : ""
                      }`}
                    >
                      {r.budget > 0 ? formatIDR(r.remaining) : "—"}
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-24 overflow-hidden rounded-full bg-muted">
                          <div className={`h-full ${barCls}`} style={{ width: `${pctW}%` }} />
                        </div>
                        <span className="tabular-nums text-xs text-muted-foreground">
                          {r.budget > 0 ? `${r.percent.toFixed(0)}%` : "—"}
                        </span>
                      </div>
                    </td>
                    <td className="px-3 py-2">
                      <Badge className={`${badgeCls[r.status]} border-0`}>
                        {badgeText[r.status]}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
