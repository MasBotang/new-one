import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { formatIDR } from "@/lib/format";
import {
  buildReport,
  downloadCSV,
  downloadXLSX,
  reportSummaryRow,
  REPORT_PERIOD_LABEL,
  type ReportPeriod,
} from "@/services/finance-report.service";
import { FinancePageHeader, SectionTitle } from "./_shared";
import { FinanceExportMenu } from "./_shared-v2";

const PERIODS: ReportPeriod[] = ["daily", "weekly", "monthly", "yearly"];

export function FinanceReportsPage() {
  const [period, setPeriod] = useState<ReportPeriod>("monthly");
  const report = useMemo(() => buildReport(period), [period]);

  const rowsForExport = [reportSummaryRow(report)];
  const baseFilename = `laporan-keuangan-${period}-${new Date().toISOString().slice(0, 10)}`;

  return (
    <div className="space-y-8">
      <FinancePageHeader
        title="Reports"
        description="Generator laporan keuangan berdasarkan periode."
        actions={
          <FinanceExportMenu
            onExportExcel={() =>
              downloadXLSX([{ name: "Ringkasan", rows: rowsForExport }], `${baseFilename}.xlsx`)
            }
            onExportCSV={() => downloadCSV(rowsForExport, `${baseFilename}.csv`)}
          />
        }
      />

      <section>
        <SectionTitle title="Pilih Periode" />
        <div className="flex flex-wrap gap-2">
          {PERIODS.map((p) => (
            <Button
              key={p}
              size="sm"
              variant={p === period ? "default" : "outline"}
              onClick={() => setPeriod(p)}
            >
              {REPORT_PERIOD_LABEL[p]}
            </Button>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle
          title="Ringkasan"
          subtitle={`${REPORT_PERIOD_LABEL[period]} — ${report.range.label}`}
        />
        <Card className="rounded-xl">
          <CardContent className="grid gap-4 p-5 md:grid-cols-2 lg:grid-cols-3">
            <Item label="Omset" value={formatIDR(report.revenue)} />
            <Item label="HPP" value={formatIDR(report.hpp)} />
            <Item label="Laba Kotor" value={formatIDR(report.grossProfit)} tone="positive" />
            <Item label="Pengeluaran" value={formatIDR(report.expenses)} tone="warning" />
            <Item
              label="Laba Bersih"
              value={formatIDR(report.netProfit)}
              tone={report.netProfit >= 0 ? "positive" : "destructive"}
            />
            <Item label="Order" value={String(report.orders)} />
            <Item label="Kas Masuk" value={formatIDR(report.cashIn)} tone="positive" />
            <Item label="Kas Keluar" value={formatIDR(report.cashOut)} tone="warning" />
            <Item
              label="Net Cashflow"
              value={formatIDR(report.netCashflow)}
              tone={report.netCashflow >= 0 ? "positive" : "destructive"}
            />
            <Item label="Pencairan Fund" value={formatIDR(report.fundWithdraws)} />
            <Item label="Pembayaran Hutang" value={formatIDR(report.debtPayments)} />
          </CardContent>
        </Card>
      </section>

      <section>
        <SectionTitle title="Output" subtitle="Pilih format ekspor laporan" />
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            onClick={() =>
              downloadXLSX([{ name: "Ringkasan", rows: rowsForExport }], `${baseFilename}.xlsx`)
            }
          >
            Download Excel
          </Button>
          <Button size="sm" variant="outline" onClick={() => downloadCSV(rowsForExport, `${baseFilename}.csv`)}>
            Download CSV
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() =>
              toast.info("PDF Coming Soon", {
                description: "Engine PDF akan ditambahkan di iterasi berikutnya.",
              })
            }
          >
            Download PDF
            <Badge variant="secondary" className="ml-2 text-[10px]">
              Soon
            </Badge>
          </Button>
        </div>
      </section>
    </div>
  );
}

function Item({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: string;
  tone?: "default" | "positive" | "warning" | "destructive";
}) {
  const cls =
    tone === "positive"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "warning"
        ? "text-amber-600 dark:text-amber-400"
        : tone === "destructive"
          ? "text-destructive"
          : "text-foreground";
  return (
    <div>
      <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </div>
      <div className={`mt-1 font-display text-xl font-semibold tabular-nums ${cls}`}>{value}</div>
    </div>
  );
}
