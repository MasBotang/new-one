import { useMemo } from "react";
import { Calendar, Coins, LineChart as LineChartIcon, TrendingDown, TrendingUp, Wallet } from "lucide-react";
import { formatIDR } from "@/lib/format";
import {
  allHorizons,
  currentCashBalance,
  dailyAverages,
} from "@/services/finance-projection.service";
import { FinancePageHeader, SectionTitle } from "./_shared";
import { FinanceChartCard, FinanceSummaryCard } from "./_shared-v2";
import { useFinanceRefresh } from "@/hooks/use-finance-refresh";

export function FinanceCashProjectionPage() {
  const tick = useFinanceRefresh();
  const avgs = useMemo(() => dailyAverages(30), [tick]);
  const horizons = useMemo(() => allHorizons(), [tick]);
  const cashNow = useMemo(() => currentCashBalance(), [tick]);

  return (
    <div className="space-y-8">
      <FinancePageHeader
        title="Cash Projection"
        description="Estimasi kas 30 / 60 / 90 hari berdasarkan rata-rata arus kas 30 hari terakhir. Semua angka bersifat estimasi."
      />

      <section>
        <SectionTitle title="Basis Perhitungan" subtitle="Rata-rata harian 30 hari terakhir" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <FinanceSummaryCard label="Saldo Kas Saat Ini" value={formatIDR(cashNow)} icon={Wallet} />
          <FinanceSummaryCard
            label="Rata-rata Omset/Hari"
            value={formatIDR(avgs.avgRevenue)}
            icon={TrendingUp}
            tone="positive"
          />
          <FinanceSummaryCard
            label="Rata-rata Keluar/Hari"
            value={formatIDR(avgs.avgOutflow)}
            icon={TrendingDown}
            tone="warning"
          />
          <FinanceSummaryCard
            label="Net Cashflow/Hari"
            value={formatIDR(avgs.avgNetCashflow)}
            tone={avgs.avgNetCashflow >= 0 ? "positive" : "destructive"}
            icon={Coins}
          />
        </div>
      </section>

      <section>
        <SectionTitle title="Proyeksi" subtitle="Estimasi 30 / 60 / 90 hari ke depan" />
        <div className="grid gap-4 lg:grid-cols-3">
          {horizons.map((h) => (
            <FinanceChartCard
              key={h.horizonDays}
              title={`${h.horizonDays} Hari`}
              subtitle={
                h.runwayDays !== null
                  ? `Runway ${h.runwayDays} hari`
                  : "Cashflow positif — runway tidak terbatas"
              }
            >
              <dl className="grid grid-cols-1 gap-3 text-sm">
                <Row label="Prediksi Omset" value={formatIDR(h.projectedRevenue)} tone="positive" />
                <Row label="Prediksi Laba Kotor" value={formatIDR(h.projectedGrossProfit)} />
                <Row
                  label="Kebutuhan Operasional"
                  value={formatIDR(h.projectedOperationalNeed)}
                  tone="warning"
                />
                <Row label="Prediksi Kas Keluar" value={formatIDR(h.projectedOutflow)} />
                <Row
                  label="Prediksi Saldo Kas"
                  value={formatIDR(h.projectedCashBalance)}
                  tone={h.projectedCashBalance >= 0 ? "positive" : "destructive"}
                />
                <Row
                  label="Runway"
                  value={h.runwayDays === null ? "Tak terbatas" : `${h.runwayDays} hari`}
                  tone={h.runwayDays !== null && h.runwayDays <= 30 ? "destructive" : "default"}
                  icon={<Calendar className="h-3.5 w-3.5" />}
                />
              </dl>
            </FinanceChartCard>
          ))}
        </div>
      </section>

      <p className="flex items-center gap-2 text-xs text-muted-foreground">
        <LineChartIcon className="h-3.5 w-3.5" />
        Proyeksi menggunakan rata-rata linier — tidak memperhitungkan musiman, event khusus, atau perubahan harga.
      </p>
    </div>
  );
}

function Row({
  label,
  value,
  tone = "default",
  icon,
}: {
  label: string;
  value: string;
  tone?: "default" | "positive" | "warning" | "destructive";
  icon?: React.ReactNode;
}) {
  const cls =
    tone === "positive"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "warning"
        ? "text-amber-600 dark:text-amber-400"
        : tone === "destructive"
          ? "text-destructive"
          : "text-foreground";
  return (
    <div className="flex items-center justify-between border-b border-border/50 pb-2 last:border-0 last:pb-0">
      <dt className="flex items-center gap-1.5 text-muted-foreground">
        {icon}
        {label}
      </dt>
      <dd className={`tabular-nums font-medium ${cls}`}>{value}</dd>
    </div>
  );
}
