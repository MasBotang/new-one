import { Fragment, useMemo, useState } from "react";
import { useFinanceRefresh } from "@/hooks/use-finance-refresh";
import {
  ArrowDownRight,
  ArrowUpRight,
  Inbox,
  ReceiptText,
  Search,
  SlidersHorizontal,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { financeAnalytics } from "@/services/finance.service";
import {
  FINANCE_PAYMENT_LABEL,
  FUND_POT_LABEL,
  type FinancePayment,
  type FundPot,
} from "@/services/types";
import { formatIDR, formatDateTime } from "@/lib/format";
import {
  FinanceEmptyState,
  FinancePageHeader,
  FinanceKpiCard,
} from "./_shared";

export function FinanceLedgerPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [pot, setPot] = useState<"all" | FundPot>("all");
  const [pay, setPay] = useState<"all" | FinancePayment>("all");
  const tick = useFinanceRefresh();

  const all = useMemo(() => financeAnalytics.ledger(), [tick]);
  const categories = useMemo(
    () => Array.from(new Set(all.map((r) => r.category))),
    [all],
  );
  const rows = useMemo(
    () =>
      all.filter((r) => {
        if (cat !== "all" && r.category !== cat) return false;
        if (pot !== "all" && r.pot !== pot) return false;
        if (pay !== "all" && r.payment !== pay) return false;
        if (q && !`${r.description} ${r.refId}`.toLowerCase().includes(q.toLowerCase()))
          return false;
        return true;
      }),
    [all, cat, pot, pay, q],
  );

  const inflow = rows
    .filter((r) => r.direction === "in")
    .reduce((a, r) => a + r.amount, 0);
  const outflow = rows
    .filter((r) => r.direction === "out")
    .reduce((a, r) => a + r.amount, 0);
  const net = inflow - outflow;

  // Group by day for sticky-date timeline visual grouping
  const grouped = useMemo(() => {
    const map = new Map<string, typeof rows>();
    rows.forEach((r) => {
      const d = new Date(r.at);
      const key = d.toISOString().slice(0, 10);
      if (!map.has(key)) map.set(key, [] as typeof rows);
      map.get(key)!.push(r);
    });
    return Array.from(map.entries());
  }, [rows]);

  const activeFilters =
    (cat !== "all" ? 1 : 0) + (pot !== "all" ? 1 : 0) + (pay !== "all" ? 1 : 0);

  return (
    <div className="space-y-6">
      <FinancePageHeader
        title="Finance Ledger"
        description="Semua arus kas masuk & keluar dalam satu timeline."
        meta={
          <>
            <span className="tabular-nums">{rows.length} entri</span>
            <span aria-hidden>·</span>
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden /> {formatIDR(inflow)}
            </span>
            <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
              <ArrowDownRight className="h-3.5 w-3.5" aria-hidden /> {formatIDR(outflow)}
            </span>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <FinanceKpiCard
          label="Total Masuk"
          value={formatIDR(inflow)}
          tone="positive"
          icon={ArrowUpRight}
        />
        <FinanceKpiCard
          label="Total Keluar"
          value={formatIDR(outflow)}
          tone="warning"
          icon={ArrowDownRight}
        />
        <FinanceKpiCard
          label="Net Cashflow"
          value={formatIDR(net)}
          tone={net >= 0 ? "positive" : "warning"}
        />
      </div>

      <Card className="sticky top-0 z-20 rounded-xl border-border/70 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/70">
        <CardContent className="flex flex-wrap items-center gap-2 p-3 sm:p-4">
          <div className="relative min-w-[220px] flex-1">
            <Search
              className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <Input
              className="pl-9"
              placeholder="Cari deskripsi / ref…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              aria-label="Cari ledger"
            />
          </div>
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="w-[170px]" aria-label="Filter kategori">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Kategori</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={pot} onValueChange={(v) => setPot(v as typeof pot)}>
            <SelectTrigger className="w-[170px]" aria-label="Filter pos dana">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Pos Dana</SelectItem>
              {(Object.keys(FUND_POT_LABEL) as FundPot[]).map((p) => (
                <SelectItem key={p} value={p}>
                  {FUND_POT_LABEL[p]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={pay} onValueChange={(v) => setPay(v as typeof pay)}>
            <SelectTrigger className="w-[150px]" aria-label="Filter payment">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Payment</SelectItem>
              {(Object.keys(FINANCE_PAYMENT_LABEL) as FinancePayment[]).map((p) => (
                <SelectItem key={p} value={p}>
                  {FINANCE_PAYMENT_LABEL[p]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {activeFilters > 0 ? (
            <Badge variant="secondary" className="ml-auto gap-1">
              <SlidersHorizontal className="h-3 w-3" aria-hidden /> {activeFilters} filter
            </Badge>
          ) : null}
        </CardContent>
      </Card>

      <Card className="overflow-hidden rounded-xl">
        <CardContent className="p-0">
          {rows.length === 0 ? (
            <FinanceEmptyState
              icon={Inbox}
              title="Tidak ada transaksi"
              description="Coba ubah filter atau kata kunci pencarian di atas."
            />
          ) : (
            <TooltipProvider delayDuration={200}>
              <div className="max-h-[70dvh] overflow-auto">
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-muted/60 backdrop-blur">
                    <TableRow>
                      <TableHead className="w-[160px]">Waktu</TableHead>
                      <TableHead>Deskripsi</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Pos Dana</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead className="text-right">Jumlah</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {grouped.map(([day, list]) => {
                      const dayIn = list
                        .filter((r) => r.direction === "in")
                        .reduce((a, r) => a + r.amount, 0);
                      const dayOut = list
                        .filter((r) => r.direction === "out")
                        .reduce((a, r) => a + r.amount, 0);
                      return (
                        <Fragment key={day}>
                          <TableRow
                            key={`h-${day}`}
                            className="sticky top-10 z-[5] bg-muted/40 hover:bg-muted/40"
                          >
                            <TableCell
                              colSpan={6}
                              className="py-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground"
                            >
                              <div className="flex flex-wrap items-center justify-between gap-2">
                                <span>
                                  {new Date(day).toLocaleDateString("id-ID", {
                                    weekday: "long",
                                    day: "2-digit",
                                    month: "long",
                                    year: "numeric",
                                  })}
                                </span>
                                <span className="normal-case tracking-normal text-muted-foreground/80">
                                  <span className="text-emerald-600 dark:text-emerald-400">
                                    +{formatIDR(dayIn)}
                                  </span>{" "}
                                  ·{" "}
                                  <span className="text-amber-600 dark:text-amber-400">
                                    −{formatIDR(dayOut)}
                                  </span>
                                </span>
                              </div>
                            </TableCell>
                          </TableRow>
                          {list.map((r) => (
                            <TableRow
                              key={r.id}
                              className="cursor-default transition-colors hover:bg-muted/40 focus-within:bg-muted/40"
                            >
                              <TableCell className="whitespace-nowrap text-xs text-muted-foreground tabular-nums">
                                {formatDateTime(r.at)}
                              </TableCell>
                              <TableCell className="max-w-[280px]">
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span className="block truncate font-medium text-foreground">
                                      {r.description}
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent>{r.description}</TooltipContent>
                                </Tooltip>
                                {r.refId ? (
                                  <span className="block truncate text-[10px] text-muted-foreground">
                                    {r.refId}
                                  </span>
                                ) : null}
                              </TableCell>
                              <TableCell>
                                <Badge variant="secondary" className="font-normal">
                                  {r.category}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-xs text-muted-foreground">
                                {r.pot ? FUND_POT_LABEL[r.pot] : "—"}
                              </TableCell>
                              <TableCell className="text-xs text-muted-foreground">
                                {FINANCE_PAYMENT_LABEL[r.payment]}
                              </TableCell>
                              <TableCell
                                className={`text-right font-semibold tabular-nums ${
                                  r.direction === "in"
                                    ? "text-emerald-600 dark:text-emerald-400"
                                    : "text-foreground"
                                }`}
                              >
                                {r.direction === "in" ? "+" : "−"} {formatIDR(r.amount)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </Fragment>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>

      {rows.length === 0 && all.length === 0 ? (
        <div className="pt-2 text-center text-xs text-muted-foreground">
          <ReceiptText className="mx-auto mb-1 h-4 w-4" aria-hidden /> Ledger kosong — transaksi
          akan muncul otomatis dari POS & Pengeluaran.
        </div>
      ) : null}
    </div>
  );
}
