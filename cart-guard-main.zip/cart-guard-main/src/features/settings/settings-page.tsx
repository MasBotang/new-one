/**
 * Settings Module v1.0
 *
 * Pusat konfigurasi bisnis ERP. HANYA 4 section:
 *   1. Business    — nama, logo, default customer, sales target
 *   2. Sales       — Price Groups
 *   3. Production  — kulit yield / step, buffer %, avg weeks
 *   4. Finance     — pot allocation, development target
 *
 * Section yang TIDAK boleh ada di sini:
 *   • Profile Akun / Account Management (dipindah ke modul /accounts)
 *   • Analytics settings
 *   • System (backup/restore/import/export/version)
 *   • Currency / Tax Rate (dihapus — tidak dipakai di seluruh project)
 *
 * Storage key TIDAK berubah:
 *   - business settings  → StorageKeys.settings  (via settingsService)
 *   - finance settings   → StorageKeys.financeSettings (via financeSettings)
 *   - price groups       → priceGroupService
 */

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useRole } from "@/lib/role-context";
import { settingsService } from "@/services/settings.service";
import { financeSettings } from "@/services/finance.service";
import type {
  BusinessSettings,
  ProductionSettings,
  FinanceSettings,
  FinanceAllocation,
  PriceGroup,
  SourceOrder,
} from "@/services/types";
import { SOURCE_ORDER_LABEL, SOURCE_ORDER_LIST } from "@/services/types";
import { DEFAULT_PRODUCTION_SETTINGS } from "@/services/types";
import { priceGroupService } from "@/services/price-group.service";
import { toast } from "sonner";
import { Trash2, Plus } from "lucide-react";

export function SettingsPage() {
  const { role } = useRole();
  const canEditFinance = role === "owner" || role === "admin";
  const canEditProduction = role === "owner" || role === "admin";
  const canEditSales = role === "owner" || role === "admin";

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-8 p-6">
      <header className="flex flex-col gap-1">
        <h1 className="font-display text-3xl font-semibold tracking-tight">Pengaturan</h1>
        <p className="text-sm text-muted-foreground">
          Konfigurasi bisnis untuk Sales, Production, dan Finance.
        </p>
      </header>

      <BusinessSection />
      {canEditSales && <SalesSection />}
      {canEditProduction && <ProductionSection />}
      {canEditFinance && <FinanceSection />}
    </div>
  );
}

// ============================================================================
// 1. BUSINESS
// ============================================================================

function BusinessSection() {
  const [s, setS] = useState<BusinessSettings>(settingsService.get());

  useEffect(() => {
    setS(settingsService.get());
  }, []);

  function save() {
    settingsService.save(s);
    toast.success("Business settings disimpan");
  }

  return (
    <SectionCard title="Business">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Nama Bisnis" htmlFor="bname">
          <Input
            id="bname"
            value={s.businessName}
            onChange={(e) => setS({ ...s, businessName: e.target.value })}
          />
        </Field>

        <Field
          label="Business Logo (URL)"
          htmlFor="blogo"
          hint="Opsional. Placeholder — dipakai di header/print pada versi mendatang."
        >
          <Input
            id="blogo"
            value={s.businessLogo ?? ""}
            onChange={(e) => setS({ ...s, businessLogo: e.target.value })}
            placeholder="https://…"
          />
        </Field>

        <Field
          label="Nama Customer Default"
          htmlFor="defcust"
          hint="Dipakai saat kasir tidak mengisi nama customer di POS."
        >
          <Input
            id="defcust"
            value={s.defaultCustomerName}
            onChange={(e) => setS({ ...s, defaultCustomerName: e.target.value })}
            placeholder="Pelanggan Umum"
          />
        </Field>

        <Field label="Target Penjualan Harian (IDR)" htmlFor="target">
          <NumberInput
            id="target"
            min={0}
            value={s.salesTargetDaily}
            onChange={(v) => setS({ ...s, salesTargetDaily: v })}
          />
        </Field>
      </div>

      <div className="mt-4">
        <Button onClick={save}>Simpan Business</Button>
      </div>
    </SectionCard>
  );
}

// ============================================================================
// 2. SALES — Price Groups
// ============================================================================

function SalesSection() {
  const [rows, setRows] = useState<PriceGroup[]>([]);
  const [name, setName] = useState("");
  const [sources, setSources] = useState<SourceOrder[]>([]);

  function refresh() {
    setRows(priceGroupService.list());
  }
  useEffect(refresh, []);

  function toggleSource(s: SourceOrder) {
    setSources((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  }
  function add() {
    if (!name.trim()) {
      toast.error("Nama Price Group wajib");
      return;
    }
    priceGroupService.upsert({
      id: `pg_${Date.now()}`,
      name: name.trim(),
      sources,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setName("");
    setSources([]);
    refresh();
    toast.success("Price Group ditambahkan");
  }
  function updateRow(pg: PriceGroup, patch: Partial<PriceGroup>) {
    priceGroupService.upsert({ ...pg, ...patch });
    refresh();
  }
  function remove(pg: PriceGroup) {
    if (pg.isDefault) {
      toast.error("Price Group default tidak bisa dihapus");
      return;
    }
    priceGroupService.remove(pg.id);
    refresh();
    toast.success("Price Group dihapus");
  }

  return (
    <SectionCard title="Sales — Price Groups">
      <div className="grid gap-3 md:grid-cols-[1fr_auto]">
        <Input
          placeholder="Nama Price Group baru (mis. Grabfood Special)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <Button onClick={add}>
          <Plus className="h-4 w-4" /> Tambah
        </Button>
      </div>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {SOURCE_ORDER_LIST.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => toggleSource(s)}
            className={`rounded-full border px-2.5 py-1 text-xs ${
              sources.includes(s)
                ? "border-primary bg-primary/10 text-foreground"
                : "border-border text-muted-foreground"
            }`}
          >
            {SOURCE_ORDER_LABEL[s]}
          </button>
        ))}
      </div>

      <div className="mt-4 overflow-hidden rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-3 py-2">Nama</th>
              <th className="px-3 py-2">Sources</th>
              <th className="px-3 py-2">Default</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {rows.map((pg) => (
              <tr key={pg.id} className="border-t">
                <td className="px-3 py-2 font-medium">
                  <Input
                    className="h-8"
                    value={pg.name}
                    onChange={(e) => updateRow(pg, { name: e.target.value })}
                  />
                </td>
                <td className="px-3 py-2">
                  <div className="flex flex-wrap gap-1">
                    {SOURCE_ORDER_LIST.map((s) => {
                      const on = pg.sources.includes(s);
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() =>
                            updateRow(pg, {
                              sources: on
                                ? pg.sources.filter((x) => x !== s)
                                : [...pg.sources, s],
                            })
                          }
                          className={`rounded-full border px-2 py-0.5 text-[11px] ${
                            on
                              ? "border-primary bg-primary/10"
                              : "border-border text-muted-foreground"
                          }`}
                        >
                          {SOURCE_ORDER_LABEL[s]}
                        </button>
                      );
                    })}
                  </div>
                </td>
                <td className="px-3 py-2">
                  {pg.isDefault ? (
                    <Badge variant="outline">Default</Badge>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        const list = priceGroupService.list().map((r) => ({
                          ...r,
                          isDefault: r.id === pg.id,
                        }));
                        priceGroupService.save(list);
                        refresh();
                      }}
                    >
                      Set default
                    </Button>
                  )}
                </td>
                <td className="px-3 py-2 text-right">
                  <Button size="sm" variant="ghost" onClick={() => remove(pg)}>
                    <Trash2 className="h-4 w-4 text-destructive" strokeWidth={1.75} />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Sources yang dicentang otomatis memakai Price Group ini di POS. Harga per produk diatur
        di halaman Atur Produk.
      </p>
    </SectionCard>
  );
}

// ============================================================================
// 3. PRODUCTION
// ============================================================================

function ProductionSection() {
  const [p, setP] = useState<ProductionSettings>(
    settingsService.production() ?? DEFAULT_PRODUCTION_SETTINGS,
  );

  useEffect(() => {
    setP(settingsService.production() ?? DEFAULT_PRODUCTION_SETTINGS);
  }, []);

  function save() {
    settingsService.updateProduction(p);
    toast.success("Production settings disimpan");
  }

  function reset() {
    setP(DEFAULT_PRODUCTION_SETTINGS);
  }

  return (
    <SectionCard title="Production">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Kulit Yield (pcs / kg)" htmlFor="kyield" hint="Default 82.">
          <NumberInput
            id="kyield"
            min={1}
            value={p.kulitYieldPerKg}
            onChange={(v) => setP({ ...p, kulitYieldPerKg: v })}
          />
        </Field>
        <Field label="Kulit Step (kg)" htmlFor="kstep" hint="Kelipatan pembulatan adonan.">
          <NumberInput
            id="kstep"
            min={0.1}
            step={0.1}
            value={p.kulitStepKg}
            onChange={(v) => setP({ ...p, kulitStepKg: v })}
          />
        </Field>
        <Field
          label="Buffer (%)"
          htmlFor="kbuf"
          hint="Buffer di atas rata-rata penjualan hari yang sama."
        >
          <NumberInput
            id="kbuf"
            min={0}
            value={p.bufferPct}
            onChange={(v) => setP({ ...p, bufferPct: v })}
          />
        </Field>
        <Field
          label="Average Weeks"
          htmlFor="kavg"
          hint="Jumlah minggu histori untuk avg same-day."
        >
          <NumberInput
            id="kavg"
            min={1}
            value={p.avgWeeks}
            onChange={(v) => setP({ ...p, avgWeeks: v })}
          />
        </Field>
      </div>
      <div className="mt-4 flex gap-2">
        <Button onClick={save}>Simpan Production</Button>
        <Button variant="ghost" onClick={reset}>
          Reset ke default
        </Button>
      </div>
    </SectionCard>
  );
}

// ============================================================================
// 4. FINANCE — Pot Allocation + Development Target
// ============================================================================

const POT_LABEL: Record<keyof FinanceAllocation, string> = {
  owner: "Owner",
  development: "Development",
  operational: "Operational",
  debt: "Debt",
};
const POT_KEYS: (keyof FinanceAllocation)[] = ["owner", "development", "operational", "debt"];

function FinanceSection() {
  const [s, setS] = useState<FinanceSettings>(financeSettings.get());

  useEffect(() => {
    setS(financeSettings.get());
  }, []);

  const total = POT_KEYS.reduce((sum, k) => sum + (Number(s.allocation[k]) || 0), 0);
  const isValid = total === 100;

  function updateAlloc(k: keyof FinanceAllocation, v: number) {
    setS({ ...s, allocation: { ...s.allocation, [k]: v } });
  }

  function save() {
    if (!isValid) {
      toast.error(`Total alokasi harus 100% (sekarang ${total}%)`);
      return;
    }
    financeSettings.save(s);
    toast.success("Finance settings disimpan");
  }

  return (
    <SectionCard title="Finance">
      <div>
        <div className="mb-2 flex items-center justify-between">
          <div className="text-sm font-medium text-foreground">Pot Allocation</div>
          <Badge variant={isValid ? "outline" : "destructive"}>Total: {total}%</Badge>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {POT_KEYS.map((k) => (
            <Field key={k} label={`${POT_LABEL[k]} (%)`} htmlFor={`alloc-${k}`}>
              <NumberInput
                id={`alloc-${k}`}
                min={0}
                max={100}
                value={s.allocation[k]}
                onChange={(v) => updateAlloc(k, v)}
              />
            </Field>
          ))}
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Alokasi profit otomatis dibagi ke 4 pot. Total wajib 100%.
        </p>
      </div>

      <div className="mt-6">
        <Field
          label="Development Target (IDR)"
          htmlFor="devtgt"
          hint="Target dana development. Kosong = default sistem."
        >
          <NumberInput
            id="devtgt"
            min={0}
            value={s.developmentTarget}
            onChange={(v) => setS({ ...s, developmentTarget: v })}
          />
        </Field>
      </div>

      <div className="mt-4">
        <Button onClick={save} disabled={!isValid}>
          Simpan Finance
        </Button>
      </div>
    </SectionCard>
  );
}

// ============================================================================
// Layout helpers
// ============================================================================

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function Field({
  label,
  htmlFor,
  hint,
  children,
}: {
  label: string;
  htmlFor?: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
