/**
 * Attendance Service — owner data attendance operator.
 *
 * Storage: `StorageKeys.attendance` (independent, tidak menyentuh storage
 * Production/Finance/Inventory/Sales/Analytics).
 *
 * Identity: WAJIB `operatorId` = Account.id. Nama operator hanya display,
 * tidak disimpan di record attendance.
 */
import { storage, StorageKeys } from "@/services/storage";
import type { AttendanceStatus } from "@/features/attendance/constants";

export interface AttendanceRecord {
  id: string;
  /** YYYY-MM-DD (local). Kunci logis per operator+hari. */
  date: string;
  /** Account.id — join basis untuk Payroll & Production Performance. */
  operatorId: string;
  /** ISO datetime (opsional bila status = absent/leave). */
  checkIn?: string;
  /** ISO datetime (opsional bila belum keluar). */
  checkOut?: string;
  status: AttendanceStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

function now(): string {
  return new Date().toISOString();
}

function read(): AttendanceRecord[] {
  return storage.get<AttendanceRecord[]>(StorageKeys.attendance) ?? [];
}

function write(list: AttendanceRecord[]): void {
  storage.set(StorageKeys.attendance, list);
}

export interface UpsertAttendanceInput {
  date: string; // YYYY-MM-DD
  operatorId: string;
  checkIn?: string;
  checkOut?: string;
  status: AttendanceStatus;
  notes?: string;
}

export const attendanceService = {
  list(): AttendanceRecord[] {
    return read();
  },

  /**
   * Upsert per (operatorId, date). Payroll bergantung pada asumsi
   * maksimal 1 record per hari per operator.
   */
  upsert(input: UpsertAttendanceInput): AttendanceRecord {
    const list = read();
    const idx = list.findIndex(
      (r) => r.operatorId === input.operatorId && r.date === input.date,
    );
    if (idx === -1) {
      const rec: AttendanceRecord = {
        id: crypto.randomUUID(),
        date: input.date,
        operatorId: input.operatorId,
        checkIn: input.checkIn,
        checkOut: input.checkOut,
        status: input.status,
        notes: input.notes?.trim() || undefined,
        createdAt: now(),
        updatedAt: now(),
      };
      write([...list, rec]);
      return rec;
    }
    const cur = list[idx];
    const next: AttendanceRecord = {
      ...cur,
      checkIn: input.checkIn,
      checkOut: input.checkOut,
      status: input.status,
      notes: input.notes?.trim() || undefined,
      updatedAt: now(),
    };
    const arr = [...list];
    arr[idx] = next;
    write(arr);
    return next;
  },

  remove(id: string): void {
    write(read().filter((r) => r.id !== id));
  },
};

/**
 * Working hours = checkOut - checkIn (jam). Jika belum ada checkOut → 0.
 * Rumus terpusat — jangan menghitung ulang di UI atau service lain.
 */
export function computeWorkingHours(rec: Pick<AttendanceRecord, "checkIn" | "checkOut">): number {
  if (!rec.checkIn || !rec.checkOut) return 0;
  const inMs = new Date(rec.checkIn).getTime();
  const outMs = new Date(rec.checkOut).getTime();
  if (!Number.isFinite(inMs) || !Number.isFinite(outMs) || outMs <= inMs) return 0;
  return (outMs - inMs) / (1000 * 60 * 60);
}
