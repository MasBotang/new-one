/**
 * /accounts/attendance — Attendance Module.
 *
 * Responsibility: mencatat kehadiran operator (Check In / Check Out /
 * Status / Working Hours). BUKAN Payroll. Semua perhitungan gaji, bonus,
 * lembur, potongan, slip gaji ada di Payroll module (tahap berikutnya).
 *
 * Layout: Header · Period Filter · Summary KPI · Attendance Table ·
 *         Attendance Statistics · Insight Box.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CalendarDays, Clock, Percent, Plus, Search, UserCheck, UserMinus, Users } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  InsightCard,
  KPICard,
  TableCard,
} from "@/components/analytics";
import { formatNumber } from "@/lib/format";

import {
  ATTENDANCE_STATUSES,
  ATTENDANCE_STATUS_LABEL,
  ATTENDANCE_STATUS_TONE,
  type AttendanceStatus,
} from "./constants";
import {
  PERIOD_LABELS,
  computeAttendance,
  loadOperators,
  resolvePeriod,
  ymd,
  type AttendanceTableRow,
  type OperatorStat,
  type PeriodPreset,
} from "./data";
import { attendanceService } from "./attendance.service";
import { buildAttendanceInsights } from "./insights";

const PERIOD_ORDER: PeriodPreset[] = ["today", "week", "month", "custom"];
const ATTENDANCE_QUERY_KEY = ["attendance"] as const;

function pct(n: number, digits = 1): string {
  return `${(n * 100).toFixed(digits)}%`;
}
function fmtTime(iso?: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}
function fmtDateStr(dateStr: string): string {
  const d = new Date(`${dateStr}T00:00:00`);
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtDateTime(iso?: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AttendancePage() {
  const qc = useQueryClient();

  const [preset, setPreset] = useState<PeriodPreset>("month");
  const [custom, setCustom] = useState<{ from?: Date; to?: Date }>({});
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | AttendanceStatus>("all");
  const [sortBy, setSortBy] = useState<"date" | "operator" | "hours">("date");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<AttendanceTableRow | null>(null);

  const period = useMemo(() => {
    if (preset === "custom" && custom.from && custom.to) {
      return resolvePeriod("custom", { from: custom.from, to: custom.to });
    }
    if (preset === "custom") return resolvePeriod("today");
    return resolvePeriod(preset);
  }, [preset, custom]);

  const operatorsQuery = useQuery({
    queryKey: ["attendance-operators"],
    queryFn: loadOperators,
  });

  // Depend on attendance query for reactivity on upsert/remove.
  const attendanceStore = useQuery({
    queryKey: ATTENDANCE_QUERY_KEY,
    queryFn: () => attendanceService.list(),
    initialData: attendanceService.list(),
  });

  const data = useMemo(() => {
    const ops = operatorsQuery.data ?? [];
    // Recompute whenever store changes.
    void attendanceStore.data;
    return computeAttendance(period, ops);
  }, [period, operatorsQuery.data, attendanceStore.data]);

  const insights = useMemo(() => buildAttendanceInsights(data), [data]);

  const filteredRows = useMemo(() => {
    const needle = search.trim().toLowerCase();
    let rows = data.rows;
    if (statusFilter !== "all") rows = rows.filter((r) => r.status === statusFilter);
    if (needle) {
      rows = rows.filter((r) => r.operatorName.toLowerCase().includes(needle));
    }
    const sorted = [...rows];
    if (sortBy === "operator") sorted.sort((a, b) => a.operatorName.localeCompare(b.operatorName));
    else if (sortBy === "hours") sorted.sort((a, b) => b.workingHours - a.workingHours);
    return sorted;
  }, [data.rows, search, statusFilter, sortBy]);

  const removeM = useMutation({
    mutationFn: async (id: string) => attendanceService.remove(id),
    onSuccess: () => {
      toast.success("Record dihapus.");
      qc.invalidateQueries({ queryKey: ATTENDANCE_QUERY_KEY });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Accounts Module"
        title="Attendance"
        description="Catat kehadiran operator per hari. Sumber data untuk Payroll — modul ini tidak menghitung gaji, bonus, atau lembur."
        actions={
          <Button
            size="sm"
            onClick={() => {
              setEditing(null);
              setEditorOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" /> Catat Kehadiran
          </Button>
        }
        filters={
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex flex-wrap gap-1 rounded-lg border bg-card p-1">
              {PERIOD_ORDER.filter((p) => p !== "custom").map((p) => (
                <Button
                  key={p}
                  size="sm"
                  variant={preset === p ? "default" : "ghost"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => setPreset(p)}
                >
                  {PERIOD_LABELS[p]}
                </Button>
              ))}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    size="sm"
                    variant={preset === "custom" ? "default" : "ghost"}
                    className="h-7 gap-1 px-2.5 text-xs"
                  >
                    <CalendarDays className="h-3.5 w-3.5" />
                    Custom
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-auto p-0">
                  <Calendar
                    mode="range"
                    numberOfMonths={2}
                    selected={{ from: custom.from, to: custom.to }}
                    onSelect={(r) => {
                      setCustom({ from: r?.from, to: r?.to });
                      if (r?.from && r?.to) setPreset("custom");
                    }}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <Badge variant="secondary" className="text-xs">
              {period.label}
            </Badge>
          </div>
        }
      />

      {/* Summary KPI */}
      <AnalyticsSection title="Summary KPI" description="Ringkasan kehadiran hari ini & periode aktif.">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <KPICard label="Total Operators" value={formatNumber(data.kpi.totalOperators)} hint="Akun aktif" icon={Users} />
          <KPICard label="Present Today" value={formatNumber(data.kpi.presentToday)} icon={UserCheck} tone="positive" />
          <KPICard
            label="Absent Today"
            value={formatNumber(data.kpi.absentToday)}
            icon={UserMinus}
            tone={data.kpi.absentToday > 0 ? "warning" : "muted"}
          />
          <KPICard
            label="Late Today"
            value={formatNumber(data.kpi.lateToday)}
            icon={Clock}
            tone={data.kpi.lateToday > 0 ? "warning" : "muted"}
          />
          <KPICard
            label="Avg Working Hours"
            value={`${data.kpi.avgWorkingHours.toFixed(1)}j`}
            deltaPct={data.kpi.growth.avgWorkingHours}
            hint="rata-rata jam kerja / record"
            icon={Clock}
          />
          <KPICard
            label="Attendance Rate"
            value={pct(data.kpi.attendanceRate)}
            deltaPct={data.kpi.growth.attendanceRate}
            hint={`${data.workingDays} hari kerja periode`}
            icon={Percent}
          />
        </div>
      </AnalyticsSection>

      {/* Attendance Table */}
      <AnalyticsSection
        title="Attendance Table"
        description="Daftar record kehadiran periode aktif."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Cari operator…"
                className="h-8 w-48 pl-8 text-xs"
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as "all" | AttendanceStatus)}>
              <SelectTrigger className="h-8 w-36 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                {ATTENDANCE_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {ATTENDANCE_STATUS_LABEL[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
              <SelectTrigger className="h-8 w-36 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Sort: Tanggal</SelectItem>
                <SelectItem value="operator">Sort: Operator</SelectItem>
                <SelectItem value="hours">Sort: Working Hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
        }
      >
        <TableCard
          title="Record Kehadiran"
          subtitle="operatorId = Account.id"
          columns={[
            { key: "date", header: "Tanggal", render: (r: AttendanceTableRow) => fmtDateStr(r.date) },
            { key: "operator", header: "Operator", render: (r: AttendanceTableRow) => r.operatorName },
            { key: "in", header: "Jam Masuk", render: (r: AttendanceTableRow) => fmtTime(r.checkIn) },
            { key: "out", header: "Jam Keluar", render: (r: AttendanceTableRow) => fmtTime(r.checkOut) },
            {
              key: "hours",
              header: "Working Hours",
              align: "right",
              render: (r: AttendanceTableRow) => r.workingHours.toFixed(2),
            },
            {
              key: "status",
              header: "Status",
              render: (r: AttendanceTableRow) => (
                <Badge variant={ATTENDANCE_STATUS_TONE[r.status]} className="text-[10px]">
                  {ATTENDANCE_STATUS_LABEL[r.status]}
                </Badge>
              ),
            },
            {
              key: "updated",
              header: "Last Updated",
              render: (r: AttendanceTableRow) => (
                <span className="text-xs text-muted-foreground">{fmtDateTime(r.updatedAt)}</span>
              ),
            },
            {
              key: "actions",
              header: "",
              align: "right",
              render: (r: AttendanceTableRow) => (
                <div className="flex justify-end gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs"
                    onClick={() => {
                      setEditing(r);
                      setEditorOpen(true);
                    }}
                  >
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs text-destructive hover:text-destructive"
                    onClick={() => removeM.mutate(r.id)}
                  >
                    Hapus
                  </Button>
                </div>
              ),
            },
          ]}
          rows={filteredRows}
          emptyMessage="Belum ada record kehadiran pada periode ini."
        />
      </AnalyticsSection>

      {/* Attendance Statistics */}
      <AnalyticsSection
        title="Attendance Statistics"
        description="Ringkasan per operator. Payroll-ready — join basis: operatorId."
      >
        <TableCard
          title="Statistik Operator"
          subtitle={`${data.workingDays} hari kerja periode ini`}
          columns={[
            { key: "operator", header: "Operator", render: (r: OperatorStat) => r.operator },
            {
              key: "present",
              header: "Present",
              align: "right",
              render: (r: OperatorStat) => formatNumber(r.totalPresent),
            },
            { key: "late", header: "Late", align: "right", render: (r: OperatorStat) => formatNumber(r.totalLate) },
            {
              key: "absent",
              header: "Absent",
              align: "right",
              render: (r: OperatorStat) => formatNumber(r.totalAbsent),
            },
            { key: "leave", header: "Leave", align: "right", render: (r: OperatorStat) => formatNumber(r.totalLeave) },
            {
              key: "avgHours",
              header: "Avg Hours",
              align: "right",
              render: (r: OperatorStat) => r.avgWorkingHours.toFixed(2),
            },
            {
              key: "totalHours",
              header: "Total Hours",
              align: "right",
              render: (r: OperatorStat) => r.workingHours.toFixed(1),
            },
            {
              key: "rate",
              header: "Attendance %",
              align: "right",
              render: (r: OperatorStat) => pct(r.attendanceRate),
            },
          ]}
          rows={data.stats}
          emptyMessage="Belum ada operator terdaftar."
        />
      </AnalyticsSection>

      {/* Insight */}
      <AnalyticsSection title="Insight" description="Rule-based — bukan AI.">
        <InsightCard items={insights} emptyMessage="Belum ada highlight untuk periode ini." />
      </AnalyticsSection>

      {/* Editor */}
      <AttendanceEditor
        open={editorOpen}
        onOpenChange={setEditorOpen}
        editing={editing}
        operators={operatorsQuery.data ?? []}
        onSaved={() => {
          qc.invalidateQueries({ queryKey: ATTENDANCE_QUERY_KEY });
        }}
      />
    </AnalyticsLayout>
  );
}

/* -------------------- Editor Sheet -------------------- */

interface EditorProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: AttendanceTableRow | null;
  operators: { id: string; name: string; role: string; status: "active" | "inactive" }[];
  onSaved: () => void;
}

interface EditorState {
  operatorId: string;
  date: string; // YYYY-MM-DD
  checkInTime: string; // HH:MM
  checkOutTime: string; // HH:MM
  status: AttendanceStatus;
  notes: string;
}

function emptyState(): EditorState {
  return {
    operatorId: "",
    date: ymd(new Date()),
    checkInTime: "",
    checkOutTime: "",
    status: "present",
    notes: "",
  };
}

function isoFromDateAndTime(dateStr: string, timeStr: string): string | undefined {
  if (!timeStr) return undefined;
  const [h, m] = timeStr.split(":").map((n) => parseInt(n, 10));
  if (Number.isNaN(h) || Number.isNaN(m)) return undefined;
  const d = new Date(`${dateStr}T00:00:00`);
  d.setHours(h, m, 0, 0);
  return d.toISOString();
}

function timeFromIso(iso?: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function AttendanceEditor({ open, onOpenChange, editing, operators, onSaved }: EditorProps) {
  const isEdit = !!editing;
  const [state, setState] = useState<EditorState>(emptyState);

  // Reset when opened for new target.
  const key = editing?.id ?? "new";
  useMemo(() => {
    if (!open) return;
    if (editing) {
      setState({
        operatorId: editing.operatorId,
        date: editing.date,
        checkInTime: timeFromIso(editing.checkIn),
        checkOutTime: timeFromIso(editing.checkOut),
        status: editing.status,
        notes: editing.notes ?? "",
      });
    } else {
      setState(emptyState());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, key]);

  const saveM = useMutation({
    mutationFn: async () => {
      if (!state.operatorId) throw new Error("Operator wajib dipilih.");
      if (!state.date) throw new Error("Tanggal wajib diisi.");
      attendanceService.upsert({
        operatorId: state.operatorId,
        date: state.date,
        status: state.status,
        checkIn: isoFromDateAndTime(state.date, state.checkInTime),
        checkOut: isoFromDateAndTime(state.date, state.checkOutTime),
        notes: state.notes,
      });
    },
    onSuccess: () => {
      toast.success(isEdit ? "Kehadiran diperbarui." : "Kehadiran dicatat.");
      onOpenChange(false);
      onSaved();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex w-full flex-col sm:max-w-md">
        <SheetHeader>
          <SheetTitle>{isEdit ? "Edit Kehadiran" : "Catat Kehadiran"}</SheetTitle>
          <SheetDescription>
            Satu record per operator per hari. Working Hours dihitung otomatis dari Check In / Check Out.
          </SheetDescription>
        </SheetHeader>

        <form
          className="mt-4 flex-1 space-y-4 overflow-y-auto pr-1"
          onSubmit={(e) => {
            e.preventDefault();
            saveM.mutate();
          }}
        >
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs font-medium text-muted-foreground">Operator</Label>
            <Select
              value={state.operatorId}
              onValueChange={(v) => setState((s) => ({ ...s, operatorId: v }))}
              disabled={isEdit}
            >
              <SelectTrigger>
                <SelectValue placeholder="Pilih operator" />
              </SelectTrigger>
              <SelectContent>
                {operators.map((o) => (
                  <SelectItem key={o.id} value={o.id}>
                    {o.name}
                    <span className="ml-1 text-xs text-muted-foreground">
                      · {o.role}
                      {o.status === "inactive" ? " · nonaktif" : ""}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Tanggal</Label>
              <Input
                type="date"
                value={state.date}
                onChange={(e) => setState((s) => ({ ...s, date: e.target.value }))}
                disabled={isEdit}
                required
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Status</Label>
              <Select
                value={state.status}
                onValueChange={(v) => setState((s) => ({ ...s, status: v as AttendanceStatus }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ATTENDANCE_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {ATTENDANCE_STATUS_LABEL[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Jam Masuk</Label>
              <Input
                type="time"
                value={state.checkInTime}
                onChange={(e) => setState((s) => ({ ...s, checkInTime: e.target.value }))}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Jam Keluar</Label>
              <Input
                type="time"
                value={state.checkOutTime}
                onChange={(e) => setState((s) => ({ ...s, checkOutTime: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <Label className="text-xs font-medium text-muted-foreground">Catatan</Label>
            <Textarea
              rows={3}
              value={state.notes}
              onChange={(e) => setState((s) => ({ ...s, notes: e.target.value }))}
              placeholder="Opsional…"
            />
          </div>

          <p className="rounded-md border border-dashed p-2 text-xs text-muted-foreground">
            Working Hours = Jam Keluar − Jam Masuk (jam). Bila belum ada Jam Keluar → 0.
          </p>
        </form>

        <SheetFooter className="mt-4">
          <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
            Batal
          </Button>
          <Button onClick={() => saveM.mutate()} disabled={saveM.isPending}>
            {saveM.isPending ? "Menyimpan…" : isEdit ? "Simpan" : "Catat"}
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
