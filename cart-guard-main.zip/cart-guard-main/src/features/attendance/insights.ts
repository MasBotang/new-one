/**
 * Attendance — rule-based insight generator.
 * Deterministik, bukan AI. Semua ambang dari `constants.ts`.
 */
import type { InsightItem } from "@/components/analytics";
import { formatNumber } from "@/lib/format";
import { ATTENDANCE_INSIGHT_THRESHOLDS } from "./constants";
import type { AttendanceData } from "./data";

function pct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function buildAttendanceInsights(data: AttendanceData): InsightItem[] {
  const items: InsightItem[] = [];
  const withData = data.stats.filter(
    (s) => s.totalPresent + s.totalLate + s.totalAbsent + s.totalLeave + s.totalHalfDay > 0,
  );
  if (withData.length === 0) return items;

  // Kehadiran terbaik
  const best = [...withData].sort((a, b) => b.attendanceRate - a.attendanceRate)[0];
  if (best && best.attendanceRate >= ATTENDANCE_INSIGHT_THRESHOLDS.highAttendanceRate) {
    items.push({
      level: "positive",
      title: `Kehadiran terbaik: ${best.operator}`,
      detail: `Attendance rate ${pct(best.attendanceRate)} · ${best.totalPresent}/${best.workingDays} hari`,
    });
  }

  // Paling sering terlambat
  const mostLate = [...withData].sort((a, b) => b.totalLate - a.totalLate)[0];
  if (mostLate && mostLate.totalLate >= ATTENDANCE_INSIGHT_THRESHOLDS.frequentLateCount) {
    items.push({
      level: "warning",
      title: `Sering terlambat: ${mostLate.operator}`,
      detail: `${mostLate.totalLate}× keterlambatan periode ini`,
    });
  }

  // Working hours tertinggi
  const topHours = [...withData].sort((a, b) => b.workingHours - a.workingHours)[0];
  if (topHours && topHours.workingHours > 0) {
    items.push({
      level: "info",
      title: `Jam kerja tertinggi: ${topHours.operator}`,
      detail: `${formatNumber(Math.round(topHours.workingHours))} jam · avg ${topHours.avgWorkingHours.toFixed(1)} jam/hari`,
    });
  }

  // Attendance rate turun
  const rateLow = withData.filter(
    (s) => s.attendanceRate > 0 && s.attendanceRate < ATTENDANCE_INSIGHT_THRESHOLDS.lowAttendanceRate,
  );
  if (rateLow.length > 0) {
    items.push({
      level: "negative",
      title: `${rateLow.length} operator di bawah ${pct(ATTENDANCE_INSIGHT_THRESHOLDS.lowAttendanceRate)}`,
      detail: rateLow
        .slice(0, 3)
        .map((s) => `${s.operator} (${pct(s.attendanceRate)})`)
        .join(" · "),
    });
  }

  // Trend rate vs periode sebelumnya
  const g = data.kpi.growth.attendanceRate;
  if (g != null) {
    if (g >= ATTENDANCE_INSIGHT_THRESHOLDS.trendUpPct) {
      items.push({
        level: "positive",
        title: `Attendance rate meningkat ${pct(g)}`,
        detail: `Rate periode ini ${pct(data.kpi.attendanceRate)}`,
      });
    } else if (g <= -ATTENDANCE_INSIGHT_THRESHOLDS.trendDownPct) {
      items.push({
        level: "negative",
        title: `Attendance rate menurun ${pct(Math.abs(g))}`,
        detail: `Rate periode ini ${pct(data.kpi.attendanceRate)}`,
      });
    }
  }

  return items;
}
