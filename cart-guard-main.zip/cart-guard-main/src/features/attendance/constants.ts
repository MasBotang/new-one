/**
 * Attendance Module — enums, labels, threshold constants.
 * Semua enum & threshold WAJIB dari file ini. Dilarang hardcode di UI.
 */

export type AttendanceStatus = "present" | "late" | "absent" | "leave" | "half_day";

export const ATTENDANCE_STATUSES: AttendanceStatus[] = [
  "present",
  "late",
  "absent",
  "leave",
  "half_day",
];

export const ATTENDANCE_STATUS_LABEL: Record<AttendanceStatus, string> = {
  present: "Hadir",
  late: "Terlambat",
  absent: "Alpa",
  leave: "Izin",
  half_day: "Setengah Hari",
};

export const ATTENDANCE_STATUS_TONE: Record<
  AttendanceStatus,
  "default" | "secondary" | "destructive" | "outline"
> = {
  present: "default",
  late: "secondary",
  absent: "destructive",
  leave: "outline",
  half_day: "secondary",
};

/**
 * Batas jam masuk normal (>= ini → status "late" saat auto-derive).
 * Format 24-jam lokal: "HH:MM".
 */
export const ATTENDANCE_LATE_THRESHOLD = "08:15";

/** Standar jam kerja per hari (untuk perhitungan half-day / referensi). */
export const STANDARD_WORKING_HOURS = 8;

/** Ambang insight rule-based. */
export const ATTENDANCE_INSIGHT_THRESHOLDS = {
  frequentLateCount: 3, // >= n keterlambatan → highlight
  highAttendanceRate: 0.95, // rate >= 95% → best performer
  lowAttendanceRate: 0.7, // rate < 70% → warning
  trendUpPct: 0.05, // vs periode sebelumnya
  trendDownPct: 0.05,
} as const;
