/**
 * Attendance — data layer (aggregation, READ-ONLY di sisi kalkulasi).
 *
 * Sumber:
 *   - attendanceService.list()           → record kehadiran
 *   - listAccounts() (accounts.functions) → daftar operator (Account.id)
 *
 * Semua statistik menggunakan `operatorId` (Account.id).
 * Rumus (tidak boleh di-hardcode di UI):
 *   - workingHours   = checkOut - checkIn (jam)
 *   - attendanceRate = present / workingDays
 *   - workingDays    = distinct hari dalam periode (Sen–Sab; Minggu di-skip)
 */
import { listAccounts, type AccountView } from "@/lib/accounts.functions";
import {
  attendanceService,
  computeWorkingHours,
  type AttendanceRecord,
} from "./attendance.service";
import type { AttendanceStatus } from "./constants";

/* ---------------------- Period ---------------------- */

export type PeriodPreset = "today" | "week" | "month" | "custom";

export const PERIOD_LABELS: Record<PeriodPreset, string> = {
  today: "Hari Ini",
  week: "Minggu Ini",
  month: "Bulan Ini",
  custom: "Custom",
};

export interface DateRange {
  from: Date;
  to: Date;
}

export interface Period {
  preset: PeriodPreset;
  range: DateRange;
  previous: DateRange;
  label: string;
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}
export function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function startOfWeekMonday(d: Date): Date {
  const s = startOfDay(d);
  const day = s.getDay();
  const diff = (day + 6) % 7;
  return addDays(s, -diff);
}

export function resolvePeriod(
  preset: PeriodPreset,
  custom?: { from: Date; to: Date },
  ref = new Date(),
): Period {
  const today = startOfDay(ref);
  let range: DateRange;
  switch (preset) {
    case "today":
      range = { from: today, to: addDays(today, 1) };
      break;
    case "week": {
      const from = startOfWeekMonday(today);
      range = { from, to: addDays(from, 7) };
      break;
    }
    case "month": {
      const from = new Date(today.getFullYear(), today.getMonth(), 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      range = { from, to };
      break;
    }
    case "custom":
      range = custom
        ? { from: startOfDay(custom.from), to: addDays(startOfDay(custom.to), 1) }
        : { from: today, to: addDays(today, 1) };
      break;
  }
  const span = range.to.getTime() - range.from.getTime();
  const previous: DateRange = {
    from: new Date(range.from.getTime() - span),
    to: new Date(range.from.getTime()),
  };
  const fmt = (d: Date) =>
    d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const lastDay = new Date(range.to.getTime() - 1);
  const label = span <= 86400000 ? fmt(range.from) : `${fmt(range.from)} – ${fmt(lastDay)}`;
  return { preset, range, previous, label };
}

/* ---------------------- Helpers ---------------------- */

function inRangeYmd(dateStr: string, r: DateRange): boolean {
  const t = new Date(`${dateStr}T00:00:00`).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

/**
 * Hitung jumlah "hari kerja" dalam periode: Senin–Sabtu (Minggu = libur).
 * Payroll berikutnya dapat mengoverride via kalender kerja per operator.
 */
export function workingDaysInRange(range: DateRange): number {
  let count = 0;
  const cursor = new Date(range.from);
  while (cursor.getTime() < range.to.getTime()) {
    if (cursor.getDay() !== 0) count += 1; // 0 = Minggu
    cursor.setDate(cursor.getDate() + 1);
  }
  return count;
}

/* ---------------------- Operator directory ---------------------- */

export interface OperatorDirectory {
  id: string;
  name: string;
  role: string;
  status: "active" | "inactive";
}

export async function loadOperators(): Promise<OperatorDirectory[]> {
  const accounts = await listAccounts();
  // Operator = akun aktif. Owner dikecualikan (bukan operator lapangan).
  return accounts
    .filter((a: AccountView) => a.role !== "owner")
    .map((a) => ({ id: a.id, name: a.fullName, role: a.role, status: a.status }));
}

/* ---------------------- Table rows ---------------------- */

export interface AttendanceTableRow extends AttendanceRecord {
  operatorName: string;
  workingHours: number;
}

export function buildTableRows(
  range: DateRange,
  operators: OperatorDirectory[],
): AttendanceTableRow[] {
  const byId = new Map(operators.map((o) => [o.id, o.name]));
  return attendanceService
    .list()
    .filter((r) => inRangeYmd(r.date, range))
    .map((r) => ({
      ...r,
      operatorName: byId.get(r.operatorId) ?? "—",
      workingHours: computeWorkingHours(r),
    }))
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
}

/* ---------------------- KPI ---------------------- */

export interface AttendanceKPI {
  totalOperators: number;
  presentToday: number;
  absentToday: number;
  lateToday: number;
  avgWorkingHours: number;
  attendanceRate: number; // present / (operators * workingDays) dalam periode
  growth: {
    attendanceRate: number | null;
    avgWorkingHours: number | null;
  };
}

interface RangeAgg {
  present: number;
  late: number;
  absent: number;
  hoursSum: number;
  hoursCount: number;
}

function aggregate(range: DateRange): RangeAgg {
  const acc: RangeAgg = { present: 0, late: 0, absent: 0, hoursSum: 0, hoursCount: 0 };
  for (const r of attendanceService.list()) {
    if (!inRangeYmd(r.date, range)) continue;
    if (r.status === "present" || r.status === "half_day") acc.present += 1;
    if (r.status === "late") {
      acc.late += 1;
      acc.present += 1; // late tetap dihitung hadir
    }
    if (r.status === "absent") acc.absent += 1;
    const wh = computeWorkingHours(r);
    if (wh > 0) {
      acc.hoursSum += wh;
      acc.hoursCount += 1;
    }
  }
  return acc;
}

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur === 0 ? 0 : null;
  return (cur - prev) / prev;
}

export function computeKPI(period: Period, operators: OperatorDirectory[]): AttendanceKPI {
  const today = ymd(new Date());
  const todayRecs = attendanceService.list().filter((r) => r.date === today);
  const presentToday = todayRecs.filter((r) => r.status === "present" || r.status === "late" || r.status === "half_day").length;
  const lateToday = todayRecs.filter((r) => r.status === "late").length;
  // Absent today = operator tanpa record ATAU record status "absent"
  const activeOps = operators.filter((o) => o.status === "active");
  const withRecord = new Set(todayRecs.map((r) => r.operatorId));
  const explicitAbsent = todayRecs.filter((r) => r.status === "absent").length;
  const implicitAbsent = activeOps.filter((o) => !withRecord.has(o.id)).length;

  const cur = aggregate(period.range);
  const prev = aggregate(period.previous);
  const wd = workingDaysInRange(period.range);
  const wdPrev = workingDaysInRange(period.previous);
  const capacity = activeOps.length * wd;
  const capacityPrev = activeOps.length * wdPrev;
  const rate = capacity > 0 ? cur.present / capacity : 0;
  const ratePrev = capacityPrev > 0 ? prev.present / capacityPrev : 0;
  const avgHours = cur.hoursCount > 0 ? cur.hoursSum / cur.hoursCount : 0;
  const avgHoursPrev = prev.hoursCount > 0 ? prev.hoursSum / prev.hoursCount : 0;

  return {
    totalOperators: activeOps.length,
    presentToday,
    absentToday: explicitAbsent + implicitAbsent,
    lateToday,
    avgWorkingHours: avgHours,
    attendanceRate: rate,
    growth: {
      attendanceRate: pctChange(rate, ratePrev),
      avgWorkingHours: pctChange(avgHours, avgHoursPrev),
    },
  };
}

/* ---------------------- Operator statistics ---------------------- */

export interface OperatorStat {
  operatorId: string; // Account.id — payroll join key
  operator: string;
  role: string;
  totalPresent: number;
  totalLate: number;
  totalAbsent: number;
  totalLeave: number;
  totalHalfDay: number;
  avgWorkingHours: number;
  attendanceRate: number; // present / workingDays
  /** Payroll-ready aggregate fields — dihitung dari Attendance, bukan Payroll. */
  workingDays: number;
  workingHours: number;
  lateCount: number;
  leaveCount: number;
  absentCount: number;
}

export function operatorStatistics(
  range: DateRange,
  operators: OperatorDirectory[],
): OperatorStat[] {
  const workingDays = workingDaysInRange(range);
  const recs = attendanceService.list().filter((r) => inRangeYmd(r.date, range));
  const byOp = new Map<string, AttendanceRecord[]>();
  for (const r of recs) {
    const bucket = byOp.get(r.operatorId) ?? [];
    bucket.push(r);
    byOp.set(r.operatorId, bucket);
  }
  return operators.map((op) => {
    const bucket = byOp.get(op.id) ?? [];
    let totalPresent = 0;
    let totalLate = 0;
    let totalAbsent = 0;
    let totalLeave = 0;
    let totalHalfDay = 0;
    let hoursSum = 0;
    let hoursCount = 0;
    for (const r of bucket) {
      switch (r.status) {
        case "present":
          totalPresent += 1;
          break;
        case "late":
          totalLate += 1;
          totalPresent += 1;
          break;
        case "absent":
          totalAbsent += 1;
          break;
        case "leave":
          totalLeave += 1;
          break;
        case "half_day":
          totalHalfDay += 1;
          totalPresent += 1;
          break;
      }
      const wh = computeWorkingHours(r);
      if (wh > 0) {
        hoursSum += wh;
        hoursCount += 1;
      }
    }
    const avgWorkingHours = hoursCount > 0 ? hoursSum / hoursCount : 0;
    const rate = workingDays > 0 ? totalPresent / workingDays : 0;
    return {
      operatorId: op.id,
      operator: op.name,
      role: op.role,
      totalPresent,
      totalLate,
      totalAbsent,
      totalLeave,
      totalHalfDay,
      avgWorkingHours,
      attendanceRate: rate,
      workingDays,
      workingHours: hoursSum,
      lateCount: totalLate,
      leaveCount: totalLeave,
      absentCount: totalAbsent,
    };
  });
}

/* ---------------------- Bundled compute ---------------------- */

export interface AttendanceData {
  period: Period;
  operators: OperatorDirectory[];
  kpi: AttendanceKPI;
  rows: AttendanceTableRow[];
  stats: OperatorStat[];
  workingDays: number;
}

export function computeAttendance(
  period: Period,
  operators: OperatorDirectory[],
): AttendanceData {
  return {
    period,
    operators,
    kpi: computeKPI(period, operators),
    rows: buildTableRows(period.range, operators),
    stats: operatorStatistics(period.range, operators),
    workingDays: workingDaysInRange(period.range),
  };
}

/* ---------------------- Status helper ---------------------- */

export function statusLabelSafe(s: AttendanceStatus): string {
  return s;
}
