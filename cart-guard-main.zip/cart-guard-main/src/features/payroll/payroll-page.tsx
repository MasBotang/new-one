/**
 * /finance/payroll — Payroll Calculation Module.
 *
 * Responsibility: menghitung gaji operator berdasarkan Attendance,
 * Production Performance, dan Salary Rules. Modul ini ADALAH consumer
 * data — BUKAN owner produksi, absensi, atau aturan gaji.
 */
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  BadgeDollarSign,
  Banknote,
  CalendarRange,
  Coins,
  Factory,
  Minus,
  Plus,
  Save,
  Trash2,
  Users,
  Wallet,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";

import {
  AnalyticsHeader,
  AnalyticsLayout,
  AnalyticsSection,
  InsightCard,
  KPICard,
  TableCard,
  type TableColumn,
} from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";

import {
  PAYROLL_STATUS_LABEL,
  PAYROLL_STATUS_TONE,
  PAYROLL_PERIOD_LABEL,
  PAYROLL_STATUSES,
  CALCULATION_TYPE_LABEL,
  type PayrollPeriodPreset,
  type PayrollStatus,
} from "./constants";
import {
  computePayroll,
  loadOperators,
  resolvePayrollPeriod,
  ymd,
  type PayrollRow,
} from "./data";
import {
  payrollService,
  manualDeductionService,
} from "./payroll.service";
import {
  salaryRulesService,
  salaryBonusService,
  salaryAdditionalService,
  type SalaryCalculationType,
} from "@/services/salary.service";
import { buildPayrollInsights } from "./insights";

/* ---------------- Helpers ---------------- */

function toISO(d: Date): string {
  return d.toISOString();
}

function fmtDate(iso: string): string {
  return new Date(iso).toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

/* ---------------- Component ---------------- */

export function PayrollPage() {
  const qc = useQueryClient();
  const [preset, setPreset] = useState<PayrollPeriodPreset>("this_month");
  const [customFrom, setCustomFrom] = useState<string>(ymd(new Date()));
  const [customTo, setCustomTo] = useState<string>(ymd(new Date()));
  const [tick, setTick] = useState(0);
  const bump = () => setTick((t) => t + 1);

  const period = useMemo(
    () =>
      resolvePayrollPeriod(
        preset,
        preset === "custom"
          ? { from: new Date(`${customFrom}T00:00:00`), to: new Date(`${customTo}T00:00:00`) }
          : undefined,
      ),
    [preset, customFrom, customTo],
  );

  const operatorsQ = useQuery({ queryKey: ["payroll-operators"], queryFn: loadOperators });
  const operators = operatorsQ.data ?? [];

  const data = useMemo(() => computePayroll(period, operators), [period, operators, tick]);
  const history = useMemo(() => payrollService.list(), [tick]);
  const savedStatus = useMemo<PayrollStatus>(() => {
    const iso = { start: toISO(period.range.from), end: toISO(period.range.to) };
    return (
      history.find((h) => h.periodStart === iso.start && h.periodEnd === iso.end)?.status ?? "DRAFT"
    );
  }, [history, period]);

  const insights = useMemo(() => buildPayrollInsights(data), [data]);
  const [selected, setSelected] = useState<PayrollRow | null>(null);
  const [ruleOpen, setRuleOpen] = useState(false);
  const [bonusOpen, setBonusOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [deductOpen, setDeductOpen] = useState(false);

  /* ---------------- Mutations ---------------- */

  const saveMut = useMutation({
    mutationFn: (status: PayrollStatus) => {
      const rows = data.rows.map((r) => ({
        operatorId: r.operatorId,
        operator: r.operator,
        role: r.role,
        workingDays: r.workingDays,
        workingHours: r.workingHours,
        lateCount: r.lateCount,
        absentCount: r.absentCount,
        productionQty: r.productionQty,
        release: r.release,
        efficiency: r.efficiency,
        productionIncentive: r.productionIncentive,
        bonus: r.bonus,
        additional: r.additional,
        deduction: r.deduction,
        grossSalary: r.grossSalary,
        netSalary: r.netSalary,
      }));
      const totals = {
        operators: data.kpi.totalOperators,
        totalProductionQty: data.kpi.totalProduction,
        totalProductionIncentive: data.kpi.totalIncentive,
        totalBonus: data.kpi.totalBonus,
        totalAdditional: data.kpi.totalAdditional,
        totalDeduction: data.kpi.totalDeduction,
        totalGross: data.rows.reduce((s, r) => s + r.grossSalary, 0),
        totalNet: data.kpi.totalPayroll,
      };
      payrollService.save({
        periodStart: toISO(period.range.from),
        periodEnd: toISO(period.range.to),
        status,
        totals,
        rows,
      });
      return Promise.resolve();
    },
    onSuccess: (_r, status) => {
      toast.success(`Payroll disimpan (${PAYROLL_STATUS_LABEL[status]}).`);
      bump();
      qc.invalidateQueries({ queryKey: ["payroll-operators"] });
    },
  });

  /* ---------------- Table ---------------- */

  const columns: TableColumn<PayrollRow>[] = [
    {
      key: "operator",
      header: "Operator",
      render: (r) => (
        <button
          className="font-medium text-foreground hover:underline"
          onClick={() => setSelected(r)}
        >
          {r.operator}
        </button>
      ),
    },
    { key: "role", header: "Position", render: (r) => <span className="capitalize">{r.role}</span> },
    { key: "wd", header: "Hari Kerja", align: "right", render: (r) => formatNumber(r.workingDays) },
    {
      key: "wh",
      header: "Jam Kerja",
      align: "right",
      render: (r) => `${r.workingHours.toFixed(1)}j`,
    },
    { key: "prod", header: "Produksi", align: "right", render: (r) => formatNumber(r.productionQty) },
    {
      key: "inc",
      header: "Insentif Produksi",
      align: "right",
      render: (r) => formatIDR(r.productionIncentive),
    },
    { key: "bonus", header: "Bonus", align: "right", render: (r) => formatIDR(r.bonus) },
    { key: "add", header: "Additional", align: "right", render: (r) => formatIDR(r.additional) },
    {
      key: "ded",
      header: "Potongan",
      align: "right",
      render: (r) =>
        r.deduction > 0 ? (
          <span className="text-destructive">-{formatIDR(r.deduction)}</span>
        ) : (
          formatIDR(0)
        ),
    },
    {
      key: "net",
      header: "Net Salary",
      align: "right",
      render: (r) => <span className="font-semibold">{formatIDR(r.netSalary)}</span>,
    },
    {
      key: "status",
      header: "Status",
      align: "center",
      render: () => (
        <Badge variant={PAYROLL_STATUS_TONE[savedStatus]} className="text-[10px]">
          {PAYROLL_STATUS_LABEL[savedStatus]}
        </Badge>
      ),
    },
  ];

  const historyCols: TableColumn<(typeof history)[number]>[] = [
    {
      key: "period",
      header: "Periode",
      render: (h) => `${fmtDate(h.periodStart)} – ${fmtDate(h.periodEnd)}`,
    },
    {
      key: "ops",
      header: "Operator",
      align: "right",
      render: (h) => formatNumber(h.totals.operators),
    },
    {
      key: "total",
      header: "Total Payroll",
      align: "right",
      render: (h) => formatIDR(h.totals.totalNet),
    },
    {
      key: "status",
      header: "Status",
      align: "center",
      render: (h) => (
        <Badge variant={PAYROLL_STATUS_TONE[h.status]} className="text-[10px]">
          {PAYROLL_STATUS_LABEL[h.status]}
        </Badge>
      ),
    },
    {
      key: "created",
      header: "Dibuat",
      render: (h) => fmtDate(h.createdAt),
    },
    {
      key: "actions",
      header: "",
      align: "right",
      render: (h) => (
        <div className="flex justify-end gap-1">
          {PAYROLL_STATUSES.filter((s) => s !== h.status).map((s) => (
            <Button
              key={s}
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-[11px]"
              onClick={() => {
                payrollService.setStatus(h.id, s);
                bump();
                toast.success(`Status diubah ke ${PAYROLL_STATUS_LABEL[s]}.`);
              }}
            >
              → {PAYROLL_STATUS_LABEL[s]}
            </Button>
          ))}
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-destructive"
            onClick={() => {
              payrollService.remove(h.id);
              bump();
            }}
            aria-label="Hapus"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <AnalyticsLayout>
      <AnalyticsHeader
        eyebrow="Finance · Payroll"
        title="Payroll Calculation"
        description="Menghitung gaji operator berdasarkan Attendance, Production Performance, dan Salary Rules. Payroll hanya membaca modul upstream."
        filters={
          <>
            <Select value={preset} onValueChange={(v) => setPreset(v as PayrollPeriodPreset)}>
              <SelectTrigger className="h-9 w-[180px]">
                <CalendarRange className="mr-2 h-3.5 w-3.5" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(PAYROLL_PERIOD_LABEL) as PayrollPeriodPreset[]).map((k) => (
                  <SelectItem key={k} value={k}>
                    {PAYROLL_PERIOD_LABEL[k]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {preset === "custom" && (
              <>
                <Input
                  type="date"
                  value={customFrom}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="h-9 w-[150px]"
                />
                <Input
                  type="date"
                  value={customTo}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="h-9 w-[150px]"
                />
              </>
            )}
            <span className="text-xs text-muted-foreground">{period.label}</span>
          </>
        }
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => setRuleOpen(true)}>
              <Coins className="mr-1.5 h-3.5 w-3.5" />
              Salary Rules
            </Button>
            <Button variant="outline" size="sm" onClick={() => setBonusOpen(true)}>
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              Bonus
            </Button>
            <Button variant="outline" size="sm" onClick={() => setAddOpen(true)}>
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              Additional
            </Button>
            <Button variant="outline" size="sm" onClick={() => setDeductOpen(true)}>
              <Minus className="mr-1.5 h-3.5 w-3.5" />
              Potongan
            </Button>
            <Button size="sm" onClick={() => saveMut.mutate("CALCULATED")}>
              <Save className="mr-1.5 h-3.5 w-3.5" />
              Simpan Payroll
            </Button>
          </>
        }
      />

      <AnalyticsSection title="Ringkasan Payroll" description={period.label}>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <KPICard
            label="Total Operator"
            value={formatNumber(data.kpi.totalOperators)}
            icon={Users}
          />
          <KPICard
            label="Total Payroll"
            value={formatIDR(data.kpi.totalPayroll)}
            icon={Wallet}
            tone="default"
            deltaPct={data.kpi.laborCostGrowth}
          />
          <KPICard
            label="Total Produksi"
            value={formatNumber(data.kpi.totalProduction)}
            icon={Factory}
          />
          <KPICard
            label="Total Bonus"
            value={formatIDR(data.kpi.totalBonus)}
            icon={BadgeDollarSign}
          />
          <KPICard
            label="Total Additional"
            value={formatIDR(data.kpi.totalAdditional)}
            icon={Banknote}
          />
          <KPICard
            label="Rata-rata Gaji"
            value={formatIDR(data.kpi.averageSalary)}
            hint="dari operator dengan net > 0"
          />
        </div>
      </AnalyticsSection>

      <AnalyticsSection title="Detail Payroll">
        <TableCard
          title="Perhitungan per Operator"
          subtitle="Klik nama operator untuk detail attendance & produksi."
          columns={columns}
          rows={data.rows}
          emptyMessage="Belum ada operator aktif untuk dihitung."
        />
      </AnalyticsSection>

      <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
        <AnalyticsSection title="Riwayat Payroll">
          <TableCard
            title="Payroll History"
            columns={historyCols}
            rows={history}
            emptyMessage="Belum ada payroll tersimpan."
          />
        </AnalyticsSection>
        <AnalyticsSection title="Insight">
          <InsightCard items={insights} />
        </AnalyticsSection>
      </div>

      <OperatorDetailSheet
        row={selected}
        onClose={() => setSelected(null)}
        status={savedStatus}
      />

      <SalaryRulesDialog
        open={ruleOpen}
        onClose={() => setRuleOpen(false)}
        operators={data.rows}
        onSaved={bump}
      />
      <ManualEntryDialog
        open={bonusOpen}
        onClose={() => setBonusOpen(false)}
        operators={data.rows}
        onSubmit={(v) => salaryBonusService.create(v)}
        title="Tambah Bonus Manual"
        description="Bonus akan diagregasi ke operator pada periode yang mencakup tanggal ini."
        onSaved={bump}
      />
      <ManualEntryDialog
        open={addOpen}
        onClose={() => setAddOpen(false)}
        operators={data.rows}
        onSubmit={(v) => salaryAdditionalService.create(v)}
        title="Tambah Additional Payment"
        description="Tambahan pembayaran (transport, uang makan, dll)."
        onSaved={bump}
      />
      <ManualEntryDialog
        open={deductOpen}
        onClose={() => setDeductOpen(false)}
        operators={data.rows}
        onSubmit={(v) => manualDeductionService.create(v)}
        title="Tambah Manual Deduction"
        description="Potongan manual — tidak ada rumus otomatis di v1."
        onSaved={bump}
      />
    </AnalyticsLayout>
  );
}

/* ---------------- Operator detail ---------------- */

function OperatorDetailSheet({
  row,
  status,
  onClose,
}: {
  row: PayrollRow | null;
  status: PayrollStatus;
  onClose: () => void;
}) {
  return (
    <Sheet open={!!row} onOpenChange={(o) => (!o ? onClose() : undefined)}>
      <SheetContent side="right" className="w-full sm:max-w-md">
        {row && (
          <>
            <SheetHeader>
              <SheetTitle>{row.operator}</SheetTitle>
              <SheetDescription className="capitalize">
                {row.role} · <Badge variant={PAYROLL_STATUS_TONE[status]} className="text-[10px]">{PAYROLL_STATUS_LABEL[status]}</Badge>
              </SheetDescription>
            </SheetHeader>
            <div className="mt-4 space-y-4 text-sm">
              <Card>
                <CardContent className="p-4">
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Attendance
                  </div>
                  <Row label="Hari Kerja" value={formatNumber(row.workingDays)} />
                  <Row label="Jam Kerja" value={`${row.workingHours.toFixed(1)} jam`} />
                  <Row label="Terlambat" value={formatNumber(row.lateCount)} />
                  <Row label="Absen" value={formatNumber(row.absentCount)} />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Produksi
                  </div>
                  <Row label="Produksi (pcs)" value={formatNumber(row.productionQty)} />
                  <Row label="Release" value={formatNumber(row.release)} />
                  <Row label="Efisiensi" value={`${(row.efficiency * 100).toFixed(1)}%`} />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    Salary
                  </div>
                  <Row
                    label="Rule"
                    value={
                      row.rule
                        ? row.rule.calculationType === "PER_UNIT_PRODUCTION"
                          ? `${CALCULATION_TYPE_LABEL.PER_UNIT_PRODUCTION} · ${formatIDR(row.rule.ratePerUnit ?? 0)}/unit`
                          : `${CALCULATION_TYPE_LABEL.FIXED_AMOUNT} · ${formatIDR(row.rule.fixedAmount ?? 0)}`
                        : "Belum diatur"
                    }
                  />
                  <Row label="Insentif Produksi" value={formatIDR(row.productionIncentive)} />
                  <Row label="Bonus" value={formatIDR(row.bonus)} />
                  <Row label="Additional" value={formatIDR(row.additional)} />
                  <Row label="Potongan" value={`-${formatIDR(row.deduction)}`} />
                  <div className="mt-2 border-t pt-2">
                    <Row label="Gross Salary" value={formatIDR(row.grossSalary)} />
                    <Row
                      label="Net Salary"
                      value={<span className="font-semibold">{formatIDR(row.netSalary)}</span>}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
            <SheetFooter className="mt-4">
              <Button variant="outline" onClick={onClose}>Tutup</Button>
            </SheetFooter>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-1 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}

/* ---------------- Salary Rules Dialog ---------------- */

function SalaryRulesDialog({
  open,
  onClose,
  operators,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  operators: PayrollRow[];
  onSaved: () => void;
}) {
  const [operatorId, setOperatorId] = useState<string>("");
  const [calcType, setCalcType] = useState<SalaryCalculationType>("PER_UNIT_PRODUCTION");
  const [rate, setRate] = useState<string>("100");
  const [fixed, setFixed] = useState<string>("0");

  function submit() {
    if (!operatorId) {
      toast.error("Pilih operator.");
      return;
    }
    salaryRulesService.upsert({
      operatorId,
      calculationType: calcType,
      ratePerUnit: calcType === "PER_UNIT_PRODUCTION" ? Number(rate) || 0 : undefined,
      fixedAmount: calcType === "FIXED_AMOUNT" ? Number(fixed) || 0 : undefined,
    });
    toast.success("Salary rule tersimpan.");
    onSaved();
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => (!o ? onClose() : undefined)}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Salary Rules</DialogTitle>
          <DialogDescription>
            Atur rate produksi atau nominal tetap per operator. Data tersimpan di modul Salary
            Rules; Payroll hanya membaca.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Operator</Label>
            <Select value={operatorId} onValueChange={setOperatorId}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih operator" />
              </SelectTrigger>
              <SelectContent>
                {operators.map((o) => (
                  <SelectItem key={o.operatorId} value={o.operatorId}>
                    {o.operator}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label>Tipe Kalkulasi</Label>
            <Select value={calcType} onValueChange={(v) => setCalcType(v as SalaryCalculationType)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PER_UNIT_PRODUCTION">
                  {CALCULATION_TYPE_LABEL.PER_UNIT_PRODUCTION}
                </SelectItem>
                <SelectItem value="FIXED_AMOUNT">
                  {CALCULATION_TYPE_LABEL.FIXED_AMOUNT}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          {calcType === "PER_UNIT_PRODUCTION" ? (
            <div className="space-y-1">
              <Label>Rate per Unit (Rp)</Label>
              <Input type="number" value={rate} onChange={(e) => setRate(e.target.value)} />
            </div>
          ) : (
            <div className="space-y-1">
              <Label>Nominal Tetap (Rp)</Label>
              <Input type="number" value={fixed} onChange={(e) => setFixed(e.target.value)} />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={submit}>Simpan</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- Manual Entry Dialog ---------------- */

function ManualEntryDialog({
  open,
  onClose,
  operators,
  onSubmit,
  title,
  description,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  operators: PayrollRow[];
  onSubmit: (v: { operatorId: string; date: string; amount: number; reason?: string }) => void;
  title: string;
  description: string;
  onSaved: () => void;
}) {
  const [operatorId, setOperatorId] = useState<string>("");
  const [date, setDate] = useState<string>(ymd(new Date()));
  const [amount, setAmount] = useState<string>("0");
  const [reason, setReason] = useState<string>("");

  function submit() {
    if (!operatorId) {
      toast.error("Pilih operator.");
      return;
    }
    if (!Number(amount) || Number(amount) <= 0) {
      toast.error("Jumlah harus lebih dari 0.");
      return;
    }
    onSubmit({ operatorId, date, amount: Number(amount), reason: reason || undefined });
    toast.success("Tersimpan.");
    setAmount("0");
    setReason("");
    onSaved();
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => (!o ? onClose() : undefined)}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Operator</Label>
            <Select value={operatorId} onValueChange={setOperatorId}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih operator" />
              </SelectTrigger>
              <SelectContent>
                {operators.map((o) => (
                  <SelectItem key={o.operatorId} value={o.operatorId}>
                    {o.operator}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Tanggal</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label>Jumlah (Rp)</Label>
              <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Alasan</Label>
            <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={submit}>Simpan</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}