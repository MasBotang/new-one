/**
 * Payroll Calculation Module — enum & label constants.
 *
 * WAJIB: semua enum & label untuk Payroll diambil dari file ini.
 * Dilarang hardcode string status/tipe di UI.
 */

export type PayrollStatus = "DRAFT" | "CALCULATED" | "PAID";

export const PAYROLL_STATUSES: PayrollStatus[] = ["DRAFT", "CALCULATED", "PAID"];

export const PAYROLL_STATUS_LABEL: Record<PayrollStatus, string> = {
  DRAFT: "Draft",
  CALCULATED: "Terhitung",
  PAID: "Dibayar",
};

export const PAYROLL_STATUS_TONE: Record<
  PayrollStatus,
  "default" | "secondary" | "outline" | "destructive"
> = {
  DRAFT: "outline",
  CALCULATED: "secondary",
  PAID: "default",
};

export type PayrollPeriodPreset = "this_month" | "last_month" | "custom";

export const PAYROLL_PERIOD_LABEL: Record<PayrollPeriodPreset, string> = {
  this_month: "Bulan Ini",
  last_month: "Bulan Sebelumnya",
  custom: "Custom",
};

export const CALCULATION_TYPE_LABEL = {
  PER_UNIT_PRODUCTION: "Per Unit Produksi",
  FIXED_AMOUNT: "Nominal Tetap",
} as const;

export const PAYROLL_INSIGHT_THRESHOLDS = {
  laborCostGrowthWarn: 0.1,
  lowAbsentCount: 1,
} as const;