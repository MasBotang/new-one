/**
 * Payroll — rule-based insights (BUKAN AI).
 */
import type { InsightItem } from "@/components/analytics";
import { formatIDR, formatNumber } from "@/lib/format";
import { PAYROLL_INSIGHT_THRESHOLDS } from "./constants";
import type { PayrollData } from "./data";

export function buildPayrollInsights(data: PayrollData): InsightItem[] {
  const items: InsightItem[] = [];
  const { rows, kpi } = data;
  if (rows.length === 0) return items;

  const sortedByNet = [...rows].sort((a, b) => b.netSalary - a.netSalary);
  const top = sortedByNet[0];
  if (top && top.netSalary > 0) {
    items.push({
      level: "positive",
      title: `Payroll tertinggi: ${top.operator}`,
      detail: `Net ${formatIDR(top.netSalary)} (produksi ${formatNumber(top.productionQty)} pcs).`,
    });
  }

  const sortedByProd = [...rows].sort((a, b) => b.productionQty - a.productionQty);
  const topProd = sortedByProd[0];
  if (topProd && topProd.productionQty > 0 && topProd.operatorId !== top?.operatorId) {
    items.push({
      level: "info",
      title: `Produksi tertinggi: ${topProd.operator}`,
      detail: `${formatNumber(topProd.productionQty)} pcs di periode ini.`,
    });
  }

  if (typeof kpi.laborCostGrowth === "number") {
    if (kpi.laborCostGrowth >= PAYROLL_INSIGHT_THRESHOLDS.laborCostGrowthWarn) {
      items.push({
        level: "warning",
        title: "Biaya tenaga kerja naik signifikan",
        detail: `Total payroll naik ${(kpi.laborCostGrowth * 100).toFixed(1)}% vs periode sebelumnya.`,
      });
    } else if (kpi.laborCostGrowth <= -PAYROLL_INSIGHT_THRESHOLDS.laborCostGrowthWarn) {
      items.push({
        level: "info",
        title: "Biaya tenaga kerja turun",
        detail: `Total payroll turun ${(Math.abs(kpi.laborCostGrowth) * 100).toFixed(1)}% vs periode sebelumnya.`,
      });
    }
  }

  const disciplined = rows
    .filter((r) => r.absentCount <= PAYROLL_INSIGHT_THRESHOLDS.lowAbsentCount && r.workingDays > 0)
    .sort((a, b) => a.absentCount - b.absentCount || b.workingDays - a.workingDays)[0];
  if (disciplined) {
    items.push({
      level: "positive",
      title: `Absensi rendah: ${disciplined.operator}`,
      detail: `Hanya ${disciplined.absentCount} absen dari ${disciplined.workingDays} hari kerja.`,
    });
  }

  const noRule = rows.filter((r) => !r.rule).length;
  if (noRule > 0) {
    items.push({
      level: "warning",
      title: `${noRule} operator belum memiliki Salary Rule`,
      detail: "Atur rate/fixed amount di panel Salary Rules agar incentive terhitung.",
    });
  }

  return items;
}