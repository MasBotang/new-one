/**
 * Payroll Calculation — data layer (READ-ONLY dari modul upstream).
 *
 * Sumber (diakses via public API, tanpa memutasi):
 *   - listAccounts()                              → operator directory (Account.id)
 *   - attendance/data#operatorStatistics           → workingDays / hours / late / absent
 *   - analytics/production/data#operatorPerformance → production qty / release / efficiency
 *   - salaryRulesService                          → rate produksi / fixed amount
 *   - salaryBonusService                          → manual bonus per periode
 *   - salaryAdditionalService                     → additional payment per periode
 *   - manualDeductionService                      → potongan manual per periode
 *
 * Semua join menggunakan `operatorId` (Account.id).
 * Rumus terpusat di file ini — jangan menghitung ulang di UI.
 */
import { listAccounts, type AccountView } from "@/lib/accounts.functions";
import {
  operatorStatistics,
  workingDaysInRange,
  ymd,
  type OperatorDirectory,
} from "@/features/attendance/data";
import { operatorPerformance } from "@/features/analytics/production/data";
import {
  salaryRulesService,
  salaryBonusService,
  salaryAdditionalService,
  type SalaryRule,
} from "@/services/salary.service";
import { manualDeductionService } from "./payroll.service";
import type { PayrollPeriodPreset } from "./constants";

export type { PayrollPeriodPreset } from "./constants";

export interface DateRange {
  from: Date;
  to: Date;
}

export interface PayrollPeriod {
  preset: PayrollPeriodPreset;
  range: DateRange;
  previous: DateRange;
  label: string;
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function addDays(d: Date, n: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

export function resolvePayrollPeriod(
  preset: PayrollPeriodPreset,
  custom?: { from: Date; to: Date },
  ref = new Date(),
): PayrollPeriod {
  const today = startOfDay(ref);
  let range: DateRange;
  switch (preset) {
    case "this_month": {
      const from = new Date(today.getFullYear(), today.getMonth(), 1);
      const to = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      range = { from, to };
      break;
    }
    case "last_month": {
      const from = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const to = new Date(today.getFullYear(), today.getMonth(), 1);
      range = { from, to };
      break;
    }
    case "custom":
      range = custom
        ? { from: startOfDay(custom.from), to: addDays(startOfDay(custom.to), 1) }
        : { from: today, to: addDays(today, 1) };
      break;
  }
  const span = range.to.getTime() - range.from.getTime();
  const previous: DateRange = {
    from: new Date(range.from.getTime() - span),
    to: new Date(range.from.getTime()),
  };
  const fmt = (d: Date) =>
    d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
  const lastDay = new Date(range.to.getTime() - 1);
  const label = span <= 86400000 ? fmt(range.from) : `${fmt(range.from)} – ${fmt(lastDay)}`;
  return { preset, range, previous, label };
}

function inRangeYmd(dateStr: string, r: DateRange): boolean {
  const t = new Date(`${dateStr}T00:00:00`).getTime();
  return t >= r.from.getTime() && t < r.to.getTime();
}

export async function loadOperators(): Promise<OperatorDirectory[]> {
  const accounts = await listAccounts();
  return accounts
    .filter((a: AccountView) => a.role !== "owner" && a.status === "active")
    .map((a) => ({ id: a.id, name: a.fullName, role: a.role, status: a.status }));
}

export interface PayrollRow {
  operatorId: string;
  operator: string;
  role: string;
  workingDays: number;
  workingHours: number;
  lateCount: number;
  absentCount: number;
  productionQty: number;
  release: number;
  efficiency: number;
  rule?: SalaryRule;
  productionIncentive: number;
  bonus: number;
  additional: number;
  deduction: number;
  grossSalary: number;
  netSalary: number;
}

/**
 * Formula:
 *   productionIncentive = rule.calculationType === "PER_UNIT_PRODUCTION"
 *                            ? productionQty * rule.ratePerUnit
 *                            : rule.fixedAmount ?? 0
 *   gross = productionIncentive + bonus + additional
 *   net   = gross - deduction (deduction MANUAL — v1 tidak ada rumus otomatis)
 */
function computeIncentive(rule: SalaryRule | undefined, productionQty: number): number {
  if (!rule) return 0;
  if (rule.calculationType === "PER_UNIT_PRODUCTION") {
    return Math.max(0, Math.round(productionQty * (rule.ratePerUnit ?? 0)));
  }
  return Math.max(0, Math.round(rule.fixedAmount ?? 0));
}

export function computePayrollRows(
  period: PayrollPeriod,
  operators: OperatorDirectory[],
): PayrollRow[] {
  const stats = operatorStatistics(period.range, operators);
  const statsById = new Map(stats.map((s) => [s.operatorId, s]));
  const perf = operatorPerformance(period.range);
  const perfById = new Map(perf.map((p) => [p.operatorId, p]));
  const rules = salaryRulesService.list();
  const rulesById = new Map(rules.map((r) => [r.operatorId, r]));

  const bonusesByOp = new Map<string, number>();
  for (const b of salaryBonusService.list()) {
    if (!inRangeYmd(b.date, period.range)) continue;
    bonusesByOp.set(b.operatorId, (bonusesByOp.get(b.operatorId) ?? 0) + b.amount);
  }
  const additionalsByOp = new Map<string, number>();
  for (const a of salaryAdditionalService.list()) {
    if (!inRangeYmd(a.date, period.range)) continue;
    additionalsByOp.set(a.operatorId, (additionalsByOp.get(a.operatorId) ?? 0) + a.amount);
  }
  const deductionsByOp = new Map<string, number>();
  for (const d of manualDeductionService.list()) {
    if (!inRangeYmd(d.date, period.range)) continue;
    deductionsByOp.set(d.operatorId, (deductionsByOp.get(d.operatorId) ?? 0) + d.amount);
  }

  return operators.map<PayrollRow>((op) => {
    const s = statsById.get(op.id);
    const p = perfById.get(op.id);
    const rule = rulesById.get(op.id);
    const productionQty = p?.production ?? 0;
    const productionIncentive = computeIncentive(rule, productionQty);
    const bonus = bonusesByOp.get(op.id) ?? 0;
    const additional = additionalsByOp.get(op.id) ?? 0;
    const deduction = deductionsByOp.get(op.id) ?? 0;
    const grossSalary = productionIncentive + bonus + additional;
    const netSalary = grossSalary - deduction;
    return {
      operatorId: op.id,
      operator: op.name,
      role: op.role,
      workingDays: s?.workingDays ?? workingDaysInRange(period.range),
      workingHours: s?.workingHours ?? 0,
      lateCount: s?.lateCount ?? 0,
      absentCount: s?.absentCount ?? 0,
      productionQty,
      release: p?.release ?? 0,
      efficiency: p?.efficiency ?? 0,
      rule,
      productionIncentive,
      bonus,
      additional,
      deduction,
      grossSalary,
      netSalary,
    };
  });
}

export interface PayrollKPI {
  totalOperators: number;
  totalPayroll: number;
  totalProduction: number;
  totalBonus: number;
  totalAdditional: number;
  totalDeduction: number;
  totalIncentive: number;
  averageSalary: number;
  laborCostGrowth: number | null;
}

function pctChange(cur: number, prev: number): number | null {
  if (prev === 0) return cur === 0 ? 0 : null;
  return (cur - prev) / prev;
}

export interface PayrollData {
  period: PayrollPeriod;
  operators: OperatorDirectory[];
  rows: PayrollRow[];
  kpi: PayrollKPI;
}

export function computePayroll(
  period: PayrollPeriod,
  operators: OperatorDirectory[],
): PayrollData {
  const rows = computePayrollRows(period, operators);
  const totalPayroll = rows.reduce((s, r) => s + r.netSalary, 0);
  const totalProduction = rows.reduce((s, r) => s + r.productionQty, 0);
  const totalBonus = rows.reduce((s, r) => s + r.bonus, 0);
  const totalAdditional = rows.reduce((s, r) => s + r.additional, 0);
  const totalDeduction = rows.reduce((s, r) => s + r.deduction, 0);
  const totalIncentive = rows.reduce((s, r) => s + r.productionIncentive, 0);
  const paidHeads = rows.filter((r) => r.netSalary > 0).length;
  const averageSalary = paidHeads > 0 ? totalPayroll / paidHeads : 0;

  const prevRows = computePayrollRows(
    {
      preset: period.preset,
      range: period.previous,
      previous: period.previous,
      label: "",
    },
    operators,
  );
  const prevPayroll = prevRows.reduce((s, r) => s + r.netSalary, 0);

  const kpi: PayrollKPI = {
    totalOperators: rows.length,
    totalPayroll,
    totalProduction,
    totalBonus,
    totalAdditional,
    totalDeduction,
    totalIncentive,
    averageSalary,
    laborCostGrowth: pctChange(totalPayroll, prevPayroll),
  };
  return { period, operators, rows, kpi };
}

export { ymd };