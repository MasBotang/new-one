/**
 * Payroll Service — owner data payroll period + manual deduction.
 *
 * Storage:
 *   - StorageKeys.payrolls           → daftar payroll period beserta hasil
 *   - StorageKeys.payrollDeductions  → manual deduction per operator
 *
 * Payroll TIDAK menyimpan ulang attendance / production / salary rules —
 * semuanya dibaca on-demand dari service pemiliknya.
 */
import { storage, StorageKeys } from "@/services/storage";
import type { PayrollStatus } from "./constants";

export interface PayrollOperatorSnapshot {
  operatorId: string;
  operator: string;
  role: string;
  workingDays: number;
  workingHours: number;
  lateCount: number;
  absentCount: number;
  productionQty: number;
  release: number;
  efficiency: number;
  productionIncentive: number;
  bonus: number;
  additional: number;
  deduction: number;
  grossSalary: number;
  netSalary: number;
}

export interface PayrollRecord {
  id: string;
  periodStart: string;
  periodEnd: string;
  status: PayrollStatus;
  createdAt: string;
  updatedAt: string;
  totals: {
    operators: number;
    totalProductionQty: number;
    totalProductionIncentive: number;
    totalBonus: number;
    totalAdditional: number;
    totalDeduction: number;
    totalGross: number;
    totalNet: number;
  };
  rows: PayrollOperatorSnapshot[];
  notes?: string;
}

export interface ManualDeduction {
  id: string;
  operatorId: string;
  date: string;
  amount: number;
  reason?: string;
  createdAt: string;
}

function now(): string {
  return new Date().toISOString();
}

function readPayrolls(): PayrollRecord[] {
  return storage.get<PayrollRecord[]>(StorageKeys.payrolls) ?? [];
}
function writePayrolls(list: PayrollRecord[]): void {
  storage.set(StorageKeys.payrolls, list);
}

export interface SavePayrollInput {
  periodStart: string;
  periodEnd: string;
  status: PayrollStatus;
  totals: PayrollRecord["totals"];
  rows: PayrollOperatorSnapshot[];
  notes?: string;
}

export const payrollService = {
  list(): PayrollRecord[] {
    return readPayrolls().sort((a, b) => (a.periodStart < b.periodStart ? 1 : -1));
  },
  save(input: SavePayrollInput): PayrollRecord {
    const list = readPayrolls();
    const idx = list.findIndex(
      (p) => p.periodStart === input.periodStart && p.periodEnd === input.periodEnd,
    );
    if (idx === -1) {
      const rec: PayrollRecord = {
        id: crypto.randomUUID(),
        periodStart: input.periodStart,
        periodEnd: input.periodEnd,
        status: input.status,
        totals: input.totals,
        rows: input.rows,
        notes: input.notes?.trim() || undefined,
        createdAt: now(),
        updatedAt: now(),
      };
      writePayrolls([...list, rec]);
      return rec;
    }
    const cur = list[idx];
    const next: PayrollRecord = {
      ...cur,
      status: input.status,
      totals: input.totals,
      rows: input.rows,
      notes: input.notes?.trim() || undefined,
      updatedAt: now(),
    };
    const arr = [...list];
    arr[idx] = next;
    writePayrolls(arr);
    return next;
  },
  setStatus(id: string, status: PayrollStatus): void {
    const list = readPayrolls();
    const idx = list.findIndex((p) => p.id === id);
    if (idx === -1) return;
    const arr = [...list];
    arr[idx] = { ...arr[idx], status, updatedAt: now() };
    writePayrolls(arr);
  },
  remove(id: string): void {
    writePayrolls(readPayrolls().filter((p) => p.id !== id));
  },
};

function readDeductions(): ManualDeduction[] {
  return storage.get<ManualDeduction[]>(StorageKeys.payrollDeductions) ?? [];
}
function writeDeductions(list: ManualDeduction[]): void {
  storage.set(StorageKeys.payrollDeductions, list);
}

export interface CreateDeductionInput {
  operatorId: string;
  date: string;
  amount: number;
  reason?: string;
}

export const manualDeductionService = {
  list(): ManualDeduction[] {
    return readDeductions();
  },
  create(input: CreateDeductionInput): ManualDeduction {
    const rec: ManualDeduction = {
      id: crypto.randomUUID(),
      operatorId: input.operatorId,
      date: input.date,
      amount: Math.max(0, Math.round(input.amount)),
      reason: input.reason?.trim() || undefined,
      createdAt: now(),
    };
    writeDeductions([...readDeductions(), rec]);
    return rec;
  },
  remove(id: string): void {
    writeDeductions(readDeductions().filter((r) => r.id !== id));
  },
};