import { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Pencil,
  Search,
  AlertTriangle,
  PackageX,
  Boxes,
  Power,
  Trash2,
  PackagePlus,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NumberInput } from "@/components/ui/number-input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { inventoryService, type NewInventoryItem } from "@/services/inventory.service";
import { InventoryItemDetailSheet } from "./inventory-item-detail-sheet";

import {
  INVENTORY_CATEGORY_LABEL,
  type InventoryCategory,
  type InventoryItem,
} from "@/services/types";
import { formatIDR, formatNumber } from "@/lib/format";
import { effectiveSafety } from "@/services/shopping-list.service";
import { toast } from "sonner";

const UNIT_PRESETS = ["gram", "kg", "ml", "liter", "pcs", "butir", "pack", "botol", "lembar", "sachet", "ikat"];

function emptyDraft(): NewInventoryItem {
  return {
    name: "",
    category: "raw",
    unit: "pcs",
    stock: 0,
    minStock: 0,
    purchasePrice: 0,
    purchaseQuantity: 1,
    active: true,
    safetyStock: 0,
    purchaseType: "satuan",
    unitsPerCarton: 0,
  };
}

function stockStatus(i: InventoryItem) {
  if (!i.active) return { label: "Nonaktif", tone: "muted" as const };
  if (i.stock <= 0) return { label: "Habis", tone: "destructive" as const };
  const safety = effectiveSafety(i);
  if (safety > 0 && i.stock <= safety)
    return { label: "Menipis", tone: "warning" as const };
  return { label: "Aman", tone: "ok" as const };
}

export function InventoryItemsPage() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<"all" | InventoryCategory>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive" | "low" | "out">(
    "all",
  );
  const [editing, setEditing] = useState<InventoryItem | null>(null);
  const [draft, setDraft] = useState<NewInventoryItem | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<InventoryItem | null>(null);
  const [detailItem, setDetailItem] = useState<InventoryItem | null>(null);

  function refresh() {
    setItems(inventoryService.list());
  }
  useEffect(refresh, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const catOrder: Record<InventoryCategory, number> = {
      raw: 0,
      packaging: 1,
      operational: 2,
      production_item: 3,
    };
    return items
      .filter((i) => {
        if (q && !i.name.toLowerCase().includes(q) && !i.unit.toLowerCase().includes(q))
          return false;
        // production_item tidak pernah ditampilkan di daftar stok fisik.
        if (i.category === "production_item") return false;
        if (categoryFilter !== "all" && i.category !== categoryFilter) return false;
        const s = stockStatus(i);
        if (statusFilter === "active" && !i.active) return false;
        if (statusFilter === "inactive" && i.active) return false;
        if (statusFilter === "low" && s.tone !== "warning") return false;
        if (statusFilter === "out" && s.tone !== "destructive") return false;
        return true;
      })
      .sort((a, b) => {
        const c = catOrder[a.category] - catOrder[b.category];
        if (c !== 0) return c;
        return a.name.localeCompare(b.name, "id", { sensitivity: "base" });
      });
  }, [items, query, categoryFilter, statusFilter]);

  const stats = useMemo(() => {
    const total = items.length;
    const low = items.filter((i) => stockStatus(i).tone === "warning").length;
    const out = items.filter((i) => stockStatus(i).tone === "destructive").length;
    return { total, low, out };
  }, [items]);

  function openNew() {
    setDraft(emptyDraft());
    setEditing(null);
    setIsNew(true);
  }
  function openEdit(i: InventoryItem) {
    setEditing(i);
    setDraft({
      name: i.name,
      category: i.category,
      unit: i.unit,
      stock: i.stock,
      minStock: i.minStock,
      purchasePrice: i.purchasePrice,
      purchaseQuantity: i.purchaseQuantity,
      active: i.active,
      safetyStock: i.safetyStock ?? 0,
      purchaseType: i.purchaseType ?? "satuan",
      unitsPerCarton: i.unitsPerCarton ?? 0,
      lastPurchasePrice: i.lastPurchasePrice,
      lastPurchaseAt: i.lastPurchaseAt,
      lastSupplier: i.lastSupplier,
    });
    setIsNew(false);
  }
  function close() {
    setDraft(null);
    setEditing(null);
    setIsNew(false);
  }

  function save() {
    if (!draft) return;
    const name = draft.name.trim();
    const unit = draft.unit.trim();
    if (!name) return toast.error("Nama item wajib diisi");
    if (!unit) return toast.error("Satuan wajib diisi");
    if (draft.purchasePrice < 0) return toast.error("Harga beli tidak boleh negatif");
    if (draft.purchaseQuantity <= 0) return toast.error("Qty beli harus lebih dari 0");
    if (draft.stock < 0 || draft.minStock < 0)
      return toast.error("Stok dan minimum stok tidak boleh negatif");
    const payload: NewInventoryItem = { ...draft, name, unit };
    try {
      if (isNew) {
        inventoryService.create(payload);
        toast.success("Item ditambahkan");
      } else if (editing) {
        // Stok TIDAK bisa diubah manual dari halaman Inventory.
        // Penyesuaian stok hanya lewat Barang Masuk / Stock Opname.
        const { stock: _ignored, ...rest } = payload;
        void _ignored;
        inventoryService.update(editing.id, rest);
        toast.success("Item diperbarui");
      }
      refresh();
      close();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  function toggleActive(i: InventoryItem) {
    inventoryService.setActive(i.id, !i.active);
    refresh();
    toast.success(i.active ? "Item dinonaktifkan" : "Item diaktifkan");
  }

  function remove() {
    if (!confirmDelete) return;
    inventoryService.remove(confirmDelete.id);
    setConfirmDelete(null);
    refresh();
    toast.success("Item dihapus");
  }

  const cpu =
    draft && draft.purchaseQuantity > 0
      ? Math.round((draft.purchasePrice / draft.purchaseQuantity) * 100) / 100
      : 0;

  const canSave = !!draft
    && draft.name.trim().length > 0
    && draft.unit.trim().length > 0
    && draft.purchasePrice >= 0
    && draft.purchaseQuantity > 0
    && draft.stock >= 0
    && draft.minStock >= 0;

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold tracking-tight">Items Inventaris</h1>
        <p className="text-sm text-muted-foreground">
          Master data semua bahan baku, kemasan, dan kebutuhan operasional.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <SmallStat icon={<Boxes className="h-4 w-4" />} label="Total Items" value={String(stats.total)} />
        <SmallStat icon={<AlertTriangle className="h-4 w-4" />} label="Stok Menipis" value={String(stats.low)} tone="warning" />
        <SmallStat icon={<PackageX className="h-4 w-4" />} label="Stok Habis" value={String(stats.out)} tone="destructive" />
      </div>

      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[220px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari nama atau satuan…"
                className="pl-9"
              />
            </div>
            <Select
              value={categoryFilter}
              onValueChange={(v) => setCategoryFilter(v as typeof categoryFilter)}
            >
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Kategori</SelectItem>
                {(Object.keys(INVENTORY_CATEGORY_LABEL) as InventoryCategory[])
                  .filter((c) => c !== "production_item")
                  .map((c) => (
                    <SelectItem key={c} value={c}>
                      {INVENTORY_CATEGORY_LABEL[c]}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Select
              value={statusFilter}
              onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
            >
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="active">Aktif</SelectItem>
                <SelectItem value="inactive">Nonaktif</SelectItem>
                <SelectItem value="low">Stok Menipis</SelectItem>
                <SelectItem value="out">Stok Habis</SelectItem>
              </SelectContent>
            </Select>
            <span className="text-xs text-muted-foreground">{filtered.length} item</span>
            <Button onClick={openNew} className="ml-auto">
              <Plus className="h-4 w-4" /> Tambah Item
            </Button>
          </div>

          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader className="bg-muted/40">
                <TableRow className="hover:bg-transparent">
                  <TableHead>Nama Item</TableHead>
                  <TableHead className="w-[130px]">Kategori</TableHead>
                  <TableHead className="w-[110px] text-right">Stok</TableHead>
                  <TableHead className="w-[80px]">Satuan</TableHead>
                  <TableHead className="w-[130px] text-right">Harga Terakhir</TableHead>
                  <TableHead className="w-[140px] text-right">Nilai Persediaan</TableHead>
                  <TableHead className="w-[110px] text-right">Safety</TableHead>
                  <TableHead className="w-[110px]">Status</TableHead>
                  <TableHead className="w-[120px] text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow className="hover:bg-transparent">
                    <TableCell colSpan={9} className="py-16">
                      <div className="flex flex-col items-center gap-2 text-center">
                        <div className="grid h-10 w-10 place-items-center rounded-full bg-muted text-muted-foreground">
                          <Boxes className="h-5 w-5" strokeWidth={1.5} />
                        </div>
                        <div className="text-sm font-medium">Belum ada item ditemukan</div>
                        <div className="max-w-sm text-xs text-muted-foreground">
                          Tambahkan item baru atau ubah filter pencarian.
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((i) => {
                  const s = stockStatus(i);
                  const lastPrice = i.lastPurchasePrice ?? i.costPerUnit ?? 0;
                  const inventoryValue = i.stock * lastPrice;
                  const safety = effectiveSafety(i);
                  return (
                    <TableRow
                      key={i.id}
                      className={`cursor-pointer ${!i.active ? "opacity-60" : ""}`}
                      onClick={() => setDetailItem(i)}
                    >
                      <TableCell className="font-medium">{i.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{INVENTORY_CATEGORY_LABEL[i.category]}</Badge>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {formatNumber(i.stock)}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{i.unit}</TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {lastPrice > 0 ? formatIDR(lastPrice) : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {inventoryValue > 0 ? formatIDR(inventoryValue) : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {safety > 0 ? formatNumber(safety) : "—"}
                      </TableCell>
                      <TableCell>
                        {s.tone === "destructive" ? (
                          <Badge variant="destructive">{s.label}</Badge>
                        ) : s.tone === "warning" ? (
                          <Badge className="bg-amber-500/15 text-amber-700 hover:bg-amber-500/20 dark:text-amber-400">
                            {s.label}
                          </Badge>
                        ) : s.tone === "muted" ? (
                          <Badge variant="secondary">{s.label}</Badge>
                        ) : (
                          <Badge variant="outline" className="text-emerald-600 dark:text-emerald-400">
                            {s.label}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => toggleActive(i)}
                          aria-label={i.active ? "Nonaktifkan" : "Aktifkan"}
                          title={i.active ? "Nonaktifkan" : "Aktifkan"}
                        >
                          <Power className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => openEdit(i)} aria-label="Edit">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setConfirmDelete(i)}
                          aria-label="Hapus"
                        >
                          <Trash2 className="h-4 w-4 text-destructive" strokeWidth={1.75} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!draft} onOpenChange={(o) => !o && close()}>
        <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{isNew ? "Tambah Item Inventaris" : "Edit Item Inventaris"}</DialogTitle>
            <DialogDescription>
              Cost per Unit dihitung otomatis dari Harga Beli dibagi Qty Beli.
            </DialogDescription>
          </DialogHeader>
          {draft && (
            <div className="flex flex-col gap-6">
              <section className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <Label>Nama Item</Label>
                  <Input
                    value={draft.name}
                    onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                    placeholder="cth. Tepung Terigu"
                    autoFocus
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Kategori</Label>
                  <Select
                    value={draft.category}
                    onValueChange={(v) =>
                      setDraft({ ...draft, category: v as InventoryCategory })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(Object.keys(INVENTORY_CATEGORY_LABEL) as InventoryCategory[]).map((c) => (
                        <SelectItem key={c} value={c}>
                          {INVENTORY_CATEGORY_LABEL[c]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Satuan</Label>
                  <Select
                    value={UNIT_PRESETS.includes(draft.unit) ? draft.unit : "__custom__"}
                    onValueChange={(v) =>
                      setDraft({ ...draft, unit: v === "__custom__" ? "" : v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {UNIT_PRESETS.map((u) => (
                        <SelectItem key={u} value={u}>
                          {u}
                        </SelectItem>
                      ))}
                      <SelectItem value="__custom__">+ Satuan lain…</SelectItem>
                    </SelectContent>
                  </Select>
                  {!UNIT_PRESETS.includes(draft.unit) && (
                    <Input
                      className="mt-1"
                      placeholder="Tulis satuan, cth. dus"
                      value={draft.unit}
                      onChange={(e) => setDraft({ ...draft, unit: e.target.value })}
                    />
                  )}
                </div>
              </section>

              <Separator />

              <section className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col gap-1.5">
                  <Label>Stok {isNew ? "Awal" : "Saat Ini"}</Label>
                  {isNew ? (
                    <>
                      <NumberInput
                        value={draft.stock}
                        onChange={(v) => setDraft({ ...draft, stock: v })}
                        allowDecimal
                        min={0}
                      />
                      <p className="text-xs text-muted-foreground">
                        Stok awal saat item pertama dibuat.
                      </p>
                    </>
                  ) : (
                    <>
                      <Input
                        readOnly
                        value={`${formatNumber(draft.stock)} ${draft.unit}`}
                        className="bg-muted/40"
                      />
                      <p className="text-xs text-muted-foreground">
                        Penyesuaian stok hanya lewat Barang Masuk atau Stock Opname.
                      </p>
                    </>
                  )}
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Minimum Stok</Label>
                  <NumberInput
                    value={draft.minStock}
                    onChange={(v) => setDraft({ ...draft, minStock: v })}
                    allowDecimal
                    min={0}
                  />
                  <p className="text-xs text-muted-foreground">
                    Sistem menandai item di bawah angka ini sebagai "Menipis".
                  </p>
                </div>
              </section>


              <Separator />

              <section className="grid gap-4 md:grid-cols-3">
                <div className="flex flex-col gap-1.5">
                  <Label>Safety Stock</Label>
                  <NumberInput
                    value={draft.safetyStock ?? 0}
                    onChange={(v) => setDraft({ ...draft, safetyStock: v })}
                    allowDecimal
                    min={0}
                  />
                  <p className="text-xs text-muted-foreground">
                    Ambang untuk Daftar Belanja otomatis.
                  </p>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Jenis Pembelian</Label>
                  <Select
                    value={draft.purchaseType ?? "satuan"}
                    onValueChange={(v) =>
                      setDraft({ ...draft, purchaseType: v as "satuan" | "karton" })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="satuan">Satuan</SelectItem>
                      <SelectItem value="karton">Karton</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Isi per Karton</Label>
                  <NumberInput
                    value={draft.unitsPerCarton ?? 0}
                    onChange={(v) => setDraft({ ...draft, unitsPerCarton: v })}
                    allowDecimal
                    min={0}
                    disabled={draft.purchaseType !== "karton"}
                  />
                </div>
              </section>

              <Separator />

              <section className="flex flex-col gap-3">
                <div className="text-sm font-medium">Informasi Harga Beli</div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex flex-col gap-1.5">
                    <Label>Harga Beli (Rp)</Label>
                    <NumberInput
                      value={draft.purchasePrice}
                      onChange={(v) => setDraft({ ...draft, purchasePrice: v })}
                      min={0}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>Qty Beli ({draft.unit || "satuan"})</Label>
                    <NumberInput
                      value={draft.purchaseQuantity}
                      onChange={(v) => setDraft({ ...draft, purchaseQuantity: v })}
                      allowDecimal
                      min={0}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between rounded-md border bg-muted/30 px-3 py-2 text-xs">
                  <span className="text-muted-foreground">
                    Cost per {draft.unit || "satuan"} (dihitung otomatis)
                  </span>
                  <span className="font-mono font-semibold tabular-nums">
                    {formatIDR(cpu)} / {draft.unit || "satuan"}
                  </span>
                </div>
              </section>

              <Separator />

              <div className="flex items-center justify-between rounded-md border px-3 py-2">
                <div className="flex flex-col">
                  <span className="text-sm font-medium">Item Aktif</span>
                  <span className="text-xs text-muted-foreground">
                    Nonaktifkan item lama tanpa menghapus historinya.
                  </span>
                </div>
                <Switch
                  checked={draft.active}
                  onCheckedChange={(c) => setDraft({ ...draft, active: c })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={close}>
              Batal
            </Button>
            <Button onClick={save} disabled={!canSave}>
              <PackagePlus className="h-4 w-4" />
              {isNew ? "Tambahkan" : "Simpan Perubahan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus item ini?</AlertDialogTitle>
            <AlertDialogDescription>
              {confirmDelete && (
                <>
                  Item <strong>{confirmDelete.name}</strong> akan dihapus permanen. Pergerakan
                  stok yang sudah tercatat tetap disimpan untuk audit.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={remove}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Ya, hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <InventoryItemDetailSheet
        item={detailItem}
        open={!!detailItem}
        onOpenChange={(o) => !o && setDetailItem(null)}
      />

    </div>
  );
}

function SmallStat({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone?: "warning" | "destructive";
}) {
  const cls =
    tone === "destructive"
      ? "text-destructive"
      : tone === "warning"
        ? "text-amber-600 dark:text-amber-400"
        : "text-foreground";
  return (
    <Card>
      <CardContent className="flex items-center justify-between gap-3 pt-6">
        <div className="flex flex-col gap-1">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            {label}
          </span>
          <span className={`text-2xl font-semibold tracking-tight ${cls}`}>{value}</span>
        </div>
        <div className="grid h-9 w-9 place-items-center rounded-lg border bg-muted/40 text-muted-foreground">
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}