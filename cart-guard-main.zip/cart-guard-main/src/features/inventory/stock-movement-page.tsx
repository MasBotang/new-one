import { useEffect, useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  History,
  Search,
  Info,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { inventoryService } from "@/services/inventory.service";
import { stockMovementService } from "@/services/stock-movement.service";
import {
  STOCK_MOVEMENT_LABEL,
  type InventoryItem,
  type StockMovement,
  type StockMovementType,
} from "@/services/types";
import { formatDateTime, formatNumber } from "@/lib/format";

/**
 * Riwayat Stok — Inventory v1.0.
 *
 * Halaman ini **read-only**. Sesuai kontrak FEATURE FREEZE:
 *   Stock Movement adalah histori. Tidak boleh edit, tidak boleh
 *   delete, tidak boleh tambah manual. Semua movement dihasilkan
 *   otomatis dari:
 *     • Barang Masuk (restock)
 *     • Production (consumption / output / waste)
 *     • Release ke Ready Stock
 *     • Adjustment dari Stock Opname
 *
 * UI penambahan movement manual sengaja dihilangkan agar tidak ada
 * pintu belakang yang membobol Single Source of Truth kepemilikan
 * stok.
 */

const FILTER_TYPES: StockMovementType[] = [
  "restock",
  "operational_usage",
  "adjustment",
  "production_consumption",
  "production_output",
  "sales_packaging_usage",
];

export function StockMovementPage() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | StockMovementType>("all");

  function refresh() {
    setItems(inventoryService.list());
    setMovements(stockMovementService.list());
  }
  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  // items map disiapkan untuk future enrichments (currently unused —
  // kolom item name sudah tersimpan langsung pada movement).
  useMemo(() => {
    const m = new Map<string, InventoryItem>();
    for (const i of items) m.set(i.id, i);
    return m;
  }, [items]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return movements.filter((m) => {
      if (typeFilter !== "all" && m.type !== typeFilter) return false;
      if (q && !m.itemName.toLowerCase().includes(q) && !(m.reason ?? "").toLowerCase().includes(q))
        return false;
      return true;
    });
  }, [movements, query, typeFilter]);

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Riwayat Stok</h1>
          <p className="text-sm text-muted-foreground">
            Catatan resmi seluruh perubahan stok — read-only.
          </p>
        </div>
      </header>

      <div className="flex items-start gap-2 rounded-md border border-dashed bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        <span>
          Pergerakan stok tercatat otomatis dari{" "}
          <span className="font-medium text-foreground">Barang Masuk</span>,{" "}
          <span className="font-medium text-foreground">Produksi</span>,{" "}
          <span className="font-medium text-foreground">Release</span> ke Ready
          Stock, dan <span className="font-medium text-foreground">Stock Opname</span>.
          Tidak ada penambahan manual di halaman ini.
        </span>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[220px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari nama item atau alasan…"
                className="pl-9"
              />
            </div>
            <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as typeof typeFilter)}>
              <SelectTrigger className="w-[220px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Sumber</SelectItem>
                {FILTER_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {STOCK_MOVEMENT_LABEL[t]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span className="text-xs text-muted-foreground">
              {filtered.length} pergerakan
            </span>
          </div>

          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader className="bg-muted/40">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-[170px]">Waktu</TableHead>
                  <TableHead>Item</TableHead>
                  <TableHead className="w-[190px]">Sumber</TableHead>
                  <TableHead>Alasan</TableHead>
                  <TableHead className="w-[140px] text-right">Perubahan</TableHead>
                  <TableHead className="w-[120px] text-right">Sisa</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <TableRow className="hover:bg-transparent">
                    <TableCell colSpan={6} className="py-16">
                      <div className="flex flex-col items-center gap-2 text-center">
                        <div className="grid h-10 w-10 place-items-center rounded-full bg-muted text-muted-foreground">
                          <History className="h-5 w-5" strokeWidth={1.5} />
                        </div>
                        <div className="text-sm font-medium">
                          Belum ada pergerakan stok
                        </div>
                        <div className="max-w-sm text-xs text-muted-foreground">
                          Pergerakan akan muncul otomatis saat Anda mencatat
                          Barang Masuk atau menjalankan Produksi.
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {filtered.map((m) => {
                  const inflow = m.delta > 0;
                  const Icon = inflow ? ArrowUpRight : ArrowDownRight;
                  return (
                    <TableRow key={m.id}>
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                        {formatDateTime(m.createdAt)}
                      </TableCell>
                      <TableCell className="font-medium">{m.itemName}</TableCell>
                      <TableCell>
                        <Badge variant={inflow ? "outline" : "secondary"}>
                          {STOCK_MOVEMENT_LABEL[m.type]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {m.reason ?? "—"}
                        {m.notes && (
                          <span className="block truncate text-[11px] text-muted-foreground/70">
                            {m.notes}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        <span
                          className={`inline-flex items-center gap-1 font-semibold ${
                            inflow
                              ? "text-emerald-600 dark:text-emerald-400"
                              : "text-rose-600 dark:text-rose-400"
                          }`}
                        >
                          <Icon className="h-3.5 w-3.5" />
                          {inflow ? "+" : ""}
                          {formatNumber(m.delta)} {m.unit}
                        </span>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {formatNumber(m.balanceAfter)}{" "}
                        <span className="text-xs text-muted-foreground">{m.unit}</span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
