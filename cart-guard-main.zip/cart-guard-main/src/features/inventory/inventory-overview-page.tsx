import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Boxes,
  AlertTriangle,
  PackageX,
  Plus,
  ClipboardCheck,
  ShoppingCart,
  History,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { inventoryService } from "@/services/inventory.service";
import { type InventoryItem } from "@/services/types";
import { formatNumber } from "@/lib/format";
import {
  shoppingListService,
  type ShoppingListEntry,
} from "@/services/shopping-list.service";

/**
 * Inventory Overview (Home) — Inventory v1.0.
 *
 * Sesuai kontrak FEATURE FREEZE, halaman ini SENGAJA sederhana dan
 * tidak berisi chart / trend / KPI / analytics. Semua analitik pindah
 * ke modul Reports. Home hanya menyajikan angka operasional harian
 * dan pintu masuk cepat ke workflow inventaris.
 */
function MetricCard({
  label,
  value,
  icon: Icon,
  hint,
  tone,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
  hint?: string;
  tone?: "default" | "warning" | "destructive";
}) {
  const toneCls =
    tone === "warning"
      ? "text-amber-600 dark:text-amber-400"
      : tone === "destructive"
        ? "text-destructive"
        : "text-foreground";
  return (
    <Card className="h-full">
      <CardContent className="flex h-full items-start justify-between gap-3 pt-6">
        <div className="flex min-w-0 flex-col gap-1">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            {label}
          </span>
          <span className={`truncate text-2xl font-semibold tracking-tight ${toneCls}`}>
            {value}
          </span>
          {hint && <span className="truncate text-xs text-muted-foreground">{hint}</span>}
        </div>
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border bg-muted/40 text-muted-foreground">
          <Icon className="h-4 w-4" strokeWidth={1.75} />
        </div>
      </CardContent>
    </Card>
  );
}

export function InventoryOverviewPage() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [shopping, setShopping] = useState<ShoppingListEntry[]>([]);

  function refresh() {
    setItems(inventoryService.list());
    setShopping(shoppingListService.compute());
  }
  useEffect(() => {
    refresh();
    const onVisible = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, []);

  const stats = useMemo(() => {
    // production_item = hasil produksi (internal WIP), tidak dihitung
    // sebagai stok fisik yang dibeli. Filter agar konsisten dengan
    // Shopping List.
    const real = items.filter((i) => i.category !== "production_item" && i.active);
    const total = real.length;
    const out = real.filter((i) => i.stock <= 0).length;
    const low = real.filter(
      (i) => i.stock > 0 && i.minStock > 0 && i.stock <= i.minStock,
    ).length;
    return { total, out, low };
  }, [items]);

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold tracking-tight">Inventaris</h1>
          <p className="text-sm text-muted-foreground">
            Pusat pengelolaan stok fisik: bahan baku, kemasan, dan operasional.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link to="/inventory/items">
              <Boxes className="h-4 w-4" /> Daftar Barang
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/inventory/stock-opname">
              <ClipboardCheck className="h-4 w-4" /> Stock Opname
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/inventory/stock-movement">
              <History className="h-4 w-4" /> Riwayat Stok
            </Link>
          </Button>
          <Button asChild>
            <Link to="/inventory/purchase-in">
              <Plus className="h-4 w-4" /> Barang Masuk
            </Link>
          </Button>
        </div>
      </header>

      {/* Ringkasan operasional — tanpa chart, tanpa trend, tanpa KPI. */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <MetricCard
          label="Jumlah Item"
          value={formatNumber(stats.total)}
          icon={Boxes}
          hint="Item aktif dalam inventaris"
        />
        <MetricCard
          label="Stok Menipis"
          value={formatNumber(stats.low)}
          icon={AlertTriangle}
          tone={stats.low > 0 ? "warning" : "default"}
          hint="Di / bawah minimum stock"
        />
        <MetricCard
          label="Stok Habis"
          value={formatNumber(stats.out)}
          icon={PackageX}
          tone={stats.out > 0 ? "destructive" : "default"}
          hint="Perlu restock segera"
        />
      </div>

      {/* Shopping List — SSoT: forecast + pre-order + minStock (alert). */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Shopping List
            </CardTitle>
          </div>
          <Badge variant="outline">{shopping.length} item</Badge>
        </CardHeader>
        <CardContent className="flex flex-col gap-2">
          {shopping.length === 0 && (
            <p className="py-6 text-center text-sm text-muted-foreground">
              Tidak ada rekomendasi belanja. Stok mencukupi kebutuhan produksi
              dan pre-order aktif.
            </p>
          )}
          <div className="flex max-h-[420px] flex-col gap-2 overflow-y-auto pr-1">
            {shopping.map((s) => (
              <div
                key={s.item.id}
                className="flex flex-wrap items-center gap-3 rounded-md border px-3 py-2 hover:bg-muted/40"
              >
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate text-sm font-medium">{s.item.name}</span>
                  <span className="truncate text-xs text-muted-foreground">
                    Stok {formatNumber(s.stock)} {s.item.unit}
                    {s.productionNeed > 0 &&
                      ` · Produksi ${formatNumber(s.productionNeed)}`}
                    {s.preorderNeed > 0 &&
                      ` · PO ${formatNumber(s.preorderNeed)}`}
                    {s.minStock > 0 && ` · Min ${formatNumber(s.minStock)}`}
                  </span>
                </div>
                <div className="text-right text-xs">
                  <div className="font-semibold tabular-nums">
                    {s.recommendedCartons
                      ? `${s.recommendedCartons} Karton (${formatNumber(s.recommendedQuantity)} ${s.item.unit})`
                      : `${formatNumber(s.recommendedQuantity)} ${s.item.unit}`}
                  </div>
                  <div className="text-[10px] text-muted-foreground">Rekomendasi beli</div>
                </div>
                <Badge
                  variant={
                    s.priority === "today"
                      ? "destructive"
                      : s.priority === "tomorrow"
                        ? "secondary"
                        : "outline"
                  }
                  className={
                    s.priority === "tomorrow"
                      ? "bg-amber-500/15 text-amber-700 hover:bg-amber-500/20 dark:text-amber-400"
                      : ""
                  }
                >
                  {s.reason}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
