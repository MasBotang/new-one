import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NumberInput } from "@/components/ui/number-input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { PackagePlus } from "lucide-react";
import { inventoryService } from "@/services/inventory.service";
import { purchaseService, type PurchaseKind, type PurchaseRecord } from "@/services/purchase.service";
import { formatDateTime, formatIDR, formatNumber } from "@/lib/format";
import { useRole } from "@/lib/role-context";

function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function PurchaseInPage() {
  const { profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "Admin";

  const items = useMemo(
    () =>
      inventoryService
        .list()
        .filter((i) => i.active && i.category !== "production_item"),
    [],
  );

  const [date, setDate] = useState(todayISO());
  const [itemId, setItemId] = useState("");
  const [supplier, setSupplier] = useState("");
  const [notes, setNotes] = useState("");
  const [kind, setKind] = useState<PurchaseKind>("satuan");
  const [quantity, setQuantity] = useState(0);
  const [pricePerUnit, setPricePerUnit] = useState(0);
  const [cartons, setCartons] = useState(0);
  const [unitsPerCarton, setUnitsPerCarton] = useState(0);
  const [pricePerCarton, setPricePerCarton] = useState(0);
  const [rows, setRows] = useState<PurchaseRecord[]>([]);

  function refresh() {
    setRows(purchaseService.list().slice(0, 30));
  }
  useEffect(refresh, []);

  const selectedItem = useMemo(
    () => items.find((i) => i.id === itemId),
    [items, itemId],
  );

  // Preload defaults when item changes.
  useEffect(() => {
    if (!selectedItem) return;
    if (selectedItem.purchaseType) setKind(selectedItem.purchaseType);
    if (selectedItem.unitsPerCarton) setUnitsPerCarton(selectedItem.unitsPerCarton);
  }, [selectedItem]);

  const totals = useMemo(() => {
    if (kind === "karton") {
      const totalQty = (cartons || 0) * (unitsPerCarton || 0);
      const totalPrice = (cartons || 0) * (pricePerCarton || 0);
      const pricePer = totalQty > 0 ? totalPrice / totalQty : 0;
      return { totalQty, totalPrice, pricePer };
    }
    const totalQty = quantity || 0;
    const totalPrice = (quantity || 0) * (pricePerUnit || 0);
    const pricePer = totalQty > 0 ? totalPrice / totalQty : pricePerUnit || 0;
    return { totalQty, totalPrice, pricePer };
  }, [kind, cartons, unitsPerCarton, pricePerCarton, quantity, pricePerUnit]);

  function reset() {
    setQuantity(0);
    setPricePerUnit(0);
    setCartons(0);
    setPricePerCarton(0);
    setSupplier("");
    setNotes("");
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!itemId) return toast.error("Pilih barang terlebih dahulu");
    try {
      purchaseService.create({
        itemId,
        date,
        supplier: supplier.trim() || undefined,
        notes: notes.trim() || undefined,
        kind,
        cartons: kind === "karton" ? cartons : undefined,
        unitsPerCarton: kind === "karton" ? unitsPerCarton : undefined,
        pricePerCarton: kind === "karton" ? pricePerCarton : undefined,
        quantity: kind === "satuan" ? quantity : undefined,
        pricePerUnit: kind === "satuan" ? pricePerUnit : undefined,
        actor,
      });
      toast.success("Barang masuk tercatat, stok bertambah");
      reset();
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan");
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 p-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Barang Masuk</h1>
        <p className="text-sm text-muted-foreground">
          Catat setiap pembelian di sini. Stok akan bertambah otomatis dan harga terakhir diperbarui.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Form Barang Masuk
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form className="grid gap-4 md:grid-cols-2" onSubmit={submit}>
            <div className="flex flex-col gap-1.5">
              <Label>Tanggal</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Barang</Label>
              <Select value={itemId} onValueChange={setItemId}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih barang…" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {items.map((i) => (
                    <SelectItem key={i.id} value={i.id}>
                      {i.name} · stok {formatNumber(i.stock)} {i.unit}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Supplier (opsional)</Label>
              <Input value={supplier} onChange={(e) => setSupplier(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Jenis Pembelian</Label>
              <Select value={kind} onValueChange={(v) => setKind(v as PurchaseKind)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="satuan">Satuan</SelectItem>
                  <SelectItem value="karton">Karton</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {kind === "satuan" ? (
              <>
                <div className="flex flex-col gap-1.5">
                  <Label>Qty ({selectedItem?.unit ?? "unit"})</Label>
                  <NumberInput value={quantity} onChange={setQuantity} allowDecimal min={0} />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Harga Satuan (Rp)</Label>
                  <NumberInput value={pricePerUnit} onChange={setPricePerUnit} min={0} />
                </div>
              </>
            ) : (
              <>
                <div className="flex flex-col gap-1.5">
                  <Label>Jumlah Karton</Label>
                  <NumberInput value={cartons} onChange={setCartons} min={0} />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Isi per Karton ({selectedItem?.unit ?? "unit"})</Label>
                  <NumberInput value={unitsPerCarton} onChange={setUnitsPerCarton} min={0} allowDecimal />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <Label>Harga per Karton (Rp)</Label>
                  <NumberInput value={pricePerCarton} onChange={setPricePerCarton} min={0} />
                </div>
              </>
            )}

            <div className="flex flex-col gap-1.5 md:col-span-2">
              <Label>Catatan (opsional)</Label>
              <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>

            <div className="md:col-span-2 grid gap-2 rounded-lg border bg-muted/30 p-3 text-sm sm:grid-cols-3">
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Total Qty</span>
                <span className="font-semibold tabular-nums">
                  {formatNumber(totals.totalQty)} {selectedItem?.unit ?? ""}
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Harga per Unit</span>
                <span className="font-semibold tabular-nums">{formatIDR(totals.pricePer)}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Total Pembelian</span>
                <span className="font-semibold tabular-nums">{formatIDR(totals.totalPrice)}</span>
              </div>
            </div>

            <div className="md:col-span-2 flex justify-end">
              <Button type="submit" disabled={!itemId || totals.totalQty <= 0}>
                <PackagePlus className="h-4 w-4" /> Simpan Barang Masuk
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Riwayat Pembelian (30 terakhir)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Waktu</TableHead>
                  <TableHead>Barang</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Jenis</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Harga/Unit</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                      Belum ada pembelian.
                    </TableCell>
                  </TableRow>
                )}
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="text-xs">{formatDateTime(r.createdAt)}</TableCell>
                    <TableCell className="font-medium">{r.itemName}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {r.supplier ?? "—"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{r.kind === "karton" ? "Karton" : "Satuan"}</Badge>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(r.totalQuantity)} {r.unit}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatIDR(r.effectivePricePerUnit)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums font-semibold">
                      {formatIDR(r.totalPrice)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}