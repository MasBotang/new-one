import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NumberInput } from "@/components/ui/number-input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { ClipboardCheck, CheckCircle2 } from "lucide-react";
import { inventoryService } from "@/services/inventory.service";
import { stockOpnameService, type StockOpnameRecord } from "@/services/stock-opname.service";
import { formatDateTime, formatNumber } from "@/lib/format";
import { useRole } from "@/lib/role-context";


const REASONS = ["Rusak", "Hilang", "Expired", "Salah Hitung", "Susut Alami", "Lainnya"];

export function StockOpnamePage() {
  const { profile, user } = useRole();
  const actor = profile?.full_name ?? user?.email ?? "Admin";
  const items = useMemo(
    () => inventoryService.list().filter((i) => i.active && i.category !== "production_item"),
    [],
  );
  const [itemId, setItemId] = useState("");
  const [physical, setPhysical] = useState(0);
  const [reason, setReason] = useState("Rusak");
  const [customReason, setCustomReason] = useState("");
  const [notes, setNotes] = useState("");
  const [rows, setRows] = useState<StockOpnameRecord[]>([]);
  const [success, setSuccess] = useState<StockOpnameRecord | null>(null);

  function refresh() {
    setRows(stockOpnameService.list().slice(0, 30));
  }
  useEffect(refresh, []);

  const selected = useMemo(() => items.find((i) => i.id === itemId), [items, itemId]);
  const diff = selected ? physical - selected.stock : 0;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!itemId) return toast.error("Pilih item");
    const finalReason = reason === "Lainnya" ? customReason.trim() : reason;
    if (!finalReason) return toast.error("Alasan wajib diisi");
    try {
      const rec = stockOpnameService.create({
        itemId,
        physicalStock: physical,
        reason: finalReason,
        notes: notes.trim() || undefined,
        actor,
      });
      setSuccess(rec);
      setItemId("");
      setPhysical(0);
      setNotes("");
      refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan");
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 p-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Stock Opname</h1>
        <p className="text-sm text-muted-foreground">
          Cocokkan stok sistem dengan stok fisik gudang. Selisih akan otomatis dicatat sebagai penyesuaian.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Form Opname
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form className="grid gap-4 md:grid-cols-2" onSubmit={submit}>
            <div className="flex flex-col gap-1.5 md:col-span-2">
              <Label>Item</Label>
              <Select value={itemId} onValueChange={setItemId}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih item" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {items.map((i) => (
                    <SelectItem key={i.id} value={i.id}>
                      {i.name} · sistem {formatNumber(i.stock)} {i.unit}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label>Stok Sistem</Label>
              <Input
                readOnly
                value={selected ? `${formatNumber(selected.stock)} ${selected.unit}` : "—"}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Stok Fisik ({selected?.unit ?? "unit"})</Label>
              <NumberInput value={physical} onChange={setPhysical} allowDecimal min={0} />
            </div>
            <div className="flex flex-col gap-1.5 md:col-span-2">
              <div className="rounded-md border bg-muted/30 px-3 py-2 text-sm">
                Selisih:{" "}
                <span
                  className={
                    diff === 0
                      ? "font-semibold"
                      : diff > 0
                        ? "font-semibold text-emerald-600 dark:text-emerald-400"
                        : "font-semibold text-destructive"
                  }
                >
                  {diff > 0 ? "+" : ""}
                  {selected ? `${formatNumber(diff)} ${selected.unit}` : "—"}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label>Alasan</Label>
              <Select value={reason} onValueChange={setReason}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {REASONS.map((r) => (
                    <SelectItem key={r} value={r}>
                      {r}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {reason === "Lainnya" && (
                <Input
                  className="mt-1"
                  placeholder="Tulis alasan"
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                />
              )}
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Catatan (opsional)</Label>
              <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>

            <div className="md:col-span-2 flex justify-end">
              <Button type="submit" disabled={!itemId}>
                <ClipboardCheck className="h-4 w-4" /> Simpan Opname
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Riwayat Opname (30 terakhir)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Waktu</TableHead>
                  <TableHead>Item</TableHead>
                  <TableHead className="text-right">Sistem</TableHead>
                  <TableHead className="text-right">Fisik</TableHead>
                  <TableHead className="text-right">Selisih</TableHead>
                  <TableHead>Alasan</TableHead>
                  <TableHead>Oleh</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                      Belum ada opname.
                    </TableCell>
                  </TableRow>
                )}
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="text-xs">{formatDateTime(r.createdAt)}</TableCell>
                    <TableCell className="font-medium">{r.itemName}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(r.systemStock)} {r.unit}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {formatNumber(r.physicalStock)} {r.unit}
                    </TableCell>
                    <TableCell
                      className={`text-right tabular-nums font-semibold ${
                        r.diff === 0
                          ? ""
                          : r.diff > 0
                            ? "text-emerald-600 dark:text-emerald-400"
                            : "text-destructive"
                      }`}
                    >
                      {r.diff > 0 ? "+" : ""}
                      {formatNumber(r.diff)}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{r.reason}</Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.actor}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!success} onOpenChange={(o) => !o && setSuccess(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="h-5 w-5" /> Stock Opname Berhasil
            </DialogTitle>
          </DialogHeader>
          {success && (
            <div className="flex flex-col gap-3">
              <div className="rounded-lg border bg-muted/30 p-4">
                <div className="text-sm font-medium">{success.itemName}</div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                      Sistem
                    </span>
                    <span className="text-lg font-semibold tabular-nums">
                      {formatNumber(success.systemStock)}
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                      Fisik
                    </span>
                    <span className="text-lg font-semibold tabular-nums">
                      {formatNumber(success.physicalStock)}
                    </span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                      Penyesuaian
                    </span>
                    <span
                      className={`text-lg font-semibold tabular-nums ${
                        success.diff === 0
                          ? ""
                          : success.diff > 0
                            ? "text-emerald-600 dark:text-emerald-400"
                            : "text-destructive"
                      }`}
                    >
                      {success.diff > 0 ? "+" : ""}
                      {formatNumber(success.diff)}
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                Inventory telah diperbarui. Stock Movement berhasil dicatat.
              </p>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setSuccess(null)}>Selesai</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
