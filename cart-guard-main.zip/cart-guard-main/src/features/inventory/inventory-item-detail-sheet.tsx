import { useMemo, useState } from "react";
import { Search, History, ArrowDownRight, ArrowUpRight, Wrench, Activity } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { stockMovementService, isStockIn } from "@/services/stock-movement.service";
import { effectiveSafety } from "@/services/shopping-list.service";
import {
  INVENTORY_CATEGORY_LABEL,
  type InventoryItem,
  type StockMovement,
  type StockMovementType,
} from "@/services/types";
import { formatIDR, formatNumber } from "@/lib/format";

type MovementFilter =
  | "all"
  | "in"
  | "out"
  | "adjustment"
  | "production"
  | "packaging"
  | "operational";

interface Props {
  item: InventoryItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const TYPE_STYLE: Record<
  StockMovementType,
  { label: string; className: string }
> = {
  restock: {
    label: "Restock",
    className:
      "bg-emerald-500/15 text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-400",
  },
  production_output: {
    label: "Produksi (Masuk)",
    className:
      "bg-sky-500/15 text-sky-700 hover:bg-sky-500/20 dark:text-sky-400",
  },
  production_consumption: {
    label: "Produksi",
    className:
      "bg-sky-500/15 text-sky-700 hover:bg-sky-500/20 dark:text-sky-400",
  },
  sales_packaging_usage: {
    label: "Packaging / Sales",
    className:
      "bg-orange-500/15 text-orange-700 hover:bg-orange-500/20 dark:text-orange-400",
  },
  operational_usage: {
    label: "Operasional",
    className:
      "bg-violet-500/15 text-violet-700 hover:bg-violet-500/20 dark:text-violet-400",
  },
  adjustment: {
    label: "Adjustment",
    className: "bg-muted text-muted-foreground hover:bg-muted",
  },
};

function matchFilter(m: StockMovement, f: MovementFilter): boolean {
  if (f === "all") return true;
  if (f === "adjustment") return m.type === "adjustment";
  if (f === "production")
    return m.type === "production_output" || m.type === "production_consumption";
  if (f === "packaging") return m.type === "sales_packaging_usage";
  if (f === "operational") return m.type === "operational_usage";
  if (f === "in") return isStockIn(m.type);
  if (f === "out")
    return !isStockIn(m.type) && m.type !== "adjustment";
  return true;
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}
function formatTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

export function InventoryItemDetailSheet({ item, open, onOpenChange }: Props) {
  const [filter, setFilter] = useState<MovementFilter>("all");
  const [query, setQuery] = useState("");

  const movements = useMemo(
    () => (item ? stockMovementService.byItem(item.id) : []),
    [item],
  );

  const monthSummary = useMemo(() => {
    const now = new Date();
    const y = now.getFullYear();
    const mo = now.getMonth();
    let inQty = 0;
    let outQty = 0;
    let adjQty = 0;
    for (const m of movements) {
      const d = new Date(m.createdAt);
      if (d.getFullYear() !== y || d.getMonth() !== mo) continue;
      if (m.type === "adjustment") adjQty += m.delta;
      else if (m.delta > 0) inQty += m.delta;
      else outQty += Math.abs(m.delta);
    }
    return { inQty, outQty, adjQty };
  }, [movements]);

  const last30 = useMemo(() => {
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
    let inQty = 0;
    let outQty = 0;
    let adjQty = 0;
    let total = 0;
    for (const m of movements) {
      if (new Date(m.createdAt).getTime() < cutoff) continue;
      total += 1;
      if (m.type === "adjustment") adjQty += m.delta;
      else if (m.delta > 0) inQty += m.delta;
      else outQty += Math.abs(m.delta);
    }
    return { inQty, outQty, adjQty, total };
  }, [movements]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return movements.filter((m) => {
      if (!matchFilter(m, filter)) return false;
      if (!q) return true;
      const hay = `${m.reason ?? ""} ${m.notes ?? ""}`.toLowerCase();
      return hay.includes(q);
    });
  }, [movements, filter, query]);

  if (!item) return null;

  const lastPrice = item.lastPurchasePrice ?? item.costPerUnit ?? 0;
  const inventoryValue = item.stock * lastPrice;
  const safety = effectiveSafety(item);
  const status = !item.active
    ? { label: "Nonaktif", cls: "bg-muted text-muted-foreground" }
    : item.stock <= 0
      ? { label: "Habis", cls: "bg-destructive/15 text-destructive" }
      : safety > 0 && item.stock <= safety
        ? {
            label: "Menipis",
            cls: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
          }
        : {
            label: "Aman",
            cls: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
          };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="flex w-full flex-col gap-0 p-0 sm:max-w-xl"
      >
        <SheetHeader className="border-b bg-background px-6 pb-4 pt-6">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <SheetTitle className="truncate text-xl">{item.name}</SheetTitle>
              <SheetDescription className="mt-1 flex flex-wrap items-center gap-2">
                <Badge variant="outline">
                  {INVENTORY_CATEGORY_LABEL[item.category]}
                </Badge>
                <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${status.cls}`}>
                  {status.label}
                </span>
                {item.lastSupplier && (
                  <span className="text-xs text-muted-foreground">
                    Supplier: {item.lastSupplier}
                  </span>
                )}
              </SheetDescription>
            </div>
          </div>
        </SheetHeader>

        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="flex flex-col gap-5 p-6">
              {/* Section 1 — Info */}
              <Card>
                <CardContent className="grid grid-cols-2 gap-x-4 gap-y-3 pt-6 text-sm">
                  <InfoRow label="Stok Saat Ini" value={`${formatNumber(item.stock)} ${item.unit}`} strong />
                  <InfoRow label="Satuan" value={item.unit} />
                  <InfoRow
                    label="Harga Terakhir"
                    value={lastPrice > 0 ? formatIDR(lastPrice) : "—"}
                  />
                  <InfoRow
                    label="Cost per Unit"
                    value={item.costPerUnit > 0 ? formatIDR(item.costPerUnit) : "—"}
                  />
                  <InfoRow label="Safety Stock" value={safety > 0 ? formatNumber(safety) : "—"} />
                  <InfoRow
                    label="Nilai Persediaan"
                    value={inventoryValue > 0 ? formatIDR(inventoryValue) : "—"}
                    strong
                  />
                </CardContent>
              </Card>

              {/* Section 2 — Month summary */}
              <div>
                <div className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Ringkasan Bulan Ini
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <MiniStat
                    icon={<ArrowUpRight className="h-3.5 w-3.5" />}
                    label="Masuk"
                    value={formatNumber(monthSummary.inQty)}
                    tone="in"
                  />
                  <MiniStat
                    icon={<ArrowDownRight className="h-3.5 w-3.5" />}
                    label="Keluar"
                    value={formatNumber(monthSummary.outQty)}
                    tone="out"
                  />
                  <MiniStat
                    icon={<Wrench className="h-3.5 w-3.5" />}
                    label="Adjustment"
                    value={`${monthSummary.adjQty > 0 ? "+" : ""}${formatNumber(monthSummary.adjQty)}`}
                  />
                  <MiniStat
                    icon={<Activity className="h-3.5 w-3.5" />}
                    label="Saldo"
                    value={formatNumber(item.stock)}
                    tone="balance"
                  />
                </div>
              </div>

              {/* Section 4 — Statistics 30 days */}
              <div>
                <div className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  30 Hari Terakhir
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <MiniStat label="Masuk" value={formatNumber(last30.inQty)} tone="in" />
                  <MiniStat label="Keluar" value={formatNumber(last30.outQty)} tone="out" />
                  <MiniStat
                    label="Adjustment"
                    value={`${last30.adjQty > 0 ? "+" : ""}${formatNumber(last30.adjQty)}`}
                  />
                  <MiniStat label="Total Movement" value={formatNumber(last30.total)} />
                </div>
              </div>

              <Separator />

              {/* Section 3 — Timeline */}
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold">Timeline Pergerakan</div>
                  <span className="text-xs text-muted-foreground">
                    {filtered.length} entri
                  </span>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Cari referensi atau catatan…"
                      className="pl-9"
                    />
                  </div>
                  <Select
                    value={filter}
                    onValueChange={(v) => setFilter(v as MovementFilter)}
                  >
                    <SelectTrigger className="w-full sm:w-[170px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua</SelectItem>
                      <SelectItem value="in">Masuk</SelectItem>
                      <SelectItem value="out">Keluar</SelectItem>
                      <SelectItem value="adjustment">Adjustment</SelectItem>
                      <SelectItem value="production">Produksi</SelectItem>
                      <SelectItem value="packaging">Packaging / Sales</SelectItem>
                      <SelectItem value="operational">Operasional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {movements.length === 0 ? (
                  <EmptyState message="Belum ada riwayat pergerakan barang." />
                ) : filtered.length === 0 ? (
                  <EmptyState message="Tidak ada movement yang cocok dengan filter." />
                ) : (
                  <ol className="relative flex flex-col gap-3 border-l border-border/70 pl-4">
                    {filtered.map((m) => {
                      const style = TYPE_STYLE[m.type];
                      const positive = m.delta > 0;
                      return (
                        <li key={m.id} className="relative">
                          <span
                            className={`absolute -left-[21px] top-2 h-2.5 w-2.5 rounded-full ring-2 ring-background ${
                              positive
                                ? "bg-emerald-500"
                                : m.type === "adjustment"
                                  ? "bg-muted-foreground/60"
                                  : "bg-destructive"
                            }`}
                          />
                          <Card className="border-border/80">
                            <CardContent className="flex flex-col gap-2 pt-4">
                              <div className="flex items-start justify-between gap-3">
                                <div className="flex flex-wrap items-center gap-2">
                                  <Badge className={style.className} variant="secondary">
                                    {style.label}
                                  </Badge>
                                  <span className="text-xs text-muted-foreground">
                                    {formatDate(m.createdAt)} · {formatTime(m.createdAt)}
                                  </span>
                                </div>
                                <div className="text-right">
                                  <div
                                    className={`text-sm font-semibold tabular-nums ${
                                      positive
                                        ? "text-emerald-600 dark:text-emerald-400"
                                        : m.type === "adjustment"
                                          ? "text-foreground"
                                          : "text-destructive"
                                    }`}
                                  >
                                    {positive ? "+" : ""}
                                    {formatNumber(m.delta)} {item.unit}
                                  </div>
                                  <div className="text-[11px] text-muted-foreground">
                                    Saldo: {formatNumber(m.balanceAfter)}
                                  </div>
                                </div>
                              </div>
                              {(m.reason || m.notes) && (
                                <div className="text-xs text-muted-foreground">
                                  {m.reason && (
                                    <div>
                                      <span className="font-medium text-foreground">
                                        Ref:
                                      </span>{" "}
                                      {m.reason}
                                    </div>
                                  )}
                                  {m.notes && (
                                    <div className="mt-0.5">{m.notes}</div>
                                  )}
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        </li>
                      );
                    })}
                  </ol>
                )}
              </div>
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function InfoRow({
  label,
  value,
  strong,
}: {
  label: string;
  value: string;
  strong?: boolean;
}) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <span
        className={`tabular-nums ${strong ? "text-base font-semibold" : "text-sm"}`}
      >
        {value}
      </span>
    </div>
  );
}

function MiniStat({
  label,
  value,
  icon,
  tone,
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
  tone?: "in" | "out" | "balance";
}) {
  const cls =
    tone === "in"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "out"
        ? "text-destructive"
        : tone === "balance"
          ? "text-primary"
          : "text-foreground";
  return (
    <div className="rounded-lg border bg-muted/30 px-3 py-2">
      <div className="flex items-center gap-1 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className={`text-lg font-semibold tabular-nums ${cls}`}>{value}</div>
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed py-10 text-center">
      <div className="grid h-10 w-10 place-items-center rounded-full bg-muted text-muted-foreground">
        <History className="h-5 w-5" strokeWidth={1.5} />
      </div>
      <div className="text-sm text-muted-foreground">{message}</div>
    </div>
  );
}
