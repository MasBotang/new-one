import { storage, StorageKeys } from "./storage";
import { productService } from "./product.service";
import { userService } from "./user.service";
import { inventoryService } from "./inventory.service";
import { recipeService } from "./recipe.service";
import type { InventoryItem, Product, RecipeType, User } from "./types";

const seedProducts: Product[] = [
  { id: "p1", name: "Es Kopi Susu", category: "Kopi", price: 18000, cost: 6000, stock: 50, active: true, imageUrl: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&q=70" },
  { id: "p2", name: "Americano", category: "Kopi", price: 20000, cost: 5000, stock: 50, active: true, imageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&q=70" },
  { id: "p3", name: "Cappuccino", category: "Kopi", price: 25000, cost: 7000, stock: 50, active: true, imageUrl: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=400&q=70" },
  { id: "p4", name: "Matcha Latte", category: "Teh", price: 28000, cost: 9000, stock: 40, active: true, imageUrl: "https://images.unsplash.com/photo-1545518514-ce8448f542b3?w=400&q=70" },
  { id: "p5", name: "Lemon Tea", category: "Teh", price: 15000, cost: 4000, stock: 60, active: true, imageUrl: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&q=70" },
  { id: "p6", name: "Chocolate", category: "Teh", price: 22000, cost: 7000, stock: 40, active: true, imageUrl: "https://images.unsplash.com/photo-1542990253-0b8be07d6b8b?w=400&q=70" },
  { id: "p7", name: "Croissant", category: "Pastry", price: 18000, cost: 8000, stock: 20, active: true, imageUrl: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=70" },
  { id: "p8", name: "Pain au Chocolat", category: "Pastry", price: 22000, cost: 9000, stock: 20, active: true, imageUrl: "https://images.unsplash.com/photo-1623334044303-241021148842?w=400&q=70" },
  { id: "p9", name: "Sandwich Tuna", category: "Makanan", price: 35000, cost: 14000, stock: 15, active: true, imageUrl: "https://images.unsplash.com/photo-1539252554935-80c8cabf1542?w=400&q=70" },
  { id: "p10", name: "Nasi Ayam", category: "Makanan", price: 30000, cost: 12000, stock: 25, active: true, imageUrl: "https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?w=400&q=70" },
  { id: "p11", name: "Air Mineral", category: "Lainnya", price: 8000, cost: 2500, stock: 100, active: true, imageUrl: "https://images.unsplash.com/photo-1560023907-5f339617ea30?w=400&q=70" },
  { id: "p12", name: "Soft Drink", category: "Lainnya", price: 12000, cost: 4000, stock: 80, active: true, imageUrl: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&q=70" },
];

const seedUsers: User[] = [
  { id: "u1", name: "Andi", role: "admin" },
  { id: "u2", name: "Budi", role: "owner" },
  { id: "u3", name: "Citra", role: "cashier" },
  { id: "u4", name: "Dewi", role: "production" },
];

export function seedIfEmpty() {
  if (storage.has(StorageKeys.seeded)) {
    // Migration: backfill imageUrl / stock for previously-seeded products.
    const existing = productService.list();
    if (existing.length > 0) {
      let changed = false;
      const byId = new Map(seedProducts.map((p) => [p.id, p]));
      const merged = existing.map((p) => {
        const ref = byId.get(p.id);
        const next = { ...p };
        if (!next.imageUrl && ref?.imageUrl) {
          next.imageUrl = ref.imageUrl;
          changed = true;
        }
        if (next.stock == null) {
          next.stock = ref?.stock ?? 0;
          changed = true;
        }
        return next;
      });
      if (changed) productService.save(merged);
    }
    return;
  }
  if (productService.list().length === 0) productService.save(seedProducts);
  if (userService.list().length === 0) userService.save(seedUsers);
  storage.set(StorageKeys.seeded, true);
}

// ---------------- Inventory (Version 2) ----------------
type SeedInv = Omit<InventoryItem, "id" | "createdAt" | "updatedAt" | "costPerUnit"> & {
  id?: string;
};

const seedInventory: SeedInv[] = [
  // Operasional
  { name: "Air Mineral", category: "operational", unit: "botol", stock: 40, minStock: 20, purchasePrice: 5000, purchaseQuantity: 1, active: true },
  { name: "Gas LPG 3kg", category: "operational", unit: "tabung", stock: 6, minStock: 3, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Sabun Cuci", category: "operational", unit: "pcs", stock: 10, minStock: 3, purchasePrice: 18000, purchaseQuantity: 1, active: true },
  { name: "Sabun Tangan", category: "operational", unit: "pcs", stock: 5, minStock: 2, purchasePrice: 15000, purchaseQuantity: 1, active: true },
  { name: "Tisu", category: "operational", unit: "pack", stock: 20, minStock: 5, purchasePrice: 12000, purchaseQuantity: 1, active: true },
  { name: "Lakban", category: "operational", unit: "roll", stock: 10, minStock: 3, purchasePrice: 15000, purchaseQuantity: 1, active: true },
  { name: "Spidol", category: "operational", unit: "pcs", stock: 5, minStock: 2, purchasePrice: 8000, purchaseQuantity: 1, active: true },
  { name: "Masker", category: "operational", unit: "box", stock: 5, minStock: 1, purchasePrice: 25000, purchaseQuantity: 1, active: true },
  { name: "Sarung Tangan", category: "operational", unit: "box", stock: 5, minStock: 1, purchasePrice: 30000, purchaseQuantity: 1, active: true },
  { name: "Kantong Sampah", category: "operational", unit: "pack", stock: 8, minStock: 2, purchasePrice: 18000, purchaseQuantity: 1, active: true },
  // Packaging — Launch Box
  { name: "Launch Box Xtra Kecil (Isi 2)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 800, purchaseQuantity: 1, active: true },
  { name: "Launch Box Kecil (Isi 3)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 1000, purchaseQuantity: 1, active: true },
  { name: "Launch Box Sedang (Isi 4-5)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 1200, purchaseQuantity: 1, active: true },
  { name: "Launch Box Sedang Xtra (Isi 6-8)", category: "packaging", unit: "pcs", stock: 200, minStock: 50, purchasePrice: 1500, purchaseQuantity: 1, active: true },
  // Packaging — Plastik Non PE
  { name: "Plastik Non PE Kecil", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 200, purchaseQuantity: 1, active: true },
  { name: "Plastik Non PE Sedang", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 300, purchaseQuantity: 1, active: true },
  { name: "Plastik Non PE Besar", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 400, purchaseQuantity: 1, active: true },
  // Packaging — Plastik PE
  { name: "Plastik PE Kecil", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 250, purchaseQuantity: 1, active: true },
  { name: "Plastik PE Sedang", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 350, purchaseQuantity: 1, active: true },
  { name: "Plastik PE Besar", category: "packaging", unit: "pcs", stock: 300, minStock: 100, purchasePrice: 500, purchaseQuantity: 1, active: true },
  // Bahan Baku
  { name: "Bawang Merah", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Bawang Putih", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Cabai Kriting", category: "raw", unit: "kg", stock: 2, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Cabai Rawit", category: "raw", unit: "kg", stock: 2, minStock: 1, purchasePrice: 70000, purchaseQuantity: 1, active: true },
  { name: "Carnation 2kg", category: "raw", unit: "kg", stock: 8, minStock: 4, purchasePrice: 477100, purchaseQuantity: 8, active: true },
  { name: "Choco Crunchy 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 611000, purchaseQuantity: 12, active: true },
  { name: "Cidea Crabstick 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 573900, purchaseQuantity: 12, active: true },
  { name: "Dada Fillet", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 55000, purchaseQuantity: 1, active: true },
  { name: "Daun Salam & Jeruk", category: "raw", unit: "ikat", stock: 3, minStock: 1, purchasePrice: 2000, purchaseQuantity: 1, active: true },
  { name: "Delmonte Cabe 1kg", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 220000, purchaseQuantity: 10, active: true },
  { name: "Garam", category: "raw", unit: "pcs", stock: 3, minStock: 1, purchasePrice: 6000, purchaseQuantity: 1, active: true },
  { name: "Greentea Crunchy 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 680000, purchaseQuantity: 12, active: true },
  { name: "Gula", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Jagung", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 12000, purchaseQuantity: 1, active: true },
  { name: "Kentang", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 18000, purchaseQuantity: 1, active: true },
  { name: "Kewpie 1kg", category: "raw", unit: "kg", stock: 4, minStock: 2, purchasePrice: 395000, purchaseQuantity: 6, active: true },
  { name: "Ladaku", category: "raw", unit: "sachet", stock: 24, minStock: 12, purchasePrice: 11500, purchaseQuantity: 12, active: true },
  { name: "Mamayo 1kg", category: "raw", unit: "kg", stock: 6, minStock: 3, purchasePrice: 255000, purchaseQuantity: 12, active: true },
  { name: "Mentega", category: "raw", unit: "gram", stock: 1000, minStock: 400, purchasePrice: 5000, purchaseQuantity: 200, active: true },
  { name: "Minyak 1 KG Tropical", category: "raw", unit: "liter", stock: 10, minStock: 4, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Minyak Adonan Risol", category: "raw", unit: "liter", stock: 5, minStock: 2, purchasePrice: 20000, purchaseQuantity: 1, active: true },
  { name: "Nori MamaSuka", category: "raw", unit: "pcs", stock: 10, minStock: 4, purchasePrice: 13800, purchaseQuantity: 1, active: true },
  { name: "Panir Pita 10kg", category: "raw", unit: "kg", stock: 10, minStock: 5, purchasePrice: 133000, purchaseQuantity: 10, active: true },
  { name: "Prochiz Gold Cheddar 2kg", category: "raw", unit: "kg", stock: 4, minStock: 2, purchasePrice: 815000, purchaseQuantity: 8, active: true },
  { name: "Prochiz Quick Melt Slice", category: "raw", unit: "pcs", stock: 48, minStock: 24, purchasePrice: 500000, purchaseQuantity: 48, active: true },
  { name: "Rice Crispy 1kg", category: "raw", unit: "kg", stock: 3, minStock: 1, purchasePrice: 50000, purchaseQuantity: 1, active: true },
  { name: "Slice Beef 1kg", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 950000, purchaseQuantity: 10, active: true },
  { name: "Susu UHT Diamond", category: "raw", unit: "kg", stock: 10, minStock: 5, purchasePrice: 190000, purchaseQuantity: 10, active: true },
  { name: "Telur", category: "raw", unit: "kg", stock: 5, minStock: 2, purchasePrice: 28000, purchaseQuantity: 1, active: true },
  { name: "Tepung Tapioka Gunung", category: "raw", unit: "pcs", stock: 10, minStock: 5, purchasePrice: 105000, purchaseQuantity: 20, active: true },
  { name: "Tepung Terigu", category: "raw", unit: "kg", stock: 25, minStock: 10, purchasePrice: 213000, purchaseQuantity: 25, active: true },
  { name: "Totole Kaldu Jamur", category: "raw", unit: "gram", stock: 800, minStock: 400, purchasePrice: 51000, purchaseQuantity: 400, active: true },
  { name: "Wortel", category: "raw", unit: "kg", stock: 4, minStock: 2, purchasePrice: 15000, purchaseQuantity: 1, active: true },
];

export function seedInventoryIfEmpty() {
  if (storage.has(StorageKeys.inventorySeeded)) return;
  // Reseed: replace any legacy inventory list wholesale with the current seed.
  inventoryService.save([]);
  for (const i of seedInventory) inventoryService.create(i);
  storage.set(StorageKeys.inventorySeeded, true);
}

// ---------------- Recipes (Version 1) ----------------
type SeedRecipeIngredient = { name: string; quantity: number };
type SeedRecipe = {
  name: string;
  type: RecipeType;
  outputName: string;
  outputQuantity: number;
  outputUnit: string;
  notes?: string;
  ingredients: SeedRecipeIngredient[];
};

const seedRecipes: SeedRecipe[] = [
  {
    name: "Kulit Risol",
    type: "semi_finished",
    outputName: "Kulit Risol",
    outputQuantity: 90,
    outputUnit: "pcs",
    notes: "Untuk 1 kg adonan kulit (asumsi 90 lembar).",
    ingredients: [
      { name: "Tepung Terigu", quantity: 1 },
      { name: "Tepung Tapioka Gunung", quantity: 0.26 },
      { name: "Garam", quantity: 0.05 },
      { name: "Air", quantity: 2.6 },
      { name: "Telur", quantity: 0.133 },
      { name: "Minyak Adonan Risol", quantity: 0.04 },
      { name: "Gas LPG 3kg", quantity: 0.6 },
    ],
  },
  {
    name: "Panir",
    type: "semi_finished",
    outputName: "Adonan Panir",
    outputQuantity: 90,
    outputUnit: "pcs",
    notes: "Komposisi panir untuk 1 kg kulit risol.",
    ingredients: [
      { name: "Tepung Terigu", quantity: 0.2 },
      { name: "Air", quantity: 0.6 },
      { name: "Panir Pita 10kg", quantity: 0.765 },
    ],
  },
  {
    name: "Saus Mayo Original",
    type: "semi_finished",
    outputName: "Saus Mayo Original",
    outputQuantity: 35,
    outputUnit: "porsi",
    ingredients: [
      { name: "Mamayo 1kg", quantity: 1.1 },
      { name: "Carnation 2kg", quantity: 0.11 },
    ],
  },
  {
    name: "Saus Spicy Mayo",
    type: "semi_finished",
    outputName: "Saus Spicy Mayo",
    outputQuantity: 70,
    outputUnit: "porsi",
    ingredients: [
      { name: "Mamayo 1kg", quantity: 1.1 },
      { name: "Carnation 2kg", quantity: 0.11 },
      { name: "Delmonte Cabe 1kg", quantity: 1 },
      { name: "Nori MamaSuka", quantity: 0.296 },
    ],
  },
  {
    name: "Saus Mayo Spesial",
    type: "semi_finished",
    outputName: "Saus Mayo Spesial",
    outputQuantity: 70,
    outputUnit: "porsi",
    ingredients: [
      { name: "Mamayo 1kg", quantity: 1.1 },
      { name: "Carnation 2kg", quantity: 0.11 },
      { name: "Delmonte Cabe 1kg", quantity: 0.5 },
      { name: "Kewpie 1kg", quantity: 0.5 },
    ],
  },
  {
    name: "Isian Ayam Pedas",
    type: "semi_finished",
    outputName: "Isian Ayam Pedas",
    outputQuantity: 100,
    outputUnit: "porsi",
    notes: "Bumbu (bawang, cabai, kaldu, garam, gula, minyak) ditambahkan secukupnya sesuai selera.",
    ingredients: [
      { name: "Dada Fillet", quantity: 1 },
      { name: "Gas LPG 3kg", quantity: 5 },
    ],
  },
  {
    name: "Isian Ragout",
    type: "semi_finished",
    outputName: "Isian Ragout",
    outputQuantity: 100,
    outputUnit: "porsi",
    ingredients: [
      { name: "Wortel", quantity: 1 },
      { name: "Kentang", quantity: 1 },
      { name: "Jagung", quantity: 1 },
      { name: "Dada Fillet", quantity: 1 },
      { name: "Mentega", quantity: 50 },
      { name: "Totole Kaldu Jamur", quantity: 100 },
      { name: "Susu UHT Diamond", quantity: 1 },
      { name: "Air", quantity: 0.5 },
      { name: "Garam", quantity: 0.1 },
      { name: "Tepung Terigu", quantity: 0.15 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.25 },
      { name: "Gas LPG 3kg", quantity: 1.2 },
    ],
  },
  // ---- Finished (Varian Risol) ----
  {
    name: "Risol Mayo Original",
    type: "finished",
    outputName: "Risol Mayo Original",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Saus Mayo Original", quantity: 1 },
      { name: "Slice Beef 1kg", quantity: 0.05 },
      { name: "Telur", quantity: 0.0085 },
    ],
  },
  {
    name: "Risol Spicy Nori",
    type: "finished",
    outputName: "Risol Spicy Nori",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Saus Spicy Mayo", quantity: 1 },
      { name: "Cidea Crabstick 1kg", quantity: 0.06 },
      { name: "Telur", quantity: 0.0085 },
    ],
  },
  {
    name: "Risol Mayo Spesial",
    type: "finished",
    outputName: "Risol Mayo Spesial",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Saus Mayo Spesial", quantity: 1 },
      { name: "Slice Beef 1kg", quantity: 0.05 },
      { name: "Telur", quantity: 0.0085 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.004 },
      { name: "Prochiz Quick Melt Slice", quantity: 0.0667 },
    ],
  },
  {
    name: "Risol Ragout Ayam",
    type: "finished",
    outputName: "Risol Ragout Ayam",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Isian Ragout", quantity: 1 },
    ],
  },
  {
    name: "Risol Coklat Crispy",
    type: "finished",
    outputName: "Risol Coklat Crispy",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Choco Crunchy 1kg", quantity: 0.022 },
      { name: "Rice Crispy 1kg", quantity: 0.01 },
    ],
  },
  {
    name: "Risol Matcha Cheese",
    type: "finished",
    outputName: "Risol Matcha Cheese",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Greentea Crunchy 1kg", quantity: 0.025 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.02 },
    ],
  },
  {
    name: "Risol Choco Cheese",
    type: "finished",
    outputName: "Risol Choco Cheese",
    outputQuantity: 1,
    outputUnit: "pcs",
    ingredients: [
      { name: "Kulit Risol", quantity: 1 },
      { name: "Adonan Panir", quantity: 1 },
      { name: "Choco Crunchy 1kg", quantity: 0.025 },
      { name: "Prochiz Gold Cheddar 2kg", quantity: 0.02 },
    ],
  },
];

export function seedRecipesIfEmpty() {
  if (storage.has(StorageKeys.recipesSeeded)) return;
  if (recipeService.list().length > 0) {
    storage.set(StorageKeys.recipesSeeded, true);
    return;
  }
  for (const r of seedRecipes) {
    const items = inventoryService.list();
    const byName = new Map(items.map((i) => [i.name.toLowerCase(), i]));
    const ingredients = r.ingredients
      .map((ing) => {
        const item = byName.get(ing.name.toLowerCase());
        if (!item) {
          // Bahan umum yang tidak ditrack di inventaris (mis. air keran) tidak
          // perlu memicu warning — cukup skip dari daftar bahan resep.
          const UNTRACKED = new Set(["air"]);
          if (!UNTRACKED.has(ing.name.trim().toLowerCase())) {
            console.warn(
              `[seed] recipe "${r.name}": bahan "${ing.name}" tidak ditemukan di inventaris`,
            );
          }
          return null;
        }
        const source = item.category === "production_item" ? ("recipe" as const) : ("inventory" as const);
        return { inventoryItemId: item.id, quantity: ing.quantity, source };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);
    if (ingredients.length === 0) continue;
    try {
      recipeService.create({
        name: r.name,
        type: r.type,
        outputTargetType: "inventory",
        outputRefId: "",
        outputName: r.outputName,
        outputQuantity: r.outputQuantity,
        outputUnit: r.outputUnit,
        estimatedYieldPct: 100,
        notes: r.notes ?? "",
        ingredients,
        active: true,
      });
    } catch (e) {
      console.error(`[seed] gagal membuat resep "${r.name}":`, e);
    }
  }
  storage.set(StorageKeys.recipesSeeded, true);
}