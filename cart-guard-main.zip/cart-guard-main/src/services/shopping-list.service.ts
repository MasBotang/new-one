import { inventoryService } from "./inventory.service";
import { recipeService } from "./recipe.service";
import { productionPlanningService } from "./production-planning.service";
import { preorderService } from "./preorder.service";
import type { InventoryItem, Recipe } from "./types";

/**
 * Shopping List — Single Source of Truth untuk rekomendasi pembelian.
 *
 * Filosofi Inventory v1.0:
 * Shopping List BUKAN sekadar `stock < minStock`. Ia diturunkan dari
 * kebutuhan produksi ke depan sehingga rekomendasi belanja mengikuti
 * demand aktual, bukan hanya alert restock.
 *
 *   Forecast Produksi + Pre-Order + Minimum Stock (alert)
 *          │
 *          ▼  (Recipe explosion — semi-finished direkursi ke raw)
 *   Kebutuhan Bahan (per InventoryItem)
 *          │
 *          ▼
 *   Shopping List
 *
 * MinStock berperan sebagai alert baseline, BUKAN target produksi dan
 * BUKAN forecast. Bila stok saat ini + kebutuhan produksi masih di atas
 * minStock, item tidak masuk daftar belanja.
 */

export type ShoppingPriority = "today" | "tomorrow" | "watch";

export interface ShoppingListEntry {
  item: InventoryItem;
  /** Kebutuhan bahan dari forecast produksi hari ini (unit item). */
  productionNeed: number;
  /** Kebutuhan bahan dari Pre-Order aktif (unit item). */
  preorderNeed: number;
  /** Minimum stock (alert baseline). */
  minStock: number;
  /** Stok saat ini. */
  stock: number;
  /** Kekurangan yang harus dibeli = max(0, productionNeed + preorderNeed + minStock − stock). */
  deficit: number;
  priority: ShoppingPriority;
  /** Rekomendasi qty pembelian dalam unit item. */
  recommendedQuantity: number;
  /** Jika pembelian per karton, jumlah karton hasil pembulatan. */
  recommendedCartons?: number;
  /** Isi per karton (echoed for UI). */
  unitsPerCarton?: number;
  reason: string;
}

/**
 * Backward-compat: sebagian caller lama mengharapkan angka "safety".
 * Setelah Inventory v1.0, safety = minStock (alert baseline). Field
 * `safetyStock` opsional pada item dipertahankan sebagai override manual.
 */
export function effectiveSafety(item: InventoryItem): number {
  const s = Number(item.safetyStock);
  if (Number.isFinite(s) && s > 0) return s;
  return Math.max(0, Number(item.minStock) || 0);
}

/**
 * Ekspansi resep menjadi kebutuhan per InventoryItem.
 * Rekursif untuk ingredient dengan source="recipe" (semi-finished/adonan).
 *
 * @param outputUnitsNeeded jumlah unit output resep yang dibutuhkan
 * @param acc               akumulator kebutuhan per inventory item id
 * @param seen              guard anti-cycle
 */
function explodeRecipe(
  recipe: Recipe,
  outputUnitsNeeded: number,
  acc: Map<string, number>,
  seen: Set<string> = new Set(),
): void {
  if (outputUnitsNeeded <= 0) return;
  if (seen.has(recipe.id)) return;
  seen.add(recipe.id);

  const perOutput = recipe.outputQuantity > 0 ? recipe.outputQuantity : 1;
  const batches = outputUnitsNeeded / perOutput;
  for (const ing of recipe.ingredients) {
    const qty = ing.quantity * batches;
    if (qty <= 0) continue;
    if (ing.source === "recipe" && ing.recipeId) {
      const sub = recipeService.get(ing.recipeId);
      if (sub) {
        explodeRecipe(sub, qty, acc, new Set(seen));
        continue;
      }
    }
    acc.set(ing.inventoryItemId, (acc.get(ing.inventoryItemId) ?? 0) + qty);
  }
}

function todayISODate(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/**
 * Kumpulkan kebutuhan produksi (per productId) dari:
 *   1. Rekomendasi Forecast (productionPlanningService.buildPlanning)
 *   2. Pre-Order yang belum selesai (scheduled | ready_to_process)
 * Return dua map terpisah agar UI bisa menampilkan sumbernya.
 */
function collectProductionDemand(): {
  forecast: Map<string, number>;
  preorder: Map<string, number>;
} {
  const forecast = new Map<string, number>();
  const preorder = new Map<string, number>();

  try {
    const rows = productionPlanningService.buildPlanning(new Date());
    for (const r of rows) {
      if (r.target > 0) forecast.set(r.productId, r.target);
    }
  } catch {
    // planning membutuhkan produk aktif; abaikan bila gagal
  }

  const today = todayISODate();
  try {
    const active = preorderService.list().filter(
      (p) => (p.status === "scheduled" || p.status === "ready_to_process") && p.date >= today,
    );
    for (const po of active) {
      for (const it of po.items) {
        preorder.set(it.productId, (preorder.get(it.productId) ?? 0) + (Number(it.qty) || 0));
      }
    }
  } catch {
    // preorder module opsional
  }

  return { forecast, preorder };
}

export const shoppingListService = {
  /**
   * SSoT rekomendasi belanja. Dihitung on-demand — tidak menyimpan cache.
   *
   * Rumus:
   *   need     = productionNeed + preorderNeed
   *   deficit  = max(0, need + minStock − stock)
   *
   * MinStock dimasukkan sebagai *alert baseline* — memastikan setelah
   * produksi berjalan, stok tidak jatuh di bawah minimum.
   */
  compute(): ShoppingListEntry[] {
    const items = inventoryService
      .list()
      .filter((i) => i.active && i.category !== "production_item");

    // 1. Kumpulkan kebutuhan produksi per productId
    const { forecast, preorder } = collectProductionDemand();

    // 2. Peta productId → recipe (finished, outputTargetType="product")
    const recipeByProduct = new Map<string, Recipe>();
    for (const r of recipeService.active()) {
      if (r.outputTargetType === "product" && r.outputRefId) {
        recipeByProduct.set(r.outputRefId, r);
      }
    }

    // 3. Ekspansi resep → kebutuhan per inventory item
    const forecastNeed = new Map<string, number>();
    const preorderNeed = new Map<string, number>();
    for (const [productId, qty] of forecast) {
      const r = recipeByProduct.get(productId);
      if (r) explodeRecipe(r, qty, forecastNeed);
    }
    for (const [productId, qty] of preorder) {
      const r = recipeByProduct.get(productId);
      if (r) explodeRecipe(r, qty, preorderNeed);
    }

    // 4. Bangun entries. Kandidat = item yang muncul di kebutuhan produksi
    //    ATAU stok saat ini ≤ minStock (alert restock murni).
    const candidates = new Set<string>();
    for (const id of forecastNeed.keys()) candidates.add(id);
    for (const id of preorderNeed.keys()) candidates.add(id);
    for (const i of items) {
      if (i.minStock > 0 && i.stock <= i.minStock) candidates.add(i.id);
    }

    const out: ShoppingListEntry[] = [];
    for (const item of items) {
      if (!candidates.has(item.id)) continue;
      const pNeed = Math.max(0, forecastNeed.get(item.id) ?? 0);
      const oNeed = Math.max(0, preorderNeed.get(item.id) ?? 0);
      const minStock = Math.max(0, Number(item.minStock) || 0);
      const need = pNeed + oNeed;
      const requirement = need + minStock;
      const deficit = Math.max(0, requirement - item.stock);
      if (deficit <= 0) continue;

      let recommendedQuantity = Math.ceil(deficit * 100) / 100;
      let recommendedCartons: number | undefined;
      const unitsPerCarton = item.unitsPerCarton;
      if (item.purchaseType === "karton" && unitsPerCarton && unitsPerCarton > 0) {
        recommendedCartons = Math.max(1, Math.ceil(deficit / unitsPerCarton));
        recommendedQuantity = recommendedCartons * unitsPerCarton;
      }

      // Prioritas — didorong oleh urgensi operasional, bukan chart analitik.
      // - today   : stok habis, atau kebutuhan hari ini > stok
      // - tomorrow: stok akan menipis setelah produksi (jatuh di bawah minStock)
      // - watch   : sekadar alert minStock
      let priority: ShoppingPriority;
      if (item.stock <= 0 || (pNeed > 0 && item.stock < pNeed)) priority = "today";
      else if (need > 0 && item.stock < requirement) priority = "tomorrow";
      else priority = "watch";

      const reason =
        priority === "today"
          ? "BELI HARI INI"
          : priority === "tomorrow"
            ? "BELI BESOK"
            : "PANTAU";

      out.push({
        item,
        productionNeed: Math.round(pNeed * 100) / 100,
        preorderNeed: Math.round(oNeed * 100) / 100,
        minStock,
        stock: item.stock,
        deficit: Math.round(deficit * 100) / 100,
        priority,
        recommendedQuantity,
        recommendedCartons,
        unitsPerCarton,
        reason,
      });
    }

    const rank: Record<ShoppingPriority, number> = { today: 0, tomorrow: 1, watch: 2 };
    out.sort((a, b) => rank[a.priority] - rank[b.priority] || b.deficit - a.deficit);
    return out;
  },
};
