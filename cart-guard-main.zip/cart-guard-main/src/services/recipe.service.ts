import { storage, StorageKeys } from "./storage";
import { inventoryService } from "./inventory.service";
import type { Recipe, RecipeIngredient } from "./types";

function uid() {
  return `rcp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

export type NewRecipe = Omit<Recipe, "id" | "createdAt" | "updatedAt">;

export interface RecipeValidationError {
  field: string;
  message: string;
}

/**
 * Auto-create/link inventory item untuk output resep.
 * Mengembalikan field2 turunan: outputRefId, outputTargetType, outputUnit, outputName.
 */
function resolveOutput(input: NewRecipe): Pick<
  Recipe,
  "outputRefId" | "outputTargetType" | "outputUnit" | "outputName"
> {
  const name = (input.outputName?.trim() || input.name?.trim() || "Panir");
  const unit = input.outputUnit?.trim() || "pcs";
  // Panir recipes are pure compositions — they don't produce a stockable
  // output. Skip auto-creating an inventory item.
  if (input.type === "panir") {
    return {
      outputTargetType: "inventory",
      outputRefId: "",
      outputName: name,
      outputUnit: unit,
    };
  }
  const item = inventoryService.ensureProductionItem(name, unit);
  return {
    outputTargetType: "inventory",
    outputRefId: item.id,
    outputName: name,
    outputUnit: item.unit,
  };
}

function validate(input: NewRecipe, ignoreId?: string): RecipeValidationError[] {
  const errs: RecipeValidationError[] = [];
  if (!input.name.trim()) errs.push({ field: "name", message: "Nama resep wajib diisi" });
  if (recipeService.isDuplicateName(input.name, ignoreId))
    errs.push({ field: "name", message: "Nama resep sudah digunakan" });
  // Panir recipes are pure compositions (per 1 pcs) — output name/qty/unit
  // are not required from the user; they'll be auto-defaulted.
  if (input.type !== "panir") {
    if (!input.outputName?.trim())
      errs.push({ field: "outputName", message: "Nama output wajib diisi" });
    if (!(input.outputQuantity > 0))
      errs.push({ field: "outputQuantity", message: "Qty output harus > 0" });
    if (!input.outputUnit.trim()) errs.push({ field: "outputUnit", message: "Satuan output wajib" });
  }
  if (input.estimatedYieldPct < 0 || input.estimatedYieldPct > 100)
    errs.push({ field: "estimatedYieldPct", message: "Yield 0–100%" });
  if (!input.ingredients.length)
    errs.push({ field: "ingredients", message: "Minimal 1 bahan" });
  const seen = new Set<string>();
  for (const ing of input.ingredients) {
    if (!ing.inventoryItemId) {
      errs.push({
        field: "ingredients",
        message:
          ing.source === "recipe"
            ? "Pilih adonan sumber untuk setiap bahan"
            : "Setiap bahan harus dipilih dari inventaris",
      });
      continue;
    }
    if (seen.has(ing.inventoryItemId)) {
      errs.push({ field: "ingredients", message: "Bahan duplikat tidak diperbolehkan" });
    }
    seen.add(ing.inventoryItemId);
    if (!(ing.quantity > 0))
      errs.push({ field: "ingredients", message: "Qty bahan harus > 0" });
    if (!inventoryService.get(ing.inventoryItemId))
      errs.push({ field: "ingredients", message: "Bahan tidak ditemukan di inventaris" });
  }
  return errs;
}

export const recipeService = {
  list(): Recipe[] {
    const raw = storage.get<Recipe[]>(StorageKeys.recipes);
    if (!Array.isArray(raw)) return [];
    return raw.filter((r) => r && typeof r === "object" && typeof r.id === "string");
  },
  save(list: Recipe[]) {
    storage.set(StorageKeys.recipes, list);
  },
  get(id: string): Recipe | undefined {
    return recipeService.list().find((r) => r.id === id);
  },
  active(): Recipe[] {
    return recipeService.list().filter((r) => r.active);
  },
  isDuplicateName(name: string, ignoreId?: string): boolean {
    const n = name.trim().toLowerCase();
    if (!n) return false;
    return recipeService
      .list()
      .some((r) => r.id !== ignoreId && r.name.trim().toLowerCase() === n);
  },
  validate,
  create(input: NewRecipe): Recipe {
    const errs = validate(input);
    if (errs.length) throw new Error(errs[0].message);
    const resolved = resolveOutput(input);
    const now = new Date().toISOString();
    const r: Recipe = { ...input, ...resolved, id: uid(), createdAt: now, updatedAt: now };
    const list = recipeService.list();
    list.unshift(r);
    recipeService.save(list);
    return r;
  },
  update(id: string, patch: Partial<NewRecipe>): Recipe | undefined {
    const list = recipeService.list();
    const i = list.findIndex((x) => x.id === id);
    if (i < 0) return undefined;
    const merged: NewRecipe = { ...list[i], ...patch } as NewRecipe;
    const errs = validate(merged, id);
    if (errs.length) throw new Error(errs[0].message);
    const resolved = resolveOutput(merged);
    const next: Recipe = {
      ...list[i],
      ...patch,
      ...resolved,
      updatedAt: new Date().toISOString(),
    };
    list[i] = next;
    recipeService.save(list);
    return next;
  },
  setActive(id: string, active: boolean) {
    const list = recipeService.list();
    const i = list.findIndex((x) => x.id === id);
    if (i < 0) return;
    list[i] = { ...list[i], active, updatedAt: new Date().toISOString() };
    recipeService.save(list);
  },
  remove(id: string) {
    recipeService.save(recipeService.list().filter((r) => r.id !== id));
  },
  emptyIngredient(): RecipeIngredient {
    return { inventoryItemId: "", quantity: 0, source: "inventory" };
  },
};