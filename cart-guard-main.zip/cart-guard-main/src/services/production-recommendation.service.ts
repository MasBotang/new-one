/**
 * Production Recommendation Engine
 * ---------------------------------
 * Single source of truth untuk rekomendasi produksi harian.
 *
 * Prinsip:
 *   Rekomendasi = max(0, round(Forecast + PreOrder − ReadyStock))
 *
 * Engine ini TIDAK tahu cara menghitung forecast — didelegasikan ke
 * `ForecastStrategy` (Strategy Pattern, lihat `./forecast/forecast-strategy.ts`).
 * Default: WeightedForecastStrategy.
 *
 * Minimum Stock adalah AMBANG ALERT semata — tidak pernah menjadi target
 * produksi. Recommendation Engine hanya memakai Forecast + PreOrder − ReadyStock.
 *
 * Sistem hanya memberikan rekomendasi. Keputusan akhir tetap di Tim Produksi
 * (Lean / Just-In-Time production). Service ini TIDAK mengubah stok, TIDAK
 * membuat run, dan TIDAK menulis ke storage.
 */
import { productService } from "./product.service";
import { preorderService } from "./preorder.service";
import type { Product } from "./types";
import {
  defaultForecastStrategy,
  type ForecastStrategy,
  type ProductForecast,
} from "./forecast/forecast-strategy";

export type { ProductForecast } from "./forecast/forecast-strategy";

export interface ProductionRecommendation {
  productId: string;
  name: string;
  forecast: number;
  preorder: number;
  readyStock: number;
  minStock: number;
  /** rekomendasi jumlah produksi (dibulatkan, non-negatif). */
  recommended: number;
  /** true jika readyStock <= minStock. Hanya ambang alert, bukan target. */
  belowMinStock: boolean;
  /** Kekurangan untuk memenuhi PO saja (max(0, PO − RS)). */
  preorderShortfall: number;
}

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

/** Strategi aktif — dapat diganti di masa depan tanpa mengubah engine. */
let activeStrategy: ForecastStrategy = defaultForecastStrategy();

export const productionRecommendationService = {
  /** Baca strategy aktif (untuk logging / dokumentasi). */
  strategy(): ForecastStrategy {
    return activeStrategy;
  },

  /**
   * (Internal) Ganti strategi forecast. Belum diekspos ke UI Phase 1.
   * Disediakan agar wiring strategy pattern lengkap dan siap dipakai Phase 2.
   */
  setStrategy(strategy: ForecastStrategy) {
    activeStrategy = strategy;
  },

  /** Forecast per produk — didelegasikan ke ForecastStrategy aktif. */
  forecasts(target = new Date()): ProductForecast[] {
    return activeStrategy.forecast({ target });
  },

  /**
   * Total PreOrder aktif (scheduled + ready_to_process) per produk untuk
   * tanggal target. PO belum selesai tetap dihitung.
   */
  preorderDemand(target = new Date()): Map<string, number> {
    const out = new Map<string, number>();
    // target dipertahankan untuk kompatibilitas API; PO belum selesai tetap
    // dihitung apapun tanggalnya.
    void target;
    for (const po of preorderService.list()) {
      if (po.status !== "scheduled" && po.status !== "ready_to_process") continue;
      for (const it of po.items) {
        out.set(it.productId, (out.get(it.productId) ?? 0) + (Number(it.qty) || 0));
      }
    }
    return out;
  },

  /**
   * Tabel rekomendasi produksi utama.
   * Rekomendasi = max(0, round(Forecast + PreOrder − ReadyStock)).
   * Minimum Stock TIDAK masuk formula — hanya memicu flag `belowMinStock`.
   */
  build(target = new Date()): ProductionRecommendation[] {
    void startOfDay; // eslint noop: helper disimpan untuk kejelasan intent
    const forecasts = productionRecommendationService.forecasts(target);
    const po = productionRecommendationService.preorderDemand(target);
    const productsById = new Map<string, Product>(productService.list().map((p) => [p.id, p]));

    const rows: ProductionRecommendation[] = forecasts.map((f) => {
      const product = productsById.get(f.productId);
      // Ready Stock dimiliki productService (Sales). Production hanya membaca.
      const readyStock = product?.stock ?? 0;
      const minStock = product?.minStock ?? 0;
      const preorder = po.get(f.productId) ?? 0;
      const need = f.forecast + preorder - readyStock;
      const recommended = Math.max(0, Math.round(need));
      const preorderShortfall = Math.max(0, Math.round(preorder - readyStock));
      return {
        productId: f.productId,
        name: f.name,
        forecast: f.forecast,
        preorder,
        readyStock,
        minStock,
        recommended,
        belowMinStock: minStock > 0 && readyStock <= minStock,
        preorderShortfall,
      };
    });

    return rows.sort((a, b) => b.recommended - a.recommended || a.name.localeCompare(b.name));
  },
};
