/**
 * Finance Service — READ-ONLY consumer of Sales / Inventory / Production /
 * Settlement / Shift modules. Owns Expense, Debt, Fund Withdraw, and
 * Settings storage.
 *
 * Analytics (today/month/allTime/cashflow/cashPosition/healthScore/
 * topInsights/potBalance/ledger/…) live in `finance-analytics.service.ts`.
 * For backward compatibility this module re-exports `financeAnalytics` and
 * `LedgerEntry` so existing importers of "./finance.service" keep working.
 *
 * Business constants (allocation defaults, health thresholds, warning
 * levels, star mapping) live in `finance.constants.ts` — never inline
 * business numbers in service code.
 */

import { storage, StorageKeys } from "./storage";
import {
  DEFAULT_ALLOCATION,
  DEFAULT_DEVELOPMENT_TARGET,
} from "./finance.constants";
import type {
  FinanceExpense,
  FinanceDebt,
  FinanceDebtPayment,
  FinanceFundWithdraw,
  FinanceSettings,
  ExpenseCategory,
} from "./types";

const uid = (p: string) =>
  `${p}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

const DEFAULT_SETTINGS: FinanceSettings = {
  allocation: { ...DEFAULT_ALLOCATION },
  developmentTarget: DEFAULT_DEVELOPMENT_TARGET,
  openingBalance: { cash: 0, qris: 0, bank: 0, dompet: 0 },
};

// ---------- storage helpers ----------

function readList<T>(key: string): T[] {
  return storage.get<T[]>(key) ?? [];
}

// ---------- settings ----------

export const financeSettings = {
  get(): FinanceSettings {
    const s = storage.get<Partial<FinanceSettings>>(StorageKeys.financeSettings);
    if (!s) return DEFAULT_SETTINGS;
    return {
      ...DEFAULT_SETTINGS,
      ...s,
      allocation: { ...DEFAULT_SETTINGS.allocation, ...(s.allocation ?? {}) },
      openingBalance: {
        ...DEFAULT_SETTINGS.openingBalance,
        ...(s.openingBalance ?? {}),
      },
    };
  },
  save(next: FinanceSettings) {
    storage.set(StorageKeys.financeSettings, next);
  },
};

// ---------- expenses ----------

export const financeExpenses = {
  list(): FinanceExpense[] {
    return readList<FinanceExpense>(StorageKeys.financeExpenses);
  },
  create(input: Omit<FinanceExpense, "id">): FinanceExpense {
    const rec: FinanceExpense = { ...input, id: uid("exp") };
    const list = financeExpenses.list();
    list.unshift(rec);
    storage.set(StorageKeys.financeExpenses, list);
    return rec;
  },
  update(id: string, patch: Partial<Omit<FinanceExpense, "id">>) {
    const list = financeExpenses.list();
    const idx = list.findIndex((e) => e.id === id);
    if (idx < 0) return;
    list[idx] = { ...list[idx], ...patch };
    storage.set(StorageKeys.financeExpenses, list);
  },
  remove(id: string) {
    storage.set(
      StorageKeys.financeExpenses,
      financeExpenses.list().filter((e) => e.id !== id),
    );
  },
};

// ---------- debts ----------

export const financeDebts = {
  list(): FinanceDebt[] {
    return readList<FinanceDebt>(StorageKeys.financeDebts);
  },
  create(input: Omit<FinanceDebt, "id" | "createdAt" | "active">): FinanceDebt {
    const rec: FinanceDebt = {
      ...input,
      id: uid("debt"),
      createdAt: new Date().toISOString(),
      active: true,
    };
    const list = financeDebts.list();
    list.unshift(rec);
    storage.set(StorageKeys.financeDebts, list);
    return rec;
  },
  update(id: string, patch: Partial<FinanceDebt>) {
    const list = financeDebts.list();
    const idx = list.findIndex((d) => d.id === id);
    if (idx < 0) return;
    list[idx] = { ...list[idx], ...patch };
    storage.set(StorageKeys.financeDebts, list);
  },
  remove(id: string) {
    storage.set(
      StorageKeys.financeDebts,
      financeDebts.list().filter((d) => d.id !== id),
    );
  },
  payments(): FinanceDebtPayment[] {
    return readList<FinanceDebtPayment>(StorageKeys.financeDebtPayments);
  },
  addPayment(input: Omit<FinanceDebtPayment, "id">): FinanceDebtPayment {
    const rec: FinanceDebtPayment = { ...input, id: uid("dpay") };
    const list = financeDebts.payments();
    list.unshift(rec);
    storage.set(StorageKeys.financeDebtPayments, list);
    return rec;
  },
  removePayment(id: string) {
    storage.set(
      StorageKeys.financeDebtPayments,
      financeDebts.payments().filter((p) => p.id !== id),
    );
  },
  totals() {
    const debts = financeDebts.list();
    const payments = financeDebts.payments();
    const principal = debts.reduce((a, d) => a + d.principal, 0);
    const paid = payments.reduce((a, p) => a + p.amount, 0);
    const remaining = Math.max(0, principal - paid);
    const progress = principal > 0 ? Math.min(1, paid / principal) : 0;
    return { principal, paid, remaining, progress };
  },
};

// ---------- fund withdraws ----------

export const financeFundWithdraws = {
  list(): FinanceFundWithdraw[] {
    return readList<FinanceFundWithdraw>(StorageKeys.financeFundWithdraws);
  },
  create(input: Omit<FinanceFundWithdraw, "id">): FinanceFundWithdraw {
    const rec: FinanceFundWithdraw = { ...input, id: uid("fw") };
    const list = financeFundWithdraws.list();
    list.unshift(rec);
    storage.set(StorageKeys.financeFundWithdraws, list);
    return rec;
  },
  remove(id: string) {
    storage.set(
      StorageKeys.financeFundWithdraws,
      financeFundWithdraws.list().filter((f) => f.id !== id),
    );
  },
};

// ---------- Backward-compat re-exports ----------

export { financeAnalytics } from "./finance-analytics.service";
export type { LedgerEntry, PeriodSummary } from "./finance-analytics.service";
export type { SalesAggregate } from "./finance-aggregation";
export type { ExpenseCategory };
