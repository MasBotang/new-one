import { storage, StorageKeys } from "./storage";
import { inventoryService } from "./inventory.service";
import { productService } from "./product.service";
import { stockMovementService } from "./stock-movement.service";
import { recipeService } from "./recipe.service";
import { auditService } from "./audit.service";
import type {
  FinishingValidation,
  ProductionActivity,
  ProductionRun,
  ProductionRunConsumed,
  Recipe,
} from "./types";

function uid() {
  return `prod_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

export interface ExecuteRunInput {
  recipeId: string;
  /** Aktivitas yang dipilih dari Activity Hub. */
  activity: ProductionActivity;
  batches: number;
  operator: string;
  notes?: string;
  /** Override the produced quantity (defaults to outputQty × batches × yield%). */
  producedQuantityOverride?: number;
  /** Label pelipat (mis. "Pelipat A") untuk activity=produce_finished. */
  folderLabel?: string;
  /** Produk rusak (waste) untuk activity=produce_finished — hanya dicatat, tidak mempengaruhi stok. */
  wasteQuantity?: number;
  /** Berat aktual (untuk activity=create_adonan) — dipakai menghitung batch aktual. */
  actualWeight?: number;
  actualWeightUnit?: "g" | "kg";
}

export interface ValidateFinishingInput {
  productId: string;
  validatedQty: number;
  rejectedQty?: number;
  operator: string;
  notes?: string;
}

export interface RecordPanirInput {
  /** Total pcs yang berhasil dipanir hari ini (gabungan seluruh varian). */
  panirQty: number;
  operator: string;
  notes?: string;
}

export interface ReconciliationRow {
  inventoryItemId: string;
  name: string;
  unit: string;
  lipatByFolder: Record<string, number>;
  totalLipat: number;
  panir: number;
  loss: number;
}

export interface PanirSummary {
  totalLipat: number;
  totalPanir: number;
  selisih: number;
  byVariant: { inventoryItemId: string; name: string; unit: string; lipat: number }[];
  activePanirRecipe: Recipe | null;
  /** Preview konsumsi bahan bila panirQty diisi. */
  requirementsFor: (panirQty: number) => IngredientRequirement[];
}

export interface IngredientRequirement {
  itemId: string;
  name: string;
  unit: string;
  required: number;
  available: number;
  sufficient: boolean;
  missingFromInventory: boolean;
}

function resolveOutputName(r: Recipe): string {
  if (r.outputTargetType === "inventory") {
    return inventoryService.get(r.outputRefId)?.name ?? "(item dihapus)";
  }
  return productService.list().find((p) => p.id === r.outputRefId)?.name ?? "(produk dihapus)";
}

export const productionService = {
  runs(): ProductionRun[] {
    return storage.get<ProductionRun[]>(StorageKeys.productionRuns) ?? [];
  },
  saveRuns(list: ProductionRun[]) {
    storage.set(StorageKeys.productionRuns, list);
  },
  recentRuns(limit = 10): ProductionRun[] {
    return productionService.runs().slice(0, limit);
  },
  runsByRecipe(recipeId: string): ProductionRun[] {
    return productionService.runs().filter((r) => r.recipeId === recipeId);
  },
  validations(): FinishingValidation[] {
    return storage.get<FinishingValidation[]>(StorageKeys.finishingValidations) ?? [];
  },
  saveValidations(list: FinishingValidation[]) {
    storage.set(StorageKeys.finishingValidations, list);
  },
  outputName(r: Recipe): string {
    return resolveOutputName(r);
  },
  /** Computes ingredient requirements for a given recipe × batches. */
  requirements(recipe: Recipe, batches: number): IngredientRequirement[] {
    const safeBatches = Math.max(0, batches);
    return recipe.ingredients.map((ing) => {
      const item = inventoryService.get(ing.inventoryItemId);
      const required = ing.quantity * safeBatches;
      const available = item?.stock ?? 0;
      return {
        itemId: ing.inventoryItemId,
        name: item?.name ?? "(item dihapus)",
        unit: item?.unit ?? "",
        required,
        available,
        sufficient: !!item && available >= required,
        missingFromInventory: !item,
      };
    });
  },
  executeRun(input: ExecuteRunInput): ProductionRun {
    const recipe = recipeService.get(input.recipeId);
    if (!recipe) throw new Error("Resep tidak ditemukan");
    if (!recipe.active) throw new Error("Resep nonaktif");
    if (!(input.batches > 0)) throw new Error("Jumlah batch harus > 0");

    // Activity ↔ recipe-type guardrails.
    if (input.activity === "create_adonan" && recipe.type !== "semi_finished") {
      throw new Error("Activity Buat Adonan hanya untuk resep Setengah Jadi");
    }
    if (input.activity === "produce_finished" && recipe.type !== "finished") {
      throw new Error("Activity Produksi Barang Jadi hanya untuk resep Barang Jadi");
    }

    const reqs = productionService.requirements(recipe, input.batches);
    const blocker = reqs.find((r) => !r.sufficient);
    if (blocker) {
      throw new Error(
        blocker.missingFromInventory
          ? `Bahan "${blocker.name}" tidak tersedia di inventaris`
          : `Stok bahan "${blocker.name}" tidak cukup (butuh ${blocker.required} ${blocker.unit}, tersedia ${blocker.available})`,
      );
    }

    const consumed: ProductionRunConsumed[] = [];
    // 1) consume ingredients
    for (const r of reqs) {
      stockMovementService.record({
        itemId: r.itemId,
        type: "production_consumption",
        quantity: r.required,
        reason: `Produksi: ${recipe.name}`,
      });
      consumed.push({ itemId: r.itemId, name: r.name, unit: r.unit, quantity: r.required });
    }

    // 2) produced quantity (default = outputQty × batches × yield%)
    const yieldFactor = recipe.estimatedYieldPct > 0 ? recipe.estimatedYieldPct / 100 : 1;
    const produced =
      input.producedQuantityOverride != null && input.producedQuantityOverride >= 0
        ? input.producedQuantityOverride
        : Math.round(recipe.outputQuantity * input.batches * yieldFactor * 100) / 100;

    // 3) write output to its target
    if (recipe.outputTargetType === "inventory") {
      const item = inventoryService.get(recipe.outputRefId);
      if (!item) throw new Error("Item output sudah dihapus dari inventaris");
      stockMovementService.record({
        itemId: item.id,
        type: "production_output",
        quantity: produced,
        reason: `Hasil produksi: ${recipe.name}`,
      });
    } else {
      // Finished goods masuk ke WIP stock — BELUM bisa dijual sampai melewati
      // Finishing Validation. Sales/POS hanya membaca `stock` (ready stock).
      const products = productService.list();
      const i = products.findIndex((p) => p.id === recipe.outputRefId);
      if (i < 0) throw new Error("Produk output sudah dihapus dari katalog");
      products[i] = {
        ...products[i],
        wipStock: (products[i].wipStock ?? 0) + produced,
      };
      productService.save(products);
    }

    const run: ProductionRun = {
      id: uid(),
      createdAt: new Date().toISOString(),
      activity: input.activity,
      recipeId: recipe.id,
      recipeName: recipe.name,
      batches: input.batches,
      producedQuantity: produced,
      outputUnit: recipe.outputUnit,
      outputTargetType: recipe.outputTargetType,
      outputRefId: recipe.outputRefId,
      outputName: resolveOutputName(recipe),
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
      consumed,
      folderLabel: input.folderLabel?.trim() || undefined,
      wasteQuantity:
        input.activity === "produce_finished" && input.wasteQuantity && input.wasteQuantity > 0
          ? input.wasteQuantity
          : undefined,
      actualWeight:
        input.activity === "create_adonan" && input.actualWeight && input.actualWeight > 0
          ? input.actualWeight
          : undefined,
      actualWeightUnit:
        input.activity === "create_adonan" && input.actualWeight && input.actualWeight > 0
          ? input.actualWeightUnit ?? "g"
          : undefined,
      actualBatches:
        input.activity === "create_adonan" ? Math.round(input.batches * 10000) / 10000 : undefined,
    };
    const list = productionService.runs();
    list.unshift(run);
    productionService.saveRuns(list);
    return run;
  },

  /**
   * Finishing Validation: pindahkan WIP stock → Ready Stock.
   * Tidak menulis stock movement (bukan transaksi inventory).
   */
  validateFinishing(input: ValidateFinishingInput): FinishingValidation {
    const validated = Math.max(0, Number(input.validatedQty) || 0);
    const rejected = Math.max(0, Number(input.rejectedQty) || 0);
    const total = validated + rejected;
    if (total <= 0) throw new Error("Masukkan jumlah validasi yang valid");

    const products = productService.list();
    const i = products.findIndex((p) => p.id === input.productId);
    if (i < 0) throw new Error("Produk tidak ditemukan");
    const wip = products[i].wipStock ?? 0;
    if (total > wip) {
      throw new Error(
        `Jumlah validasi (${total}) melebihi WIP tersedia (${wip}) untuk ${products[i].name}`,
      );
    }
    products[i] = {
      ...products[i],
      wipStock: wip - total,
      stock: (products[i].stock ?? 0) + validated,
    };
    productService.save(products);

    const now = new Date().toISOString();
    const record: FinishingValidation = {
      id: `fv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: now,
      productId: products[i].id,
      productName: products[i].name,
      validatedQty: validated,
      rejectedQty: rejected,
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
    };
    const vlist = productionService.validations();
    vlist.unshift(record);
    productionService.saveValidations(vlist);

    // Mirror as ProductionRun for unified history.
    const run: ProductionRun = {
      id: uid(),
      createdAt: now,
      activity: "finishing_validation",
      recipeId: "",
      recipeName: `Validasi: ${products[i].name}`,
      batches: 0,
      producedQuantity: validated,
      outputUnit: "pcs",
      outputTargetType: "product",
      outputRefId: products[i].id,
      outputName: products[i].name,
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
      consumed: [],
      rejectedQuantity: rejected,
    };
    const runs = productionService.runs();
    runs.unshift(run);
    productionService.saveRuns(runs);

    return record;
  },

  /** Daftar produk yang punya WIP stock > 0 (kandidat finishing validation). */
  pendingFinishing(): { productId: string; name: string; wipStock: number; readyStock: number }[] {
    return productService
      .list()
      .filter((p) => (p.wipStock ?? 0) > 0)
      .map((p) => ({
        productId: p.id,
        name: p.name,
        wipStock: p.wipStock ?? 0,
        readyStock: p.stock ?? 0,
      }));
  },

  /**
   * Catat hasil PANIR global (satu total gabungan lintas varian).
   *
   * - Staff panir hanya menginput 1 angka: total pcs yang berhasil dipanir hari ini.
   * - Bahan panir dihitung dari resep panir aktif (komposisi per 1 pcs) × panirQty.
   * - Rekonsiliasi dilakukan dengan membandingkan total ini vs total lipat harian.
   */
  recordPanir(input: RecordPanirInput): ProductionRun {
    const panir = Math.max(0, Number(input.panirQty) || 0);
    if (panir <= 0) throw new Error("Jumlah panir harus > 0");

    const panirRecipe = recipeService.active().find((r) => r.type === "panir");
    if (!panirRecipe) {
      throw new Error(
        "Resep panir belum diatur. Minta admin membuat resep panir aktif terlebih dahulu.",
      );
    }

    // Preflight: pastikan stok cukup sebelum menulis apapun.
    const shortages: string[] = [];
    for (const ing of panirRecipe.ingredients) {
      const invItem = inventoryService.get(ing.inventoryItemId);
      const required = ing.quantity * panir;
      if (!invItem) {
        shortages.push(`bahan panir tidak ditemukan di inventaris`);
      } else if ((invItem.stock ?? 0) < required) {
        shortages.push(
          `${invItem.name} (butuh ${required} ${invItem.unit}, tersedia ${invItem.stock})`,
        );
      }
    }
    if (shortages.length > 0) {
      throw new Error(`Stok bahan panir tidak cukup: ${shortages.join("; ")}`);
    }

    const consumed: ProductionRunConsumed[] = [];
    for (const ing of panirRecipe.ingredients) {
      const invItem = inventoryService.get(ing.inventoryItemId)!;
      const required = ing.quantity * panir;
      stockMovementService.record({
        itemId: invItem.id,
        type: "production_consumption",
        quantity: required,
        reason: `Panir (${panir} pcs)`,
      });
      consumed.push({
        itemId: invItem.id,
        name: invItem.name,
        unit: invItem.unit,
        quantity: required,
      });
    }

    const now = new Date().toISOString();
    const run: ProductionRun = {
      id: uid(),
      createdAt: now,
      activity: "panir",
      recipeId: panirRecipe.id,
      recipeName: `Panir (${panirRecipe.name})`,
      batches: panir,
      producedQuantity: panir,
      outputUnit: "pcs",
      outputTargetType: "inventory",
      outputRefId: "",
      outputName: "Panir (Total)",
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
      consumed,
    };
    const runs = productionService.runs();
    runs.unshift(run);
    productionService.saveRuns(runs);
    return run;
  },

  /** Ringkasan panir hari ini: total lipat vs total panir + resep aktif. */
  todayPanirSummary(): PanirSummary {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const runs = productionService.runs().filter((r) => new Date(r.createdAt) >= start);
    const variantMap = new Map<string, { name: string; unit: string; lipat: number }>();
    let totalLipat = 0;
    let totalPanir = 0;
    for (const r of runs) {
      if (r.activity === "produce_finished") {
        const key = r.outputRefId;
        if (!variantMap.has(key)) {
          variantMap.set(key, { name: r.outputName, unit: r.outputUnit, lipat: 0 });
        }
        variantMap.get(key)!.lipat += r.producedQuantity;
        totalLipat += r.producedQuantity;
      } else if (r.activity === "panir") {
        totalPanir += r.producedQuantity;
      }
    }
    const activePanirRecipe = recipeService.active().find((r) => r.type === "panir") ?? null;
    return {
      totalLipat: Math.round(totalLipat * 100) / 100,
      totalPanir: Math.round(totalPanir * 100) / 100,
      selisih: Math.round((totalLipat - totalPanir) * 100) / 100,
      byVariant: Array.from(variantMap.entries())
        .map(([id, v]) => ({ inventoryItemId: id, ...v }))
        .sort((a, b) => a.name.localeCompare(b.name)),
      activePanirRecipe,
      requirementsFor: (qty: number) =>
        activePanirRecipe ? productionService.requirements(activePanirRecipe, qty) : [],
    };
  },

  /** Total qty lipat hari ini untuk satu inventory item. */
  todayLipatTotal(inventoryItemId: string): number {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    return productionService
      .runs()
      .filter(
        (r) =>
          r.activity === "produce_finished" &&
          r.outputRefId === inventoryItemId &&
          new Date(r.createdAt) >= start,
      )
      .reduce((s, r) => s + r.producedQuantity, 0);
  },

  /** Total qty panir hari ini untuk satu inventory item. */
  todayPanirTotal(inventoryItemId: string): number {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    return productionService
      .runs()
      .filter(
        (r) =>
          r.activity === "panir" &&
          r.outputRefId === inventoryItemId &&
          new Date(r.createdAt) >= start,
      )
      .reduce((s, r) => s + r.producedQuantity, 0);
  },

  /**
   * Rekonsiliasi harian: untuk tiap varian risol yang dilipat / dipanir hari ini,
   * tampilkan total lipat per pelipat, total panir, selisih.
   */
  dailyReconciliation(): ReconciliationRow[] {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const todays = productionService
      .runs()
      .filter((r) => new Date(r.createdAt) >= start)
      .filter((r) => r.activity === "produce_finished");

    const map = new Map<string, ReconciliationRow>();
    for (const r of todays) {
      const key = r.outputRefId;
      if (!map.has(key)) {
        map.set(key, {
          inventoryItemId: key,
          name: r.outputName,
          unit: r.outputUnit,
          lipatByFolder: {},
          totalLipat: 0,
          panir: 0,
          loss: 0,
        });
      }
      const row = map.get(key)!;
      if (r.activity === "produce_finished") {
        const folder = r.folderLabel?.trim() || "Tanpa Label";
        row.lipatByFolder[folder] = (row.lipatByFolder[folder] ?? 0) + r.producedQuantity;
        row.totalLipat += r.producedQuantity;
      } else if (r.activity === "panir") {
        row.panir += r.producedQuantity;
      }
    }
    for (const row of map.values()) {
      row.totalLipat = Math.round(row.totalLipat * 100) / 100;
      row.panir = Math.round(row.panir * 100) / 100;
      row.loss = Math.round((row.totalLipat - row.panir) * 100) / 100;
    }
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name));
  },

  /* =====================================================================
   * Production Record + Release (Workflow Baru — backward compatible)
   * ===================================================================== */

  /**
   * Catat hasil produksi finished good tanpa konsumsi bahan otomatis
   * (operator sudah mencatat manual di modul Pencatatan Produksi lama, atau
   * bahan sudah dikurangi via resep). Menambah wipStock (Ready Stock Production).
   * Hasil masuk ke Waiting Release, BELUM bisa dijual.
   */
  recordProduction(input: {
    productId: string;
    quantity: number;
    operator: string;
    notes?: string;
    role?: string;
  }): ProductionRun {
    const qty = Math.max(0, Number(input.quantity) || 0);
    if (qty <= 0) throw new Error("Qty produksi harus > 0");
    const products = productService.list();
    const i = products.findIndex((p) => p.id === input.productId);
    if (i < 0) throw new Error("Produk tidak ditemukan");
    products[i] = { ...products[i], wipStock: (products[i].wipStock ?? 0) + qty };
    productService.save(products);

    const now = new Date().toISOString();
    const run: ProductionRun = {
      id: `prod_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: now,
      activity: "produce_finished",
      recipeId: "",
      recipeName: `Produksi: ${products[i].name}`,
      batches: 0,
      producedQuantity: qty,
      outputUnit: "pcs",
      outputTargetType: "product",
      outputRefId: products[i].id,
      outputName: products[i].name,
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
      consumed: [],
    };
    const runs = productionService.runs();
    runs.unshift(run);
    productionService.saveRuns(runs);

    auditService.log({
      actor: input.operator || "Operator",
      actorRole: input.role,
      action: "production_record_created",
      entity: "product",
      entityId: products[i].id,
      metadata: { productName: products[i].name, quantity: qty },
    });
    return run;
  },

  /**
   * Release: pindahkan qty dari wipStock (Ready Stock Production) ke stock
   * (Ready Stock Sales). Catat audit + mirror ProductionRun untuk history.
   * Stock movement Inventory TIDAK ditulis karena produk (Product) bukan
   * InventoryItem — sesuai konvensi Sales/POS yang membaca product.stock.
   */
  release(input: {
    productId: string;
    quantity: number;
    operator: string;
    notes?: string;
    role?: string;
  }): FinishingValidation {
    const qty = Math.max(0, Number(input.quantity) || 0);
    if (qty <= 0) throw new Error("Qty release harus > 0");
    const products = productService.list();
    const i = products.findIndex((p) => p.id === input.productId);
    if (i < 0) throw new Error("Produk tidak ditemukan");
    const wip = products[i].wipStock ?? 0;
    if (qty > wip) {
      throw new Error(
        `Qty release (${qty}) melebihi Ready Stock Production (${wip}) untuk ${products[i].name}`,
      );
    }
    products[i] = {
      ...products[i],
      wipStock: wip - qty,
      stock: (products[i].stock ?? 0) + qty,
    };
    productService.save(products);

    const now = new Date().toISOString();
    const record: FinishingValidation = {
      id: `fv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: now,
      productId: products[i].id,
      productName: products[i].name,
      validatedQty: qty,
      rejectedQty: 0,
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
    };
    const vlist = productionService.validations();
    vlist.unshift(record);
    productionService.saveValidations(vlist);

    const run: ProductionRun = {
      id: `prod_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: now,
      activity: "finishing_validation",
      recipeId: "",
      recipeName: `Release: ${products[i].name}`,
      batches: 0,
      producedQuantity: qty,
      outputUnit: "pcs",
      outputTargetType: "product",
      outputRefId: products[i].id,
      outputName: products[i].name,
      operator: input.operator || "Operator",
      notes: input.notes?.trim() || undefined,
      consumed: [],
    };
    const runs = productionService.runs();
    runs.unshift(run);
    productionService.saveRuns(runs);

    auditService.log({
      actor: input.operator || "Operator",
      actorRole: input.role,
      action: "production_release",
      entity: "product",
      entityId: products[i].id,
      metadata: { productName: products[i].name, quantity: qty },
    });
    return record;
  },
};