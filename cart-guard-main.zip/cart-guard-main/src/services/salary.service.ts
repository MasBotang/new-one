/**
 * Salary Rules — data source untuk Payroll (READ-ONLY dari sisi Payroll).
 *
 * Modul ini menyimpan aturan gaji operator: rate produksi, bonus manual,
 * dan additional payment. Payroll Calculation TIDAK memodifikasi storage
 * ini secara langsung — semua CRUD dilakukan oleh admin melalui halaman
 * Salary Rules (atau, untuk v1, dialog kecil di Payroll page yang secara
 * eksplisit memanggil service ini sebagai layanan Salary Rules — bukan
 * atas nama Payroll).
 *
 * Identity join: WAJIB `operatorId` = Account.id.
 */
import { storage, StorageKeys } from "@/services/storage";

/* ---------------- Salary Rule (per operator) ---------------- */

export type SalaryCalculationType = "PER_UNIT_PRODUCTION" | "FIXED_AMOUNT";

export interface SalaryRule {
  id: string;
  operatorId: string; // Account.id
  calculationType: SalaryCalculationType;
  /** Berlaku bila PER_UNIT_PRODUCTION — rate per unit produksi. */
  ratePerUnit?: number;
  /** Berlaku bila FIXED_AMOUNT — nilai gaji pokok periode. */
  fixedAmount?: number;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

/* ---------------- Salary Bonus (manual, per entri) ---------------- */

export interface SalaryBonus {
  id: string;
  operatorId: string; // Account.id
  /** YYYY-MM-DD */
  date: string;
  amount: number;
  reason?: string;
  createdAt: string;
}

/* ---------------- Additional Payment (manual, per entri) ---------------- */

export interface SalaryAdditional {
  id: string;
  operatorId: string; // Account.id
  /** YYYY-MM-DD */
  date: string;
  amount: number;
  reason?: string;
  createdAt: string;
}

function now(): string {
  return new Date().toISOString();
}

/* ---------------- Rules ---------------- */

function readRules(): SalaryRule[] {
  return storage.get<SalaryRule[]>(StorageKeys.salaryRules) ?? [];
}
function writeRules(list: SalaryRule[]): void {
  storage.set(StorageKeys.salaryRules, list);
}

export interface UpsertSalaryRuleInput {
  operatorId: string;
  calculationType: SalaryCalculationType;
  ratePerUnit?: number;
  fixedAmount?: number;
  notes?: string;
}

export const salaryRulesService = {
  list(): SalaryRule[] {
    return readRules();
  },
  byOperator(operatorId: string): SalaryRule | undefined {
    return readRules().find((r) => r.operatorId === operatorId);
  },
  upsert(input: UpsertSalaryRuleInput): SalaryRule {
    const list = readRules();
    const idx = list.findIndex((r) => r.operatorId === input.operatorId);
    if (idx === -1) {
      const rec: SalaryRule = {
        id: crypto.randomUUID(),
        operatorId: input.operatorId,
        calculationType: input.calculationType,
        ratePerUnit: input.calculationType === "PER_UNIT_PRODUCTION" ? input.ratePerUnit : undefined,
        fixedAmount: input.calculationType === "FIXED_AMOUNT" ? input.fixedAmount : undefined,
        notes: input.notes?.trim() || undefined,
        createdAt: now(),
        updatedAt: now(),
      };
      writeRules([...list, rec]);
      return rec;
    }
    const cur = list[idx];
    const next: SalaryRule = {
      ...cur,
      calculationType: input.calculationType,
      ratePerUnit: input.calculationType === "PER_UNIT_PRODUCTION" ? input.ratePerUnit : undefined,
      fixedAmount: input.calculationType === "FIXED_AMOUNT" ? input.fixedAmount : undefined,
      notes: input.notes?.trim() || undefined,
      updatedAt: now(),
    };
    const arr = [...list];
    arr[idx] = next;
    writeRules(arr);
    return next;
  },
  remove(id: string): void {
    writeRules(readRules().filter((r) => r.id !== id));
  },
};

/* ---------------- Bonuses ---------------- */

function readBonuses(): SalaryBonus[] {
  return storage.get<SalaryBonus[]>(StorageKeys.salaryBonuses) ?? [];
}
function writeBonuses(list: SalaryBonus[]): void {
  storage.set(StorageKeys.salaryBonuses, list);
}

export interface CreateBonusInput {
  operatorId: string;
  date: string;
  amount: number;
  reason?: string;
}

export const salaryBonusService = {
  list(): SalaryBonus[] {
    return readBonuses();
  },
  create(input: CreateBonusInput): SalaryBonus {
    const rec: SalaryBonus = {
      id: crypto.randomUUID(),
      operatorId: input.operatorId,
      date: input.date,
      amount: Math.max(0, Math.round(input.amount)),
      reason: input.reason?.trim() || undefined,
      createdAt: now(),
    };
    writeBonuses([...readBonuses(), rec]);
    return rec;
  },
  remove(id: string): void {
    writeBonuses(readBonuses().filter((r) => r.id !== id));
  },
};

/* ---------------- Additionals ---------------- */

function readAdditionals(): SalaryAdditional[] {
  return storage.get<SalaryAdditional[]>(StorageKeys.salaryAdditionals) ?? [];
}
function writeAdditionals(list: SalaryAdditional[]): void {
  storage.set(StorageKeys.salaryAdditionals, list);
}

export interface CreateAdditionalInput {
  operatorId: string;
  date: string;
  amount: number;
  reason?: string;
}

export const salaryAdditionalService = {
  list(): SalaryAdditional[] {
    return readAdditionals();
  },
  create(input: CreateAdditionalInput): SalaryAdditional {
    const rec: SalaryAdditional = {
      id: crypto.randomUUID(),
      operatorId: input.operatorId,
      date: input.date,
      amount: Math.max(0, Math.round(input.amount)),
      reason: input.reason?.trim() || undefined,
      createdAt: now(),
    };
    writeAdditionals([...readAdditionals(), rec]);
    return rec;
  },
  remove(id: string): void {
    writeAdditionals(readAdditionals().filter((r) => r.id !== id));
  },
};