import { storage, StorageKeys } from "./storage";
import type { PriceGroup, Product, SourceOrder } from "./types";

function now() {
  return new Date().toISOString();
}

const SEED: Omit<PriceGroup, "createdAt" | "updatedAt">[] = [
  { id: "pg_outlet", name: "Outlet", sources: ["outlet", "whatsapp"], isDefault: true },
  { id: "pg_shopeefood", name: "ShopeeFood", sources: ["shopeefood"] },
  { id: "pg_gofood", name: "GoFood", sources: ["gofood"] },
  { id: "pg_grabfood", name: "GrabFood", sources: ["grabfood"] },
  { id: "pg_reseller", name: "Reseller", sources: ["reseller"] },
];

function ensureSeed(): PriceGroup[] {
  const seeded = storage.get<boolean>(StorageKeys.priceGroupsSeeded);
  const existing = storage.get<PriceGroup[]>(StorageKeys.priceGroups);
  if (seeded && existing && existing.length) return existing;
  const t = now();
  const rows: PriceGroup[] = SEED.map((s) => ({ ...s, createdAt: t, updatedAt: t }));
  storage.set(StorageKeys.priceGroups, rows);
  storage.set(StorageKeys.priceGroupsSeeded, true);
  return rows;
}

export const priceGroupService = {
  list(): PriceGroup[] {
    return ensureSeed();
  },
  save(rows: PriceGroup[]) {
    storage.set(StorageKeys.priceGroups, rows);
  },
  upsert(pg: PriceGroup) {
    const list = priceGroupService.list();
    const i = list.findIndex((x) => x.id === pg.id);
    const t = now();
    if (i >= 0) list[i] = { ...pg, updatedAt: t };
    else list.push({ ...pg, createdAt: t, updatedAt: t });
    priceGroupService.save(list);
  },
  remove(id: string) {
    priceGroupService.save(priceGroupService.list().filter((x) => x.id !== id));
  },
  byId(id: string | undefined): PriceGroup | undefined {
    if (!id) return undefined;
    return priceGroupService.list().find((x) => x.id === id);
  },
  /** Resolve which price group applies to a source. Falls back to default. */
  forSource(source: SourceOrder): PriceGroup {
    const list = priceGroupService.list();
    const hit = list.find((g) => g.sources.includes(source));
    if (hit) return hit;
    return list.find((g) => g.isDefault) ?? list[0];
  },
  /** Return the effective price of a product under a price group. */
  priceFor(product: Product, priceGroupId: string | undefined): number {
    if (priceGroupId && product.prices) {
      const explicit = product.prices[priceGroupId];
      if (typeof explicit === "number" && explicit > 0) return explicit;
    }
    // Reseller back-compat: kalau grup mengarah ke source "reseller" dan produk
    // punya priceReseller lama, pakai itu.
    if (priceGroupId) {
      const g = priceGroupService.byId(priceGroupId);
      if (g && g.sources.includes("reseller") && product.priceReseller && product.priceReseller > 0) {
        return product.priceReseller;
      }
    }
    return product.price;
  },
};
