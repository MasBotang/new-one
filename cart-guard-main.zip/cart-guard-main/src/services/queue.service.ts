import { storage, StorageKeys } from "./storage";
import type { SalePacking, SaleType, SourceOrder } from "./types";
import { auditService } from "./audit.service";

export type QueueStatus =
  | "waiting"
  | "cooking"
  | "packing"
  | "ready"
  | "completed";

export const QUEUE_STATUS_LABEL: Record<QueueStatus, string> = {
  waiting: "Menunggu",
  cooking: "Memasak",
  packing: "Packing",
  ready: "Siap",
  completed: "Selesai",
};

export interface QueueOrder {
  id: string;
  saleId: string;
  saleCode: string;
  createdAt: string;
  updatedAt: string;
  status: QueueStatus;
  saleType: SaleType;
  customerName: string;
  customerPhone?: string;
  pickupAt?: string;
  isPreorder: boolean;
  itemCount: number;
  itemsSummary: string;
  timeline: { status: QueueStatus; at: string; by?: string }[];
  lastActor?: string;
  sourceOrder?: SourceOrder;
  /** Id Pre Order sumber, bila queue ini di-promote dari PO. */
  preorderId?: string;
  outletId?: string;
  /** Nomor antrean harian dari Sale (contoh "#024"). */
  orderNumber?: string;
  /** Detail pembagian packing untuk ditampilkan pada Queue. */
  packings?: SalePacking[];
}

function uid() {
  return `q_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

/**
 * Alur status sesuai sale type:
 *   frozen: waiting → packing → ready → completed
 *   matang: waiting → cooking → packing → ready → completed
 */
export function nextStatus(
  current: QueueStatus,
  saleType: SaleType,
): QueueStatus | null {
  if (current === "completed") return null;
  if (saleType === "matang") {
    if (current === "waiting") return "cooking";
    if (current === "cooking") return "packing";
  } else {
    if (current === "waiting") return "packing";
  }
  if (current === "packing") return "ready";
  if (current === "ready") return "completed";
  return null;
}

export const queueService = {
  list(): QueueOrder[] {
    return storage.get<QueueOrder[]>(StorageKeys.orderQueue) ?? [];
  },
  save(rows: QueueOrder[]) {
    storage.set(StorageKeys.orderQueue, rows);
  },
  create(
    input: Omit<QueueOrder, "id" | "createdAt" | "updatedAt" | "status" | "timeline">,
  ): QueueOrder {
    const now = new Date().toISOString();
    const initial: QueueStatus = "waiting";
    const rec: QueueOrder = {
      id: uid(),
      status: initial,
      createdAt: now,
      updatedAt: now,
      timeline: [{ status: initial, at: now }],
      ...input,
    };
    const list = queueService.list();
    list.unshift(rec);
    queueService.save(list);
    return rec;
  },
  advance(id: string, actor?: string): QueueOrder | null {
    const list = queueService.list();
    const i = list.findIndex((q) => q.id === id);
    if (i < 0) return null;
    const cur = list[i];
    const next = nextStatus(cur.status, cur.saleType);
    if (!next) return cur;
    const now = new Date().toISOString();
    const updated: QueueOrder = {
      ...cur,
      status: next,
      updatedAt: now,
      lastActor: actor,
      timeline: [...cur.timeline, { status: next, at: now, by: actor }],
    };
    list[i] = updated;
    queueService.save(list);
    // Sprint 1 (H-3): audit log semua perubahan status antrean.
    try {
      auditService.log({
        actor: actor ?? "system",
        action: "queue_status_change",
        entity: "queue",
        entityId: id,
        metadata: {
          from: cur.status,
          to: next,
          saleId: cur.saleId,
          orderNumber: cur.orderNumber,
          customerName: cur.customerName,
        },
      });
    } catch (err) {
      console.error("[queue] audit log failed", err);
    }
    if (typeof window !== "undefined") {
      window.dispatchEvent(new Event("desalut:queue-changed"));
    }
    return updated;
  },
  setStatus(id: string, status: QueueStatus, actor?: string): QueueOrder | null {
    const list = queueService.list();
    const i = list.findIndex((q) => q.id === id);
    if (i < 0) return null;
    const prev = list[i];
    const now = new Date().toISOString();
    const updated: QueueOrder = {
      ...list[i],
      status,
      updatedAt: now,
      lastActor: actor,
      timeline: [...list[i].timeline, { status, at: now, by: actor }],
    };
    list[i] = updated;
    queueService.save(list);
    try {
      auditService.log({
        actor: actor ?? "system",
        action: "queue_status_change",
        entity: "queue",
        entityId: id,
        metadata: {
          from: prev.status,
          to: status,
          saleId: prev.saleId,
          orderNumber: prev.orderNumber,
          customerName: prev.customerName,
          manual: true,
        },
      });
    } catch (err) {
      console.error("[queue] audit log failed", err);
    }
    if (typeof window !== "undefined") {
      window.dispatchEvent(new Event("desalut:queue-changed"));
    }
    return updated;
  },
  active(): QueueOrder[] {
    return queueService.list().filter((q) => q.status !== "completed");
  },
  bySale(saleId: string): QueueOrder | undefined {
    return queueService.list().find((q) => q.saleId === saleId);
  },
  /**
   * Hapus entri queue untuk sale tertentu. Dipakai saat rollback refund:
   * pesanan yang direfund tidak boleh tetap tampil di antrean produksi.
   * Idempoten — no-op bila tidak ada entri.
   */
  removeBySale(saleId: string): boolean {
    const list = queueService.list();
    const next = list.filter((q) => q.saleId !== saleId);
    if (next.length === list.length) return false;
    queueService.save(next);
    return true;
  },
  /**
   * Sprint 3 (Finding #3B): relink saleId Queue lama saat Pre Order di-Complete.
   * Queue awalnya dibuat dengan placeholder `saleId = po.id` di promoteDue().
   * Setelah PO di-Complete dan Sale asli terbentuk, saleId harus dipindah ke
   * sale.id agar deriveStatus() & canRefund() menemukan Queue yang benar.
   * Status Queue (waiting/cooking/…) sengaja dipertahankan.
   * Idempoten & aman — return null bila queue tidak ditemukan.
   */
  relinkSale(queueId: string, newSaleId: string): QueueOrder | null {
    const list = queueService.list();
    const i = list.findIndex((q) => q.id === queueId);
    if (i < 0) return null;
    const cur = list[i];
    if (cur.saleId === newSaleId) return cur;
    const updated: QueueOrder = {
      ...cur,
      saleId: newSaleId,
      updatedAt: new Date().toISOString(),
    };
    list[i] = updated;
    queueService.save(list);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new Event("desalut:queue-changed"));
    }
    return updated;
  },

};