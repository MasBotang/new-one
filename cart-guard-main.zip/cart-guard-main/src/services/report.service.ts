import { saleAmountByMethod } from "@/lib/payment";
import { salesService } from "./sales.service";
import type { PaymentMethod, Sale } from "./types";

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function endOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
}

export interface DashboardMetrics {
  revenue: number;
  profit: number;
  orders: number;
  aov: number;
  trend: { label: string; revenue: number }[];
  bestSellers: { name: string; qty: number; revenue: number }[];
  peakHours: { hour: string; orders: number }[];
  payments: { method: string; total: number }[];
}

function aggregate(sales: Sale[]) {
  const live = sales.filter((s) => !s.voided);
  const revenue = live.reduce((a, s) => a + s.total, 0);
  const cogs = live.reduce(
    (a, s) => a + s.items.reduce((b, i) => b + i.cost * i.qty, 0),
    0,
  );
  return { live, revenue, profit: revenue - cogs };
}

export const reportService = {
  today(): DashboardMetrics {
    const sales = salesService.byDateRange(startOfDay(new Date()), endOfDay(new Date()));
    return reportService.metrics(sales, 24);
  },
  last7(): DashboardMetrics {
    const to = endOfDay(new Date());
    const from = startOfDay(new Date());
    from.setDate(from.getDate() - 6);
    return reportService.metrics(salesService.byDateRange(from, to), 7);
  },
  metrics(sales: Sale[], buckets: number): DashboardMetrics {
    const { live, revenue, profit } = aggregate(sales);
    const orders = live.length;
    const aov = orders ? revenue / orders : 0;

    const trend: { label: string; revenue: number }[] = [];
    if (buckets === 24) {
      const byHour = new Array(24).fill(0);
      live.forEach((s) => {
        byHour[new Date(s.createdAt).getHours()] += s.total;
      });
      for (let h = 0; h < 24; h++) trend.push({ label: `${h}:00`, revenue: byHour[h] });
    } else {
      const map = new Map<string, number>();
      for (let i = buckets - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const key = d.toISOString().slice(0, 10);
        map.set(key, 0);
      }
      live.forEach((s) => {
        const key = s.createdAt.slice(0, 10);
        if (map.has(key)) map.set(key, (map.get(key) ?? 0) + s.total);
      });
      map.forEach((v, k) => trend.push({ label: k.slice(5), revenue: v }));
    }

    const bestMap = new Map<string, { name: string; qty: number; revenue: number }>();
    live.forEach((s) =>
      s.items.forEach((i) => {
        const cur = bestMap.get(i.productId) ?? { name: i.name, qty: 0, revenue: 0 };
        cur.qty += i.qty;
        cur.revenue += i.price * i.qty;
        bestMap.set(i.productId, cur);
      }),
    );
    const bestSellers = [...bestMap.values()].sort((a, b) => b.qty - a.qty).slice(0, 5);

    const hours = new Array(24).fill(0);
    live.forEach((s) => {
      hours[new Date(s.createdAt).getHours()] += 1;
    });
    const peakHours = hours
      .map((orders, h) => ({ hour: `${h}:00`, orders }))
      .filter((x) => x.orders > 0)
      .sort((a, b) => b.orders - a.orders)
      .slice(0, 5);

    const payMap = new Map<PaymentMethod, number>();
    live.forEach((s) => {
      const parts = saleAmountByMethod(s);
      (Object.keys(parts) as PaymentMethod[]).forEach((m) => {
        if (parts[m] > 0) payMap.set(m, (payMap.get(m) ?? 0) + parts[m]);
      });
    });
    const payments = [...payMap.entries()].map(([method, total]) => ({ method, total }));

    return { revenue, profit, orders, aov, trend, bestSellers, peakHours, payments };
  },
};