/**
 * Finance Budget Service — additive V2.
 *
 * Simpan target budget bulanan owner per kategori. TIDAK mengubah
 * schema/service Finance yang sudah di-freeze. Data disimpan dalam
 * localStorage terpisah (`financeBudgets`).
 */

import { storage, StorageKeys } from "./storage";
import { financeExpenses, financeFundWithdraws, financeDebts } from "./finance.service";

export type BudgetCategory =
  | "operational"
  | "development"
  | "marketing"
  | "owner_salary"
  | "debt";

export const BUDGET_CATEGORY_LABEL: Record<BudgetCategory, string> = {
  operational: "Operasional",
  development: "Development",
  marketing: "Marketing",
  owner_salary: "Owner Salary",
  debt: "Cicilan Hutang",
};

export interface FinanceBudget {
  category: BudgetCategory;
  monthlyAmount: number;
  note?: string;
  updatedAt: string;
}

const DEFAULTS: FinanceBudget[] = [];

export const financeBudgets = {
  list(): FinanceBudget[] {
    return storage.get<FinanceBudget[]>(StorageKeys.financeBudgets) ?? DEFAULTS;
  },
  get(category: BudgetCategory): FinanceBudget | undefined {
    return financeBudgets.list().find((b) => b.category === category);
  },
  upsert(category: BudgetCategory, monthlyAmount: number, note?: string): FinanceBudget {
    const list = financeBudgets.list();
    const rec: FinanceBudget = {
      category,
      monthlyAmount,
      note,
      updatedAt: new Date().toISOString(),
    };
    const idx = list.findIndex((b) => b.category === category);
    if (idx >= 0) list[idx] = rec;
    else list.push(rec);
    storage.set(StorageKeys.financeBudgets, list);
    return rec;
  },
  remove(category: BudgetCategory) {
    storage.set(
      StorageKeys.financeBudgets,
      financeBudgets.list().filter((b) => b.category !== category),
    );
  },
};

/** Realisasi aktual bulan berjalan per kategori budget (read-only). */
export function budgetActuals(): Record<BudgetCategory, number> {
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth();
  const inMonth = (iso: string) => {
    const d = new Date(iso);
    return d.getFullYear() === y && d.getMonth() === m;
  };
  const out: Record<BudgetCategory, number> = {
    operational: 0,
    development: 0,
    marketing: 0,
    owner_salary: 0,
    debt: 0,
  };
  for (const e of financeExpenses.list()) {
    if (!inMonth(e.at)) continue;
    if (e.pot === "operational") out.operational += e.amount;
    if (e.pot === "development") out.development += e.amount;
    const cat = (e.category as string) ?? "";
    if (cat.toLowerCase().includes("marketing")) out.marketing += e.amount;
  }
  for (const w of financeFundWithdraws.list()) {
    if (!inMonth(w.at)) continue;
    if (w.pot === "owner") out.owner_salary += w.amount;
    if (w.pot === "development") out.development += w.amount;
    if (w.pot === "operational") out.operational += w.amount;
  }
  for (const p of financeDebts.payments()) {
    if (!inMonth(p.at)) continue;
    out.debt += p.amount;
  }
  return out;
}

export interface BudgetRow {
  category: BudgetCategory;
  label: string;
  budget: number;
  actual: number;
  remaining: number;
  percent: number;
  status: "ok" | "warning" | "over" | "empty";
  note?: string;
}

export function budgetRows(): BudgetRow[] {
  const actuals = budgetActuals();
  const list = financeBudgets.list();
  const known = new Set(list.map((b) => b.category));
  const cats: BudgetCategory[] = [
    "operational",
    "development",
    "marketing",
    "owner_salary",
    "debt",
  ];
  return cats.map((c) => {
    const b = list.find((x) => x.category === c);
    const budget = b?.monthlyAmount ?? 0;
    const actual = actuals[c] ?? 0;
    const remaining = budget - actual;
    const percent = budget > 0 ? (actual / budget) * 100 : 0;
    let status: BudgetRow["status"];
    if (budget === 0) status = "empty";
    else if (percent >= 100) status = "over";
    else if (percent >= 80) status = "warning";
    else status = "ok";
    return {
      category: c,
      label: BUDGET_CATEGORY_LABEL[c],
      budget,
      actual,
      remaining,
      percent,
      status,
      note: b?.note,
    };
  }).filter((_, i, arr) => arr[i].budget > 0 || known.has(arr[i].category) || true);
}
