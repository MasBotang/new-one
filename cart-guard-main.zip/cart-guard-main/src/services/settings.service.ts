import { storage, StorageKeys } from "./storage";
import { DEFAULT_PRODUCTION_SETTINGS, type BusinessSettings, type ProductionSettings } from "./types";

const DEFAULTS: BusinessSettings = {
  businessName: "DeSalut",
  salesTargetDaily: 2_000_000,
  defaultCustomerName: "Pelanggan Umum",
  production: DEFAULT_PRODUCTION_SETTINGS,
};

export const settingsService = {
  get(): BusinessSettings {
    const stored = (storage.get<BusinessSettings>(StorageKeys.settings) ?? {}) as Partial<BusinessSettings>;
    const merged: BusinessSettings = { ...DEFAULTS, ...stored };
    merged.production = { ...DEFAULT_PRODUCTION_SETTINGS, ...(stored.production ?? {}) };
    return merged;
  },
  save(s: BusinessSettings) {
    storage.set(StorageKeys.settings, s);
  },
  production(): ProductionSettings {
    return settingsService.get().production ?? DEFAULT_PRODUCTION_SETTINGS;
  },
  updateProduction(patch: Partial<ProductionSettings>): ProductionSettings {
    const cur = settingsService.get();
    const next: BusinessSettings = {
      ...cur,
      production: { ...(cur.production ?? DEFAULT_PRODUCTION_SETTINGS), ...patch },
    };
    settingsService.save(next);
    return next.production!;
  },
};
