import type { Storage } from "./storage";

const isBrowser = typeof window !== "undefined" && typeof window.localStorage !== "undefined";

/**
 * Custom event dispatched on every same-tab storage write. Native `storage`
 * event only fires on OTHER tabs, so components that need to refresh after a
 * local write subscribe to this event as well.
 */
export const STORAGE_WRITE_EVENT = "desalut:storage-write";

function emitWrite(key: string) {
  if (!isBrowser) return;
  try {
    window.dispatchEvent(new CustomEvent(STORAGE_WRITE_EVENT, { detail: { key } }));
  } catch {
    /* older browsers without CustomEvent — non-fatal */
  }
}

export const localStorageAdapter: Storage = {
  get<T>(key: string): T | null {
    if (!isBrowser) return null;
    try {
      const raw = window.localStorage.getItem(key);
      return raw == null ? null : (JSON.parse(raw) as T);
    } catch {
      return null;
    }
  },
  set<T>(key: string, value: T) {
    if (!isBrowser) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
      emitWrite(key);
    } catch {
      /* quota / private mode: swallow */
    }
  },
  remove(key: string) {
    if (!isBrowser) return;
    window.localStorage.removeItem(key);
    emitWrite(key);
  },
  has(key: string) {
    if (!isBrowser) return false;
    return window.localStorage.getItem(key) !== null;
  },
};
