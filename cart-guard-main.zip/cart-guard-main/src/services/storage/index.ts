import { localStorageAdapter } from "./localStorageAdapter";
import type { Storage } from "./storage";

/** Active storage adapter. Swap this single line to migrate. */
export const storage: Storage = localStorageAdapter;

export { StorageKeys } from "./keys";
export type { Storage } from "./storage";