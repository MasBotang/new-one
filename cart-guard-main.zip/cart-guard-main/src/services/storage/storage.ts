/**
 * Storage abstraction. UI/services depend on this — never on window.localStorage.
 * Swap the adapter to migrate to REST/Supabase/etc. without touching UI code.
 */
export interface Storage {
  get<T>(key: string): T | null;
  set<T>(key: string, value: T): void;
  remove(key: string): void;
  has(key: string): boolean;
}