import { storage, StorageKeys } from "./storage";
import type { Sale, SaleType, SourceOrder, SalePacking, SalePlastic, SaleExtraPackaging } from "./types";
import { productService } from "./product.service";

import { queueService } from "./queue.service";
import { auditService } from "./audit.service";
import { stockMovementService } from "./stock-movement.service";
import { inventoryService } from "./inventory.service";
import { buildAutoPacking } from "./packing";

/**
 * Human-readable transaction ID: `INV-YYYYMMDD-NNNN`.
 * Per-day sequence stored in localStorage; resets each day.
 */
function nextSalesId(now = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  const day = `${y}${m}${d}`;
  const seq = storage.get<{ day: string; n: number }>(StorageKeys.salesSequence);
  const n = seq && seq.day === day ? seq.n + 1 : 1;
  storage.set(StorageKeys.salesSequence, { day, n });
  return `INV-${day}-${String(n).padStart(4, "0")}`;
}

/**
 * Nomor antrean harian format `#001`. Reset per hari.
 */
function nextOrderNumber(now = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  const day = `${y}${m}${d}`;
  const seq = storage.get<{ day: string; n: number }>(StorageKeys.orderNumberSequence);
  const n = seq && seq.day === day ? seq.n + 1 : 1;
  storage.set(StorageKeys.orderNumberSequence, { day, n });
  return `#${String(n).padStart(3, "0")}`;
}

export const salesService = {
  list(): Sale[] {
    // Backfill: sale lama tanpa sourceOrder dianggap "outlet".
    const rows = storage.get<Sale[]>(StorageKeys.sales) ?? [];
    return rows.map((s) => ({
      ...s,
      sourceOrder: (s.sourceOrder ?? "outlet") as SourceOrder,
    }));
  },
  create(input: Omit<Sale, "id" | "createdAt">): Sale {
    const now = new Date();
    const saleType: SaleType = input.saleType ?? "frozen";
    const sourceOrder: SourceOrder = (input.sourceOrder ?? "outlet") as SourceOrder;

    // Bila caller tidak mengirim packings, buat default 1 packing berisi seluruh item.
    const packings: SalePacking[] =
      input.packings && input.packings.length > 0
        ? input.packings
        : [buildAutoPacking(input.items.map((i) => ({ productId: i.productId, name: i.name, qty: i.qty })))];
    const plastic: SalePlastic | undefined = input.plastic;
    const extraPackaging: SaleExtraPackaging[] | undefined = input.extraPackaging;

    const sale: Sale = {
      id: nextSalesId(now),
      createdAt: now.toISOString(),
      ...input,
      saleType,
      sourceOrder,
      orderNumber: nextOrderNumber(now),
      packings,
      plastic,
      extraPackaging,
    };
    const list = storage.get<Sale[]>(StorageKeys.sales) ?? [];
    list.unshift(sale);
    storage.set(StorageKeys.sales, list);

    // ---- Automation post-checkout ----
    // 1. Kurangi Ready Stock — fail-loud (Sprint 1 H-1). Pra-validasi seluruh
    //    item dahulu supaya tidak terjadi deduksi parsial. Setiap penulisan
    //    tercatat lewat productService.deduct → audit product_stock_write.
    {
      const products = productService.list();
      const missing: string[] = [];
      for (const line of sale.items) {
        const p = products.find((x) => x.id === line.productId);
        if (!p) continue; // produk sudah dihapus — biarkan; kasir sudah cek
        const cur = p.stock ?? 0;
        if (cur < line.qty) {
          missing.push(`${p.name} (tersedia ${cur}, butuh ${line.qty})`);
        }
      }
      if (missing.length) {
        // Rollback: sale sudah tersimpan → buang entry terbaru sebelum throw.
        const rows = storage.get<Sale[]>(StorageKeys.sales) ?? [];
        storage.set(
          StorageKeys.sales,
          rows.filter((s) => s.id !== sale.id),
        );
        throw new Error(
          `Ready stock tidak mencukupi: ${missing.join("; ")}`,
        );
      }
      for (const line of sale.items) {
        try {
          productService.deduct(line.productId, line.qty, {
            actor: sale.cashier,
            reason: `Sale ${sale.id}`,
            source: "sales",
            entityId: sale.id,
          });
        } catch (err) {
          console.error("[sales] deduct failed", err);
          throw err;
        }
      }
    }

    // 2. Kurangi stok packaging otomatis. Sprint 1 H-1: pra-validasi stok
    //    inventory dulu supaya tidak ada packaging jadi negatif diam-diam.
    //    FIX (Sprint 1.5): pra-validasi + shortage rollback WAJIB propagate
    //    ke caller (kasir). Sebelumnya try/catch luar menelan error shortage
    //    → sale terhapus dari storage tapi caller mengira sukses, queue
    //    ter-insert untuk saleId yang sudah tidak ada → Dashboard, Analytics,
    //    Finance kehilangan transaksi tanpa tanda apa pun.
    const need = new Map<string, { qty: number; name: string }>();
    const addNeed = (itemId: string | undefined, qty: number, name: string) => {
      if (!itemId || qty <= 0) return;
      const cur = need.get(itemId);
      if (cur) cur.qty += qty;
      else need.set(itemId, { qty, name });
    };
    for (const p of packings) addNeed(p.boxItemId, p.boxQty, p.boxItemName);
    if (plastic?.itemId) addNeed(plastic.itemId, plastic.qty, "plastik");
    for (const ex of extraPackaging ?? []) addNeed(ex.itemId, ex.qty, ex.itemName);
    const shortage: string[] = [];
    for (const [itemId, v] of need) {
      const inv = inventoryService.get(itemId);
      if (!inv) continue; // packaging tidak terhubung inventory → tidak diikutkan
      if (inv.stock < v.qty) {
        shortage.push(`${inv.name} (tersedia ${inv.stock}, butuh ${v.qty})`);
      }
    }
    if (shortage.length) {
      // Rollback ready stock yang sudah dikurangi + hapus sale dari storage.
      for (const line of sale.items) {
        try {
          productService.addStock(line.productId, line.qty, {
            actor: sale.cashier,
            reason: `Rollback stok — packaging kurang untuk Sale ${sale.id}`,
            source: "sales_rollback",
            entityId: sale.id,
          });
        } catch (err) {
          console.error("[sales] rollback ready stock failed", err);
        }
      }
      const rows = storage.get<Sale[]>(StorageKeys.sales) ?? [];
      storage.set(
        StorageKeys.sales,
        rows.filter((s) => s.id !== sale.id),
      );
      auditService.log({
        actor: sale.cashier,
        action: "sale_voided",
        entity: "sale",
        entityId: sale.id,
        reason: `Rollback otomatis — stok packaging tidak mencukupi: ${shortage.join("; ")}`,
        metadata: {
          rollback: {
            readyStock: sale.items.map((i) => ({ productId: i.productId, qty: i.qty })),
            reason: "packaging_shortage",
            shortage,
          },
        },
      });
      throw new Error(
        `Stok packaging tidak mencukupi: ${shortage.join("; ")}`,
      );
    }

    // Recording pergerakan stok packaging + audit. Error di sini di-log
    // (bukan fatal) karena stock sudah tervalidasi di atas, kegagalan
    // paling parah hanyalah kehilangan movement log — tidak mengubah stok.
    try {
      const usedBoxes: { itemId: string; name: string; qty: number }[] = [];
      for (const p of packings) {
        if (p.boxItemId && p.boxQty > 0) {
          stockMovementService.record({
            itemId: p.boxItemId,
            type: "sales_packaging_usage",
            quantity: p.boxQty,
            reason: `Sale ${sale.id} · ${sale.orderNumber}`,
          });
          usedBoxes.push({ itemId: p.boxItemId, name: p.boxItemName, qty: p.boxQty });
        }
      }
      if (plastic?.itemId && plastic.qty > 0) {
        stockMovementService.record({
          itemId: plastic.itemId,
          type: "sales_packaging_usage",
          quantity: plastic.qty,
          reason: `Sale ${sale.id} · plastik`,
        });
      }
      if (extraPackaging && extraPackaging.length) {
        for (const ex of extraPackaging) {
          if (ex.itemId && ex.qty > 0) {
            stockMovementService.record({
              itemId: ex.itemId,
              type: "sales_packaging_usage",
              quantity: ex.qty,
              reason: `Sale ${sale.id} · packaging tambahan`,
            });
          }
        }
        auditService.log({
          actor: sale.cashier,
          action: "sales_extra_packaging_added",
          entity: "sale",
          entityId: sale.id,
          metadata: { extras: extraPackaging, orderNumber: sale.orderNumber },
        });
      }
      auditService.log({
        actor: sale.cashier,
        action: "sales_packaging_used",
        entity: "sale",
        entityId: sale.id,
        metadata: {
          orderNumber: sale.orderNumber,
          boxes: usedBoxes,
          plastic: plastic ?? null,
        },
      });
    } catch (err) {
      console.error("[sales] packaging movement recording failed", err);
    }



    // 3. Insert antrean order — Pre Order TIDAK langsung masuk queue.
    if (!sale.isPreorder) {
      try {
        const totalQty = sale.items.reduce((a, c) => a + c.qty, 0);
        queueService.create({
          saleId: sale.id,
          saleCode: sale.id,
          saleType,
          customerName: sale.customerName ?? "-",
          customerPhone: sale.customerPhone,
          pickupAt: sale.pickupAt,
          isPreorder: false,
          itemCount: totalQty,
          itemsSummary: sale.items.map((i) => `${i.qty}× ${i.name}`).join(", "),
          sourceOrder,
          preorderId: sale.preorderId,
          orderNumber: sale.orderNumber,
          packings,
        });
      } catch (err) {
        console.error("[sales] queue insert failed", err);
      }
    }

    // 4. Audit log dasar transaksi.
    auditService.log({
      actor: sale.cashier,
      action: "sale_created",
      entity: "sale",
      entityId: sale.id,
      metadata: {
        total: sale.total,
        payment: sale.payment,
        saleType,
        customerType: sale.customerType,
        isPreorder: sale.isPreorder,
        sourceOrder,
        priceGroupId: sale.priceGroupId,
        orderNumber: sale.orderNumber,
        packingCount: packings.length,
      },
    });
    return sale;
  },
  void(id: string, opts: { reason: string; actor: string; actorRole?: string }) {
    const now = new Date().toISOString();
    let target: Sale | undefined;
    let alreadyVoided = false;
    const list = salesService.list().map((s) => {
      if (s.id !== id) return s;
      target = s;
      if (s.voided) {
        alreadyVoided = true;
        return s;
      }
      return {
        ...s,
        voided: true,
        voidReason: opts.reason,
        voidedBy: opts.actor,
        voidedAt: now,
      };
    });
    // Idempoten: sale sudah pernah di-void → jangan tulis ulang & jangan
    // menambah entri audit ganda (mencegah "duplicate audit" akibat double-click).
    if (!target || alreadyVoided) return;
    storage.set(StorageKeys.sales, list);

    // ---- Rollback penuh transaksi ----
    // Business rule (Refund Approval): mengembalikan ready stock, queue produksi,
    // packaging, dan otomatis mengeluarkan sale dari Ringkasan Penjualan /
    // Payment Breakdown / Marketplace Breakdown (summary service filter voided).
    // Audit log tetap dipertahankan (tidak dihapus).

    // 1. Kembalikan ready stock produk lewat productService.addStock supaya
    //    tiap restore ter-audit `product_stock_write` (Sprint 1 H-4).
    for (const line of target.items) {
      try {
        productService.addStock(line.productId, line.qty, {
          actor: opts.actor,
          reason: `Refund rollback · Sale ${target.id}`,
          source: "refund_rollback",
          entityId: target.id,
        });
      } catch (err) {
        console.error("[sales] refund rollback: ready stock restore failed", err);
      }
    }

    // 2. Hapus entri queue produksi (rollback antrean).
    try {
      queueService.removeBySale(target.id);
    } catch (err) {
      console.error("[sales] refund rollback: queue removal failed", err);
    }

    // 3. Kembalikan packaging yang sudah dikurangi (boxes, plastik, extras).
    try {
      const restore = (itemId: string | undefined, qty: number, note: string) => {
        if (!itemId || qty <= 0) return;
        if (!inventoryService.get(itemId)) return;
        stockMovementService.record({
          itemId,
          type: "restock",
          quantity: qty,
          reason: `Refund rollback · Sale ${target!.id}`,
          notes: note,
        });
      };
      for (const p of target.packings ?? []) {
        restore(p.boxItemId, p.boxQty, "box packing dikembalikan");
      }
      if (target.plastic) {
        restore(target.plastic.itemId, target.plastic.qty, "plastik dikembalikan");
      }
      for (const ex of target.extraPackaging ?? []) {
        restore(ex.itemId, ex.qty, "packaging tambahan dikembalikan");
      }
    } catch (err) {
      console.error("[sales] refund rollback: packaging restore failed", err);
    }

    auditService.log({
      actor: opts.actor,
      actorRole: opts.actorRole,
      action: "sale_voided",
      entity: "sale",
      entityId: id,
      reason: opts.reason,
      metadata: {
        total: target.total,
        payment: target.payment,
        rollback: {
          readyStock: target.items.map((i) => ({ productId: i.productId, qty: i.qty })),
          queueRemoved: true,
          packaging: {
            boxes: (target.packings ?? [])
              .filter((p) => p.boxItemId && p.boxQty > 0)
              .map((p) => ({ itemId: p.boxItemId, qty: p.boxQty })),
            plastic: target.plastic ?? null,
            extras: target.extraPackaging ?? [],
          },
          sourceOrder: target.sourceOrder,
        },
      },
    });
  },
  /**
   * Guard business rule: refund hanya dapat disetujui bila pesanan belum
   * memasuki proses produksi. Queue `waiting` = boleh; status lain (cooking,
   * packing, ready, completed) = sudah diproses, refund ditolak.
   * Preorder yang belum jadi Sale queue (tidak ada queue entry) juga boleh.
   */
  canRefund(id: string): { ok: true } | { ok: false; reason: string } {
    const sale = salesService.list().find((s) => s.id === id);
    if (!sale) return { ok: false, reason: "Transaksi tidak ditemukan" };
    if (sale.voided) return { ok: false, reason: "Transaksi sudah di-refund" };
    const q = queueService.bySale(id);
    if (!q) return { ok: true };
    if (q.status === "waiting") return { ok: true };
    const label =
      q.status === "cooking"
        ? "sedang dimasak"
        : q.status === "packing"
          ? "sedang di-packing"
          : q.status === "ready"
            ? "siap diambil"
            : "selesai";
    return { ok: false, reason: `Pesanan sudah masuk proses produksi (${label})` };
  },
  byDateRange(from: Date, to: Date): Sale[] {
    const f = from.getTime();
    const t = to.getTime();
    return salesService.list().filter((s) => {
      const d = new Date(s.createdAt).getTime();
      return d >= f && d <= t;
    });
  },
};