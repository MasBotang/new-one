import { storage, StorageKeys } from "./storage";
import { inventoryService } from "./inventory.service";
import type { StockMovement, StockMovementType } from "./types";

function uid() {
  return `mov_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

/** Stock In types add to balance; everything else subtracts. */
const STOCK_IN_TYPES: StockMovementType[] = ["restock", "production_output"];

export function isStockIn(t: StockMovementType): boolean {
  return STOCK_IN_TYPES.includes(t);
}

export interface NewStockMovementInput {
  itemId: string;
  type: StockMovementType;
  /** Positive number entered by user; sign is determined by type. */
  quantity: number;
  reason?: string;
  notes?: string;
  /**
   * For "adjustment": when true, this represents an absolute target stock
   * level and `quantity` is interpreted as the new balance.
   */
  adjustmentAbsolute?: boolean;
}

export const stockMovementService = {
  list(): StockMovement[] {
    return storage.get<StockMovement[]>(StorageKeys.stockMovements) ?? [];
  },
  save(list: StockMovement[]) {
    storage.set(StorageKeys.stockMovements, list);
  },
  byItem(itemId: string): StockMovement[] {
    return stockMovementService.list().filter((m) => m.itemId === itemId);
  },
  recent(limit = 10): StockMovement[] {
    return stockMovementService.list().slice(0, limit);
  },
  /**
   * Source of truth: every stock change goes through here.
   * Applies the delta to the item and persists the movement.
   */
  record(input: NewStockMovementInput): StockMovement {
    const item = inventoryService.get(input.itemId);
    if (!item) throw new Error("Item tidak ditemukan");
    const qty = Math.max(0, input.quantity);

    let requestedDelta = 0;
    if (input.type === "adjustment" && input.adjustmentAbsolute) {
      requestedDelta = qty - item.stock;
    } else if (isStockIn(input.type)) {
      requestedDelta = qty;
    } else if (input.type === "adjustment") {
      requestedDelta = -qty;
    } else {
      requestedDelta = -qty;
    }

    // FIX (Sprint 1.5): fail-loud pada shortage untuk semua tipe stock-out
    // (kecuali `adjustment` absolut, yang memang bisa menargetkan 0). Sebelumnya
    // delta di-clamp diam-diam sehingga movement mencatat delta lebih kecil
    // dari yang diminta caller — packaging usage / operational expense bisa
    // "berhasil" padahal stok tidak dikurangi penuh, menciptakan selisih
    // Inventory ↔ Ringkasan Pemakaian.
    if (
      requestedDelta < 0 &&
      !(input.type === "adjustment" && input.adjustmentAbsolute) &&
      item.stock + requestedDelta < 0
    ) {
      throw new Error(
        `Stok ${item.name} tidak mencukupi (tersedia ${item.stock}, butuh ${Math.abs(requestedDelta)})`,
      );
    }
    // Untuk adjustment absolut, tetap clamp ke 0 supaya stok tidak negatif.
    const minDelta = -item.stock;
    const delta = requestedDelta < minDelta ? minDelta : requestedDelta;
    const updated = inventoryService.adjustStock(item.id, delta);
    const balanceAfter = updated?.stock ?? Math.max(0, item.stock + delta);


    const movement: StockMovement = {
      id: uid(),
      createdAt: new Date().toISOString(),
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      type: input.type,
      quantity: Math.abs(delta),
      delta,
      reason: input.reason?.trim() || undefined,
      notes: input.notes?.trim() || undefined,
      balanceAfter,
    };

    const list = stockMovementService.list();
    list.unshift(movement);
    stockMovementService.save(list);
    return movement;
  },
};