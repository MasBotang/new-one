/**
 * Finance module — business constants (Single Source of Truth).
 *
 * All magic numbers previously scattered across finance*.service.ts and
 * feature pages MUST live here so the business rules are visible in one
 * place. Do not inline these values in service code.
 */

import type { FundPot } from "./types";

// ---------- Allocation (default profit split into pots) ----------

export const DEFAULT_ALLOCATION: Record<FundPot, number> = {
  owner: 30,
  development: 20,
  operational: 40,
  debt: 10,
};

export const DEFAULT_DEVELOPMENT_TARGET = 50_000_000;

// ---------- Health score thresholds ----------

export const HEALTH_MARGIN_TARGET = 0.25;          // 25% gross margin
export const HEALTH_WASTE_MAX = 0.05;              // waste <= 5% of revenue
export const HEALTH_EXPENSE_RATIO_MAX = 0.4;       // opex <= 40% of revenue
export const HEALTH_DEBT_PROGRESS_TARGET = 0.5;    // >= 50% debt paid

export const HEALTH_WEIGHTS = {
  margin: 25,
  cashflow: 20,
  waste: 15,
  operational: 15,
  debt: 10,
  development: 15,
} as const;

/** Star mapping — gap at 3 is intentional (product spec). */
export const HEALTH_STAR_THRESHOLDS = [
  { score: 80, stars: 5 },
  { score: 60, stars: 4 },
  { score: 40, stars: 2 },
  { score: 20, stars: 1 },
] as const;

// ---------- Warning / alert levels ----------

export const RUNWAY_WARN_DAYS = 60;   // yellow alert
export const RUNWAY_DANGER_DAYS = 30; // red alert

export const BUDGET_WARN_RATIO = 0.8;   // >=80% used = warning
export const BUDGET_OVER_RATIO = 1.0;   // >=100% used = over budget

export const GROWTH_ALERT_THRESHOLD = 0.1; // ±10% profit / revenue growth

export const DEBT_DUE_SOON_DAYS = 7;

// ---------- Projection / trend defaults ----------

export const DEFAULT_HISTORY_DAYS = 30;
export const DEFAULT_TREND_DAYS = 14;
export const DEFAULT_CASHFLOW_DAYS = 30;
export const PROJECTION_HORIZONS = [30, 60, 90] as const;
export type ProjectionHorizonDays = (typeof PROJECTION_HORIZONS)[number];

// ---------- Coverage / data quality mapping ----------

export const HEALTH_COVERAGE_TOTAL = 6;
