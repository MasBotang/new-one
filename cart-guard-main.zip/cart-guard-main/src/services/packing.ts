import type { SalePacking, SalePackingItem } from "./types";
import { inventoryService } from "./inventory.service";

export const PLASTIC_OPTIONS: string[] = [
  "Plastik PE Kecil",
  "Plastik PE Sedang",
  "Plastik PE Besar",
  "Plastik Non PE Kecil",
  "Plastik Non PE Sedang",
  "Plastik Non PE Besar",
];

/**
 * Menentukan nama Launch Box otomatis berdasarkan jumlah pcs dalam 1 packing.
 * Rentang:
 *   1-2  → Launch Box Isi 2
 *   3    → Launch Box Isi 3
 *   4-5  → Launch Box Isi 4-5
 *   6-8  → Launch Box Isi 6-8
 *   >8   → dipecah ke beberapa Launch Box Isi 6-8 (ceil(n/8)).
 */
export function autoBoxName(qty: number): string {
  if (qty <= 2) return "Launch Box Isi 2";
  if (qty === 3) return "Launch Box Isi 3";
  if (qty <= 5) return "Launch Box Isi 4-5";
  return "Launch Box Isi 6-8";
}

export function autoBoxQty(qty: number): number {
  if (qty <= 8) return 1;
  return Math.ceil(qty / 8);
}

/**
 * Cari inventory item packaging berdasarkan nama (case-insensitive, contains).
 * Bila tidak ketemu, tetap pakai nama untuk display (tanpa deduction stok).
 */
export function resolvePackagingItem(name: string): { itemId?: string; itemName: string } {
  const n = name.trim().toLowerCase();
  const found = inventoryService
    .byCategory("packaging")
    .find(
      (i) =>
        i.name.trim().toLowerCase() === n ||
        i.name.trim().toLowerCase().includes(n) ||
        n.includes(i.name.trim().toLowerCase()),
    );
  return found ? { itemId: found.id, itemName: found.name } : { itemName: name };
}

export function buildAutoPacking(
  items: { productId: string; name: string; qty: number }[],
): SalePacking {
  const packItems: SalePackingItem[] = items.map((i) => ({
    productId: i.productId,
    name: i.name,
    qty: i.qty,
  }));
  const totalQty = packItems.reduce((a, b) => a + b.qty, 0);
  const boxName = autoBoxName(totalQty);
  const boxQty = autoBoxQty(totalQty);
  const resolved = resolvePackagingItem(boxName);
  return {
    id: `pk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    items: packItems,
    totalQty,
    boxItemId: resolved.itemId,
    boxItemName: resolved.itemName,
    boxQty,
  };
}

export function recomputePacking(p: SalePacking): SalePacking {
  const totalQty = p.items.reduce((a, b) => a + b.qty, 0);
  const boxName = autoBoxName(totalQty);
  const boxQty = autoBoxQty(totalQty);
  const resolved = resolvePackagingItem(boxName);
  return {
    ...p,
    totalQty,
    boxItemId: resolved.itemId,
    boxItemName: resolved.itemName,
    boxQty,
  };
}

export function newPackingId(): string {
  return `pk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}
