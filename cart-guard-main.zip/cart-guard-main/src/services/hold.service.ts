import { storage, StorageKeys } from "./storage";
import type { HoldOrder, SaleItem } from "./types";

function uid() {
  return `hold_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

export const holdService = {
  list(): HoldOrder[] {
    return storage.get<HoldOrder[]>(StorageKeys.holdOrders) ?? [];
  },
  save(items: SaleItem[], customerName: string): HoldOrder {
    const order: HoldOrder = {
      id: uid(),
      createdAt: new Date().toISOString(),
      customerName: customerName.trim(),
      items,
      total: items.reduce((a, i) => a + i.price * i.qty, 0),
    };
    const list = holdService.list();
    list.unshift(order);
    storage.set(StorageKeys.holdOrders, list);
    return order;
  },
  remove(id: string) {
    storage.set(
      StorageKeys.holdOrders,
      holdService.list().filter((o) => o.id !== id),
    );
  },
  clear() {
    storage.remove(StorageKeys.holdOrders);
  },
};