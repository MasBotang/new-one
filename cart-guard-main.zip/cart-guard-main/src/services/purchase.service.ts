import { storage, StorageKeys } from "./storage";
import { inventoryService } from "./inventory.service";
import { stockMovementService } from "./stock-movement.service";

export type PurchaseKind = "satuan" | "karton";

export interface PurchaseRecord {
  id: string;
  createdAt: string;
  /** YYYY-MM-DD */
  date: string;
  itemId: string;
  itemName: string;
  unit: string;
  supplier?: string;
  notes?: string;
  kind: PurchaseKind;
  /** Jumlah karton (kind=karton). */
  cartons?: number;
  /** Isi per karton (kind=karton). */
  unitsPerCarton?: number;
  /** Harga per karton (kind=karton). */
  pricePerCarton?: number;
  /** Qty per satuan (kind=satuan). */
  quantity?: number;
  /** Harga per satuan (kind=satuan). */
  pricePerUnit?: number;
  /** Total qty yang masuk stok (unit item). */
  totalQuantity: number;
  /** Total nilai pembelian (Rp). */
  totalPrice: number;
  /** Harga efektif per unit (Rp). */
  effectivePricePerUnit: number;
  actor: string;
  /** ID Stock Movement yang dihasilkan. */
  movementId: string;
}

function uid() {
  return `pur_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

function todayISODate(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export interface NewPurchaseInput {
  itemId: string;
  date?: string;
  supplier?: string;
  notes?: string;
  kind: PurchaseKind;
  cartons?: number;
  unitsPerCarton?: number;
  pricePerCarton?: number;
  quantity?: number;
  pricePerUnit?: number;
  actor: string;
}

export const purchaseService = {
  list(): PurchaseRecord[] {
    return storage.get<PurchaseRecord[]>(StorageKeys.purchases) ?? [];
  },
  save(list: PurchaseRecord[]) {
    storage.set(StorageKeys.purchases, list);
  },
  byItem(itemId: string): PurchaseRecord[] {
    return purchaseService.list().filter((p) => p.itemId === itemId);
  },
  create(input: NewPurchaseInput): PurchaseRecord {
    const item = inventoryService.get(input.itemId);
    if (!item) throw new Error("Item tidak ditemukan");

    let totalQuantity = 0;
    let totalPrice = 0;

    if (input.kind === "karton") {
      const c = Math.max(0, Number(input.cartons) || 0);
      const isi = Math.max(0, Number(input.unitsPerCarton) || 0);
      const hargaK = Math.max(0, Number(input.pricePerCarton) || 0);
      if (c <= 0) throw new Error("Jumlah karton harus > 0");
      if (isi <= 0) throw new Error("Isi per karton harus > 0");
      totalQuantity = c * isi;
      totalPrice = c * hargaK;
    } else {
      const q = Math.max(0, Number(input.quantity) || 0);
      const p = Math.max(0, Number(input.pricePerUnit) || 0);
      if (q <= 0) throw new Error("Qty harus > 0");
      totalQuantity = q;
      totalPrice = q * p;
    }

    const effective =
      totalQuantity > 0 ? Math.round((totalPrice / totalQuantity) * 100) / 100 : 0;

    // 1) Catat pergerakan stok (restock) — tetap pakai jalur lama.
    const movement = stockMovementService.record({
      itemId: item.id,
      type: "restock",
      quantity: totalQuantity,
      reason: input.supplier ? `Pembelian · ${input.supplier}` : "Pembelian",
      notes: input.notes,
    });

    // 2) Update harga terakhir + costPerUnit + purchaseType/unitsPerCarton item.
    inventoryService.update(item.id, {
      purchasePrice: totalPrice,
      purchaseQuantity: totalQuantity,
      lastPurchasePrice: effective,
      lastPurchaseAt: new Date().toISOString(),
      lastSupplier: input.supplier,
      purchaseType: input.kind,
      unitsPerCarton:
        input.kind === "karton" ? Number(input.unitsPerCarton) || undefined : item.unitsPerCarton,
    });

    const rec: PurchaseRecord = {
      id: uid(),
      createdAt: new Date().toISOString(),
      date: input.date || todayISODate(),
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      supplier: input.supplier?.trim() || undefined,
      notes: input.notes?.trim() || undefined,
      kind: input.kind,
      cartons: input.kind === "karton" ? Number(input.cartons) : undefined,
      unitsPerCarton: input.kind === "karton" ? Number(input.unitsPerCarton) : undefined,
      pricePerCarton: input.kind === "karton" ? Number(input.pricePerCarton) : undefined,
      quantity: input.kind === "satuan" ? Number(input.quantity) : undefined,
      pricePerUnit: input.kind === "satuan" ? Number(input.pricePerUnit) : undefined,
      totalQuantity,
      totalPrice,
      effectivePricePerUnit: effective,
      actor: input.actor,
      movementId: movement.id,
    };
    const list = purchaseService.list();
    list.unshift(rec);
    purchaseService.save(list);
    return rec;
  },
};