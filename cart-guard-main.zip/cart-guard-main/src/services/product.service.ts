import { storage, StorageKeys } from "./storage";
import type { Product } from "./types";
import { priceGroupService } from "./price-group.service";
import { auditService } from "./audit.service";

export const productService = {
  list(): Product[] {
    return storage.get<Product[]>(StorageKeys.products) ?? [];
  },
  save(products: Product[]) {
    storage.set(StorageKeys.products, products);
  },
  upsert(p: Product) {
    const list = productService.list();
    const i = list.findIndex((x) => x.id === p.id);
    if (i >= 0) list[i] = p;
    else list.push(p);
    productService.save(list);
  },
  remove(id: string) {
    productService.save(productService.list().filter((p) => p.id !== id));
  },
  categories(): string[] {
    const set = new Set<string>();
    for (const p of productService.list()) if (p.category) set.add(p.category);
    return Array.from(set).sort();
  },
  generateSku(category: string): string {
    const prefix = (category || "PRD")
      .replace(/[^a-zA-Z0-9]/g, "")
      .slice(0, 3)
      .toUpperCase()
      .padEnd(3, "X");
    const existing = productService.list().filter((p) => p.sku?.startsWith(prefix + "-"));
    const nums = existing
      .map((p) => parseInt(p.sku!.split("-")[1] ?? "0", 10))
      .filter((n) => !isNaN(n));
    const next = (nums.length ? Math.max(...nums) : 0) + 1;
    return `${prefix}-${String(next).padStart(4, "0")}`;
  },
  /** Effective price for a product under a Price Group. */
  priceFor(product: Product, priceGroupId: string | undefined): number {
    return priceGroupService.priceFor(product, priceGroupId);
  },
  /**
   * Sprint 1 (H-1 + H-4): satu-satunya jalur mengurangi ready stock.
   * Fail-loud bila stok tidak mencukupi (throw). Semua penulisan stok
   * tercatat pada Audit Log (action `product_stock_write`).
   */
  deduct(
    productId: string,
    qty: number,
    ctx: { actor: string; reason: string; source: string; entityId?: string },
  ): { productId: string; before: number; after: number; delta: number } {
    if (qty <= 0) throw new Error("Qty deduksi harus > 0");
    const list = productService.list();
    const i = list.findIndex((p) => p.id === productId);
    if (i < 0) throw new Error(`Produk ${productId} tidak ditemukan`);
    const before = list[i].stock ?? 0;
    if (before < qty) {
      throw new Error(
        `Ready stock ${list[i].name} tidak mencukupi (tersedia ${before}, butuh ${qty})`,
      );
    }
    const after = before - qty;
    list[i] = { ...list[i], stock: after };
    productService.save(list);
    try {
      auditService.log({
        actor: ctx.actor,
        action: "product_stock_write",
        entity: "product",
        entityId: productId,
        reason: ctx.reason,
        metadata: {
          op: "deduct",
          source: ctx.source,
          entityId: ctx.entityId,
          before,
          after,
          delta: -qty,
          name: list[i].name,
        },
      });
    } catch (err) {
      console.error("[product] audit deduct failed", err);
    }
    return { productId, before, after, delta: -qty };
  },
  /**
   * Menambah ready stock. Sesuai BRD 6 "Ready Stock hanya berasal dari
   * Production" — dipanggil dari Production, refund rollback, atau seed.
   * Selalu audit `product_stock_write` untuk jejak fraud prevention.
   */
  addStock(
    productId: string,
    qty: number,
    ctx: { actor: string; reason: string; source: string; entityId?: string },
  ): { productId: string; before: number; after: number; delta: number } | null {
    if (qty <= 0) return null;
    const list = productService.list();
    const i = list.findIndex((p) => p.id === productId);
    if (i < 0) return null;
    const before = list[i].stock ?? 0;
    const after = before + qty;
    list[i] = { ...list[i], stock: after };
    productService.save(list);
    try {
      auditService.log({
        actor: ctx.actor,
        action: "product_stock_write",
        entity: "product",
        entityId: productId,
        reason: ctx.reason,
        metadata: {
          op: "add",
          source: ctx.source,
          entityId: ctx.entityId,
          before,
          after,
          delta: qty,
          name: list[i].name,
        },
      });
    } catch (err) {
      console.error("[product] audit add failed", err);
    }
    return { productId, before, after, delta: qty };
  },
};