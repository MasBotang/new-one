/**
 * Forecast Strategy — Strategy Pattern untuk Recommendation Engine.
 *
 * Recommendation Engine tidak boleh mengetahui bagaimana forecast dihitung.
 * Ia hanya memanggil `ForecastStrategy.forecast(context)` dan menerima peta
 * hasil (productId → pcs). Strategi dapat diganti tanpa menyentuh engine.
 *
 * Saat ini tersedia:
 *   - `WeightedForecastStrategy` (default): blended weighted average dari
 *     avgSameDay + avg7d + avg30d.
 *
 * TIDAK ada UI pengaturan strategi (Phase 1 masih FEATURE FREEZE). Strategi
 * di-wire secara internal via `defaultForecastStrategy()`.
 */
import { salesService } from "../sales.service";
import { productService } from "../product.service";
import { settingsService } from "../settings.service";
import { productionPlanningService } from "../production-planning.service";

export interface ForecastContext {
  /** Tanggal acuan perhitungan forecast (default hari ini). */
  target: Date;
}

export interface ProductForecast {
  productId: string;
  name: string;
  /** Rata-rata pcs pada weekday yang sama, N minggu ke belakang. */
  avgSameDay: number;
  /** Rata-rata pcs 7 hari terakhir. */
  avg7d: number;
  /** Rata-rata pcs 30 hari terakhir. */
  avg30d: number;
  /** Forecast final (blended). */
  forecast: number;
}

export interface ForecastStrategy {
  /** Identifier strategi untuk logging / dokumentasi. */
  readonly id: string;
  /** Hitung forecast per produk aktif. */
  forecast(ctx: ForecastContext): ProductForecast[];
}

// ---------- Helpers (internal) ----------

function startOfDay(d: Date): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

/** Sum penjualan (non-void) per produk dalam rentang [from, to). */
function salesInRange(from: Date, to: Date): Map<string, number> {
  const out = new Map<string, number>();
  for (const s of salesService.list()) {
    if (s.voided) continue;
    const d = new Date(s.createdAt);
    if (d < from || d >= to) continue;
    for (const it of s.items) {
      out.set(it.productId, (out.get(it.productId) ?? 0) + (Number(it.qty) || 0));
    }
  }
  return out;
}

function avgLastNDays(days: number, target: Date): Map<string, number> {
  const to = startOfDay(target);
  const from = new Date(to);
  from.setDate(from.getDate() - days);
  const totals = salesInRange(from, to);
  const out = new Map<string, number>();
  for (const [pid, total] of totals) out.set(pid, total / days);
  return out;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

// ---------- Weighted Forecast Strategy ----------

export interface WeightedForecastConfig {
  /** Bobot rata-rata weekday yang sama (N minggu terakhir). */
  sameDay: number;
  /** Bobot rata-rata 7 hari. */
  avg7d: number;
  /** Bobot rata-rata 30 hari. */
  avg30d: number;
  /** Jumlah minggu untuk perhitungan same-day (fallback dari ProductionSettings). */
  sameDayWeeksFallback: number;
}

/**
 * Konfigurasi default Weighted Forecast.
 *
 * Bobot ini adalah baseline business rule Phase 1. Ia HANYA hidup di sini —
 * algoritma utama tidak boleh mengandung magic number.
 */
export const DEFAULT_WEIGHTED_FORECAST_CONFIG: WeightedForecastConfig = {
  sameDay: 0.5,
  avg7d: 0.3,
  avg30d: 0.2,
  sameDayWeeksFallback: 4,
};

export class WeightedForecastStrategy implements ForecastStrategy {
  readonly id = "weighted";
  constructor(private readonly config: WeightedForecastConfig = DEFAULT_WEIGHTED_FORECAST_CONFIG) {}

  forecast(ctx: ForecastContext): ProductForecast[] {
    const { target } = ctx;
    const settings = settingsService.production();
    const weeks =
      settings.avgWeeks && settings.avgWeeks > 0
        ? settings.avgWeeks
        : this.config.sameDayWeeksFallback;

    const sameDay = productionPlanningService.computeAvgSameDay(target, weeks);
    const avg7 = avgLastNDays(7, target);
    const avg30 = avgLastNDays(30, target);

    const w1 = this.config.sameDay;
    const w2 = this.config.avg7d;
    const w3 = this.config.avg30d;

    return productService
      .list()
      .filter((p) => p.active !== false)
      .map((p) => {
        const a1 = sameDay.get(p.id) ?? 0;
        const a2 = avg7.get(p.id) ?? 0;
        const a3 = avg30.get(p.id) ?? 0;
        const blended = w1 * a1 + w2 * a2 + w3 * a3;
        return {
          productId: p.id,
          name: p.name,
          avgSameDay: round2(a1),
          avg7d: round2(a2),
          avg30d: round2(a3),
          forecast: round2(blended),
        };
      });
  }
}

/** Strategi default yang dipakai Recommendation Engine. */
export function defaultForecastStrategy(): ForecastStrategy {
  return new WeightedForecastStrategy();
}
