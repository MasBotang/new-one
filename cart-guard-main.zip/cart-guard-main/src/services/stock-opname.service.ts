import { storage, StorageKeys } from "./storage";
import { inventoryService } from "./inventory.service";
import { stockMovementService } from "./stock-movement.service";

export interface StockOpnameRecord {
  id: string;
  createdAt: string;
  itemId: string;
  itemName: string;
  unit: string;
  systemStock: number;
  physicalStock: number;
  diff: number;
  reason: string;
  notes?: string;
  actor: string;
  movementId: string;
}

function uid() {
  return `opn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

export const stockOpnameService = {
  list(): StockOpnameRecord[] {
    return storage.get<StockOpnameRecord[]>(StorageKeys.stockOpnames) ?? [];
  },
  save(list: StockOpnameRecord[]) {
    storage.set(StorageKeys.stockOpnames, list);
  },
  create(input: {
    itemId: string;
    physicalStock: number;
    reason: string;
    notes?: string;
    actor: string;
  }): StockOpnameRecord {
    const item = inventoryService.get(input.itemId);
    if (!item) throw new Error("Item tidak ditemukan");
    const physical = Math.max(0, Number(input.physicalStock) || 0);
    const systemStock = item.stock;
    const diff = physical - systemStock;

    const movement = stockMovementService.record({
      itemId: item.id,
      type: "adjustment",
      quantity: physical,
      adjustmentAbsolute: true,
      reason: `Stock Opname · ${input.reason}`,
      notes: input.notes,
    });

    const rec: StockOpnameRecord = {
      id: uid(),
      createdAt: new Date().toISOString(),
      itemId: item.id,
      itemName: item.name,
      unit: item.unit,
      systemStock,
      physicalStock: physical,
      diff,
      reason: input.reason,
      notes: input.notes,
      actor: input.actor,
      movementId: movement.id,
    };
    const list = stockOpnameService.list();
    list.unshift(rec);
    stockOpnameService.save(list);
    return rec;
  },
  /** N opname terbaru (default 5). */
  recent(n = 5): StockOpnameRecord[] {
    return stockOpnameService.list().slice(0, n);
  },
  /**
   * Jumlah item unik yang pada opname TERAKHIR-nya memiliki selisih (≠ 0).
   * Perlu investigasi.
   */
  investigationCount(): number {
    const seen = new Set<string>();
    let count = 0;
    for (const r of stockOpnameService.list()) {
      if (seen.has(r.itemId)) continue;
      seen.add(r.itemId);
      if (r.diff !== 0) count++;
    }
    return count;
  },
  /** Statistik ringkas opname. */
  stats() {
    const list = stockOpnameService.list();
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    let today = 0;
    let month = 0;
    let totalMinus = 0;
    let totalPlus = 0;
    for (const r of list) {
      const t = new Date(r.createdAt).getTime();
      if (t >= startOfDay) today++;
      if (t >= startOfMonth) month++;
      if (r.diff < 0) totalMinus += r.diff;
      else if (r.diff > 0) totalPlus += r.diff;
    }
    return { today, month, totalMinus, totalPlus };
  },
};