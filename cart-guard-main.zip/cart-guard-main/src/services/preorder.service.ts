import { storage, StorageKeys } from "./storage";
import type { PaymentMethod, PreOrder, PreOrderStatus, SaleItem, SaleType, SourceOrder } from "./types";
import { queueService } from "./queue.service";
import { auditService } from "./audit.service";

function uid() {
  return `po_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}
function nowIso() {
  return new Date().toISOString();
}

function totalOf(items: SaleItem[]) {
  return items.reduce((a, i) => a + i.price * i.qty, 0);
}

/**
 * Buffer minimum (menit) antara waktu saat ini dengan jam pickup untuk PO
 * yang dibuat hari ini. Menghindari kasir memilih slot yang terlalu dekat
 * sehingga customer tidak realistis mengambil pesanan.
 */
export const PREORDER_MIN_LEAD_MINUTES = 30;

function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

/** Tanggal hari ini dalam format YYYY-MM-DD (tz lokal). */
export function todayYmd(now: Date = new Date()): string {
  return ymd(now);
}

/**
 * Batas jam paling awal (HH:mm) untuk pickup pada `date` tertentu, mengikuti
 * aturan buffer PREORDER_MIN_LEAD_MINUTES. Return "00:00" bila `date` di
 * masa depan.
 */
export function minPickupTimeFor(date: string, now: Date = new Date()): string {
  if (!date) return "00:00";
  if (date > todayYmd(now)) return "00:00";
  if (date < todayYmd(now)) return "23:59"; // efektif menolak tanggal lampau
  const t = new Date(now.getTime() + PREORDER_MIN_LEAD_MINUTES * 60_000);
  return `${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}`;
}

/**
 * Validasi kombinasi tanggal + jam pickup Pre Order. Return pesan error bila
 * tidak valid; null bila valid. Dipakai baik oleh UI (POS) maupun service
 * layer (fail-safe agar tidak bisa diakali DevTools).
 */
export function validatePickup(
  date: string,
  time: string,
  now: Date = new Date(),
): string | null {
  if (!date) return "Tanggal pengambilan wajib diisi";
  if (!time) return "Jam pengambilan wajib diisi";
  const today = todayYmd(now);
  if (date < today) return "Tanggal pengambilan tidak boleh di masa lalu";
  const dt = new Date(`${date}T${time}:00`);
  if (Number.isNaN(dt.getTime())) return "Format tanggal/jam tidak valid";
  const minMs = now.getTime() + PREORDER_MIN_LEAD_MINUTES * 60_000;
  if (dt.getTime() < minMs) {
    return `Jam pengambilan minimal ${PREORDER_MIN_LEAD_MINUTES} menit dari sekarang`;
  }
  return null;
}

export const preorderService = {
  list(): PreOrder[] {
    return storage.get<PreOrder[]>(StorageKeys.preorders) ?? [];
  },
  save(rows: PreOrder[]) {
    storage.set(StorageKeys.preorders, rows);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new Event("desalut:preorders-changed"));
    }
  },
  byId(id: string): PreOrder | undefined {
    return preorderService.list().find((p) => p.id === id);
  },
  create(input: {
    customerName: string;
    customerPhone?: string;
    date: string;
    time: string;
    items: SaleItem[];
    notes?: string;
    sourceOrder: SourceOrder;
    priceGroupId?: string;
    saleType?: SaleType;
    createdBy: string;
    outletId?: string;
    downPayment?: number;
    dpMethod?: PaymentMethod;
  }): PreOrder {
    // Fail-safe: validasi pickup di service layer supaya tidak bisa diakali
    // via DevTools bila UI validasi di-bypass.
    const err = validatePickup(input.date, input.time);
    if (err) throw new Error(err);
    const t = nowIso();
    const total = totalOf(input.items);
    const dp = Math.max(0, Math.min(input.downPayment ?? 0, total));
    const rec: PreOrder = {
      id: uid(),
      status: "scheduled",
      total,
      createdAt: t,
      updatedAt: t,
      ...input,
      downPayment: dp,
      remainingBalance: total - dp,
      dpPaidAt: dp > 0 ? t : undefined,
      dpMethod: dp > 0 ? input.dpMethod : undefined,
    };
    const list = preorderService.list();
    list.unshift(rec);
    preorderService.save(list);
    if (dp > 0) {
      try {
        auditService.log({
          actor: input.createdBy,
          action: "preorder_dp_paid",
          entity: "preorder",
          entityId: rec.id,
          metadata: {
            total,
            downPayment: dp,
            remainingBalance: total - dp,
            method: input.dpMethod,
          },
        });
      } catch (err) {
        console.error("[preorder] audit dp failed", err);
      }
    }
    return rec;
  },
  update(id: string, patch: Partial<PreOrder>): PreOrder | null {
    const list = preorderService.list();
    const i = list.findIndex((p) => p.id === id);
    if (i < 0) return null;
    const merged: PreOrder = {
      ...list[i],
      ...patch,
      updatedAt: nowIso(),
    };
    if (patch.items) merged.total = totalOf(patch.items);
    // Sinkronkan remainingBalance saat total atau DP berubah.
    const dp = Math.max(0, Math.min(merged.downPayment ?? 0, merged.total));
    merged.downPayment = dp;
    merged.remainingBalance = merged.total - dp;
    list[i] = merged;
    preorderService.save(list);
    return merged;
  },
  /**
   * Sprint 1 (C-3): catat pembayaran DP terpisah (mis. customer bayar DP
   * setelah PO dibuat). Audit `preorder_dp_paid`.
   */
  payDp(
    id: string,
    amount: number,
    ctx: { actor: string; method?: PaymentMethod },
  ): PreOrder | null {
    const cur = preorderService.byId(id);
    if (!cur) return null;
    const dp = Math.max(0, Math.min((cur.downPayment ?? 0) + amount, cur.total));
    const next = preorderService.update(id, {
      downPayment: dp,
      dpPaidAt: nowIso(),
      dpMethod: ctx.method ?? cur.dpMethod,
    });
    try {
      auditService.log({
        actor: ctx.actor,
        action: "preorder_dp_paid",
        entity: "preorder",
        entityId: id,
        metadata: {
          added: amount,
          total: cur.total,
          downPayment: dp,
          remainingBalance: cur.total - dp,
          method: ctx.method ?? cur.dpMethod,
        },
      });
    } catch (err) {
      console.error("[preorder] audit payDp failed", err);
    }
    return next;
  },
  setStatus(id: string, status: PreOrderStatus): PreOrder | null {
    return preorderService.update(id, { status });
  },
  remove(id: string) {
    preorderService.save(preorderService.list().filter((p) => p.id !== id));
  },
  byDate(date: string): PreOrder[] {
    return preorderService.list().filter((p) => p.date === date);
  },
  /**
   * Promote PO scheduled yang sudah jatuh tempo (date+time <= now) menjadi
   * ready_to_process dan buat entri Queue. Tidak membuat Sale.
   */
  promoteDue(now = new Date()): { promoted: PreOrder[] } {
    const promoted: PreOrder[] = [];
    const list = preorderService.list();
    let changed = false;
    for (let i = 0; i < list.length; i++) {
      const po = list[i];
      if (po.status !== "scheduled") continue;
      const dt = new Date(`${po.date}T${po.time || "00:00"}:00`);
      if (Number.isNaN(dt.getTime())) continue;
      if (dt.getTime() > now.getTime()) continue;
      // Buat queue entry — sekali saja.
      let queueId = po.queueId;
      if (!queueId) {
        try {
          const q = queueService.create({
            saleId: po.id, // pakai id PO sebagai "saleId" placeholder hingga PO di-Complete
            saleCode: po.id,
            saleType: po.saleType ?? "frozen",
            customerName: po.customerName,
            customerPhone: po.customerPhone,
            pickupAt: dt.toISOString(),
            isPreorder: true,
            itemCount: po.items.reduce((a, c) => a + c.qty, 0),
            itemsSummary: po.items.map((i) => `${i.qty}× ${i.name}`).join(", "),
            sourceOrder: po.sourceOrder,
          });
          queueId = q.id;
        } catch (err) {
          console.error("[preorder] promote → queue.create failed", err);
        }
      }
      const updated: PreOrder = {
        ...po,
        status: "ready_to_process",
        queueId,
        updatedAt: nowIso(),
      };
      list[i] = updated;
      promoted.push(updated);
      changed = true;
    }
    if (changed) preorderService.save(list);
    return { promoted };
  },
  countByDate(date: string): number {
    return preorderService
      .list()
      .filter((p) => p.date === date && p.status !== "cancelled" && p.status !== "completed")
      .length;
  },
  /** Semua PO yang masih aktif (scheduled / ready_to_process). */
  countActive(): number {
    return preorderService
      .list()
      .filter((p) => p.status !== "cancelled" && p.status !== "completed")
      .length;
  },
  productionNeedFor(dates: string[]): { productId: string; name: string; qty: number }[] {
    const map = new Map<string, { productId: string; name: string; qty: number }>();
    for (const p of preorderService.list()) {
      if (!dates.includes(p.date)) continue;
      if (p.status === "cancelled" || p.status === "completed") continue;
      for (const it of p.items) {
        const cur = map.get(it.productId);
        if (cur) cur.qty += it.qty;
        else map.set(it.productId, { productId: it.productId, name: it.name, qty: it.qty });
      }
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty);
  },
};
