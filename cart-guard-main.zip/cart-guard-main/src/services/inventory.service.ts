import { storage, StorageKeys } from "./storage";
import type { InventoryCategory, InventoryItem } from "./types";

function uid() {
  return `inv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
}

function computeCostPerUnit(price: number, qty: number): number {
  if (!Number.isFinite(price) || !Number.isFinite(qty) || qty <= 0) return 0;
  return Math.round((price / qty) * 100) / 100;
}

export type NewInventoryItem = Omit<
  InventoryItem,
  "id" | "createdAt" | "updatedAt" | "costPerUnit"
>;

export const inventoryService = {
  list(): InventoryItem[] {
    const raw = storage.get<InventoryItem[]>(StorageKeys.inventoryItems);
    if (!Array.isArray(raw)) return [];
    // Defensive: only keep entries that minimally look like InventoryItem.
    return raw.filter(
      (x) => x && typeof x === "object" && typeof (x as InventoryItem).id === "string",
    );
  },
  save(items: InventoryItem[]) {
    storage.set(StorageKeys.inventoryItems, items);
  },
  get(id: string): InventoryItem | undefined {
    return inventoryService.list().find((i) => i.id === id);
  },
  findByName(name: string): InventoryItem | undefined {
    const n = name.trim().toLowerCase();
    if (!n) return undefined;
    return inventoryService.list().find((i) => i.name.trim().toLowerCase() === n);
  },
  /**
   * Pastikan ada InventoryItem untuk output produksi.
   * Jika belum ada, otomatis buat dengan kategori `production_item`.
   * Jika sudah ada, kembalikan item tersebut (tanpa mengubah kategori/unit).
   */
  ensureProductionItem(name: string, unit: string): InventoryItem {
    const existing = inventoryService.findByName(name);
    if (existing) return existing;
    const now = new Date().toISOString();
    const item: InventoryItem = {
      id: uid(),
      name: name.trim(),
      category: "production_item",
      unit: unit.trim() || "pcs",
      stock: 0,
      minStock: 0,
      purchasePrice: 0,
      purchaseQuantity: 0,
      costPerUnit: 0,
      active: true,
      createdAt: now,
      updatedAt: now,
    };
    const list = inventoryService.list();
    list.unshift(item);
    inventoryService.save(list);
    return item;
  },
  byCategory(cat: InventoryCategory): InventoryItem[] {
    return inventoryService.list().filter((i) => i.category === cat);
  },
  /** Case-insensitive duplicate-name check. Excludes `ignoreId` (for edits). */
  isDuplicateName(name: string, ignoreId?: string): boolean {
    const n = name.trim().toLowerCase();
    if (!n) return false;
    return inventoryService.list().some(
      (i) => i.id !== ignoreId && i.name.trim().toLowerCase() === n,
    );
  },
  create(input: NewInventoryItem): InventoryItem {
    if (inventoryService.isDuplicateName(input.name)) {
      throw new Error("Nama item sudah digunakan");
    }
    const now = new Date().toISOString();
    const item: InventoryItem = {
      ...input,
      id: uid(),
      createdAt: now,
      updatedAt: now,
      costPerUnit: computeCostPerUnit(input.purchasePrice, input.purchaseQuantity),
    };
    const list = inventoryService.list();
    list.unshift(item);
    inventoryService.save(list);
    return item;
  },
  update(id: string, patch: Partial<NewInventoryItem>): InventoryItem | undefined {
    const list = inventoryService.list();
    const i = list.findIndex((x) => x.id === id);
    if (i < 0) return undefined;
    if (patch.name && inventoryService.isDuplicateName(patch.name, id)) {
      throw new Error("Nama item sudah digunakan");
    }
    const next: InventoryItem = {
      ...list[i],
      ...patch,
      updatedAt: new Date().toISOString(),
    };
    next.costPerUnit = computeCostPerUnit(next.purchasePrice, next.purchaseQuantity);
    list[i] = next;
    inventoryService.save(list);
    return next;
  },
  /** Internal: apply a signed stock delta. Used by stockMovementService. */
  adjustStock(id: string, delta: number): InventoryItem | undefined {
    const list = inventoryService.list();
    const i = list.findIndex((x) => x.id === id);
    if (i < 0) return undefined;
    const next = {
      ...list[i],
      stock: Math.max(0, list[i].stock + delta),
      updatedAt: new Date().toISOString(),
    };
    list[i] = next;
    inventoryService.save(list);
    return next;
  },
  setActive(id: string, active: boolean) {
    inventoryService.update(id, { active } as Partial<NewInventoryItem>);
  },
  remove(id: string) {
    inventoryService.save(inventoryService.list().filter((i) => i.id !== id));
  },
  stats() {
    const items = inventoryService.list();
    const total = items.length;
    const active = items.filter((i) => i.active).length;
    const low = items.filter((i) => i.active && i.minStock > 0 && i.stock > 0 && i.stock <= i.minStock).length;
    const out = items.filter((i) => i.active && i.stock <= 0).length;
    const byCategory: Record<InventoryCategory, number> = { raw: 0, packaging: 0, operational: 0, production_item: 0 };
    for (const i of items) byCategory[i.category]++;
    return { total, active, low, out, byCategory };
  },
};